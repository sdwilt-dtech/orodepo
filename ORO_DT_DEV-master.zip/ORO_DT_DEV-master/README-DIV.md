DiversiTech OroCommerce Application Installation Notes
------------------------------------------------------

### PostgreSQL Configuration

You need to load `uuid-ossp` extension for proper doctrine's `guid` type handling.
Log into the database and run sql query:

```sql
CREATE EXTENSION "uuid-ossp";
```

### Opcache

Recommended configuration

```
;256Mb for php7
opcache.memory_consumption=256
opcache.max_accelerated_files=32531
opcache.interned_strings_buffer=32
```

See [Symfony Performance](https://symfony.com/doc/4.4/performance.html)

### Web Server Configuration

The OroCommerce sample application is based on the Symfony standard application, so the web server configuration recommendations are the [same](https://symfony.com/doc/4.4/setup/web_server_configuration.html).

### Using Redis for application caching

To use Redis for application caching, follow the corresponding [configuration instructions](https://github.com/oroinc/redis-config#configuration)

### Integration Configuration

To turn on location functionality, set Google Api Key on System -> Configuration -> System Configuration -> Google Settings -> Google Integration Settings.

Git Branching Model
-------------------

Repository uses [Git flow](http://nvie.com/posts/a-successful-git-branching-model) branching model.

Upgrading Composer Vendors
--------------------------

1. Upgrade version in composer.json if needed.
2. Check patches in directory `patches` and file `patches.json` to find items that will be covered with latest Oro Commerce version. 
3. If the overridden code was changed in the new Oro Commerce version, the patch should be adjusted or removed if it is not required anymore.
4. Run `composer update`. Patches from `patches.json` will be applied automatically.

Running behat tests
-------------------

TBD

Running PHP CS Fixer
---------------------

Example of usage:
```shell script
# Find all cases to fix
php vendor/friendsofphp/php-cs-fixer/php-cs-fixer fix --dry-run

# Apply fixes
php vendor/friendsofphp/php-cs-fixer/php-cs-fixer fix
```

See [FriendsOfPHP/PHP-CS-Fixer](https://github.com/FriendsOfPHP/PHP-CS-Fixer) repository for details.
