<?php

namespace DT\Bundle\ContactBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DTContactBundle extends Bundle
{
}
