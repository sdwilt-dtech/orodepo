<?php

namespace DT\Bundle\ContactBundle\Controller;

use DT\Bundle\ContactBundle\Model\ContactFieldsets;
use Oro\Bundle\ContactBundle\Entity\Contact;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Additional contact info widget action to provide separation by different field sets
 */
class ContactController extends AbstractController
{
    /**
     * @Route(
     *     "/info/{id}/{fieldset}",
     *     name="oro_contact_info_by_fieldset",
     *     requirements={"id"="\d+", "fieldset"="[\w_-]+"}
     * )
     *
     * @AclAncestor("oro_contact_view")
     *
     * @param Request $request
     * @param Contact $contact
     * @param string  $fieldset
     *
     * @return array|RedirectResponse
     */
    public function infoAction(Request $request, Contact $contact, string $fieldset)
    {
        $fieldsetWidgetTemplate = ContactFieldsets::$fieldsetWidgetTemplateMap[$fieldset] ?? null;

        if (!$request->get('_wid') && $fieldsetWidgetTemplate ===null) {
            return $this->redirect($this->get('router')->generate('oro_contact_view', ['id' => $contact->getId()]));
        }

        return $this->render(
            sprintf('@DTContact/Contact/widget/info/%s.html.twig', $fieldsetWidgetTemplate),
            ['entity' => $contact]
        );
    }
}
