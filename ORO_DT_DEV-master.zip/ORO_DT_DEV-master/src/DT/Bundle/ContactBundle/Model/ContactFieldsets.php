<?php

namespace DT\Bundle\ContactBundle\Model;

/**
 * Storage with field sets to separate contact information(view/edit pages)
 */
final class ContactFieldsets
{
    public const CONTACT_DETAIL_FIELDSET        = 'contact-details';
    public const PERSONAL_INFORMATION_FIELDSET  = 'personal-information';
    public const ROLES_RESPONSIBILITY_FIELDSET  = 'roles-responsibility';
    public const COMMUNICATION_FLAGS_FIELDSET   = 'communication-flags';
    public const MARKETING_INFORMATION_FIELDSET = 'marketing-information';

    /** @var array */
    public static $fieldsetWidgetTemplateMap = [
        self::CONTACT_DETAIL_FIELDSET        => 'contact_details',
        self::PERSONAL_INFORMATION_FIELDSET  => 'personal_information',
        self::ROLES_RESPONSIBILITY_FIELDSET  => 'roles_responsibility',
        self::COMMUNICATION_FLAGS_FIELDSET   => 'communication_flags',
        self::MARKETING_INFORMATION_FIELDSET => 'marketing_information',
    ];
}
