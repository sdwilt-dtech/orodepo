<?php

namespace DT\Bundle\ContactBundle\EventListener\Datagrid;

use DT\Bundle\SetupBundle\Model\ContactFields;
use Oro\Bundle\DataGridBundle\Datagrid\Common\DatagridConfiguration;

/**
 * Trait to handle common contact grid joins.s
 */
trait ContactGridJoinDataTrait
{
    /**
     * @param DatagridConfiguration $config
     */
    protected function addCustomerColumn(DatagridConfiguration $config): void
    {
        $query = $config->getOrmQuery();

        $query->addLeftJoin($query->getRootAlias() . '.' . ContactFields::DT_CUSTOMER, 'cc');

        $config->addColumn(
            'customerDtJdeId',
            ['label' => 'Customer JDE Id'],
            'cc.dt_jde_id as customerDtJdeId',
            ['data_name' => 'customerDtJdeId'],
            ['type' => 'string', 'data_name' => 'customerDtJdeId']
        );

        $config->addColumn(
            'customerName',
            ['label' => 'dt.contact.grid.contacts.customer_name.label'],
            'cc.name as customerName',
            ['data_name' => 'customerName'],
            ['type' => 'string', 'data_name' => 'customerName']
        );
    }

    /**
     * @param DatagridConfiguration $config
     */
    protected function addJobTitleColumn(DatagridConfiguration $config): void
    {
        $query = $config->getOrmQuery();

        $config->addColumn(
            'jobTitle',
            ['label' => 'oro.contact.job_title.label'],
            $query->getRootAlias() . '.jobTitle as jobTitle',
            ['data_name' => 'jobTitle'],
            ['type' => 'string', 'data_name' => 'jobTitle']
        );
    }

    /**
     * Adds customer owner name to grid.
     *
     * @param DatagridConfiguration $config
     */
    private function addOwnerColumn(DatagridConfiguration $config): void
    {
        $query = $config->getOrmQuery();

        $query->addLeftJoin($query->getRootAlias() . '.owner', 'o');
        $config->addColumn(
            'ownerName',
            ['label' => 'dt.contact.grid.contacts.owner_name.label'],
            "CONCAT(o.firstName, ' ' , o.lastName) as ownerName",
            [],
            ['type' => 'string', 'data_name' => 'ownerName']
        );
    }
}
