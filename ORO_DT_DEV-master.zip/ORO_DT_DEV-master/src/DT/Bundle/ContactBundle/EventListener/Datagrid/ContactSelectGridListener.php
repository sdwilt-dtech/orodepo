<?php

namespace DT\Bundle\ContactBundle\EventListener\Datagrid;

use Oro\Bundle\DataGridBundle\Event\BuildAfter;
use Oro\Bundle\DataGridBundle\Event\BuildBefore;
use Oro\Component\DataGrid\GridModifierHelperTrait;

/**
 * Contact select grid event listener to customize initial columns similar to salesforce.
 */
class ContactSelectGridListener
{
    use GridModifierHelperTrait;
    use ContactGridJoinDataTrait;

    /**
     * @param BuildBefore $event
     */
    public function onBuildBefore(BuildBefore $event): void
    {
        $config = $event->getDatagrid()->getConfig();

        $this->addCustomerColumn($config);
        $this->addJobTitleColumn($config);
        $this->addOwnerColumn($config);
    }

    /**
     * @param BuildAfter $event
     */
    public function onBuildAfter(BuildAfter $event): void
    {
        $config = $event->getDatagrid()->getConfig();

        $this->setColumnVisibility($this->getColumnsToHide(), $config, false);
        $this->setFiltersVisibility($this->getFiltersToHide(), $config, false);
        $this->sortColumns($this->getColumnsOrder(), $config);
        $this->sortFilters($this->getFiltersOrder(), $config);
    }

    /**
     * @return array
     */
    private function getColumnsToHide(): array
    {
        return array_merge($this->getColumnsSameAsFiltersToHide(), ['tags']);
    }

    /**
     * @return array
     */
    private function getFiltersToHide(): array
    {
        return array_merge($this->getColumnsSameAsFiltersToHide(), ['tagname']);
    }

    /**
     * @return string[]
     */
    private function getColumnsSameAsFiltersToHide(): array
    {
        return [
            'contactSourceLabel',
            'countryName',
            'regionLabel',
            'addressPostalCode'
        ];
    }

    /**
     * @return array
     */
    private function getColumnsOrder(): array
    {
        return [
            'firstName',
            'lastName',
            'customerDtJdeId',
            'customerName',
            'jobTitle',
            'primaryPhone',
            'primaryEmail',
            'ownerName'
        ];
    }

    /**
     * @return array
     */
    private function getFiltersOrder(): array
    {
        return $this->getColumnsOrder();
    }
}
