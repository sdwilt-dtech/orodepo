<?php

namespace DT\Bundle\ContactBundle\EventListener\Datagrid;

use Oro\Bundle\DataGridBundle\Event\BuildAfter;
use Oro\Bundle\DataGridBundle\Event\BuildBefore;
use Oro\Component\DataGrid\GridModifierHelperTrait;

/**
 * Contact grid event listener to customize initial columns similar to salesforce.
 */
class ContactGridListener
{
    use GridModifierHelperTrait;
    use ContactGridJoinDataTrait;

    /**
     * @param BuildBefore $event
     */
    public function onBuildBefore(BuildBefore $event): void
    {
        $config = $event->getDatagrid()->getConfig();

        $this->addCustomerColumn($config);
        $this->addJobTitleColumn($config);
    }

    /**
     * @param BuildAfter $event
     */
    public function onBuildAfter(BuildAfter $event): void
    {
        $config = $event->getDatagrid()->getConfig();

        $this->setColumnVisibility($this->getColumnsToHide(), $config, false);
        $this->setFiltersVisibility($this->getFiltersToHide(), $config, false);
        $this->setColumnVisibility($this->getColumnsToShow(), $config, true);
        $this->setFiltersVisibility($this->getFiltersToShow(), $config, true);
        $this->sortColumns($this->getColumnsOrder(), $config);
        $this->sortFilters($this->getFiltersOrder(), $config);
    }

    /**
     * @return array
     */
    private function getColumnsToHide(): array
    {
        return array_merge($this->getColumnsSameAsFiltersToHide(), ['tags']);
    }

    /**
     * @return array
     */
    private function getFiltersToHide(): array
    {
        return array_merge(
            $this->getColumnsSameAsFiltersToHide(),
            ['tagname', 'businessUnitId']
        );
    }

    /**
     * @return array
     */
    private function getColumnsSameAsFiltersToHide(): array
    {
        return [
            'source',
            'countryName',
            'regionLabel',
            'addressPostalCode',
            'createdAt',
            'updatedAt'
        ];
    }

    /**
     * @return array
     */
    private function getColumnsToShow(): array
    {
        return ['ownerName'];
    }

    /**
     * @return array
     */
    private function getFiltersToShow(): array
    {
        return ['owner'];
    }

    /**
     * @return array
     */
    private function getColumnsOrder(): array
    {
        return [
            'firstName',
            'lastName',
            'customerDtJdeId',
            'customerName',
            'jobTitle',
            'phone',
            'email',
            'ownerName'
        ];
    }

    /**
     * @return array
     */
    private function getFiltersOrder(): array
    {
        return [
            'firstName',
            'lastName',
            'customerDtJdeId',
            'customerName',
            'jobTitle',
            'phone',
            'email',
            'owner'
        ];
    }
}
