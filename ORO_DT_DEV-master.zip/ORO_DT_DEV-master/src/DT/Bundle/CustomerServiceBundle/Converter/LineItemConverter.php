<?php

namespace DT\Bundle\CustomerServiceBundle\Converter;

use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\EntityBundle\Entity\OrderErrorCaseLineItem;
use Oro\Bundle\OrderBundle\Entity\OrderLineItem;

/**
 * The aim of this class:
 * - Converts orderLineItem to orderErrorCaseLineItem
 */
class LineItemConverter
{
    /**
     * @param OrderLineItem $orderLineItem
     * @param OrderErrorCase $orderErrorCase
     * @param bool $setZeroToQuantityCredited
     * @return OrderErrorCaseLineItem
     */
    public function convert(
        OrderLineItem $orderLineItem,
        OrderErrorCase $orderErrorCase,
        bool $setZeroToQuantityCredited
    ): OrderErrorCaseLineItem {
        $orderErrorCaseLineItem = new OrderErrorCaseLineItem();
        $orderErrorCaseLineItem->setOrganization($orderErrorCase->getOrganization());
        $orderErrorCaseLineItem->setOwner($orderErrorCase->getOwner());
        $orderErrorCaseLineItem->setOrderLineItem($orderLineItem);
        $orderErrorCaseLineItem->setOrderErrorCase($orderErrorCase);
        $orderErrorCaseLineItem->setAdjustedUnitPrice($orderLineItem->getValue());

        $orderErrorCaseLineItem->setQuantityCredited(
            $setZeroToQuantityCredited ? 0: $orderLineItem->getQuantity()
        );

        return $orderErrorCaseLineItem;
    }
}
