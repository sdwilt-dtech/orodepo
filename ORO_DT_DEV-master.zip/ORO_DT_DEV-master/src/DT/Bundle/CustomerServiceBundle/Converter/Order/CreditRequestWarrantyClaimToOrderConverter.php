<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerServiceBundle\Converter\Order;

use DT\Bundle\EntityBundle\Entity\CreditRequestWarrantyClaim;
use DT\Bundle\EntityBundle\Entity\GlCode;
use DT\Bundle\EntityBundle\Entity\ReasonCode;
use DT\Bundle\EntityBundle\Entity\WarrantyProductClaimItem;
use DT\Bundle\JdeFileIntegrationBundle\Feature\Order\Import\Translator\OrderDataMapper;
use DT\Bundle\OrderBundle\Converter\EntityToOrderConverterInterface;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Bundle\OrderBundle\Entity\OrderLineItem;
use Oro\Bundle\WebsiteBundle\Entity\Website;

class CreditRequestWarrantyClaimToOrderConverter implements EntityToOrderConverterInterface
{
    private const DEFAULT_COMPANY = '00001';

    private DoctrineHelper $doctrineHelper;

    /**
     * @param DoctrineHelper $doctrineHelper
     */
    public function __construct(DoctrineHelper $doctrineHelper)
    {
        $this->doctrineHelper = $doctrineHelper;
    }

    /**
     * @param $entity
     *
     * @return bool
     */
    public function supports($entity): bool
    {
        return $entity instanceof CreditRequestWarrantyClaim;
    }

    /**
     * @param CreditRequestWarrantyClaim $entity
     *
     * @throws \Exception
     */
    public function convert($entity): Order
    {
        $warrantyClaim = $entity->getWarrantyClaim();
        if (!$warrantyClaim) {
            throw new \RuntimeException('Warranty Claim should not be blank');
        }

        $customer = $warrantyClaim->getCustomer();
        if (!$customer) {
            throw new \RuntimeException('Customer should not be blank.');
        }

        $inCode = $entity->getInCode();
        if (!$inCode) {
            throw new \RuntimeException('InCode should not be blank');
        }

        $billingType = $customer->getDtBillingType()
            ? $customer->getDtBillingType()->getId()
            : null;
        if (!$billingType) {
            throw new \RuntimeException('Customer for Warranty Claim must have billing type.');
        }

        $em = $this->doctrineHelper->getEntityManagerForClass(Order::class);

        $order = new Order();
        $order->setOwner($entity->getOwner());
        $shipTo = \in_array(
            $billingType,
            [EnumValues::DT_CUSTOMER_BILLING_TYPE_S, EnumValues::DT_CUSTOMER_BILLING_TYPE_X],
            true
        ) ? $customer :  $customer->getChildren()->first();
        $billTo = $billingType === EnumValues::DT_CUSTOMER_BILLING_TYPE_S ? $customer->getParent() : $customer;
        $order->setCustomer($shipTo);
        $order->setDtBillTo($billTo);
        $order->setOrganization($entity->getOrganization());
        $order->setDtDateRequested(new \DateTime('now', new \DateTimeZone('UTC')));
        $order->setPoNumber($warrantyClaim->getCustomerReference());
        $order->setDtOrderCompany(self::DEFAULT_COMPANY);

        $website = $this->doctrineHelper
            ->getEntityRepository(Website::class)
            ->getDefaultWebsite();
        $order->setWebsite($website);
        $order->setCurrency(OrderDataMapper::DEFAULT_CURRENCY);

        /** @var AbstractEnumValue $status */
        $orderType = $this->doctrineHelper
            ->getEntityRepository(ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_ORDER_TYPE))
            ->find($entity->getInCode()->getJdeDocType());
        $order->setDtOrderType($orderType);

        $order->setDtCostCenter(
            $this->getEnumReference(ReservedEnumCodes::DT_COST_CENTER, EnumValues::DT_COST_CENTER_BUFORD)
        );

        $em->persist($order);
        $this->convertLineItems($order, $entity);
        $em->flush();

        return $order;
    }

    /**
     * @throws \Exception
     */
    private function convertLineItems(Order $order, CreditRequestWarrantyClaim $creditRequest): void
    {
        $em = $this->doctrineHelper->getEntityManagerForClass(OrderLineItem::class);
        $warrantyClaim = $creditRequest->getWarrantyClaim();
        $inCode = $creditRequest->getInCode();
        $reason = $this->doctrineHelper
            ->getEntityRepository(ReasonCode::class)
            ->findOneBy(['name' => $inCode->getJdeReasonCode()]);

        $glCode = $this->doctrineHelper
            ->getEntityRepository(GlCode::class)
            ->findOneBy(['name' => $inCode->getGlClassCode()]);

        /** @var AbstractEnumValue $status */
        $lineType = $this->doctrineHelper
            ->getEntityRepository(ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_LINE_TYPE))
            ->find($inCode->getJdeLineType());

        $claimItems = $warrantyClaim->getClaimItems()->toArray();
        /** @var WarrantyProductClaimItem $item */
        foreach ($claimItems as $key => $item) {
            $lineItem = new OrderLineItem();
            $order->addLineItem($lineItem);
            $lineItem->setDtLineNumber($key + 1); //$key starts from 0
            $lineItem->setProductSku($item->getProduct()->getSku());
            //these fields will be added in migrations in scope of other story
            if ($item->getProductUnit()) {
                $lineItem->setProductUnit($item->getProductUnit());
                $lineItem->setProductUnitCode($item->getProductUnitCode());
            }
            $lineItem->setQuantity($item->getQuantity());
            $lineItem->setValue($item->getUnitReplacementValue());
            $lineItem->setCurrency(OrderDataMapper::DEFAULT_CURRENCY);
            $lineItem->setDtReasonCode($reason);
            $lineItem->setDtGlCode($glCode);
            $lineItem->setDtLineType($lineType);
            $lineItem->setDtPriceOverridden(true);
            $em->persist($lineItem);
        }
    }

    /**
     * @param string $enumCode
     * @param string $enumId
     * @return AbstractEnumValue
     * @throws \Doctrine\ORM\ORMException
     */
    protected function getEnumReference(string $enumCode, string $enumId): AbstractEnumValue
    {
        $className = ExtendHelper::buildEnumValueClassName($enumCode);

        return $this->doctrineHelper
            ->getEntityManagerForClass($className)
            ->getReference($className, $enumId);
    }
}
