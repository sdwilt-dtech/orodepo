<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerServiceBundle\Converter\Order;

use DT\Bundle\EntityBundle\Entity\CreditRequestOrderError;
use DT\Bundle\EntityBundle\Entity\GlCode;
use DT\Bundle\EntityBundle\Entity\OrderErrorCaseLineItem;
use DT\Bundle\EntityBundle\Entity\ReasonCode;
use DT\Bundle\JdeFileIntegrationBundle\Feature\Order\Import\Translator\OrderDataMapper;
use DT\Bundle\OrderBundle\Converter\EntityToOrderConverterInterface;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Bundle\OrderBundle\Entity\OrderLineItem;
use Oro\Bundle\ProductBundle\Entity\ProductUnit;

class CreditRequestOrderErrorToOrderConverter implements EntityToOrderConverterInterface
{
    public const DEFAULT_PRODUCT_UNIT = 'EA';

    private const DEFAULT_COMPANY = '00001';

    private $specialGlCodes = [
        'DT01' => 'FINES',
        'DT02' => 'DISCOUNTS',
        'FT10' => 'FRTDSCT',
    ];

    private DoctrineHelper $doctrineHelper;

    /**
     * @param DoctrineHelper $doctrineHelper
     */
    public function __construct(DoctrineHelper $doctrineHelper)
    {
        $this->doctrineHelper = $doctrineHelper;
    }

    /**
     * @param $entity
     * @return bool
     */
    public function supports($entity): bool
    {
        return $entity instanceof CreditRequestOrderError;
    }

    /**
     * @param CreditRequestOrderError $entity
     *
     * @throws \Exception
     */
    public function convert($entity): Order
    {
        $orderErrorCase = $entity->getOrderErrorCase();
        if (!$orderErrorCase) {
            throw new \RuntimeException('Order Error Case should not be blank');
        }
        $linkedOrder = $orderErrorCase->getOrder();
        if (!$linkedOrder) {
            throw new \RuntimeException('Linked Order should not be blank');
        }
        $inCode = $entity->getInCode();
        if (!$inCode) {
            throw new \RuntimeException('InCode should not be blank');
        }

        $em = $this->doctrineHelper->getEntityManagerForClass(Order::class);
        $inCode = $entity->getInCode();

        $order = new Order();
        $order->setOwner($entity->getOwner());
        $order->setOrganization($entity->getOrganization());
        $order->setWebsite($linkedOrder->getWebsite());
        $order->setDtDateRequested(new \DateTime('now', new \DateTimeZone('UTC')));
        $order->setCurrency($linkedOrder->getCurrency());
        /** @var AbstractEnumValue $status */
        $orderType = $this->doctrineHelper
            ->getEntityRepository(ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_ORDER_TYPE))
            ->find($inCode->getJdeDocType());
        $order->setDtOrderType($orderType);
        /** @var AbstractEnumValue $status */
        $branch = $this->doctrineHelper
            ->getEntityRepository(ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_COST_CENTER))
            ->find($orderErrorCase->getWarehouse()->getId());
        $order->setDtCostCenter($branch);
        $order->setCustomer($linkedOrder->getCustomer());
        $order->setDtBillTo($linkedOrder->getDtBillTo());
        $order->setDtOriginalSoNumber($linkedOrder->getDtOriginalSoNumber());
        $order->setDtOriginalSoType($linkedOrder->getDtOriginalSoType());
        $order->setDtOriginalSoCompany($linkedOrder->getDtOriginalSoCompany());
        $order->setPoNumber($linkedOrder->getPoNumber());
        $order->setDtOrderCompany(self::DEFAULT_COMPANY);

        $em->persist($order);

        if ($inCode->getGlClassCode() && \array_key_exists($inCode->getGlClassCode(), $this->specialGlCodes)) {
            $order->setDtCostCenter(
                $this->getEnumReference(ReservedEnumCodes::DT_COST_CENTER, EnumValues::DT_COST_CENTER_BUFORD)
            );
            $this->convertCustomLineItem($order, $entity);
        } else {
            $this->convertLineItems($order, $entity);
        }
        $em->flush();

        return $order;
    }

    /**
     * @param Order $order
     * @param CreditRequestOrderError $creditRequest
     * @throws \Doctrine\ORM\ORMException
     */
    private function convertLineItems(Order $order, CreditRequestOrderError $creditRequest): void
    {
        $em = $this->doctrineHelper->getEntityManagerForClass(OrderLineItem::class);

        $orderErrorCase = $creditRequest->getOrderErrorCase();
        $inCode = $creditRequest->getInCode();
        $reason = $this->doctrineHelper
            ->getEntityRepository(ReasonCode::class)
            ->findOneBy(['name' => $inCode->getJdeReasonCode()]);

        $glCode = $this->doctrineHelper
            ->getEntityRepository(GlCode::class)
            ->findOneBy(['name' => $inCode->getGlClassCode()]);

        /** @var AbstractEnumValue $status */
        $lineType = $this->doctrineHelper
            ->getEntityRepository(ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_LINE_TYPE))
            ->find($inCode->getJdeLineType());

        /** @var OrderErrorCaseLineItem $item */
        foreach ($orderErrorCase->getLineItems() as $item) {
            $originalLineItem = $item->getOrderLineItem();
            $lineItem = new OrderLineItem();
            $order->addLineItem($lineItem);
            $lineItem->setDtLineNumber($originalLineItem->getDtLineNumber());
            $lineItem->setProductSku($originalLineItem->getProductSku());
            $lineItem->setFreeFormProduct($originalLineItem->getFreeFormProduct());
            $lineItem->setProductUnit($originalLineItem->getProductUnit());
            $lineItem->setProductUnitCode($originalLineItem->getProductUnitCode());
            $lineItem->setCurrency($order->getCurrency());
            $lineItem->setQuantity($item->getQuantityCredited());
            $lineItem->setValue($item->getAdjustedUnitPrice());
            $lineItem->setDtReasonCode($reason);
            $lineItem->setDtGlCode($glCode);
            $lineItem->setDtLineType($lineType);
            $lineItem->setDtPriceOverridden(true);

            $em->persist($lineItem);
        }
    }

    /**
     * @param Order $order
     * @param CreditRequestOrderError $creditRequest
     * @throws \Doctrine\ORM\ORMException
     */
    private function convertCustomLineItem(Order $order, CreditRequestOrderError $creditRequest): void
    {
        $em = $this->doctrineHelper->getEntityManagerForClass(OrderLineItem::class);

        $inCode = $creditRequest->getInCode();
        $reason = $this->doctrineHelper
            ->getEntityRepository(ReasonCode::class)
            ->findOneBy(['name' => $inCode->getJdeReasonCode()]);

        $glCode = $this->doctrineHelper
            ->getEntityRepository(GlCode::class)
            ->findOneBy(['name' => $inCode->getGlClassCode()]);

        /** @var AbstractEnumValue $status */
        $lineType = $this->doctrineHelper
            ->getEntityRepository(ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_LINE_TYPE))
            ->find($inCode->getJdeLineType());

        $lineItem = new OrderLineItem();
        $order->addLineItem($lineItem);
        $lineItem->setDtLineNumber(1);
        $lineItem->setProductSku($this->specialGlCodes[$inCode->getGlClassCode()]);
        $lineItem->setFreeFormProduct($this->specialGlCodes[$inCode->getGlClassCode()]);
        /** @var ProductUnit $productUnit */
        $productUnit = $this->doctrineHelper
            ->getEntityRepository(ProductUnit::class)
            ->findOneBy(['code' => self::DEFAULT_PRODUCT_UNIT]);
        $lineItem->setProductUnit($productUnit);
        $lineItem->setProductUnitCode($productUnit->getCode());
        $lineItem->setQuantity(1);
        $lineItem->setValue($creditRequest->getAmountApproved());
        $lineItem->setCurrency(OrderDataMapper::DEFAULT_CURRENCY);
        $lineItem->setDtReasonCode($reason);
        $lineItem->setDtGlCode($glCode);
        $lineItem->setDtLineType($lineType);
        $lineItem->setDtPriceOverridden(true);

        $em->persist($lineItem);
    }

    /**
     * @param string $enumCode
     * @param string $enumId
     * @return AbstractEnumValue
     * @throws \Doctrine\ORM\ORMException
     */
    protected function getEnumReference(string $enumCode, string $enumId): AbstractEnumValue
    {
        $className = ExtendHelper::buildEnumValueClassName($enumCode);

        return $this->doctrineHelper
            ->getEntityManagerForClass($className)
            ->getReference($className, $enumId);
    }
}
