<?php

namespace DT\Bundle\CustomerServiceBundle\DependencyInjection;

use Oro\Bundle\ConfigBundle\Config\ConfigManager;
use Oro\Bundle\ConfigBundle\DependencyInjection\SettingsBuilder;
use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

class Configuration implements ConfigurationInterface
{
    public const DT_APPROVAL_NOTIFICATION_RECIPIENTS = 'dt_approval_notification_recipients';
    public const CONFIG_QC_PRODUCT_LOCKDOWN_RECIPIENTS = 'quality_case_product_lockdown_recipients';
    public const CONFIG_QC_SCRAP_RECIPIENTS = 'quality_case_scrap_recipients';
    public const KEY_ORDER_ERROR_CASE_SUBMIT_NOTIF_RECEIVER_EMAIL = 'oec_submit_notification_receiver_email';
    public const KEY_ORDER_ERROR_CASE_SUBMIT_NOTIF_THRESHOLD_AMOUNT = 'oec_submit_notification_threshold_amount';

    /**
     * {@inheritdoc}
     */
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder(DTCustomerServiceExtension::ALIAS);
        $rootNode = $treeBuilder->getRootNode();

        SettingsBuilder::append($rootNode, [
            self::KEY_ORDER_ERROR_CASE_SUBMIT_NOTIF_RECEIVER_EMAIL => [
                'value' => 'generic@example.com',
                'type' => 'string',
            ],
            self::KEY_ORDER_ERROR_CASE_SUBMIT_NOTIF_THRESHOLD_AMOUNT => [
                'value' => 1000,
                'type' => 'float',
            ],
            self::DT_APPROVAL_NOTIFICATION_RECIPIENTS => [
                'type' => 'string',
                'value' => 'generic@example.com'
            ],
            self::CONFIG_QC_PRODUCT_LOCKDOWN_RECIPIENTS => [
                'type' => 'string',
                'value' => 'generic@example.com'
            ],
            self::CONFIG_QC_SCRAP_RECIPIENTS => [
                'type' => 'string',
                'value' => 'generic@example.com'
            ],
        ]);

        return $treeBuilder;
    }

    /**
     * @param string $key
     * @param string $separator
     * @return string
     */
    public static function getConfigKey($key, $separator = ConfigManager::SECTION_MODEL_SEPARATOR)
    {
        return sprintf('%s%s%s', DTCustomerServiceExtension::ALIAS, $separator, $key);
    }

    /**
     * @param string $paramName
     *
     * @return string
     */
    public static function getConfigPathByName(string $paramName): string
    {
        return sprintf(
            '%s%s%s',
            DTCustomerServiceExtension::ALIAS,
            ConfigManager::SECTION_MODEL_SEPARATOR,
            $paramName
        );
    }
}
