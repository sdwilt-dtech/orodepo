<?php

namespace DT\Bundle\CustomerServiceBundle\Manager;

use DT\Bundle\EntityBundle\Entity\CreditOrderAwareInterface;
use DT\Bundle\OrderBundle\Converter\EntityToOrderConverterRegistry;
use Oro\Bundle\OrderBundle\Entity\Order;

class CreditOrderManager
{
    private EntityToOrderConverterRegistry $orderConverterRegistry;

    public function __construct(EntityToOrderConverterRegistry $orderConverterRegistry)
    {
        $this->orderConverterRegistry = $orderConverterRegistry;
    }

    /**
     * @param CreditOrderAwareInterface $creditOrderAwareEntity
     * @return Order|null
     */
    public function getCreditOrder(CreditOrderAwareInterface $creditOrderAwareEntity): ?Order
    {
        return $this->orderConverterRegistry->convert($creditOrderAwareEntity);
    }
}
