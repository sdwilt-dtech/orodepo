<?php

namespace DT\Bundle\CustomerServiceBundle\ImportExport\Configuration;

use DT\Bundle\EntityBundle\Entity\BusinessDevelopmentFund;
use Oro\Bundle\ImportExportBundle\Configuration\ImportExportConfiguration;
use Oro\Bundle\ImportExportBundle\Configuration\ImportExportConfigurationInterface;
use Oro\Bundle\ImportExportBundle\Configuration\ImportExportConfigurationProviderInterface;

class BDFImportExportConfigurationProvider implements ImportExportConfigurationProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function get(): ImportExportConfigurationInterface
    {
        return new ImportExportConfiguration([
            ImportExportConfiguration::FIELD_ENTITY_CLASS => BusinessDevelopmentFund::class,
            ImportExportConfiguration::FIELD_EXPORT_TEMPLATE_PROCESSOR_ALIAS => 'dt_bdf',
            ImportExportConfiguration::FIELD_IMPORT_PROCESSOR_ALIAS => 'dt_bdf.add_or_replace',
        ]);
    }
}
