<?php

namespace DT\Bundle\CustomerServiceBundle\ImportExport\TemplateFixture;

use DT\Bundle\EntityBundle\Entity\BusinessDevelopmentFund;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use Oro\Bundle\ImportExportBundle\TemplateFixture\AbstractTemplateRepository;
use Oro\Bundle\ImportExportBundle\TemplateFixture\TemplateFixtureInterface;
use Oro\Component\Testing\Unit\Entity\Stub\StubEnumValue;

class BDFFixture extends AbstractTemplateRepository implements TemplateFixtureInterface
{
    /**
     * {@inheritdoc}
     */
    public function getEntityClass()
    {
        return BusinessDevelopmentFund::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getData()
    {
        return $this->getEntityData('Example Fund');
    }

    /**
     * {@inheritdoc}
     */
    protected function createEntity($key)
    {
        return new BusinessDevelopmentFund();
    }

    /**
     * @param string                  $key
     * @param BusinessDevelopmentFund $entity
     */
    public function fillEntityData($key, $entity)
    {
        $userRepo = $this->templateManager
            ->getEntityRepository('Oro\Bundle\UserBundle\Entity\User');
        $customerRepo = $this->templateManager
            ->getEntityRepository('Oro\Bundle\CustomerBundle\Entity\Customer');
        $organizationRepo = $this->templateManager
            ->getEntityRepository('Oro\Bundle\OrganizationBundle\Entity\Organization');

        $calculatedFundType = new StubEnumValue(
            ReservedEnumCodes::DT_BUSINESS_DEVELOPMENT_FUND_CALCULATED_FUND_TYPE,
            'Customer'
        );

        switch ($key) {
            case 'Example Fund':
                $entity->setCalculatedFundType($calculatedFundType);
                $entity
                    ->setSalesforceId('DQWDF12314')
                    ->setPriorYearNetPurchases(234.12)
                    ->setOriginalAllocation(21.23)
                    ->setOriginalPercentage(0.03)
                    ->setFundYear(2020)
                    ->setComments('Comment body')
                    ->setStartAt(new \DateTime())
                    ->setEndAt(new \DateTime())
                    ->setOwner($userRepo->getEntity('John Doo'))
                    ->setOrganization($organizationRepo->getEntity('default'))
                    ->setCustomer($customerRepo->getEntity('Jerry Coleman'));

                return;
        }

        parent::fillEntityData($key, $entity);
    }
}
