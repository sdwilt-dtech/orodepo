<?php

namespace DT\Bundle\CustomerServiceBundle\Api\Processor;

use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use Oro\Bundle\ApiBundle\Processor\CustomizeLoadedData\CustomizeLoadedDataContext;
use Oro\Bundle\ApiBundle\Request\ValueTransformer;
use Oro\Bundle\ApiBundle\Util\DoctrineHelper;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;

class OrderErrorCaseData implements ProcessorInterface
{
    /** @var DoctrineHelper */
    protected $doctrineHelper;

    /** @var ValueTransformer */
    protected $valueTransformer;

    /**
     * @param DoctrineHelper          $doctrineHelper
     * @param ValueTransformer        $valueTransformer
     */
    public function __construct(
        DoctrineHelper $doctrineHelper,
        ValueTransformer $valueTransformer
    ) {
        $this->doctrineHelper = $doctrineHelper;
        $this->valueTransformer = $valueTransformer;
    }

    /**
     * {@inheritdoc}
     */
    public function process(ContextInterface $context)
    {
        $idFieldName = $context->getResultFieldName('id');
        if (!$idFieldName) {
            return;
        }

        /** @var CustomizeLoadedDataContext $context */
        $data = $context->getData();
        $amountRequestedFieldName = $context->getResultFieldName('amountRequested');
        $value = $this->doctrineHelper
            ->getEntityRepository(OrderErrorCase::class)
            ->getAmountRequestedValue($data[$idFieldName]);
        $data[$amountRequestedFieldName] = $this->valueTransformer->transformFieldValue(
            $value,
            $context->getConfig()->getField($amountRequestedFieldName)->toArray(),
            $context->getNormalizationContext()
        );

        $context->setData($data);
    }
}
