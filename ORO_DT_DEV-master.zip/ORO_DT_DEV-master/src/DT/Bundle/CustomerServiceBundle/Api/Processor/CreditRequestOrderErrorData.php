<?php

namespace DT\Bundle\CustomerServiceBundle\Api\Processor;

use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use Oro\Bundle\ApiBundle\Processor\CustomizeLoadedData\CustomizeLoadedDataContext;
use Oro\Bundle\ApiBundle\Request\ValueTransformer;
use Oro\Bundle\ApiBundle\Util\DoctrineHelper;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;

class CreditRequestOrderErrorData implements ProcessorInterface
{
    /** @var DoctrineHelper */
    protected $doctrineHelper;

    /** @var ValueTransformer */
    protected $valueTransformer;

    /**
     * @param DoctrineHelper          $doctrineHelper
     * @param ValueTransformer        $valueTransformer
     */
    public function __construct(
        DoctrineHelper $doctrineHelper,
        ValueTransformer $valueTransformer
    ) {
        $this->doctrineHelper = $doctrineHelper;
        $this->valueTransformer = $valueTransformer;
    }

    /**
     * {@inheritdoc}
     */
    public function process(ContextInterface $context)
    {
        /** @var CustomizeLoadedDataContext $context */
        $data = $context->getData();
        $orderErrorCaseFieldName = $context->getResultFieldName('orderErrorCase');
        if ($orderErrorCaseFieldName && !empty($data[$orderErrorCaseFieldName]['id'])) {
            $value = $this->doctrineHelper
                ->getEntityRepository(OrderErrorCase::class)
                ->getAmountRequestedValue($data[$orderErrorCaseFieldName]['id']);
            $amountRequestedFieldName = $context->getResultFieldName('amountRequested');
            $data[$amountRequestedFieldName] = $this->valueTransformer->transformFieldValue(
                $value,
                $context->getConfig()->getField($amountRequestedFieldName)->toArray(),
                $context->getNormalizationContext()
            );

            $context->setData($data);
        }
    }
}
