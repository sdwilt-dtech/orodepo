<?php

namespace DT\Bundle\CustomerServiceBundle\Checker;

use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\EntityBundle\Entity\Repository\OrderErrorCaseRepository;
use DT\Bundle\SetupBundle\Model\EnumValues;

class OrderErrorCaseCloseTransitionChecker
{
    /** @var OrderErrorCaseRepository */
    protected $caseRepository;

    /**
     * @param OrderErrorCaseRepository $caseRepository
     */
    public function __construct(OrderErrorCaseRepository $caseRepository)
    {
        $this->caseRepository = $caseRepository;
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return bool
     */
    public function isApplicable(OrderErrorCase $orderErrorCase): bool
    {
        if (null === $orderErrorCase->getStatus()) {
            return false;
        }

        $hasItemWithQtyGreaterZero = $this->caseRepository->hasItemWithQtyGreaterZero($orderErrorCase->getId());
        if (false === $hasItemWithQtyGreaterZero) {
            return false;
        }

        if (true === $orderErrorCase->getIsItemFound()) {
            return true;
        }

        if (EnumValues::DT_ORDER_ERROR_CASE_STATUS_NEW === $orderErrorCase->getStatus()->getId() &&
            $orderErrorCase->getIsSalesFix() &&
            null === $orderErrorCase->getCreditRequestReason()) {
            return true;
        }

        return $this->isTransitionTransitionTriggeredByCreditRequest($orderErrorCase);
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return bool
     */
    protected function isTransitionTransitionTriggeredByCreditRequest(OrderErrorCase $orderErrorCase): bool
    {
        $creditRequest = $orderErrorCase->getCreditRequest();
        if (null === $creditRequest || null === $creditRequest->getStatus()) {
            return false;
        }

        return null !== $orderErrorCase->getCreditRequestReason() &&
            EnumValues::DT_ORDER_ERROR_CASE_STATUS_SUBMITTED === $orderErrorCase->getStatus()->getId() &&
            \in_array(
                $creditRequest->getStatus()->getId(),
                [
                    EnumValues::DT_CREDIT_REQUEST_ORDER_ERROR_STATUS_CLOSED,
                    EnumValues::DT_CREDIT_REQUEST_ORDER_ERROR_STATUS_REJECTED,
                ],
                true
            );
    }
}
