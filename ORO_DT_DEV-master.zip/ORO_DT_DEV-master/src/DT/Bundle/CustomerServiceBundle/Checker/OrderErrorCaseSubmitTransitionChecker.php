<?php

namespace DT\Bundle\CustomerServiceBundle\Checker;

use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\EntityBundle\Entity\Repository\OrderErrorCaseRepository;
use DT\Bundle\SetupBundle\Model\EnumValues;

class OrderErrorCaseSubmitTransitionChecker
{
    public const REASON_INCORRECT_STATUS = 'incorrect_status';
    public const REASON_IS_SALES_FIX = 'sales_fix';
    public const REASON_HAS_NO_ITEM_WITH_QTY_BIGGER_THAN_ZERO = 'has_no_item_with_qty_bigger_than_zero';

    protected OrderErrorCaseRepository $caseRepository;

    /**
     * @param OrderErrorCaseRepository $caseRepository
     */
    public function __construct(OrderErrorCaseRepository $caseRepository)
    {
        $this->caseRepository = $caseRepository;
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return bool
     */
    public function isApplicable(OrderErrorCase $orderErrorCase): bool
    {
        return empty($this->getRestrictionReasons($orderErrorCase));
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return array|false
     */
    public function getRestrictionReasons(OrderErrorCase $orderErrorCase): array
    {
        $restrictionReasons = [];
        if (null === $orderErrorCase->getStatus() ||
            EnumValues::DT_ORDER_ERROR_CASE_STATUS_NEW !== $orderErrorCase->getStatus()->getId()) {
            $restrictionReasons[] = self::REASON_INCORRECT_STATUS;
        }

        $isSalesFix = $orderErrorCase->getIsSalesFix() && null === $orderErrorCase->getCreditRequestReason();
        if ($isSalesFix) {
            $restrictionReasons[] = self::REASON_IS_SALES_FIX;
        }

        $hasItemWithQtyGreaterZero = $this->caseRepository->hasItemWithQtyGreaterZero($orderErrorCase->getId());
        if (false === $hasItemWithQtyGreaterZero) {
            $restrictionReasons[] = self::REASON_HAS_NO_ITEM_WITH_QTY_BIGGER_THAN_ZERO;
        }

        return $restrictionReasons;
    }
}
