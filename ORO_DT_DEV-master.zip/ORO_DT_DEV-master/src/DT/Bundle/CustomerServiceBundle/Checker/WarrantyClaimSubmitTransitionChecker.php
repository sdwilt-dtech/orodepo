<?php

namespace DT\Bundle\CustomerServiceBundle\Checker;

use Doctrine\Bundle\DoctrineBundle\Registry;
use DT\Bundle\EntityBundle\Entity\WarrantyClaim;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\AttachmentBundle\Entity\Attachment;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;

class WarrantyClaimSubmitTransitionChecker
{
    public const REASON_INCORRECT_STATUS = 'incorrect_status';
    public const REASON_NO_ITEMS = 'no_items';
    public const REASON_NO_ATTACHMENTS = 'no_attachments';

    protected Registry $registry;

    /**
     * @param Registry $registry
     */
    public function __construct(Registry $registry)
    {
        $this->registry = $registry;
    }

    /**
     * @param WarrantyClaim $warrantyClaim
     * @return bool
     */
    public function isApplicable(WarrantyClaim $warrantyClaim): bool
    {
        return empty($this->getRestrictionReasons($warrantyClaim));
    }

    /**
     * @param WarrantyClaim $warrantyClaim
     * @return array
     */
    public function getRestrictionReasons(WarrantyClaim $warrantyClaim): array
    {
        $restrictionReasons = [];
        if (null === $warrantyClaim->getStatus() ||
            EnumValues::DT_WARRANTY_CLAIM_STATUS_NEW  !== $warrantyClaim->getStatus()->getId()) {
            $restrictionReasons[] = self::REASON_INCORRECT_STATUS;
        }

        $warrantyClaimItemCount = $this->getClaimItemsCountByWarrantyClaim($warrantyClaim);
        if ($warrantyClaimItemCount === 0) {
            $restrictionReasons[] = self::REASON_NO_ITEMS;
        }

        $hasAttachment = $this->warrantyClaimHasAttachment($warrantyClaim);
        if (false === $hasAttachment) {
            $restrictionReasons[] = self::REASON_NO_ATTACHMENTS;
        }

        return $restrictionReasons;
    }

    /**
     * @param WarrantyClaim $warrantyClaim
     * @return int
     */
    protected function getClaimItemsCountByWarrantyClaim(WarrantyClaim $warrantyClaim): int
    {
        $warrantyClaimRepository = $this->registry->getRepository(WarrantyClaim::class);

        return $warrantyClaimRepository->getItemsCount($warrantyClaim->getId());
    }

    /**
     * @param WarrantyClaim $warrantyClaim
     * @return bool
     */
    protected function warrantyClaimHasAttachment(WarrantyClaim $warrantyClaim): bool
    {
        $fieldName = ExtendHelper::buildAssociationName(WarrantyClaim::class);

        /**
         * It enough to get a single entity to say that entity has any attachments or no
         */
        /** @var Attachment $attachment */
        $attachment = $this->registry
            ->getRepository(Attachment::class)
            ->findOneBy(
                [
                    $fieldName => $warrantyClaim->getId()
                ]
            );

        return null !== $attachment;
    }
}
