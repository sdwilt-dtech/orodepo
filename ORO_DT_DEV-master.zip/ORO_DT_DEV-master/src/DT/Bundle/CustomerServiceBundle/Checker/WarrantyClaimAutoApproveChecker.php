<?php

namespace DT\Bundle\CustomerServiceBundle\Checker;

use DT\Bundle\EntityBundle\Entity\Repository\WarrantyClaimRepository;
use DT\Bundle\EntityBundle\Entity\WarrantyClaim;

class WarrantyClaimAutoApproveChecker
{
    public const AUTO_APPROVE_MAX_AMOUNT = 150;

    /** @var WarrantyClaimRepository */
    protected $repository;

    /**
     * @param WarrantyClaimRepository $repository
     */
    public function __construct(WarrantyClaimRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param WarrantyClaim $warrantyClaim
     * @return bool
     */
    public function isApplicable(WarrantyClaim $warrantyClaim): bool
    {
        $hasItemsWithException = $this->repository->hasItemsWithException($warrantyClaim->getId());
        if (true === $hasItemsWithException) {
            return false;
        }

        $requestedAmount = $this->repository->getRequestedAmount($warrantyClaim->getId());
        return static::AUTO_APPROVE_MAX_AMOUNT >= $requestedAmount;
    }
}
