<?php

namespace DT\Bundle\CustomerServiceBundle\Cleaner;

use Doctrine\Bundle\DoctrineBundle\Registry;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\EntityBundle\Entity\OrderErrorCaseLineItem;

class OrderErrorCaseCleaner
{
    /**
     * @var Registry
     */
    protected $registry;

    /**
     * @param Registry $registry
     */
    public function __construct(Registry $registry)
    {
        $this->registry = $registry;
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     */
    public function removeLineItemsWithZeroQty(OrderErrorCase $orderErrorCase): void
    {
        $invalidItemIds = $this->registry
            ->getRepository(OrderErrorCase::class)
            ->getItemIdsWithQtyEqualToZero($orderErrorCase->getId());

        foreach ($invalidItemIds as $lineItemId) {
            $orderErrorCaseLineItemRef = $this->registry
                ->getManagerForClass(OrderErrorCaseLineItem::class)
                ->getReference(OrderErrorCaseLineItem::class, $lineItemId);

            $orderErrorCase->removeLineItem($orderErrorCaseLineItemRef);
        }
    }
}
