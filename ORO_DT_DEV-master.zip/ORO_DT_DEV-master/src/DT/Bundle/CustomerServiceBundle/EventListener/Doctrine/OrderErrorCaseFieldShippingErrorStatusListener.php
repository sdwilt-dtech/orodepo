<?php

namespace DT\Bundle\CustomerServiceBundle\EventListener\Doctrine;

use Doctrine\ORM\Event\LifecycleEventArgs;
use Doctrine\ORM\Event\PreUpdateEventArgs;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerInterface;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerTrait;

/**
 * Catches changes in field 'shippingErrorStatus' to update field value 'shippingErrorAcknowledgedAt'
 * with current date time when value changed on accepted or disputed
 */
class OrderErrorCaseFieldShippingErrorStatusListener implements OptionalListenerInterface
{
    use OptionalListenerTrait;

    private const FIELD_NAME = 'shippingErrorStatus';

    /**
     * @param OrderErrorCase $orderErrorCase
     * @param PreUpdateEventArgs $args
     * @throws \Exception
     */
    public function preUpdate(OrderErrorCase $orderErrorCase, PreUpdateEventArgs $args): void
    {
        if (false === $args->hasChangedField(self::FIELD_NAME) || false === $this->isApplicable($orderErrorCase)) {
            return;
        }

        $orderErrorCase->setShippingErrorAcknowledgedAt(new \DateTime('now', new \DateTimeZone('UTC')));
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @param LifecycleEventArgs $event
     * @throws \Exception
     */
    public function postPersist(OrderErrorCase $orderErrorCase, LifecycleEventArgs $event)
    {
        if ($this->isApplicable($orderErrorCase)) {
            $oldAckAtValue = $orderErrorCase->getShippingErrorAcknowledgedAt();
            $newAckAtValue = new \DateTime('now', new \DateTimeZone('UTC'));
            $orderErrorCase->setShippingErrorAcknowledgedAt($newAckAtValue);

            $uow = $event->getEntityManager()->getUnitOfWork();
            $uow->propertyChanged($orderErrorCase, self::FIELD_NAME, $oldAckAtValue, $newAckAtValue);
            $uow->scheduleExtraUpdate($orderErrorCase, [self::FIELD_NAME => [$oldAckAtValue, $newAckAtValue]]);
            $uow->recomputeSingleEntityChangeSet(
                $event->getEntityManager()->getClassMetadata(OrderErrorCase::class),
                $orderErrorCase
            );
        }
    }

    /**
     * @param OrderErrorCase $entity
     * @return bool
     */
    private function isApplicable(OrderErrorCase $entity): bool
    {
        return $this->enabled && $entity->getShippingErrorStatus() &&
            \in_array(
                $entity->getShippingErrorStatus()->getId(),
                [
                    EnumValues::DT_ORDER_ERROR_CASE_SHIPPING_ERROR_STATUS_APPROVED,
                    EnumValues::DT_ORDER_ERROR_CASE_SHIPPING_ERROR_STATUS_REJECTED
                ],
                true
            );
    }
}
