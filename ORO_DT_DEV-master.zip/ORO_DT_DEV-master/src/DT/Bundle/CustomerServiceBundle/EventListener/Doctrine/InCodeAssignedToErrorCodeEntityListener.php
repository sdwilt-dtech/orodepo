<?php

namespace DT\Bundle\CustomerServiceBundle\EventListener\Doctrine;

use Doctrine\ORM\Event\LifecycleEventArgs;
use Doctrine\ORM\Event\PreUpdateEventArgs;
use DT\Bundle\CustomerServiceBundle\Provider\ApplicableInCodeProvider;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;

class InCodeAssignedToErrorCodeEntityListener
{
    /** @var ApplicableInCodeProvider */
    protected $applicableInCodeProvider;

    /**
     * @param ApplicableInCodeProvider $applicableInCodeProvider
     */
    public function __construct(ApplicableInCodeProvider $applicableInCodeProvider)
    {
        $this->applicableInCodeProvider = $applicableInCodeProvider;
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @param LifecycleEventArgs $event
     */
    public function postPersist(OrderErrorCase $orderErrorCase, LifecycleEventArgs $event)
    {
        $oldInCode = $orderErrorCase->getInCode();
        $inCode = $this->applicableInCodeProvider->getInCodeByOrderErrorCase($orderErrorCase);
        if ($oldInCode === $inCode) {
            return;
        }

        $orderErrorCase->setInCode($inCode);
        $uow = $event->getEntityManager()->getUnitOfWork();
        $uow->propertyChanged($orderErrorCase, 'inCode', $oldInCode, $inCode);
        $uow->scheduleExtraUpdate($orderErrorCase, ['inCode' => [$oldInCode, $inCode]]);
        $uow->recomputeSingleEntityChangeSet(
            $event->getEntityManager()->getClassMetadata(OrderErrorCase::class),
            $orderErrorCase
        );
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @param PreUpdateEventArgs $event
     */
    public function preUpdate(OrderErrorCase $orderErrorCase, PreUpdateEventArgs $event)
    {
        if ($event->hasChangedField('isReplace') ||
            $event->hasChangedField('isReturn') ||
            $event->hasChangedField('creditRequestReason')) {
            $inCode = $this->applicableInCodeProvider->getInCodeByOrderErrorCase($orderErrorCase);
            $orderErrorCase->setInCode($inCode);
        }
    }
}
