<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerServiceBundle\EventListener\Doctrine;

use Doctrine\ORM\Event\PreUpdateEventArgs;
use DT\Bundle\CustomerServiceBundle\DependencyInjection\Configuration;
use DT\Bundle\CustomerServiceBundle\Email\EmailTemplateSender;
use DT\Bundle\EntityBundle\Entity\QualityCase;
use Oro\Bundle\ConfigBundle\Config\ConfigManager;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerInterface;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerTrait;
use Oro\Component\MessageQueue\Transport\Exception\Exception;

class QualityCaseFieldProductLockdownListener implements OptionalListenerInterface
{
    use OptionalListenerTrait;

    public const FIELD_NAME = 'isProductLockdown';
    public const EMAIL_TEMPLATE_NAME = 'dt_qc_field_product_lockdown_changed';

    private EmailTemplateSender $emailTemplateSender;
    private ConfigManager $configManager;

    /**
     * @param EmailTemplateSender $emailTemplateSender
     * @param ConfigManager $configManager
     */
    public function __construct(
        EmailTemplateSender $emailTemplateSender,
        ConfigManager $configManager
    ) {
        $this->emailTemplateSender = $emailTemplateSender;
        $this->configManager = $configManager;
    }

    /**
     * @param QualityCase $entity
     * @param PreUpdateEventArgs $args
     *
     * @throws Exception
     */
    public function preUpdate(QualityCase $entity, PreUpdateEventArgs $args): void
    {
        if ($this->enabled && $args->hasChangedField(self::FIELD_NAME)) {
            $recipients = $this->getRecipients();
            if (empty($recipients)) {
                return;
            }

            $this->emailTemplateSender->send($entity, self::EMAIL_TEMPLATE_NAME, $recipients);
        }
    }

    /**
     * @throws Exception
     */
    public function postPersist(QualityCase $qualityCase)
    {
        if ($this->enabled && $qualityCase->getIsProductLockdown()) {
            $recipients = $this->getRecipients();
            if (empty($recipients)) {
                return;
            }

            $this->emailTemplateSender->send($qualityCase, self::EMAIL_TEMPLATE_NAME, $recipients);
        }
    }

    private function getRecipients(): array
    {
        $configValue = $this->configManager->get(
            Configuration::getConfigPathByName(
                Configuration::CONFIG_QC_PRODUCT_LOCKDOWN_RECIPIENTS
            )
        );

        return explode(';', $configValue);
    }
}
