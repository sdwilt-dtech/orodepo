<?php

namespace DT\Bundle\CustomerServiceBundle\EventListener;

use Doctrine\ORM\Event\PreUpdateEventArgs;
use DT\Bundle\CustomerServiceBundle\Async\Topics;
use DT\Bundle\EntityBundle\Entity\BusinessDevelopmentFund;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerInterface;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerTrait;
use Oro\Component\MessageQueue\Client\MessageProducerInterface;

class BusinessDevelopmentFundEntityListener implements OptionalListenerInterface
{
    use OptionalListenerTrait;

    protected MessageProducerInterface $messageProducer;

    /**
     * @param MessageProducerInterface $messageProducer
     */
    public function __construct(MessageProducerInterface $messageProducer)
    {
        $this->messageProducer = $messageProducer;
    }

    /**
     * @param BusinessDevelopmentFund $businessDevelopmentFund
     * @param PreUpdateEventArgs $args
     */
    public function preUpdate(BusinessDevelopmentFund $businessDevelopmentFund, PreUpdateEventArgs $args)
    {
        if (!$this->enabled) {
            return;
        }

        $hasChangedFields = $this->hasChangedFields($args);
        if ($hasChangedFields) {
            $fundYear = $businessDevelopmentFund->getFundYear();
            $this->sendMessageToProducerIfApplicable($fundYear, $businessDevelopmentFund->getCustomer());
            if ($args->hasChangedField('fundYear') && $args->hasChangedField('customer')) {
                $oldFundYear = $args->getOldValue('fundYear');
                $oldCustomer = $args->getOldValue('customer');
                if ($oldFundYear && $oldCustomer) {
                    $this->sendMessageToProducerIfApplicable($oldFundYear, $oldCustomer);
                }
            } elseif ($args->hasChangedField('fundYear')) {
                $oldFundYear = $args->getOldValue('fundYear');
                $this->sendMessageToProducerIfApplicable($oldFundYear, $businessDevelopmentFund->getCustomer());
            } elseif ($args->hasChangedField('customer')) {
                $oldCustomer = $args->getOldValue('customer');
                $this->sendMessageToProducerIfApplicable($fundYear, $oldCustomer);
            }
        }
    }

    /**
     * @param BusinessDevelopmentFund $businessDevelopmentFund
     */
    public function postPersist(BusinessDevelopmentFund $businessDevelopmentFund)
    {
        if (!$this->enabled) {
            return;
        }

        $this->sendMessageToProducerIfApplicable(
            $businessDevelopmentFund->getFundYear(),
            $businessDevelopmentFund->getCustomer()
        );
    }

    /**
     * @param BusinessDevelopmentFund $businessDevelopmentFund
     */
    public function postRemove(BusinessDevelopmentFund $businessDevelopmentFund)
    {
        if (!$this->enabled) {
            return;
        }

        $this->sendMessageToProducerIfApplicable(
            $businessDevelopmentFund->getFundYear(),
            $businessDevelopmentFund->getCustomer()
        );
    }

    /**
     * @param int|null $fundYear
     * @param Customer|null $customer
     */
    protected function sendMessageToProducerIfApplicable(?int $fundYear, ?Customer $customer): void
    {
        if (null === $fundYear || null === $customer || null === $customer->getId()) {
            return;
        }

        $this->messageProducer->send(
            Topics::BUSINESS_DEVELOPMENT_FUND_CALCULATION,
            [
                'fund_year' => $fundYear,
                'customer_id' => $customer->getId()
            ]
        );
    }

    /**
     * @param PreUpdateEventArgs $args
     * @return bool
     */
    protected function hasChangedFields(PreUpdateEventArgs $args): bool
    {
        $hasChangedFields = $args->hasChangedField('priorYearNetPurchases');
        $hasChangedFields = $hasChangedFields || $args->hasChangedField('fundYear');
        $hasChangedFields = $hasChangedFields || $args->hasChangedField('customer');
        $hasChangedFields = $hasChangedFields || $args->hasChangedField('calculatedFundType');
        return $hasChangedFields;
    }
}
