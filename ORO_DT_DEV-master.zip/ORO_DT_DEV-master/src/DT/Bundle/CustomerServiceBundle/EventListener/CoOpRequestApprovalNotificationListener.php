<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerServiceBundle\EventListener;

use Doctrine\ORM\Event\PreUpdateEventArgs;
use DT\Bundle\CustomerServiceBundle\DependencyInjection\Configuration;
use DT\Bundle\CustomerServiceBundle\Email\EmailTemplateSender;
use DT\Bundle\EntityBundle\Entity\CoOpRequest;
use Oro\Bundle\ConfigBundle\Config\ConfigManager;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerInterface;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerTrait;
use Oro\Component\MessageQueue\Transport\Exception\Exception;

class CoOpRequestApprovalNotificationListener implements OptionalListenerInterface
{
    use OptionalListenerTrait;

    private const APPROVED_FIELD_NAME = 'isApproved';
    private const DECLINED_FIELD_NAME = 'isDeclined';
    private const APPROVED_TEMPLATE_NAME = 'co_op_request_approved';
    private const DECLINED_TEMPLATE_NAME = 'co_op_request_declined';

    private EmailTemplateSender $emailTemplateSender;

    private ConfigManager $configManager;

    private array $recipients = [];

    public function __construct(
        EmailTemplateSender $emailTemplateSender,
        ConfigManager $configManager
    ) {
        $this->emailTemplateSender = $emailTemplateSender;
        $this->configManager = $configManager;
    }

    /**
     * @param CoOpRequest $entity
     * @param PreUpdateEventArgs $args
     *
     * @throws Exception
     */
    public function preUpdate(CoOpRequest $entity, PreUpdateEventArgs $args): void
    {
        if (!$this->enabled || !count($this->getRecipients())) {
            return;
        }

        if ($args->hasChangedField(self::APPROVED_FIELD_NAME) && $args->getNewValue(self::APPROVED_FIELD_NAME)) {
            $this->emailTemplateSender->send($entity, self::APPROVED_TEMPLATE_NAME, $this->getRecipients());
        } elseif ($args->hasChangedField(self::DECLINED_FIELD_NAME) && $args->getNewValue(self::DECLINED_FIELD_NAME)) {
            $this->emailTemplateSender->send($entity, self::DECLINED_TEMPLATE_NAME, $this->getRecipients());
        }
    }

    /**
     * @return array
     */
    private function getRecipients(): array
    {
        if (!$this->recipients) {
            $recipients = $this->configManager
                ->get(Configuration::getConfigPathByName(Configuration::DT_APPROVAL_NOTIFICATION_RECIPIENTS)) ? : [];

            if ($recipients) {
                $recipients = explode(';', $recipients);
                $recipients = array_map('trim', $recipients);
                $recipients = array_filter($recipients);
                $recipients = array_values($recipients);
            }

            $this->recipients = $recipients;
        }

        return $this->recipients;
    }
}
