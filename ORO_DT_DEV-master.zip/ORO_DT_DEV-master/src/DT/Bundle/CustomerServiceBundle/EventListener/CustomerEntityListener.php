<?php

namespace DT\Bundle\CustomerServiceBundle\EventListener;

use Doctrine\ORM\Event\PreUpdateEventArgs;
use DT\Bundle\CustomerServiceBundle\Async\Topics;
use DT\Bundle\EntityBundle\Entity\Repository\BusinessDevelopmentFundRepository;
use DT\Bundle\SetupBundle\Model\CustomerFields;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerInterface;
use Oro\Bundle\PlatformBundle\EventListener\OptionalListenerTrait;
use Oro\Component\MessageQueue\Client\MessageProducerInterface;

class CustomerEntityListener implements OptionalListenerInterface
{
    use OptionalListenerTrait;
    /** @var array */
    private const TARGET_CUSTOMER_BILLING_TYPES = [
        EnumValues::DT_CUSTOMER_BILLING_TYPE_X,
        EnumValues::DT_CUSTOMER_BILLING_TYPE_B,
        EnumValues::DT_CUSTOMER_BILLING_TYPE_S
    ];

    protected MessageProducerInterface $messageProducer;
    protected BusinessDevelopmentFundRepository $businessDevFundRep;

    /**
     * @param MessageProducerInterface $messageProducer
     * @param BusinessDevelopmentFundRepository $businessDevFundRep
     */
    public function __construct(
        MessageProducerInterface $messageProducer,
        BusinessDevelopmentFundRepository $businessDevFundRep
    ) {
        $this->messageProducer = $messageProducer;
        $this->businessDevFundRep = $businessDevFundRep;
    }

    /**
     * @param Customer $customer
     * @param PreUpdateEventArgs $args
     */
    public function preUpdate(Customer $customer, PreUpdateEventArgs $args)
    {
        if (false === $this->enabled || null === $customer->getDtEntityType()) {
            return;
        }

        if (false === $args->hasChangedField(CustomerFields::DT_CO_OP_FUNDS_PERCENTAGE)) {
            return;
        }

        $customerEntityType = $customer->getDtEntityType()->getId();
        $targetCustomers = $this->getAllTargetCustomers($customer);
        foreach ($targetCustomers as $targetCustomer) {
            $fundYearsByCustomer = $this->businessDevFundRep->getAvailableFundYearsByCustomerAndFundType(
                $targetCustomer,
                $customerEntityType
            );
            foreach ($fundYearsByCustomer as $fundYear) {
                $this->sendMessageToProducer($fundYear, $targetCustomer);
            }
        }
    }

    /**
     * @param Customer $customer
     * @param array $processedCustomerIds
     * @return array
     */
    protected function getAllTargetCustomers(Customer $customer, array $processedCustomerIds = []): array
    {
        $targetCustomers = [];
        $billingType = $this->getCustomerBillingTypeId($customer);
        if ($billingType && \in_array($billingType, self::TARGET_CUSTOMER_BILLING_TYPES, true)) {
            $targetCustomers[$customer->getId()] = $customer;

            return $targetCustomers;
        }

        $childCustomers = $customer->getChildren();
        foreach ($childCustomers as $childCustomer) {
            $currentProcessedCustomerIds = \array_merge(
                $processedCustomerIds,
                \array_keys($targetCustomers)
            );
            /**
             * Prevents infinite recursive loop when a child has own parent in its children
             */
            if (null === $childCustomer->getId() ||
                \in_array($childCustomer->getId(), $currentProcessedCustomerIds, true)
            ) {
                continue;
            }

            /**
             * Adds current processed customer ids to prevent recursive loop
             */
            $childTargetCustomers = $this->getChildTargetCustomers(
                $childCustomer,
                \array_unique(
                    \array_merge(
                        $currentProcessedCustomerIds,
                        [
                            $customer->getId(),
                            $childCustomer->getId()
                        ]
                    )
                )
            );
            /**
             * We uses array_replace instead of array_merge because it allows to keep int keys in array
             */
            $targetCustomers = \array_replace($targetCustomers, $childTargetCustomers);
        }

        return $targetCustomers;
    }

    /**
     * @param Customer $customer
     * @param array $processedCustomerIds
     * @return array
     */
    protected function getChildTargetCustomers(Customer $customer, array $processedCustomerIds = []): array
    {
        $targetCustomers = [];
        $billingType = $this->getCustomerBillingTypeId($customer);
        if ($billingType && \in_array($billingType, self::TARGET_CUSTOMER_BILLING_TYPES, true)) {
            $targetCustomers[$customer->getId()] = $customer;
            if ($billingType !== EnumValues::DT_CUSTOMER_BILLING_TYPE_S) {
                foreach ($customer->getChildren() as $childCustomer) {
                    $targetCustomers[$childCustomer->getId()] = $childCustomer;
                }
            }

            return $targetCustomers;
        }

        return $this->getAllTargetCustomers(
            $customer,
            $processedCustomerIds
        );
    }

    /**
     * @param Customer $customer
     * @return string|null
     */
    protected function getCustomerBillingTypeId(Customer $customer): ?string
    {
        return $customer->getDtBillingType() ? $customer->getDtBillingType()->getId() : null;
    }

    /**
     * @param int $fundYear
     * @param Customer $customer
     */
    protected function sendMessageToProducer(int $fundYear, Customer $customer): void
    {
        $this->messageProducer->send(
            Topics::BUSINESS_DEVELOPMENT_FUND_CALCULATION,
            [
                'fund_year' => $fundYear,
                'customer_id' => $customer->getId()
            ]
        );
    }
}
