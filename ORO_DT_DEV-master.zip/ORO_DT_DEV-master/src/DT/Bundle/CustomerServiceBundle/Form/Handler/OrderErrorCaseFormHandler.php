<?php

namespace DT\Bundle\CustomerServiceBundle\Form\Handler;

use DT\Bundle\CustomerServiceBundle\Handler\MassLineItemConvertHandler;
use DT\Bundle\CustomerServiceBundle\Route\OrderErrorCaseRouter;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use Oro\Bundle\FormBundle\Form\Handler\FormHandler;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;

class OrderErrorCaseFormHandler extends FormHandler
{
    /** @var RequestStack */
    protected $requestStack;

    /** @var MassLineItemConvertHandler */
    protected $massLineItemConvertHandler;

    /**
     * @param Request $request
     */
    public function setRequestStack(RequestStack $requestStack)
    {
        $this->requestStack = $requestStack;
    }

    /**
     * @param MassLineItemConvertHandler $massLineItemConvertHandler
     */
    public function setMassLineItemConvertHandler(MassLineItemConvertHandler $massLineItemConvertHandler)
    {
        $this->massLineItemConvertHandler = $massLineItemConvertHandler;
    }

    /**
     * @param OrderErrorCase $data
     * @param FormInterface $form
     */
    protected function saveData($data, FormInterface $form)
    {
        parent::saveData($data, $form);
        if ($data instanceof OrderErrorCase && $this->requestStack->getCurrentRequest()) {
            switch ($this->requestStack->getCurrentRequest()->get(OrderErrorCaseRouter::ACTION_PARAMETER)) {
                case OrderErrorCaseRouter::ACTION_SAVE_AND_ADD_ALL_ORDER_ERROR_LINE_ITEM:
                    $this->massLineItemConvertHandler->handleMassConvert(
                        $data,
                        false
                    );
                    break;
                case OrderErrorCaseRouter::ACTION_SAVE_AND_CREDIT_ALL_ORDER_ERROR_LINE_ITEM:
                    $this->massLineItemConvertHandler->handleMassConvert(
                        $data,
                        true
                    );
                    break;
            }
        }
    }
}
