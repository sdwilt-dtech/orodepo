<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerServiceBundle\Form\TemplateDataProvider;

use DT\Bundle\EntityBundle\Entity\QualityCase;
use Oro\Bundle\FormBundle\Provider\FormTemplateDataProviderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\RouterInterface;

class QualityCaseTypeTemplateDataProvider implements FormTemplateDataProviderInterface
{
    /**
     * @var RouterInterface
     */
    private $router;

    /**
     * @param RouterInterface $router
     */
    public function __construct(RouterInterface $router)
    {
        $this->router = $router;
    }

    /**
     * {@inheritdoc}
     * @param QualityCase $entity
     */
    public function getData($entity, FormInterface $form, Request $request): array
    {
        $id = $entity->getId();
        if ($id) {
            $formAction = $this->router->generate('dt_cs_quality_case_update', ['id' => $id]);
        } else {
            $formAction = $this->router->generate('dt_cs_quality_case_create');
        }

        return [
            'entity' => $entity,
            'form' => $form->createView(),
            'formAction' => $formAction,
        ];
    }
}
