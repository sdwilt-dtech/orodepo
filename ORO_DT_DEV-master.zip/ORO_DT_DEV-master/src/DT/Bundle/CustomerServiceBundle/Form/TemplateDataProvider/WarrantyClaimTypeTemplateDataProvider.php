<?php

namespace DT\Bundle\CustomerServiceBundle\Form\TemplateDataProvider;

use DT\Bundle\EntityBundle\Entity\WarrantyClaim;
use Oro\Bundle\FormBundle\Provider\FormTemplateDataProviderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\RouterInterface;

class WarrantyClaimTypeTemplateDataProvider implements FormTemplateDataProviderInterface
{
    /** @var RouterInterface */
    private $router;

    /**
     * @param RouterInterface $router
     */
    public function __construct(RouterInterface $router)
    {
        $this->router = $router;
    }

    /**
     * {@inheritdoc}
     * @param WarrantyClaim $entity
     */
    public function getData($entity, FormInterface $form, Request $request): array
    {
        if ($entity->getId()) {
            $formAction = $this->router->generate('dt_cs_warranty_claim_update', ['id' => $entity->getId()]);
        } else {
            $formAction = $this->router->generate('dt_cs_warranty_claim_create');
        }

        return [
            'entity' => $entity,
            'form' => $form->createView(),
            'formAction' => $formAction
        ];
    }
}
