<?php

namespace DT\Bundle\CustomerServiceBundle\Form\Type;

use DT\Bundle\CustomerBundle\Form\Type\CustomerTypeCustomerSelectType;
use DT\Bundle\EntityBundle\Entity\CoOpRequest;
use Oro\Bundle\ContactBundle\Form\Type\ContactSelectType;
use Oro\Bundle\FormBundle\Form\Type\CheckboxType;
use Oro\Bundle\FormBundle\Form\Type\OroMoneyType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CoOpRequestType extends AbstractType
{
    /**
     * {@inheritdoc}
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add(
                'description',
                TextareaType::class,
                [
                    'required' => true,
                    'label' => 'dt.entity.cooprequest.description.label'
                ]
            )
            ->add(
                'additionalDescription',
                TextareaType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.additional_description.label'
                ]
            )
            ->add(
                'amountRequested',
                OroMoneyType::class,
                [
                    'required' => true,
                    'label' => 'dt.entity.cooprequest.amount_requested.label'
                ]
            )
            ->add(
                'categories',
                TextType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.categories.label'
                ]
            )
            ->add(
                'isNonFocusCategories',
                CheckboxType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.is_non_focus_categories.label'
                ]
            )
            ->add(
                'customer',
                CustomerTypeCustomerSelectType::class,
                [
                    'required' => true,
                    'label' => 'dt.entity.cooprequest.customer.label'
                ]
            )
            ->add(
                'branch',
                CustomerTypeCustomerSelectType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.branch.label'
                ]
            )
            ->add(
                'contact',
                ContactSelectType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.contact.label'
                ]
            )
            ->add(
                'folowupNotes',
                TextareaType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.folowup_notes.label'
                ]
            )
            ->add(
                'fundYear',
                IntegerType::class,
                [
                    'required' => true,
                    'label' => 'dt.entity.cooprequest.fund_year.label'
                ]
            )
            ->add(
                'glAccount',
                TextType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.gl_account.label'
                ]
            )
            ->add(
                'inCode',
                TextType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.in_code.label'
                ]
            )
            ->add(
                'creditMemoNumber',
                TextType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.credit_memo_number.label'
                ]
            )
            ->add(
                'rsmEmail',
                EmailType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.cooprequest.rsm_email.label'
                ]
            );
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'data_class' => CoOpRequest::class
            ]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'dt_cs_co_op_request';
    }
}
