<?php

namespace DT\Bundle\CustomerServiceBundle\Form\Type;

use DT\Bundle\CustomerBundle\Form\Type\CustomerTypeCustomerSelectType;
use DT\Bundle\EntityBundle\Entity\BusinessDevelopmentFund;
use Oro\Bundle\FormBundle\Form\Type\OroDateType;
use Oro\Bundle\FormBundle\Form\Type\OroMoneyType;
use Oro\Bundle\FormBundle\Form\Type\OroPercentType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class BusinessDevelopmentFundType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add(
                'customer',
                CustomerTypeCustomerSelectType::class,
                [
                    'required' => true,
                    'label' => 'dt.entity.businessdevelopmentfund.customer.label'
                ]
            )
            ->add(
                'comments',
                TextareaType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.businessdevelopmentfund.comments.label'
                ]
            )
            ->add(
                'priorYearNetPurchases',
                OroMoneyType::class,
                [
                    'required' => true,
                    'label' => 'dt.entity.businessdevelopmentfund.prior_year_net_purchases.label'
                ]
            )
            ->add(
                'startAt',
                OroDateType::class,
                [
                    'required' => true,
                    'label' => 'dt.entity.businessdevelopmentfund.start_at.label'
                ]
            )
            ->add(
                'endAt',
                OroDateType::class,
                [
                    'required' => true,
                    'label' => 'dt.entity.businessdevelopmentfund.end_at.label'
                ]
            )
            ->add(
                'fundYear',
                IntegerType::class,
                [
                    'required' => true,
                    'label' => 'dt.entity.businessdevelopmentfund.fund_year.label'
                ]
            )
            ->add(
                'originalAllocation',
                OroMoneyType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.businessdevelopmentfund.original_allocation.label'
                ]
            )
            ->add(
                'originalPercentage',
                OroPercentType::class,
                [
                    'required' => false,
                    'label' => 'dt.entity.businessdevelopmentfund.original_percentage.label'
                ]
            );
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'data_class' => BusinessDevelopmentFund::class
            ]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'dt_cs_business_development_fund';
    }
}
