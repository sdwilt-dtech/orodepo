<?php

namespace DT\Bundle\CustomerServiceBundle\Form\Type;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\CustomerBundle\Form\Type\CustomerTypeCustomerSelectType;
use DT\Bundle\CustomerServiceBundle\Provider\WarrantyProductClaimItemPriceDTOProvider;
use DT\Bundle\EntityBundle\Entity\WarrantyClaim;
use DT\Bundle\EntityBundle\Entity\WarrantyProductClaimItem;
use DT\Bundle\OrderBundle\Model\DTO\ArchivedProductPriceDTO;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\ContactBundle\Form\Type\ContactSelectType;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\UserBundle\Form\Type\UserSelectType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class WarrantyClaimType extends AbstractType
{
    const NAME = 'dt_cs_warranty_claim';

    /** @var ManagerRegistry */
    protected $registry;

    /** @var WarrantyProductClaimItemPriceDTOProvider */
    protected $provider;

    /**
     * @param ManagerRegistry $registry
     * @param WarrantyProductClaimItemPriceDTOProvider $claimItemPriceProvider
     */
    public function __construct(
        ManagerRegistry $registry,
        WarrantyProductClaimItemPriceDTOProvider $claimItemPriceProvider
    ) {
        $this->registry = $registry;
        $this->provider = $claimItemPriceProvider;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        // information section
        $builder
            ->add('customerReference', TextType::class, ['required' => true]);

        // rep information section
        $builder
            ->add('rep', UserSelectType::class);

        // customer information section
        $builder->add('customer', CustomerTypeCustomerSelectType::class, [
                'required' => true,
                'create_enabled' => false
            ])
            ->add('contact', ContactSelectType::class, ['create_enabled' => false])
            ->add('issr', UserSelectType::class, ['required' => true])
            ->add('csr', UserSelectType::class);

        // product claims section
        $builder->add(
            'claimItems',
            WarrantyProductClaimItemCollectionType::class,
            [
                'entry_options' => [
                    'data_class' => WarrantyProductClaimItem::class
                ]
            ]
        );

        $builder->addEventListener(FormEvents::SUBMIT, [$this, 'updateItems']);
    }

    /**
     * @param FormEvent $event
     */
    public function updateItems(FormEvent $event)
    {
        /** @var WarrantyClaim $data */
        $data = $event->getData();

        $defaultItemDisposition = $this->getDefaultItemDisposition();

        /** @var WarrantyProductClaimItem $item */
        $claimItems = $data->getClaimItems();
        $customer = $data->getCustomer();
        /**
         * Non-valid data must be catch by validators, that will be triggered on postSubmit
         */
        if (null === $customer) {
            return;
        }

        foreach ($claimItems as $item) {
            if (!$item->getProduct() || !$item->getQuantity()) {
                $claimItems->removeElement($item);
            } else {
                $productClaimPriceDTO = $this->provider->getProductClaimPriceDTO($item, $customer);
                $isException = $this->provider->getProductClaimIsException($item, $customer);

                //currently there is no business logic, so always default value is used
                $item->setItemDisposition($defaultItemDisposition);
                $item->setIsException($isException);

                if ($productClaimPriceDTO instanceof ArchivedProductPriceDTO) {
                    $item->setUnitReplacementValue($productClaimPriceDTO->getPriceValue());

                    $unitDTO = $productClaimPriceDTO->getUnitDTO();
                    if ($unitDTO) {
                        $item->setProductUnit($unitDTO->getUnit());
                        $item->setProductUnitCode($unitDTO->getCode());
                    }
                }
            }
        }

        $event->setData($data);
    }

    /**
     * @return AbstractEnumValue
     */
    protected function getDefaultItemDisposition(): AbstractEnumValue
    {
        $enumClassName = ExtendHelper::buildEnumValueClassName(
            ReservedEnumCodes::DT_WARRANTY_PRODUCT_CLAIM_ITEM_ITEM_DISPOSITION
        );

        return $this->registry
            ->getManagerForClass($enumClassName)
            ->getReference($enumClassName, EnumValues::DT_WARRANTY_PRODUCT_CLAIM_ITEM_ITEM_DISPOSITION_FIELD_SCRAP);
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => WarrantyClaim::class,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return $this->getBlockPrefix();
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
