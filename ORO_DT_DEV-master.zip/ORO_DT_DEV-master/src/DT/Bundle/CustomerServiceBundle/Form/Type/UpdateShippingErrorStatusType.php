<?php

namespace DT\Bundle\CustomerServiceBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use Oro\Bundle\EntityExtendBundle\Form\Type\EnumSelectType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class UpdateShippingErrorStatusType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add(
                'shippingErrorStatus',
                EnumSelectType::class,
                [
                    'required'    => false,
                    'label'       => 'dt.entity.ordererrorcase.shipping_error_status.label',
                    'enum_code'   => ReservedEnumCodes::DT_ORDER_ERROR_CASE_SHIPPING_ERROR_STATUS
                ]
            );
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => OrderErrorCase::class,
            'csrf_token_id' => 'update-shipping-error-status',
            'dynamic_fields_disabled' => true,
            'ownership_disabled' => true,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'dt_update_shipping_error_status';
    }
}
