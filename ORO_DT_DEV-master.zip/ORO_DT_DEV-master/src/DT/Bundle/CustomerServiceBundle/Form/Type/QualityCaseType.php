<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerServiceBundle\Form\Type;

use DT\Bundle\CustomerBundle\Form\Type\CustomerTypeCustomerSelectType;
use DT\Bundle\EntityBundle\Entity\QualityCase;
use DT\Bundle\OrderBundle\Form\Type\CustomerOrderSelectType;
use Oro\Bundle\ContactBundle\Form\Type\ContactSelectType;
use Oro\Bundle\ProductBundle\Form\Type\ProductSelectType;
use Oro\Bundle\UserBundle\Form\Type\UserSelectType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class QualityCaseType extends AbstractType
{
    const NAME = 'dt_cs_quality_case';

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        // details section
        $builder
            ->add('subject', TextType::class, ['required' => true])
            ->add('description', TextareaType::class, ['required' => true])
            ->add('csr', UserSelectType::class, ['required' => true])
            ->add('salesSupport', UserSelectType::class, ['required' => true]);

        // contact section
        $builder
            ->add('contact', ContactSelectType::class, ['required' => true, 'create_enabled' => true])
            ->add('regionalSalesManager', UserSelectType::class, ['required' => false, 'create_enabled' => false])
            ->add('customer', CustomerTypeCustomerSelectType::class, [
                'create_enabled' => false,
                'configs' => [
                    'allowClear' => false,
                    'placeholder' => 'oro.customer.customer.form.choose',
                    'result_template_twig' => 'DTCustomerBundle:Customer:Autocomplete/result.html.twig',
                    'selection_template_twig' => 'DTCustomerBundle:Customer:Autocomplete/selection.html.twig'
                ],
            ]);

        // item information section
        $builder
            ->add('product', ProductSelectType::class, ['required' => true, 'create_enabled' => false])
            ->add('lotNumber')
            ->add('order', CustomerOrderSelectType::class)
            ->add('itemQuantity')
            ->add('wherePurchased');

        // item disposition section
        $builder
            ->add('isReturn')
            ->add('numberToReturn')
            ->add('rmaNumber')
            ->add('isFieldScrap')
            ->add('numberToFieldScrap')
            ->add('warrantyClaimNumber');

        // quality responses section
        $builder
            ->add('qualityTeamMember', UserSelectType::class, ['required' => false])
            ->add('otherIssueClassification')
            ->add('otherSitePlant')
            ->add('isProductLockdown')
            ->add('interimAction')
            ->add('correctiveActionPlan')
            ->add('rootCause')
            ->add('engineeringNotes');
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => QualityCase::class,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return $this->getBlockPrefix();
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
