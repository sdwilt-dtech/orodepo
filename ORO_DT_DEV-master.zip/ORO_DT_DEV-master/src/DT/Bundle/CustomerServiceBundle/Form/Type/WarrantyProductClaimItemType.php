<?php

namespace DT\Bundle\CustomerServiceBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\WarrantyProductClaimItem;
use Oro\Bundle\FormBundle\Form\Type\OroDateType;
use Oro\Bundle\ProductBundle\Form\Type\ProductSelectType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class WarrantyProductClaimItemType extends AbstractType
{
    const NAME = 'dt_cs_warranty_product_claim_item';

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add(
                'product',
                ProductSelectType::class,
                [
                    'required' => true,
                    'create_enabled' => false,
                    'grid_name' => 'dt-warranty-claim-product-select-grid',
                    'autocomplete_alias' => 'dt_customer_service_warranty_claim_product_search'
                ]
            )
            ->add('quantity', TextType::class, ['required' => true])
            ->add('purchasedAt', OroDateType::class, ['required' => false])
            ->add('issueDescription', TextareaType::class, ['required' => false]);
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => WarrantyProductClaimItem::class,
            'ownership_disabled'      => true,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return $this->getBlockPrefix();
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
