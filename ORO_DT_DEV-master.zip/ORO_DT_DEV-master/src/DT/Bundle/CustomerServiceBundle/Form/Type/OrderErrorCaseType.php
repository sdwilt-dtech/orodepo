<?php

namespace DT\Bundle\CustomerServiceBundle\Form\Type;

use DT\Bundle\CustomerBundle\Form\Type\CustomerTypeCustomerSelectType;
use DT\Bundle\CustomerServiceBundle\Route\OrderErrorCaseRouter;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\OrderBundle\Form\Type\CustomerOrderSelectType;
use DT\Bundle\OrderBundle\Form\Type\ShippingNumberSelectType;
use DT\Bundle\OrderBundle\Provider\ShippingNumberSelectChoicesProvider;
use Oro\Bundle\ContactBundle\Form\Type\ContactSelectType;
use Oro\Bundle\FormBundle\Utils\FormUtils;
use Oro\Bundle\OrderBundle\Entity\Order;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OrderErrorCaseType extends AbstractType
{
    /** @var ShippingNumberSelectChoicesProvider */
    protected $shippingNumberSelectChoiceProvider;

    /**
     * @param ShippingNumberSelectChoicesProvider $shippingNumberSelectChoiceProvider
     */
    public function __construct(ShippingNumberSelectChoicesProvider $shippingNumberSelectChoiceProvider)
    {
        $this->shippingNumberSelectChoiceProvider = $shippingNumberSelectChoiceProvider;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('subject', TextType::class, [
            'label' => 'dt.entity.ordererrorcase.subject.label',
            'required' => false,
        ]);
        $builder->add('customer', CustomerTypeCustomerSelectType::class, [
            'label' => 'dt.entity.ordererrorcase.customer.label',
            'required' => true,
            'create_enabled' => false
        ]);
        $builder->add('contact', ContactSelectType::class, [
            'label' => 'dt.entity.ordererrorcase.contact.label',
            'required' => true,
        ]);
        $builder->add('isReturn', CheckboxType::class, [
            'label' => 'dt.entity.ordererrorcase.is_return.label',
            'required' => false,
        ]);
        $builder->add('rmaNumber', TextType::class, [
            'label' => 'dt.entity.ordererrorcase.rma_number.label',
            'required' => false,
        ]);
        $builder->add('replacementOrderNumber', TextType::class, [
            'label' => 'dt.entity.ordererrorcase.replacement_order_number.label',
            'required' => false,
        ]);
        $builder->add('isReplace', CheckboxType::class, [
            'label' => 'dt.entity.ordererrorcase.is_replace.label',
            'required' => false
        ]);
        $builder->add('isSalesFix', CheckboxType::class, [
            'label' => 'dt.entity.ordererrorcase.is_sales_fix.label',
            'required' => false,
        ]);
        $builder->add('salesFixNumber', TextType::class, [
            'label' => 'dt.entity.ordererrorcase.sales_fix_number.label',
            'required' => false,
        ]);
        $builder->add('description', TextareaType::class, [
            'label' => 'dt.entity.ordererrorcase.description.label',
            'required' => true,
        ]);
        $builder->add('isOrderEntryError', CheckboxType::class, [
            'label' => 'dt.entity.ordererrorcase.is_order_entry_error.label',
            'required' => false,
        ]);
        $builder->add('isFreightClaim', CheckboxType::class, [
            'label' => 'dt.entity.ordererrorcase.is_freight_claim.label',
            'required' => false,
        ]);
        $builder->add('freightClaimNumber', TextType::class, [
            'label' => 'dt.entity.ordererrorcase.freight_claim_number.label',
            'required' => false,
        ]);
        $builder->add('isFieldDamaged', CheckboxType::class, [
            'label' => 'dt.entity.ordererrorcase.is_field_damaged.label',
            'required' => false,
        ]);
        $builder->add('fieldDamageDescription', TextareaType::class, [
            'label' => 'dt.entity.ordererrorcase.field_damage_description.label',
            'required' => false,
        ]);
        $builder->add('isInventoryReviewRequired', CheckboxType::class, [
            'label' => 'dt.entity.ordererrorcase.is_inventory_review_required.label',
            'required' => false,
        ]);
        $builder->add('inventoryReviewNotes', TextareaType::class, [
            'label' => 'dt.entity.ordererrorcase.inventory_review_notes.label',
            'required' => false,
        ]);
        $builder->add('itemNumbers', TextareaType::class, [
            'label' => 'dt.entity.ordererrorcase.item_numbers.label',
            'required' => false,
        ]);

        $this->addOrderWithShippingFields($builder);

        $builder->addEventListener(
            FormEvents::PRE_SET_DATA,
            [$this, 'onPreSetDataEvent']
        );

        $builder->addEventListener(
            FormEvents::PRE_SUBMIT,
            [$this, 'onPreSubmitEvent']
        );
    }

    /**
     * @param FormBuilderInterface $builder
     */
    protected function addOrderWithShippingFields(FormBuilderInterface $builder)
    {
        $builder->add('order', CustomerOrderSelectType::class, [
            'label' => 'dt.entity.ordererrorcase.order.label',
            'required' => true,
        ]);

        $builder->add('shippingNumber', ShippingNumberSelectType::class, [
            'label' => 'dt.entity.ordererrorcase.shipping_number.label',
            'required' => true,
        ]);
    }

    /**
     * @param FormEvent $event
     */
    public function onPreSetDataEvent(FormEvent $event)
    {
        $data = $event->getData();
        if (!$data instanceof OrderErrorCase) {
            return;
        }

        if ($data->getId()) {
            $form = $event->getForm();

            FormUtils::replaceField($form, 'customer', ['disabled' => true]);
            FormUtils::replaceField($form, 'order', ['disabled' => true]);

            $shippingNumberOptions = [
                'disabled' => true,
            ];
            if (null !== $data->getShippingNumber()) {
                $shippingNumberOptions['choices'] = [
                    $data->getShippingNumber() => $data->getShippingNumber()
                ];
            } else {
                $shippingNumberOptions['choices'] = [
                    $this->shippingNumberSelectChoiceProvider->getEmptyChoiceLabel() =>
                        $this->shippingNumberSelectChoiceProvider->getEmptyChoiceValue()
                ];
            }

            FormUtils::replaceField($form, 'shippingNumber', $shippingNumberOptions);
        /**
         * Case with duplicate
         */
        } elseif (!$data->getId() && $data->getOrder() instanceof Order) {
            $shippingNumberChoices = $this->shippingNumberSelectChoiceProvider->getChoicesByOrderId(
                $data->getOrder()->getId()
            );

            if (!empty($shippingNumberChoices)) {
                FormUtils::replaceField(
                    $event->getForm(),
                    'shippingNumber',
                    [
                        'choices' => $shippingNumberChoices
                    ]
                );
            }
        }
    }

    /**
     * @param FormEvent $event
     */
    public function onPreSubmitEvent(FormEvent $event)
    {
        $formData = $event->getForm()->getData();
        $eventData = $event->getData();
        if (!$formData instanceof OrderErrorCase) {
            return;
        }

        /**
         * Restore value of disabled fields
         */
        if ($formData->getId()) {
            $eventData['customer'] = $formData->getCustomer() ? $formData->getCustomer()->getId() : 0;
            $eventData['order'] = $formData->getOrder() ? $formData->getOrder()->getId() : 0;
            $eventData['shippingNumber'] = $formData->getShippingNumber() ??
                $this->shippingNumberSelectChoiceProvider->getEmptyChoiceValue();
            $event->setData($eventData);
        } else {
            $orderId = $eventData['order'] ?? false;
            if (false === $orderId) {
                return;
            }

            $shippingNumberChoices = $this->shippingNumberSelectChoiceProvider->getChoicesByOrderId(
                (int)$orderId
            );
            if (!empty($shippingNumberChoices)) {
                FormUtils::replaceField(
                    $event->getForm(),
                    'shippingNumber',
                    [
                        'choices' => $shippingNumberChoices
                    ]
                );
            }
        }
    }

    /**
     * @param FormView $view
     * @param FormInterface $form
     * @param array $options
     */
    public function finishView(FormView $view, FormInterface $form, array $options)
    {
        if (!$form->getData() || null === $form->getData()->getId()) {
            $view->vars['default_input_action'] = OrderErrorCaseRouter::ACTION_SAVE_AND_ADD_ALL_ORDER_ERROR_LINE_ITEM;
        }
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => OrderErrorCase::class,
            'csrf_token_id' => 'order-error-case'
        ]);
    }
}
