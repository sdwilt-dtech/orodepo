<?php

namespace DT\Bundle\CustomerServiceBundle\Autocomplete\WarrantyClaim;

use DT\Bundle\SetupBundle\Model\ProductFields;
use Oro\Bundle\FormBundle\Autocomplete\SearchHandler;
use Oro\Bundle\ProductBundle\Entity\Product;
use Oro\Bundle\SearchBundle\Engine\Indexer;
use Oro\Bundle\SearchBundle\Query\Criteria\Criteria;
use Oro\Bundle\SearchBundle\Query\Query;

class ProductSearchHandler extends SearchHandler
{
    /**
     * @param string $search
     * @param int    $firstResult
     * @param int    $maxResults
     * @return array
     */
    protected function searchIds($search, $firstResult, $maxResults)
    {
        $queryObj = $this->indexer->select()->from($this->entitySearchAlias);
        $queryObj->getCriteria()
            ->setMaxResults((int)$maxResults)
            ->setFirstResult((int)$firstResult);

        $field = Criteria::implodeFieldTypeName(
            Query::TYPE_INTEGER,
            ProductFields::DT_WARRANTY_BY_RMA_ONLY
        );
        $queryObj->getCriteria()->andWhere(
            Criteria::expr()->neq($field, 1)
        );

        $field1 = Criteria::implodeFieldTypeName(
            Query::TYPE_TEXT,
            'status'
        );
        $queryObj->getCriteria()->andWhere(
            Criteria::expr()->eq($field1, Product::STATUS_ENABLED)
        );

        if ($search) {
            $field = Criteria::implodeFieldTypeName(Query::TYPE_TEXT, Indexer::TEXT_ALL_DATA_FIELD);
            $queryObj->getCriteria()->andWhere(Criteria::expr()->contains($field, $search));
        }

        $ids      = [];
        $result   = $this->indexer->query($queryObj);
        $elements = $result->getElements();

        foreach ($elements as $element) {
            $ids[] = $element->getRecordId();
        }

        return $ids;
    }
}
