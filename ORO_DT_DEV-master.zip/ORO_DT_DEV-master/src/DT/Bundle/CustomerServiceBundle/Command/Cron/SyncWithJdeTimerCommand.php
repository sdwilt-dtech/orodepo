<?php

namespace DT\Bundle\CustomerServiceBundle\Command\Cron;

use Doctrine\ORM\QueryBuilder;
use Doctrine\Persistence\ObjectManager;
use DT\Bundle\EntityBundle\Entity\CreditRequestOrderError;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\BatchBundle\ORM\Query\BufferedIdentityQueryResultIterator;
use Oro\Bundle\CronBundle\Command\CronCommandInterface;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Symfony\Bridge\Doctrine\ManagerRegistry;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Transit workflow "credit_request_order_error_approval_flow" to step "pending_invoice_from_jde" by changing status of
 * CreditRequestOrderError to "pending_invoice_from_jde".
 */
class SyncWithJdeTimerCommand extends Command implements CronCommandInterface
{
    public const COMMAND_NAME = 'oro:cron:dt:customer-service:sync-with-jde-timer';

    /**
     * Number of days after which workflow should be transited.
     */
    public const DAYS_TO_TRANSIT = 15;

    /** @var int */
    private const BUFFER_SIZE = 200;

    protected ManagerRegistry $doctrine;

    /**
     * @param ManagerRegistry $doctrine
     */
    public function __construct(ManagerRegistry $doctrine)
    {
        $this->doctrine = $doctrine;
        parent::__construct();
    }

    /**
     * {@inheritdoc}
     */
    public function getDefaultDefinition()
    {
        return '0 * * * *';
    }

    /**
     * @return bool
     */
    public function isActive()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this->setName(self::COMMAND_NAME)
            ->setDescription('Submits CreditRequestOrderError entity to JDE after some period of time.');
    }

    /**
     * {@inheritdoc}
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $em = $this->doctrine->getManagerForClass(CreditRequestOrderError::class);
        /** @var ObjectManager $repo */
        $repo = $em->getRepository(CreditRequestOrderError::class);
        $date = (new \DateTime('now', new \DateTimeZone('UTC')))->modify(
            sprintf('-%d days', self::DAYS_TO_TRANSIT)
        );

        /** @var QueryBuilder $qb */
        $qb = $repo->createQueryBuilder('cr');
        $qb
            ->where(
                $qb->expr()->andX(
                    $qb->expr()->eq('cr.status', ':status'),
                    $qb->expr()->lt('cr.approvedAt', ':date'),
                )
            )
            ->setParameter('status', EnumValues::DT_CREDIT_REQUEST_ORDER_ERROR_STATUS_APPROVED)
            ->setParameter('date', $date);

        /**
         * Optimises updating process and loads data partially to have possibility
         * clear data after flush, because there is listeners (workflow listener, ..)
         * that catches changes in status and can load big amount of objects
         */
        $resultIterator = new BufferedIdentityQueryResultIterator($qb->getQuery());
        $resultIterator->setBufferSize(self::BUFFER_SIZE);

        $newStatus = $this->getNewStatus();

        $iteration = 0;
        /** @var CreditRequestOrderError $entity */
        foreach ($resultIterator as $entity) {
            $iteration++;
            $entity->setStatus($newStatus);

            if (0 === $iteration % self::BUFFER_SIZE) {
                $em->flush();
                $em->clear();

                /** Refresh status after clear */
                $newStatus = $this->getNewStatus();
            }
        }

        if (0 !== $iteration % self::BUFFER_SIZE) {
            $em->flush();
        }
    }

    /**
     * @return AbstractEnumValue
     */
    protected function getNewStatus(): AbstractEnumValue
    {
        /** @var AbstractEnumValue $newStatus */
        $newStatus = $this->doctrine
            ->getRepository(ExtendHelper::buildEnumValueClassName(
                ReservedEnumCodes::DT_CREDIT_REQUEST_ORDER_ERROR_STATUS
            ))
            ->find(EnumValues::DT_CREDIT_REQUEST_ORDER_ERROR_STATUS_PENDING_INVOICE_FROM_JDE);

        return $newStatus;
    }
}
