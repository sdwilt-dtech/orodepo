<?php

namespace DT\Bundle\CustomerServiceBundle\Command\Cron;

use Doctrine\ORM\QueryBuilder;
use Doctrine\Persistence\ObjectManager;
use DT\Bundle\EntityBundle\Entity\BaseCreditRequest;
use DT\Bundle\EntityBundle\Entity\CreditRequestOrderError;
use DT\Bundle\EntityBundle\Entity\CreditRequestWarrantyClaim;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\BatchBundle\ORM\Query\BufferedIdentityQueryResultIterator;
use Oro\Bundle\CronBundle\Command\CronCommandInterface;
use Oro\Bundle\OrderBundle\Entity\Order;
use Symfony\Bridge\Doctrine\ManagerRegistry;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Fills BaseCreditRequest entities with data from related Order.
 * This will also trigger "close" workflow transitions.
 */
class FillCreditOrderInfoCommand extends Command implements CronCommandInterface
{
    public const COMMAND_NAME = 'oro:cron:dt:customer-service:fill-credit-order-info';

    /** @var string[] */
    public const ENTITIES = [
        CreditRequestOrderError::class,
        CreditRequestWarrantyClaim::class
    ];

    /** @var int */
    private const BUFFER_SIZE = 200;

    /** @var array */
    private array $entityToStatusMapping = [
        CreditRequestOrderError::class =>
            EnumValues::DT_CREDIT_REQUEST_ORDER_ERROR_STATUS_PENDING_INVOICE_FROM_JDE,
        CreditRequestWarrantyClaim::class =>
            EnumValues::DT_CREDIT_REQUEST_WARRANTY_CLAIM_STATUS_PENDING_INVOICE_FROM_JDE
    ];

    protected ManagerRegistry $doctrine;

    /**
     * @param ManagerRegistry $doctrine
     */
    public function __construct(ManagerRegistry $doctrine)
    {
        $this->doctrine = $doctrine;
        parent::__construct();
    }

    /**
     * {@inheritdoc}
     */
    public function getDefaultDefinition()
    {
        return '*/15 * * * *';
    }

    /**
     * @return bool
     */
    public function isActive()
    {
        return true;
    }

    /**
     * {@internal doc}
     */
    protected function configure()
    {
        $this->setName(self::COMMAND_NAME)
            ->setDescription('Fills BaseCreditRequest entities with data from related Credit Order.');
    }

    /**
     * {@internal doc}
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        foreach (self::ENTITIES as $entityClass) {
            $em = $this->doctrine->getManagerForClass($entityClass);
            /** @var ObjectManager $repo */
            $repo = $em->getRepository($entityClass);

            /** @var QueryBuilder $qb */
            $qb = $repo->createQueryBuilder('e');
            $qb
                ->where(
                    $qb->expr()->andX(
                        $qb->expr()->eq('e.status', ':status'),
                    )
                )
                ->setParameter(
                    'status',
                    $this->entityToStatusMapping[$entityClass]
                );

            /**
             * Optimises updating process and loads data partially to have possibility
             * clear data after flush, because there is listeners (workflow listener, ..)
             * that catches changes in status and can load big amount of objects
             */
            $resultIterator = new BufferedIdentityQueryResultIterator($qb->getQuery());
            $resultIterator->setBufferSize(self::BUFFER_SIZE);

            $iteration = 0;
            $updatedCount = 0;
            /** @var BaseCreditRequest $entity */
            foreach ($resultIterator as $entity) {
                $iteration++;
                $creditOrder = $this->getCreditOrder($entity);
                $entity->setCreditOrder($creditOrder);

                if ($creditOrder) {
                    $updatedCount++;
                    $this->updateEntityData($creditOrder, $entity);
                }

                if (0 === $iteration % self::BUFFER_SIZE && $updatedCount > 0) {
                    $updatedCount = 0;
                    $em->flush();
                    $em->clear();
                }
            }

            if ($updatedCount > 0) {
                $em->flush();
            }
        }
    }

    /**
     * @param BaseCreditRequest $entity
     * @return Order|null
     */
    protected function getCreditOrder(BaseCreditRequest $entity): ?Order
    {
        if ($entity instanceof CreditRequestOrderError &&
            $entity->getOrderErrorCase() &&
            $entity->getOrderErrorCase()->getIsReturn()) {
            $creditOrder = $this->getOrderByRmaNumber($entity->getOrderErrorCase());

            return $creditOrder;
        }

        return $entity->getCreditOrder();
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return Order|null
     */
    protected function getOrderByRmaNumber(OrderErrorCase $orderErrorCase): ?Order
    {
        return $this->doctrine
            ->getRepository(Order::class)
            ->findOneBy(['dt_order_number' => $orderErrorCase->getRmaNumber()]);
    }

    /**
     * @param Order $creditOrder
     * @param BaseCreditRequest $entity
     */
    protected function updateEntityData(Order $creditOrder, BaseCreditRequest $entity): void
    {
        if ($creditOrder->getLineItems()->count()
            && !empty($creditOrder->getLineItems()->first()->getDtInvoiceNumber())
        ) {
            $entity->setCreditMemoNumber($creditOrder->getLineItems()->first()->getDtInvoiceNumber());
        }

        if ($creditOrder->getLineItems()->count()
            && !empty($creditOrder->getLineItems()->first()->getDtInvoiceDate())
        ) {
            $entity->setCreditMemoCreatedAt($creditOrder->getLineItems()->first()->getDtInvoiceDate());
        }
    }
}
