<?php

namespace DT\Bundle\CustomerServiceBundle\Command;

use Doctrine\ORM\QueryBuilder;
use DT\Bundle\CustomerServiceBundle\Async\Topics;
use DT\Bundle\EntityBundle\Entity\BusinessDevelopmentFund;
use DT\Bundle\EntityBundle\Entity\CoOpRequest;
use Oro\Component\MessageQueue\Client\MessageProducerInterface;
use Symfony\Bridge\Doctrine\ManagerRegistry;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Sends messages to recalculate dynamic fields for CoOpRequests and BusinessDevelopmentFunds.
 */
class RecalculateDynamicFieldsCommand extends Command
{
    public const NAME = 'dt:cs:recalculate-co-op-request-fields';
    public const YEAR_OPTION = 'fund-year';
    public const CUSTOMER_OPTION = 'customer-id';

    /** @var ManagerRegistry */
    protected ManagerRegistry $doctrine;

    /** @var MessageProducerInterface */
    protected MessageProducerInterface $messageProducer;

    /** @var ProgressBar */
    protected ProgressBar $progressBar;

    /**
     * @param ManagerRegistry          $doctrine
     * @param MessageProducerInterface $messageProducer
     */
    public function __construct(ManagerRegistry $doctrine, MessageProducerInterface $messageProducer)
    {
        $this->doctrine = $doctrine;
        $this->messageProducer = $messageProducer;

        parent::__construct(null);
    }

    /**
     * {@inheritdoc}
     */
    protected function configure(): void
    {
        $this
            ->setName(self::NAME)
            ->setDescription(
                'Sends messages to recalculate dynamic fields for CoOpRequests and BusinessDevelopmentFunds.'
            )
            ->addOption(
                self::YEAR_OPTION,
                null,
                InputOption::VALUE_OPTIONAL,
                'Entities will be filtered by specified fund-year.'
            )
            ->addOption(
                self::CUSTOMER_OPTION,
                null,
                InputOption::VALUE_OPTIONAL,
                'Entities will be filtered by specified Customer.'
            );
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     * @return int|void
     * @throws \Oro\Component\MessageQueue\Transport\Exception\Exception
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln('Starting...');

        $fundYear = $input->getOption(self::YEAR_OPTION);
        $customerId = $input->getOption(self::CUSTOMER_OPTION);

        $existedCustomersAndYears = $this->getExistedCustomerAndYearCombinations($fundYear, $customerId);

        $totalCount = count($existedCustomersAndYears);

        if (!$totalCount) {
            $output->writeln(
                'Nothing to recalculate. ' .
                'Neither CoOpRequests nor BusinessDevelopmentFunds where found by specified criteria.'
            );
        } else {
            $this->createProgressBar($output);
            $this->startProgressBar('Sending messages to recalculate...', $totalCount);

            foreach ($existedCustomersAndYears as $existedCustomerAndYear) {
                $this->sendMessageToProducer(
                    $existedCustomerAndYear['year'],
                    $existedCustomerAndYear['customer_id']
                );
                $this->advanceProgressBar();
            }

            $this->finishProgressBar('All messages sent.', $totalCount);
        }

        $output->writeln(PHP_EOL);
        $output->writeln('Finished.');
    }

    /**
     * Returns combinations "Customer - Fund Year" of existed CoOpRequests and BusinessDevelopmentFunds
     * Example: [['year' => 2019, 'customer_id' => 21345], ...]
     *
     * @param int|null $fundYear
     * @param int|null $customerId
     * @return array
     */
    protected function getExistedCustomerAndYearCombinations(?int $fundYear, ?int $customerId): array
    {
        $coOpRequestCombinations = $this->getCombinations(CoOpRequest::class, $fundYear, $customerId);
        $bDFCombinations = $this->getCombinations(BusinessDevelopmentFund::class, $fundYear, $customerId);
        $combinations = array_merge($coOpRequestCombinations, $bDFCombinations);

        $result = [];

        // remove duplicates
        foreach ($combinations as $combination) {
            $key = sprintf('%s_%s', $combination['year'], $combination['customer_id']);
            $result[$key] = $combination;
        }

        /**
         * Latest dates must be first
         */
        krsort($result);

        return $result;
    }

    /**
     * @param string   $class
     * @param int|null $fundYear
     * @param int|null $customerId
     * @return array
     */
    protected function getCombinations(string $class, ?int $fundYear, ?int $customerId): array
    {
        $repo = $this->doctrine->getRepository($class);
        /** @var QueryBuilder $qb */
        $qb = $repo->createQueryBuilder('item');
        $qb->select('item.fundYear AS year, identity(item.customer) AS customer_id');
        if ($fundYear) {
            $qb->andWhere('item.fundYear = :year')
                ->setParameter('year', $fundYear);
        } else {
            $qb->andWhere(
                $qb->expr()->isNotNull('item.fundYear')
            );
        }

        if ($customerId) {
            $qb->andWhere('item.customer = :customer_id')
                ->setParameter('customer_id', $customerId);
        } else {
            $qb->andWhere(
                $qb->expr()->isNotNull('item.customer')
            );
        }

        return $qb->groupBy('item.fundYear, item.customer')
            ->getQuery()
            ->getArrayResult();
    }

    /**
     * @param int $fundYear
     * @param int $customerId
     */
    protected function sendMessageToProducer(int $fundYear, int $customerId): void
    {
        $this->messageProducer->send(
            Topics::BUSINESS_DEVELOPMENT_FUND_CALCULATION,
            [
                'fund_year' => $fundYear,
                'customer_id' => $customerId
            ]
        );
    }

    /**
     * @param OutputInterface $output
     */
    protected function createProgressBar(OutputInterface $output): void
    {
        $progressBar = new ProgressBar($output);
        $progressBar->setBarWidth(40);
        $progressBar->setEmptyBarCharacter(' ');
        $progressBar->setFormat('%message% %current% <info>[</info>%bar%<info>]</info> %elapsed:6s% %memory:6s%');
        $progressBar->setBarCharacter('<comment>=</comment>');

        $this->progressBar = $progressBar;
    }

    /**
     * @param string $message
     * @param int    $maxSteps
     */
    protected function startProgressBar(string $message, int $maxSteps): void
    {
        $this->progressBar->setMessage("<info>$message</info>");
        $this->progressBar->setMaxSteps($maxSteps);
        $this->progressBar->start();
    }

    /**
     * @param int    $step
     */
    protected function advanceProgressBar(int $step = 1): void
    {
        $this->progressBar->advance($step);
    }

    /**
     * @param string $message
     * @param int    $progress
     */
    protected function finishProgressBar(string $message, int $progress): void
    {
        $this->progressBar->setMessage("<info>$message</info>");
        $this->progressBar->setProgress($progress);
        $this->progressBar->finish();
    }
}
