<?php

namespace DT\Bundle\CustomerServiceBundle\Command;

use DT\Bundle\EntityBundle\Entity\WarrantyClaim;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\WorkflowBundle\Exception\InvalidTransitionException;
use Oro\Bundle\WorkflowBundle\Exception\UnknownStepException;

/**
 * Sets correct workflow step for entities imported from salesforce.
 */
class WarrantyClaimUpdateWorkflowStepCommand extends AbstractUpdateWorkflowStepCommand
{
    /**
     * @param WarrantyClaim $entity
     * @throws InvalidTransitionException
     * @throws UnknownStepException
     * @throws \Oro\Bundle\WorkflowBundle\Exception\WorkflowException
     * @throws \Oro\Bundle\WorkflowBundle\Exception\WorkflowRecordGroupException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    protected function updateWorkflow($entity): void
    {
        $workflowManager = $this->workflowManager;
        $workflow = $workflowManager->getWorkflow($this->workflowName);

        $workflowConfig = $workflow->getDefinition()->getConfiguration();
        if (!isset($workflowConfig['transitions'][self::TRANSITION_TO_START])) {
            throw InvalidTransitionException::unknownTransition(self::TRANSITION_TO_START);
        }

        if (false === ($workflowConfig['transitions'][self::TRANSITION_TO_START]['is_start'])) {
            throw InvalidTransitionException::notStartTransition($this->workflowName, self::TRANSITION_TO_START);
        }

        $stepName = null;
        /**
         * In SF there is no Closed status for Warranty Claim, so we need to add transition from Approved to Closed
         * in case when related Credit Request Warranty Claim is Closed.
         */
        if ($entity->getCreditRequest() && $entity->getCreditRequest()->getStatus()) {
            $requestStatus = $entity->getCreditRequest()->getStatus()->getId();
            if (EnumValues::DT_CREDIT_REQUEST_WARRANTY_CLAIM_STATUS_CLOSED === $requestStatus) {
                $stepName = 'closed';
            }
        }

        if (!$stepName) {
            $stepName = $entity->getStatus() ? $entity->getStatus()->getId() : null;
        }

        if (!$stepName) {
            return;
        }

        $step = $this->getStepEntity($workflow, $stepName);

        $workflowItem = $workflowManager->getWorkflowItem($entity, $this->workflowName);

        if (!$workflowItem) {
            throw new \LogicException('Workflow item should already exist at the moment.');
        }

        $workflowItem->setCurrentStep($step);
    }
}
