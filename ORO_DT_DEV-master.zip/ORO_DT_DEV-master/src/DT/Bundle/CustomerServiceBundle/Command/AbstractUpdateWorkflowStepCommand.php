<?php

namespace DT\Bundle\CustomerServiceBundle\Command;

use Oro\Bundle\WorkflowBundle\Entity\WorkflowStep;
use Oro\Bundle\WorkflowBundle\Exception\InvalidTransitionException;
use Oro\Bundle\WorkflowBundle\Exception\UnknownStepException;
use Oro\Bundle\WorkflowBundle\Model\Workflow;
use Oro\Bundle\WorkflowBundle\Model\WorkflowManager;
use Oro\Bundle\WorkflowBundle\Model\WorkflowStartArguments;
use Symfony\Bridge\Doctrine\ManagerRegistry;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Sets correct workflow step for entities imported from salesforce.
 *
 * @covers \DT\Bundle\CustomerServiceBundle\Tests\Functional\Command\UpdateWorkflowStepCommandTest
 */
class AbstractUpdateWorkflowStepCommand extends Command
{
    /**
     * For entities imported from salesforce we need just set proper step without actions.
     * This transition created especially for this purpose.
     */
    public const TRANSITION_TO_START = 'create_workflow_without_actions';

    public const BATCH_SIZE = 1000;

    /** @var ManagerRegistry */
    protected ManagerRegistry $doctrine;

    /** @var WorkflowManager */
    protected WorkflowManager $workflowManager;

    /** @var string */
    protected $entityClass;

    /** @var string */
    protected $workflowName;

    /** @var ProgressBar */
    protected ProgressBar $progressBar;

    /**
     * @param ManagerRegistry $doctrine
     * @param WorkflowManager $workflowManager
     * @param string          $class
     * @param string          $workflowName
     * @param string          $commandName
     */
    public function __construct(
        ManagerRegistry $doctrine,
        WorkflowManager $workflowManager,
        $class = '',
        $workflowName = '',
        $commandName = ''
    ) {
        $this->doctrine = $doctrine;
        $this->entityClass = $class;
        $this->workflowName = $workflowName;
        $this->workflowManager = $workflowManager;
        $this->setName($commandName);

        parent::__construct(null);
    }

    /**
     * {@inheritdoc}
     */
    protected function configure(): void
    {
        if (!$this->entityClass) {
            throw new \LogicException('Entity class is not defined.');
        }

        if (!$this->getName()) {
            throw new \LogicException('Command name is not defined.');
        }

        $entityName = explode('\\', $this->entityClass);
        $entityName = end($entityName);

        $this
            ->setName($this->getName())
            ->setDescription(sprintf('Set proper workflow step for %s entity.', $entityName));
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     * @return int|void
     * @throws InvalidTransitionException
     * @throws UnknownStepException
     * @throws \Oro\Bundle\WorkflowBundle\Exception\WorkflowException
     * @throws \Oro\Bundle\WorkflowBundle\Exception\WorkflowRecordGroupException
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln('Starting...');

        $totalCount = $this->countEntities();

        if (!$totalCount) {
            $output->writeln('No entities found to update.');
        } else {
            $this->createProgressBar($output);
            $this->startProgressBar('Updating workflow', $totalCount);

            $offset = 0;

            while ($entities = $this->getEntitiesToProceed($offset, self::BATCH_SIZE)) {
                $this->startWorkflow($entities);

                foreach ($entities as $entity) {
                    $this->updateWorkflow($entity);
                }

                $this->doctrine->getManager()->flush();
                $this->doctrine->getManager()->clear();
                $this->advanceProgressBar(count($entities));
                $offset += self::BATCH_SIZE;
            }

            $this->finishProgressBar('Workflows updated.', $totalCount);
        }

        $output->writeln(PHP_EOL);
        $output->writeln('Finished.');
    }

    /**
     * @param int $offset
     * @param int $limit
     * @return array
     */
    protected function getEntitiesToProceed(int $offset, int $limit): array
    {
        return $this->doctrine
            ->getRepository($this->entityClass)
            ->createQueryBuilder('e')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }

    /**
     * @return int
     */
    protected function countEntities(): int
    {
        return $this->doctrine
            ->getRepository($this->entityClass)
            ->createQueryBuilder('e')
            ->select('count(e.id)')
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * Start workflow (if not started yet) for passed entities.
     *
     * @param $entities
     */
    protected function startWorkflow($entities): void
    {
        $entities = array_filter($entities, function ($entity) {
            $workflowItem = $this->workflowManager->getWorkflowItem($entity, $this->workflowName);

            return $workflowItem ? false : true;
        });

        $workflowStartArguments = array_map(
            function ($entity) {
                return new WorkflowStartArguments($this->workflowName, $entity, [], self::TRANSITION_TO_START);
            },
            $entities
        );

        $this->workflowManager->massStartWorkflow($workflowStartArguments);
    }

    /**
     * @param $entity
     * @throws InvalidTransitionException
     * @throws UnknownStepException
     * @throws \Oro\Bundle\WorkflowBundle\Exception\WorkflowException
     * @throws \Oro\Bundle\WorkflowBundle\Exception\WorkflowRecordGroupException
     */
    protected function updateWorkflow($entity): void
    {
        $workflowManager = $this->workflowManager;
        $workflow = $workflowManager->getWorkflow($this->workflowName);

        $workflowConfig = $workflow->getDefinition()->getConfiguration();
        if (!isset($workflowConfig['transitions'][self::TRANSITION_TO_START])) {
            throw InvalidTransitionException::unknownTransition(self::TRANSITION_TO_START);
        }

        if (false === ($workflowConfig['transitions'][self::TRANSITION_TO_START]['is_start'])) {
            throw InvalidTransitionException::notStartTransition($this->workflowName, self::TRANSITION_TO_START);
        }

        if (!$entity->getStatus()) {
            return;
        }

        $step = $this->getStepEntity($workflow, $entity->getStatus()->getId());

        $workflowItem = $workflowManager->getWorkflowItem($entity, $this->workflowName);

        if (!$workflowItem) {
            throw new \LogicException('Workflow item should already exist at the moment.');
        }

        $workflowItem->setCurrentStep($step);
    }

    /**
     * @param Workflow $workflow
     * @param          $stepName
     * @return object|WorkflowStep
     * @throws UnknownStepException
     */
    protected function getStepEntity(Workflow $workflow, $stepName): WorkflowStep
    {
        $stepRepository = $this->doctrine->getRepository(WorkflowStep::class);

        $step = $stepRepository->findOneBy([
            'name' => $stepName,
            'definition' => $workflow->getDefinition()
        ]);

        if (!$step) {
            throw new UnknownStepException($stepName);
        }

        return $step;
    }

    /**
     * @param OutputInterface $output
     */
    protected function createProgressBar(OutputInterface $output): void
    {
        $progressBar = new ProgressBar($output);
        $progressBar->setBarWidth(40);
        $progressBar->setEmptyBarCharacter(' ');
        $progressBar->setFormat('%message% %current% <info>[</info>%bar%<info>]</info> %elapsed:6s% %memory:6s%');
        $progressBar->setBarCharacter('<comment>=</comment>');

        $this->progressBar = $progressBar;
    }

    /**
     * @param string $message
     * @param int    $maxSteps
     */
    protected function startProgressBar(string $message, int $maxSteps): void
    {
        $this->progressBar->setMessage("<info>$message</info>");
        $this->progressBar->setMaxSteps($maxSteps);
        $this->progressBar->start();
    }

    /**
     * @param int    $step
     */
    protected function advanceProgressBar(int $step = 1): void
    {
        $this->progressBar->advance($step);
    }

    /**
     * @param string $message
     * @param int    $progress
     */
    protected function finishProgressBar(string $message, int $progress): void
    {
        $this->progressBar->setMessage("<info>$message</info>");
        $this->progressBar->setProgress($progress);
        $this->progressBar->finish();
    }
}
