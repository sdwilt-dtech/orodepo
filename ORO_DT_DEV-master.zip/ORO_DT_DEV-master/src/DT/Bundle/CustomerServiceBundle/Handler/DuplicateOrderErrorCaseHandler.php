<?php

namespace DT\Bundle\CustomerServiceBundle\Handler;

use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use Oro\Component\Duplicator\Duplicator;
use Oro\Component\Duplicator\DuplicatorFactory;

class DuplicateOrderErrorCaseHandler
{
    /** @var array */
    protected $settings;

    /** @var Duplicator */
    protected $duplicator;

    /** @var DuplicatorFactory */
    protected $duplicatorFactory;

    /**
     * @param DuplicatorFactory $duplicatorFactory
     * @param array $settings
     */
    public function __construct(
        DuplicatorFactory $duplicatorFactory,
        array $settings
    ) {
        $this->settings = $settings;
        $this->duplicatorFactory = $duplicatorFactory;
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return OrderErrorCase
     */
    public function getCopy(OrderErrorCase $orderErrorCase)
    {
        return $this->getDuplicator()->duplicate($orderErrorCase, $this->settings);
    }

    /**
     * @return Duplicator
     */
    protected function getDuplicator()
    {
        if (!$this->duplicator) {
            $this->duplicator = $this->duplicatorFactory->create();
        }

        return $this->duplicator;
    }
}
