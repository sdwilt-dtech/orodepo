<?php

namespace DT\Bundle\CustomerServiceBundle\Handler;

use Doctrine\Bundle\DoctrineBundle\Registry;
use DT\Bundle\CustomerServiceBundle\Converter\LineItemConverter;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\EntityBundle\Entity\OrderErrorCaseLineItem;
use DT\Bundle\EntityBundle\Entity\Repository\OrderErrorCaseRepository;
use Oro\Bundle\OrderBundle\Entity\OrderLineItem;

/**
 * The aim of this class is:
 * - Converts all orderLineItem related to Order that attached to OrderErrorCase
 */
class MassLineItemConvertHandler
{
    /** @var int */
    public const DEFAULT_BUFFER_SIZE = 100;

    /** @var Registry */
    protected $registry;

    /** @var LineItemConverter */
    protected $converter;

    /**
     * @param Registry $registry
     * @param LineItemConverter $converter
     */
    public function __construct(Registry $registry, LineItemConverter $converter)
    {
        $this->registry = $registry;
        $this->converter = $converter;
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @param bool $isCreditAllItemsAction
     */
    public function handleMassConvert(OrderErrorCase $orderErrorCase, bool $isCreditAllItemsAction): void
    {
        /** @var OrderErrorCaseRepository $orderErrorCaseRepository */
        $orderErrorCaseRepository = $this->registry->getRepository(OrderErrorCase::class);

        $iterator = $orderErrorCaseRepository->getAvailableOrderLineItems($orderErrorCase);
        $iterator->setBufferSize(self::DEFAULT_BUFFER_SIZE);

        $iteration = 0;
        $caseLineItems = [];
        /**
         * @var OrderLineItem $orderLineItem
         */
        foreach ($iterator as $position => $orderLineItem) {
            $orderErrorCaseLineItem = $this->converter->convert(
                $orderLineItem,
                $orderErrorCase,
                false === $isCreditAllItemsAction
            );
            $caseLineItems[$orderLineItem->getId()] = $orderErrorCaseLineItem;

            $iteration++;
            if (0 === $iteration % self::DEFAULT_BUFFER_SIZE) {
                $this->writeLineItems($orderErrorCase, $caseLineItems, $isCreditAllItemsAction);
                $caseLineItems = [];

                $orderErrorCase = $orderErrorCaseRepository->find($orderErrorCase->getId());
                if (null === $orderErrorCase) {
                    break;
                }
            }
        }

        if ($orderErrorCase) {
            $this->writeLineItems($orderErrorCase, $caseLineItems, $isCreditAllItemsAction);
        }
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @param array $caseLineItems
     * @param bool $isCreditAllItemsAction
     */
    protected function writeLineItems(
        OrderErrorCase $orderErrorCase,
        array $caseLineItems,
        bool $isCreditAllItemsAction
    ): void {
        if (empty($caseLineItems)) {
            return;
        }

        $manager = $this->registry->getManagerForClass(OrderErrorCaseLineItem::class);
        /** @var OrderErrorCaseRepository $orderErrorCaseRepository */
        $orderErrorCaseRepository = $this->registry->getRepository(OrderErrorCase::class);
        $attachedOrderLineItemIds = $orderErrorCaseRepository->getAttachedOrderLineItemsIdsByCaseAndOrderLineItemIds(
            $orderErrorCase,
            \array_keys($caseLineItems)
        );

        /**
         * @var OrderErrorCaseLineItem $caseLineItem
         */
        foreach ($caseLineItems as $orderLineItemId => $caseLineItem) {
            $existingCaseLineItemId = $attachedOrderLineItemIds[$orderLineItemId] ?? null;
            if (null === $existingCaseLineItemId) {
                $manager->persist($caseLineItem);
            } elseif ($isCreditAllItemsAction) {
                /** @var OrderErrorCaseLineItem $existingCaseLineItem */
                $existingCaseLineItem = $manager->getReference(OrderErrorCaseLineItem::class, $existingCaseLineItemId);
                $existingCaseLineItem->setQuantityCredited($caseLineItem->getQuantityCredited());
            }
        }

        $manager->flush();
        $manager->clear();
    }
}
