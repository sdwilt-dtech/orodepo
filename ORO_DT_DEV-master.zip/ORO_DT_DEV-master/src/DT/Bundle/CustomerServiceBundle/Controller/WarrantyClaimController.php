<?php

namespace DT\Bundle\CustomerServiceBundle\Controller;

use DT\Bundle\CustomerServiceBundle\Form\Type\WarrantyClaimType;
use DT\Bundle\EntityBundle\Entity\Repository\WarrantyClaimRepository;
use DT\Bundle\EntityBundle\Entity\WarrantyClaim;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\FormBundle\Model\UpdateHandlerFacade;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/warranty-claim")
 */
class WarrantyClaimController extends AbstractController
{
    /**
     * @Route("/view/{id}", name="dt_cs_warranty_claim_view", requirements={"id"="\d+"})
     * @Template
     * @Acl(
     *      id="dt_cs_warranty_claim_view",
     *      type="entity",
     *      class="DTEntityBundle:WarrantyClaim",
     *      permission="VIEW"
     * )
     *
     * @param WarrantyClaim $warrantyClaim
     *
     * @return array
     */
    public function viewAction(WarrantyClaim $warrantyClaim)
    {
        $amountRequested = $this
            ->getWarrantyClaimRepository()
            ->getRequestedAmount($warrantyClaim->getId());

        $itemsCount = $this
            ->getWarrantyClaimRepository()
            ->getItemsCount($warrantyClaim->getId());

        $itemsCountWithValueThreshold = $this
            ->getWarrantyClaimRepository()
            ->getItemsCountWithValueBiggerThan($warrantyClaim->getId(), 50);

        $itemsCountWithException = $this
            ->getWarrantyClaimRepository()
            ->getItemsCountWithException($warrantyClaim->getId());

        return [
            'entity' => $warrantyClaim,
            'amountRequested' => $amountRequested ?? 0,
            'itemsCount' => $itemsCount,
            'itemsCountWithValueThreshold' => $itemsCountWithValueThreshold,
            'itemsCountWithException' => $itemsCountWithException,
        ];
    }

    /**
     * @Route("/", name="dt_cs_warranty_claim_index")
     * @Template
     * @AclAncestor("dt_cs_warranty_claim_view")
     *
     * @return array
     */
    public function indexAction()
    {
        return [
            'entity_class' => WarrantyClaim::class,
        ];
    }

    /**
     * @Route("/create", name="dt_cs_warranty_claim_create")
     * @Template("DTCustomerServiceBundle:WarrantyClaim:update.html.twig")
     * @Acl(
     *      id="dt_cs_warranty_claim_create",
     *      type="entity",
     *      class="DTEntityBundle:WarrantyClaim",
     *      permission="CREATE"
     * )
     *
     * @return Response|array
     */
    public function createAction(Request $request)
    {
        $warrantyClaim = new WarrantyClaim();
        $currentDate = new \DateTime('now', new \DateTimeZone('UTC'));
        $warrantyClaim->setCustomerReference(sprintf('WAR-%s', $currentDate->format('YmdHi')));

        /** @var AbstractEnumValue $status */
        $status = $this->getDoctrine()
            ->getManagerForClass(ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_WARRANTY_CLAIM_STATUS))
            ->getReference(
                ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_WARRANTY_CLAIM_STATUS),
                EnumValues::DT_WARRANTY_CLAIM_STATUS_NEW
            );

        $warrantyClaim->setStatus($status);

        return $this->update($warrantyClaim, $request);
    }

    /**
     * @Route("/update/{id}", name="dt_cs_warranty_claim_update", requirements={"id"="\d+"})
     * @Template("DTCustomerServiceBundle:WarrantyClaim:update.html.twig")
     * @Acl(
     *      id="dt_cs_warranty_claim_update",
     *      type="entity",
     *      class="DTEntityBundle:WarrantyClaim",
     *      permission="EDIT"
     * )
     *
     * @return Response|array
     */
    public function updateAction(WarrantyClaim $warrantyClaim, Request $request)
    {
        return $this->update($warrantyClaim, $request);
    }

    /**
     * @param Request $request
     *
     * @return Response|array
     */
    protected function update(WarrantyClaim $warrantyClaim, Request $request)
    {
        return $this->get(UpdateHandlerFacade::class)->update(
            $warrantyClaim,
            $this->createForm(WarrantyClaimType::class, $warrantyClaim),
            $this->get(TranslatorInterface::class)->trans('dt.entity.warrantyclaim.saved_message'),
            $request
        );
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return array_merge(parent::getSubscribedServices(), [
            UpdateHandlerFacade::class,
            TranslatorInterface::class,
        ]);
    }

    /**
     * @return WarrantyClaimRepository
     */
    protected function getWarrantyClaimRepository(): WarrantyClaimRepository
    {
        return $this->getDoctrine()->getRepository(WarrantyClaim::class);
    }
}
