<?php

namespace DT\Bundle\CustomerServiceBundle\Controller;

use DT\Bundle\CustomerServiceBundle\Form\Type\BusinessDevelopmentFundType;
use DT\Bundle\EntityBundle\Entity\BusinessDevelopmentFund;
use Oro\Bundle\FormBundle\Model\UpdateHandlerFacade;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/business-development-fund")
 */
class BusinessDevelopmentFundController extends AbstractController
{
    /**
     * @Route("/view/{id}", name="dt_cs_business_development_fund_view", requirements={"id"="\d+"})
     * @Template
     * @Acl(
     *      id="dt_cs_business_development_fund_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DTEntityBundle:BusinessDevelopmentFund"
     * )
     *
     * @param BusinessDevelopmentFund $businessDevelopmentFund
     * @return BusinessDevelopmentFund[]
     */
    public function viewAction(BusinessDevelopmentFund $businessDevelopmentFund)
    {
        return [
            'entity' => $businessDevelopmentFund,
        ];
    }

    /**
     * @Route(
     *      "/{_format}",
     *      name="dt_cs_business_development_fund_index",
     *      requirements={"_format"="html|json"},
     *      defaults={"_format" = "html"}
     * )
     * @Template
     * @AclAncestor("dt_cs_business_development_fund_view")
     *
     * @return string[]
     */
    public function indexAction()
    {
        return [
            'entity_class' => BusinessDevelopmentFund::class
        ];
    }

    /**
     * @Route("/create", name="dt_cs_business_development_fund_create")
     * @Template("DTCustomerServiceBundle:BusinessDevelopmentFund:update.html.twig")
     * @Acl(
     *      id="dt_cs_business_development_fund_create",
     *      type="entity",
     *      class="DTEntityBundle:BusinessDevelopmentFund",
     *      permission="CREATE"
     * )
     * @param Request $request
     *
     * @return Response
     */
    public function createAction(Request $request)
    {
        $bdf = new BusinessDevelopmentFund();

        return $this->update($request, $bdf);
    }

    /**
     * @Route("/update/{id}", name="dt_cs_business_development_fund_update", requirements={"id"="\d+"})
     * @Template
     * @Acl(
     *      id="dt_cs_business_development_fund_update",
     *      type="entity",
     *      class="DTEntityBundle:BusinessDevelopmentFund",
     *      permission="EDIT"
     * )
     * @param Request $request
     * @param BusinessDevelopmentFund $bdf
     *
     * @return Response
     */
    public function updateAction(Request $request, BusinessDevelopmentFund $bdf)
    {
        return $this->update($request, $bdf);
    }

    /**
     * @param Request $request
     * @param BusinessDevelopmentFund $bdf
     *
     * @return Response|array
     */
    protected function update(Request $request, BusinessDevelopmentFund $bdf)
    {
        $updateResult = $this->get(UpdateHandlerFacade::class)->update(
            $bdf,
            $this->createForm(BusinessDevelopmentFundType::class, $bdf),
            $this->get(TranslatorInterface::class)->trans('dt.entity.businessdevelopmentfund.saved_message'),
            $request,
            null,
            'dt_cs_business_development_fund_update'
        );

        return $updateResult;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return array_merge(parent::getSubscribedServices(), [
            UpdateHandlerFacade::class,
            TranslatorInterface::class,
        ]);
    }
}
