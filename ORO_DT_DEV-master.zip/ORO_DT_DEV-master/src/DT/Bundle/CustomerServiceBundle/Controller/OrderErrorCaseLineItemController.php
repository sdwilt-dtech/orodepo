<?php

namespace DT\Bundle\CustomerServiceBundle\Controller;

use DT\Bundle\EntityBundle\Entity\OrderErrorCaseLineItem;
use FOS\RestBundle\Controller\Annotations\Delete;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/order-error-case-line-item")
 */
class OrderErrorCaseLineItemController extends AbstractController
{
    /**
     * @Delete("/delete/{id}", name="dt_cs_order_error_case_line_item_delete", requirements={"id"="\d+"})
     * @AclAncestor("dt_cs_order_error_case_update")
     *
     * @param OrderErrorCaseLineItem $orderErrorCaseLineItem
     * @return Response
     */
    public function deleteAction(OrderErrorCaseLineItem $orderErrorCaseLineItem)
    {
        $manager = $this->getDoctrine()->getManagerForClass(OrderErrorCaseLineItem::class);
        $manager->remove($orderErrorCaseLineItem);
        $manager->flush();

        return new Response(Response::HTTP_OK);
    }
}
