<?php

namespace DT\Bundle\CustomerServiceBundle\Controller;

use DT\Bundle\CustomerServiceBundle\Form\Type\OrderErrorCaseType;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\EntityBundle\Entity\Repository\OrderErrorCaseRepository;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use DT\Bundle\SetupBundle\Model\EnumValues;
use FOS\RestBundle\Controller\Annotations\Delete;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/order-error-case")
 */
class OrderErrorCaseController extends AbstractController
{
    /**
     * @Route("/view/{id}", name="dt_cs_order_error_case_view", requirements={"id"="\d+"})
     * @Template
     * @Acl(
     *      id="dt_cs_order_error_case_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DTEntityBundle:OrderErrorCase"
     * )
     *
     * @param OrderErrorCase $orderErrorCase
     * @return array
     */
    public function viewAction(OrderErrorCase $orderErrorCase)
    {
        $requestedAmountValue = $this
            ->getOrderErrorCaseRepository()
            ->getAmountRequestedValue($orderErrorCase->getId());

        $lineItemsCount = $this
            ->getOrderErrorCaseRepository()
            ->getLineItemsCount($orderErrorCase->getId());

        return [
            'entity' => $orderErrorCase,
            'requestedAmountValue' => $requestedAmountValue,
            'lineItemsCount' => $lineItemsCount
        ];
    }

    /**
     * @Route(
     *      "/{_format}",
     *      name="dt_cs_order_error_case_index",
     *      requirements={"_format"="html|json"},
     *      defaults={"_format" = "html"}
     * )
     * @Template
     * @AclAncestor("dt_cs_order_error_case_view")
     *
     * @return string[]
     */
    public function indexAction()
    {
        return [
            'entity_class' => OrderErrorCase::class
        ];
    }

    /**
     * @Delete("/delete/{id}", name="dt_cs_order_error_case_delete", requirements={"id"="\d+"})
     * @Acl(
     *      id="dt_cs_order_error_case_delete",
     *      type="entity",
     *      permission="DELETE",
     *      class="DTEntityBundle:OrderErrorCase"
     * )
     *
     * @param OrderErrorCase $orderErrorCase
     * @return Response
     */
    public function deleteAction(OrderErrorCase $orderErrorCase)
    {
        $manager = $this->getDoctrine()->getManagerForClass(OrderErrorCase::class);
        $manager->remove($orderErrorCase);
        $manager->flush();

        return new Response(Response::HTTP_OK);
    }

    /**
     * @Route("/update/{id}", name="dt_cs_order_error_case_update", requirements={"id"="\d+"})
     * @Template
     * @Acl(
     *      id="dt_cs_order_error_case_update",
     *      type="entity",
     *      permission="EDIT",
     *      class="DTEntityBundle:OrderErrorCase"
     * )
     *
     * @param OrderErrorCase $orderErrorCase
     * @return array|RedirectResponse
     */
    public function updateAction(OrderErrorCase $orderErrorCase)
    {
        return $this->update($orderErrorCase);
    }

    /**
     * @Route(
     *     "/create-from-order/{order_id}",
     *      name="dt_cs_order_error_case_create_from_order",
     *     requirements={"order_id"="\d+"}
     * )
     * @ParamConverter("order", options={"id"="order_id"})
     * @Template("DTCustomerServiceBundle:OrderErrorCase:update.html.twig")
     * @AclAncestor ("dt_cs_order_error_case_create")
     *
     * @param Order $order
     * @return array|RedirectResponse
     */
    public function createFromOrderAction(Order $order)
    {
        $orderErrorCase = new OrderErrorCase();
        $orderErrorCase->setOrder($order);
        $orderErrorCase->setCustomer($order->getCustomer());

        $statusClassName = ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_ORDER_ERROR_CASE_STATUS);
        /** @var AbstractEnumValue $status */
        $status = $this->getDoctrine()
            ->getManagerForClass($statusClassName)
            ->getReference($statusClassName, EnumValues::DT_ORDER_ERROR_CASE_STATUS_NEW);

        $orderErrorCase->setStatus($status);

        return $this->update($orderErrorCase);
    }

    /**
     * @Route(
     *     "/duplicate/{duplicate_id}",
     *      name="dt_cs_order_error_case_duplicate",
     *     requirements={"duplicate_id"="\d+"},
     * )
     * @ParamConverter("orderErrorCaseToDuplicate", options={"id"="duplicate_id"})
     * @Template("DTCustomerServiceBundle:OrderErrorCase:update.html.twig")
     * @AclAncestor ("dt_cs_order_error_case_create")
     *
     * @param OrderErrorCase $orderErrorCaseToDuplicate
     * @return array|RedirectResponse
     */
    public function duplicateAction(OrderErrorCase $orderErrorCaseToDuplicate)
    {
        $orderErrorCase = $this
            ->get('dt_customer_service.handler.duplicate_order_error_case')
            ->getCopy($orderErrorCaseToDuplicate);

        $statusClassName = ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_ORDER_ERROR_CASE_STATUS);
        /** @var AbstractEnumValue $status */
        $status = $this->getDoctrine()
            ->getManagerForClass($statusClassName)
            ->getReference($statusClassName, EnumValues::DT_ORDER_ERROR_CASE_STATUS_NEW);
        $orderErrorCase->setStatus($status);

        return $this->update($orderErrorCase);
    }

    /**
     * @Route("/create", name="dt_cs_order_error_case_create")
     * @Template("DTCustomerServiceBundle:OrderErrorCase:update.html.twig")
     * @Acl(
     *      id="dt_cs_order_error_case_create",
     *      type="entity",
     *      permission="CREATE",
     *      class="DTEntityBundle:OrderErrorCase"
     * )
     *
     * @return array|RedirectResponse
     */
    public function createAction()
    {
        $orderErrorCase = new OrderErrorCase();

        $statusClassName = ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_ORDER_ERROR_CASE_STATUS);
        /** @var AbstractEnumValue $status */
        $status = $this->getDoctrine()
            ->getManagerForClass($statusClassName)
            ->getReference($statusClassName, EnumValues::DT_ORDER_ERROR_CASE_STATUS_NEW);
        $orderErrorCase->setStatus($status);

        return $this->update($orderErrorCase);
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return array|RedirectResponse
     */
    protected function update(OrderErrorCase $orderErrorCase)
    {
        return $this->get('dt_customer_service.update_handler.order_error_case')->update(
            $orderErrorCase,
            $this->createForm(OrderErrorCaseType::class),
            $this->get('translator')->trans('dt.customer_service.controller.order_error_case.saved.message'),
            null,
            'dt_order_error_case'
        );
    }

    /**
     * @return OrderErrorCaseRepository
     */
    protected function getOrderErrorCaseRepository(): OrderErrorCaseRepository
    {
        return $this->getDoctrine()->getRepository(OrderErrorCase::class);
    }
}
