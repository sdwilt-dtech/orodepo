<?php

namespace DT\Bundle\CustomerServiceBundle\Controller;

use Doctrine\Persistence\ObjectRepository;
use DT\Bundle\CustomerServiceBundle\Form\Type\CoOpRequestType;
use DT\Bundle\EntityBundle\Entity\BusinessDevelopmentFund;
use DT\Bundle\EntityBundle\Entity\CoOpRequest;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\FormBundle\Model\UpdateHandlerFacade;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/co-op-request")
 */
class CoOpRequestController extends AbstractController
{
    public const DEFAULT_GL_ACCOUNT = '19861.7515';
    public const DEFAULT_IN_CODE = 'IN25';

    /**
     * @Route("/view/{id}", name="dt_cs_co_op_request_view", requirements={"id"="\d+"})
     * @Template
     * @Acl(
     *      id="dt_cs_co_op_request_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DTEntityBundle:CoOpRequest"
     * )
     *
     * @param CoOpRequest $coOpRequest
     * @return CoOpRequest[]
     */
    public function viewAction(CoOpRequest $coOpRequest)
    {
        $businessDevelopmentFund = $this->getBusinessDevelopmentFundRepository()
            ->findOneBy([
                'fundYear' => $coOpRequest->getFundYear(),
                'customer' => $coOpRequest->getCustomer()
            ]);
        return [
            'businessDevelopmentFund' => $businessDevelopmentFund,
            'entity' => $coOpRequest,
        ];
    }

    /**
     * @Route(
     *      "/{_format}",
     *      name="dt_cs_co_op_request_index",
     *      requirements={"_format"="html|json"},
     *      defaults={"_format" = "html"}
     * )
     * @Template
     * @AclAncestor("dt_cs_co_op_request_view")
     *
     * @return string[]
     */
    public function indexAction()
    {
        return [
            'entity_class' => CoOpRequest::class
        ];
    }

    /**
     * @return ObjectRepository
     */
    protected function getBusinessDevelopmentFundRepository()
    {
        return $this->getDoctrine()->getRepository(BusinessDevelopmentFund::class);
    }

    /**
     * @Route("/create", name="dt_cs_co_op_request_create")
     * @Template("DTCustomerServiceBundle:CoOpRequest:update.html.twig")
     * @Acl(
     *      id="dt_cs_co_op_request_create",
     *      type="entity",
     *      class="DTEntityBundle:CoOpRequest",
     *      permission="CREATE"
     * )
     * @param Request $request
     *
     * @return Response
     */
    public function createAction(Request $request)
    {
        $coOpRequest = new CoOpRequest();

        /** @var AbstractEnumValue $status */
        $status = $this->getDoctrine()
            ->getManagerForClass(
                ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_CO_OP_REQUEST_STATUS)
            )
            ->getReference(
                ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_CO_OP_REQUEST_STATUS),
                EnumValues::DT_CO_OP_REQUEST_STATUS_NEW
            );

        $coOpRequest->setStatus($status);
        $coOpRequest->setGlAccount(self::DEFAULT_GL_ACCOUNT);
        $coOpRequest->setInCode(self::DEFAULT_IN_CODE);
        $currentDate = new \DateTime('now', new \DateTimeZone('UTC'));
        $coOpRequest->setFundYear($currentDate->format('Y'));

        $customerId = (int)$request->query->get('customer_id', 0);
        $customer = $this->getDoctrine()
            ->getRepository(Customer::class)
            ->find($customerId);
        if ($customer) {
            $coOpRequest->setCustomer($customer);
        }

        return $this->update($request, $coOpRequest);
    }

    /**
     * @Route("/update/{id}", name="dt_cs_co_op_request_update", requirements={"id"="\d+"})
     * @Template
     * @Acl(
     *      id="dt_cs_co_op_request_update",
     *      type="entity",
     *      class="DTEntityBundle:CoOpRequest",
     *      permission="EDIT"
     * )
     * @param Request $request
     * @param CoOpRequest $coOpRequest
     *
     * @return Response
     */
    public function updateAction(Request $request, CoOpRequest $coOpRequest)
    {
        return $this->update($request, $coOpRequest);
    }

    /**
     * @param Request $request
     * @param CoOpRequest $coOpRequest
     *
     * @return Response|array
     */
    protected function update(Request $request, CoOpRequest $coOpRequest)
    {
        $updateResult = $this->get(UpdateHandlerFacade::class)->update(
            $coOpRequest,
            $this->createForm(CoOpRequestType::class, $coOpRequest),
            $this->get(TranslatorInterface::class)->trans('dt.entity.cooprequest.saved_message'),
            $request,
            null,
            'dt_cs_co_op_request_update'
        );

        return $updateResult;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return array_merge(parent::getSubscribedServices(), [
            UpdateHandlerFacade::class,
            TranslatorInterface::class,
        ]);
    }
}
