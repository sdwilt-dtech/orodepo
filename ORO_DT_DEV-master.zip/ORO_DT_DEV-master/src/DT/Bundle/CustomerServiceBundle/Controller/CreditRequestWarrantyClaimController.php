<?php

namespace DT\Bundle\CustomerServiceBundle\Controller;

use DT\Bundle\EntityBundle\Entity\CreditRequestWarrantyClaim;
use DT\Bundle\EntityBundle\Entity\Repository\WarrantyClaimRepository;
use DT\Bundle\EntityBundle\Entity\WarrantyClaim;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/credit-request-warranty-claim")
 */
class CreditRequestWarrantyClaimController extends AbstractController
{
    /**
     * @Route("/view/{id}", name="dt_cs_credit_request_warranty_claim_view", requirements={"id"="\d+"})
     * @Template
     * @Acl(
     *      id="dt_cs_credit_request_warranty_claim_view",
     *      type="entity",
     *      class="DTEntityBundle:CreditRequestWarrantyClaim",
     *      permission="VIEW"
     * )
     *
     * @param CreditRequestWarrantyClaim $creditRequestWarrantyClaim
     *
     * @return array
     */
    public function viewAction(CreditRequestWarrantyClaim $creditRequestWarrantyClaim)
    {
        $warrantyClaim = $creditRequestWarrantyClaim->getWarrantyClaim();
        if ($warrantyClaim) {
            $requestedAmount = $this->getWarrantyClaimRepository()->getRequestedAmount(
                $warrantyClaim->getId()
            );
        } else {
            $requestedAmount = 0;
        }

        return [
            'entity' => $creditRequestWarrantyClaim,
            'approvedAmount' => $requestedAmount ?? 0
        ];
    }

    /**
     * @Route(
     *    "/{_format}",
     *      name="dt_cs_credit_request_warranty_claim_index",
     *      requirements={"_format"="html|json"},
     *      defaults={"_format" = "html"}
     * )
     * @Template
     * @AclAncestor("dt_cs_credit_request_warranty_claim_view")
     *
     * @return array
     */
    public function indexAction()
    {
        return [
            'entity_class' => CreditRequestWarrantyClaim::class,
        ];
    }

    /**
     * @return WarrantyClaimRepository
     */
    protected function getWarrantyClaimRepository(): WarrantyClaimRepository
    {
        return $this->getDoctrine()->getRepository(WarrantyClaim::class);
    }
}
