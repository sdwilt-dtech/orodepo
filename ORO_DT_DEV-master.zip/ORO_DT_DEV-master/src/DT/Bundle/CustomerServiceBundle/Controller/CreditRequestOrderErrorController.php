<?php

namespace DT\Bundle\CustomerServiceBundle\Controller;

use DT\Bundle\CustomerServiceBundle\Provider\JdeCreditCountdownProvider;
use DT\Bundle\EntityBundle\Entity\CreditRequestOrderError;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\EntityBundle\Entity\Repository\OrderErrorCaseRepository;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/credit-request-order-error")
 */
class CreditRequestOrderErrorController extends AbstractController
{
    /**
     * @Route("/view/{id}", name="dt_cs_credit_request_order_error_view", requirements={"id"="\d+"})
     * @Template
     * @Acl(
     *      id="dt_cs_credit_request_order_error_view",
     *      type="entity",
     *      class="DTEntityBundle:CreditRequestOrderError",
     *      permission="VIEW"
     * )
     *
     * @param CreditRequestOrderError $creditRequestOrderError
     *
     * @return array
     */
    public function viewAction(CreditRequestOrderError $creditRequestOrderError)
    {
        $requestedAmountValue = null;
        $lineItemsCount = null;
        $orderErrorCase = $creditRequestOrderError->getOrderErrorCase();

        if ($orderErrorCase instanceof OrderErrorCase) {
            $orderErrorCaseRepository = $this->getOrderErrorCaseRepository();
            $requestedAmountValue = $orderErrorCaseRepository->getAmountRequestedValue($orderErrorCase->getId());
            $lineItemsCount = $orderErrorCaseRepository->getLineItemsCount($orderErrorCase->getId());
        }

        $jdeCreditCountdownDateInterval = $this->get(JdeCreditCountdownProvider::class)->getDiffDateInterval(
            $creditRequestOrderError
        );

        return [
            'entity' => $creditRequestOrderError,
            'requestedAmountValue' => $requestedAmountValue,
            'lineItemsCount' => $lineItemsCount,
            'jdeCreditCountdownDateInterval' => $jdeCreditCountdownDateInterval
        ];
    }

    /**
     * @Route(
     *      "/{_format}",
     *      name="dt_cs_credit_request_order_error_index",
     *      requirements={"_format"="html|json"},
     *      defaults={"_format" = "html"}
     * )
     * @Template
     * @AclAncestor("dt_cs_credit_request_order_error_view")
     *
     * @return array
     */
    public function indexAction()
    {
        return [
            'entity_class' => CreditRequestOrderError::class,
        ];
    }

    /**
     * @return OrderErrorCaseRepository
     */
    protected function getOrderErrorCaseRepository(): OrderErrorCaseRepository
    {
        return $this->getDoctrine()->getRepository(OrderErrorCase::class);
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return array_merge(parent::getSubscribedServices(), [
            JdeCreditCountdownProvider::class
        ]);
    }
}
