<?php

namespace DT\Bundle\CustomerServiceBundle\Controller;

use DT\Bundle\CustomerServiceBundle\Form\Type\QualityCaseType;
use DT\Bundle\EntityBundle\Entity\QualityCase;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\FormBundle\Model\UpdateHandlerFacade;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/quality-case")
 */
class QualityCaseController extends AbstractController
{
    /**
     * @Route(
     *      "/{_format}",
     *      name="dt_cs_quality_case_index",
     *      requirements={"_format"="html|json"},
     *      defaults={"_format" = "html"}
     * )
     * @Template("DTCustomerServiceBundle:QualityCase:index.html.twig")
     * @AclAncestor("dt_cs_quality_case_view")
     *
     * @return array
     */
    public function indexAction()
    {
        return [
            'entity_class' => QualityCase::class,
        ];
    }

    /**
     * @Route("/view/{id}", name="dt_cs_quality_case_view", requirements={"id"="\d+"})
     * @Template("DTCustomerServiceBundle:QualityCase:view.html.twig")
     * @Acl(
     *      id="dt_cs_quality_case_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DTEntityBundle:QualityCase"
     * )
     *
     * @return array
     */
    public function viewAction(QualityCase $qualityCase)
    {
        return [
            'entity' => $qualityCase,
        ];
    }

    /**
     * @Route(
     *     "/create-from-order/{order_id}",
     *      name="dt_cs_quality_case_create_from_order",
     *     requirements={"order_id"="\d+"}
     * )
     * @ParamConverter("order", options={"id"="order_id"})
     * @Template("DTCustomerServiceBundle:QualityCase:update.html.twig")
     * @AclAncestor ("dt_cs_quality_case_create")
     *
     * @param Order $order
     * @param Request $request
     *
     * @return array|RedirectResponse
     */
    public function createFromOrderAction(Order $order, Request $request)
    {
        $qualityCase = $this->getInitializeQualityCase();
        $qualityCase->setOrder($order);
        $qualityCase->setCustomer($order->getCustomer());
        $qualityCase->setCsr(
            $order->getCustomer()->getDtCsr() ? $order->getCustomer()->getDtCsr()->getUser() : null
        );
        $qualityCase->setSalesSupport(
            $order->getCustomer()->getDtRegion() ? $order->getCustomer()->getDtRegion()->getSalesSupport() : null
        );
        $qualityCase->setRegionalSalesManager(
            $order->getCustomer()->getDtRegion() ? $order->getCustomer()->getDtRegion()->getRegionalManager() : null
        );

        return $this->update($qualityCase, $request);
    }

    /**
     * @Route("/create", name="dt_cs_quality_case_create")
     * @Template("DTCustomerServiceBundle:QualityCase:update.html.twig")
     * @Acl(
     *      id="dt_cs_quality_case_create",
     *      type="entity",
     *      class="DTEntityBundle:QualityCase",
     *      permission="CREATE"
     * )
     *
     * @param Request $request
     * @return Response|array
     */
    public function createAction(Request $request)
    {
        $qualityCase = $this->getInitializeQualityCase();

        return $this->update($qualityCase, $request);
    }

    /**
     * @Route("/update/{id}", name="dt_cs_quality_case_update", requirements={"id"="\d+"})
     * @Template("DTCustomerServiceBundle:QualityCase:update.html.twig")
     * @Acl(
     *      id="dt_cs_quality_case_update",
     *      type="entity",
     *      class="DTEntityBundle:QualityCase",
     *      permission="EDIT"
     * )
     *
     * @return Response|array
     */
    public function updateAction(QualityCase $qualityCase, Request $request)
    {
        return $this->update($qualityCase, $request);
    }

    /**
     * @return QualityCase
     */
    protected function getInitializeQualityCase(): QualityCase
    {
        $qualityCase = new QualityCase();

        $qualityCaseStatusClassName = ExtendHelper::buildEnumValueClassName(
            ReservedEnumCodes::DT_QUALITY_CASE_STATUS
        );
        /** @var AbstractEnumValue $status */
        $status = $this->getDoctrine()
            ->getManagerForClass($qualityCaseStatusClassName)
            ->getReference($qualityCaseStatusClassName, EnumValues::DT_QUALITY_CASE_STATUS_NEW);
        $qualityCase->setStatus($status);

        $qualityCasePriorityClassName = ExtendHelper::buildEnumValueClassName(
            ReservedEnumCodes::DT_QUALITY_CASE_PRIORITY
        );
        /** @var AbstractEnumValue $priority */
        $priority = $this->getDoctrine()
            ->getManagerForClass($qualityCasePriorityClassName)
            ->getReference($qualityCasePriorityClassName, EnumValues::DT_QUALITY_CASE_PRIORITY_MEDIUM);
        $qualityCase->setPriority($priority);

        return $qualityCase;
    }

    /**
     * @param QualityCase $qualityCase
     * @param Request $request
     *
     * @return Response|array
     */
    protected function update(QualityCase $qualityCase, Request $request)
    {
        return $this->get(UpdateHandlerFacade::class)->update(
            $qualityCase,
            $this->createForm(QualityCaseType::class, $qualityCase),
            $this->get(TranslatorInterface::class)->trans('dt.entity.qualitycase.saved_message'),
            $request
        );
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return array_merge(parent::getSubscribedServices(), [
            UpdateHandlerFacade::class,
            TranslatorInterface::class,
        ]);
    }
}
