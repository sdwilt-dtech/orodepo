<?php

namespace DT\Bundle\CustomerServiceBundle\Async;

class Topics
{
    public const BUSINESS_DEVELOPMENT_FUND_CALCULATION = 'dt_customer_service.bfd_calculation';
}
