<?php

namespace DT\Bundle\CustomerServiceBundle\Async;

use DT\Bundle\CustomerServiceBundle\Provider\BusinessDevelopmentFundDataProvider;
use DT\Bundle\EntityBundle\Entity\BusinessDevelopmentFund;
use DT\Bundle\EntityBundle\Entity\CoOpRequest;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Oro\Bundle\LocaleBundle\Model\LocaleSettings;
use Oro\Component\MessageQueue\Client\TopicSubscriberInterface;
use Oro\Component\MessageQueue\Consumption\MessageProcessorInterface;
use Oro\Component\MessageQueue\Job\JobRunner;
use Oro\Component\MessageQueue\Transport\MessageInterface;
use Oro\Component\MessageQueue\Transport\SessionInterface;
use Oro\Component\MessageQueue\Util\JSON;
use Psr\Log\LoggerInterface;

class BusinessDevelopmentFundsCalculationsProcessor implements MessageProcessorInterface, TopicSubscriberInterface
{
    protected JobRunner $jobRunner;
    protected LoggerInterface $logger;
    protected DoctrineHelper $doctrineHelper;
    protected BusinessDevelopmentFundDataProvider $dataProvider;
    protected LocaleSettings $localeSettings;

    /**
     * @param JobRunner $jobRunner
     * @param LoggerInterface $logger
     * @param DoctrineHelper $doctrineHelper
     * @param BusinessDevelopmentFundDataProvider $dataProvider
     * @param LocaleSettings $localeSettings
     */
    public function __construct(
        JobRunner $jobRunner,
        LoggerInterface $logger,
        DoctrineHelper $doctrineHelper,
        BusinessDevelopmentFundDataProvider $dataProvider,
        LocaleSettings $localeSettings
    ) {
        $this->jobRunner = $jobRunner;
        $this->logger = $logger;
        $this->doctrineHelper = $doctrineHelper;
        $this->dataProvider = $dataProvider;
        $this->localeSettings = $localeSettings;
    }

    /**
     * {@inheritdoc}
     */
    public function process(MessageInterface $message, SessionInterface $session): string
    {
        try {
            $messageData = JSON::decode($message->getBody());
            $this->validateMessageData($messageData);
            /** @var Customer $customer */
            $customer = $this->doctrineHelper
                ->getEntityRepository(Customer::class)
                ->find($messageData['customer_id']);

            if (!$customer) {
                $this->logger->error(
                    'Business Development Calculation message cannot be processed. Customer does not exist.',
                    [
                        'customer_id' => (int)$messageData['customer_id']
                    ]
                );

                return self::REJECT;
            }

            if (!\is_int($messageData['fund_year'])) {
                $this->logger->error(
                    'Business Development Calculation message cannot be processed. ' .
                    'Parameter `fund_year` must be valid integer, but other given.',
                    [
                        'fund_year' => $messageData['fund_year']
                    ]
                );

                return self::REJECT;
            }

            $result = $this->processJob($message, $customer, $messageData['fund_year']);
        } catch (\InvalidArgumentException $e) {
            $this->logger->error('Business Development Calculation message cannot be processed', [
                'exception' => $e,
                'body'      => $message->getBody()
            ]);

            return self::REJECT;
        } catch (\Throwable $e) {
            $this->logger->error(
                'Business Development Calculation - unexpected exception occurred during message processing',
                [
                    'exception' => $e,
                    'topic'     => Topics::BUSINESS_DEVELOPMENT_FUND_CALCULATION,
                    'body'      => $message->getBody()
                ]
            );

            return self::REJECT;
        }

        return $result ?? self::REJECT;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedTopics(): array
    {
        return [Topics::BUSINESS_DEVELOPMENT_FUND_CALCULATION];
    }

    /**
     * @param MessageInterface $message
     * @param Customer $customer
     * @param int $fundYear
     * @return mixed|null
     */
    private function processJob(
        MessageInterface $message,
        Customer $customer,
        int $fundYear
    ) {
        $jobName = sprintf(
            '%s:%s:customer:%s',
            Topics::BUSINESS_DEVELOPMENT_FUND_CALCULATION,
            $fundYear,
            $customer->getId()
        );

        return $this->jobRunner->runUnique(
            $message->getMessageId(),
            $jobName,
            function () use ($customer, $fundYear) {
                try {
                    $this->doJob($customer, $fundYear);
                    return self::ACK;
                } catch (\Throwable $e) {
                    $this->logger->error(
                        'Business Development Calculation  - unexpected exception occurred during message processing',
                        [
                            'exception'    => $e,
                            'topic'        => Topics::BUSINESS_DEVELOPMENT_FUND_CALCULATION
                        ]
                    );

                    return self::REJECT;
                }
            }
        );
    }

    /**
     * @param Customer $customer
     * @param int $fundYear
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     */
    protected function doJob(Customer $customer, int $fundYear): void
    {
        $allocated = 0;
        $pending = 0;
        $spent = 0;
        $remaining = 0;

        /** @var BusinessDevelopmentFund|null $businessDevelopmentFund */
        $businessDevelopmentFund = $this->doctrineHelper
            ->getEntityRepository(BusinessDevelopmentFund::class)
            ->findOneBy(['fundYear' => $fundYear, 'customer' => $customer]);

        if ($businessDevelopmentFund) {
            $allocated = $this->dataProvider->getFundsAllocated($businessDevelopmentFund);
            $pending = $this->dataProvider->getFundsPending($businessDevelopmentFund);
            $spent = $this->dataProvider->getFundsSpent($businessDevelopmentFund);
            $remaining = $this->dataProvider->getFundsRemaining($businessDevelopmentFund);

            $businessDevelopmentFund
                ->setFundsAllocated($allocated)
                ->setFundsPending($pending)
                ->setFundsSpent($spent)
                ->setFundsRemaining($remaining)
                ->setFundsPercentageSpent($allocated > 0 ? ($spent / $allocated) : 0)
                ->setFundsSpentOrRequested($pending + $spent)
                ->setFundsPercentageSpentOrRequested(
                    $allocated > 0 ? (($pending + $spent) / $allocated) : 0
                );
            $entityManager = $this->doctrineHelper
                ->getEntityManager(BusinessDevelopmentFund::class);
            $entityManager->persist($businessDevelopmentFund);
            $entityManager->flush($businessDevelopmentFund);
        }

        $this->updateCoOpRequestData(
            $fundYear,
            $customer,
            (float)$allocated,
            (float)$pending,
            (float)$spent,
            (float)$remaining
        );

        $currentDate = new \DateTime('now', new \DateTimeZone($this->localeSettings->getTimeZone()));
        $currentYear = (int) $currentDate->format('Y');

        if ($fundYear === $currentYear) {
            $this->updateCustomerData(
                $customer,
                (float)$allocated,
                (float)$pending,
                (float)$remaining,
                (float)$spent
            );
        } else {
            /** @var BusinessDevelopmentFund|null $businessDevelopmentFund */
            $businessDevelopmentFund = $this->doctrineHelper
                ->getEntityRepository(BusinessDevelopmentFund::class)
                ->findOneBy([
                    'fundYear' => $currentYear,
                    'customer' => $customer
                ]);
            if ($businessDevelopmentFund) {
                $allocated = $this->dataProvider->getFundsAllocated($businessDevelopmentFund);
                $pending = $this->dataProvider->getFundsPending($businessDevelopmentFund);
                $spent = $this->dataProvider->getFundsSpent($businessDevelopmentFund);
                $remaining = $this->dataProvider->getFundsRemaining($businessDevelopmentFund);
                $this->updateCustomerData(
                    $customer,
                    $allocated,
                    $pending,
                    $remaining,
                    $spent
                );
            } else {
                $this->updateCustomerData($customer, 0, 0, 0, 0);
            }
        }
    }

    /**
     * @param array $messageData
     */
    protected function validateMessageData(array $messageData): void
    {
        if (!isset($messageData['fund_year']) || !isset($messageData['customer_id'])) {
            throw new \InvalidArgumentException(
                'Invalid message - it should contain `fund_year` and `customer_id` properties'
            );
        }
    }

    /**
     * @param Customer $customer
     * @param float $allocated
     * @param float $pending
     * @param float $remaining
     * @param float $spent
     */
    protected function updateCustomerData(
        Customer $customer,
        float $allocated,
        float $pending,
        float $remaining,
        float $spent
    ): void {
        $customer->setDtCoOpFundsAllocated($allocated);
        $customer->setDtCoOpFundsPending($pending);
        $customer->setDtCoOpFundsRemaining($remaining);
        $customer->setDtCoOpFundsSpend($spent);
        $entityManager = $this->doctrineHelper
            ->getEntityManager(Customer::class);
        $entityManager->persist($customer);
        $entityManager->flush($customer);
    }

    /**
     * @param int $fundYear
     * @param Customer $customer
     * @param float $allocated
     * @param float $pending
     * @param float $spent
     * @param float $remaining
     */
    protected function updateCoOpRequestData(
        int $fundYear,
        Customer $customer,
        float $allocated,
        float $pending,
        float $spent,
        float $remaining
    ): void {
        $coOpRequests = $this->doctrineHelper
            ->getEntityRepository(CoOpRequest::class)
            ->findBy([
                'fundYear' => $fundYear,
                'customer' => $customer
            ]);

        $entityManager = $this->doctrineHelper
            ->getEntityManager(CoOpRequest::class);

        /** @var CoOpRequest $coOpRequestItem */
        foreach ($coOpRequests as $coOpRequestItem) {
            $coOpRequestItem
                ->setFundsAllocated($allocated)
                ->setFundsPending($pending)
                ->setFundsSpent($spent)
                ->setFundsRemaining($remaining)
                ->setFundsNotCommittedOrPending($allocated - $pending - $spent);
            $entityManager->persist($coOpRequestItem);
        }

        $entityManager->flush();
    }
}
