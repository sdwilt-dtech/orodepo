<?php

namespace DT\Bundle\CustomerServiceBundle\Provider;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\EntityBundle\Entity\BusinessDevelopmentFund;
use DT\Bundle\EntityBundle\Entity\CoOpRequest;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;

class BusinessDevelopmentFundDataProvider
{
    protected array $fundsAllocated = [];
    protected array $fundsPending = [];
    protected array $fundsRemaining = [];
    protected array $fundsSpent = [];

    protected ManagerRegistry $doctrine;

    /**
     * @param ManagerRegistry $doctrine
     */
    public function __construct(ManagerRegistry $doctrine)
    {
        $this->doctrine = $doctrine;
    }

    /**
     * @param BusinessDevelopmentFund $businessDevelopmentFund
     * @return float
     */
    public function getFundsAllocated(BusinessDevelopmentFund $businessDevelopmentFund): float
    {
        $id = $businessDevelopmentFund->getId();
        if (!isset($this->fundsAllocated[$id])) {
            /** @var Customer $customer */
            $customer = $businessDevelopmentFund->getCustomer();
            $billingType = $customer->getDtBillingType()
                ? $customer->getDtBillingType()->getId()
                : null;
            $customer = $billingType === EnumValues::DT_CUSTOMER_BILLING_TYPE_S ? $customer->getParent() : $customer;
            $type = $businessDevelopmentFund->getCalculatedFundType()->getId();
            $customer = $this->getCustomer($customer, $type);

            $purchases = $businessDevelopmentFund->getPriorYearNetPurchases() ?? (float) 0;
            $coOpFundsPercentage = 0;
            if ($customer) {
                $coOpFundsPercentage = $customer->getDtCoOpFundsPercentage() ?? 0;
            }

            $this->fundsAllocated[$id] = $coOpFundsPercentage * $purchases;
        }

        return $this->fundsAllocated[$id];
    }

    /**
     * @param BusinessDevelopmentFund $businessDevelopmentFund
     * @return float
     */
    public function getFundsPending(BusinessDevelopmentFund $businessDevelopmentFund): float
    {
        $id = $businessDevelopmentFund->getId();
        if (!isset($this->fundsPending[$id])) {
            $sumOfPendingRequests = $this->doctrine
                ->getRepository(CoOpRequest::class)
                ->getSumOfPendingRequests(
                    $businessDevelopmentFund->getFundYear(),
                    $businessDevelopmentFund->getCustomer()
                );

            $this->fundsPending[$id] = $sumOfPendingRequests ?? 0;
        }

        return $this->fundsPending[$id];
    }

    /**
     * @param BusinessDevelopmentFund $businessDevelopmentFund
     * @return float
     */
    public function getFundsRemaining(BusinessDevelopmentFund $businessDevelopmentFund): float
    {
        $id = $businessDevelopmentFund->getId();
        if (!isset($this->fundsRemaining[$id])) {
            $allocated = $this->getFundsAllocated($businessDevelopmentFund);
            $pending = $this->getFundsPending($businessDevelopmentFund);
            $spent = $this->getFundsSpent($businessDevelopmentFund);
            $this->fundsRemaining[$id] = $allocated - $pending - $spent;
        }

        return $this->fundsRemaining[$id];
    }

    /**
     * @param BusinessDevelopmentFund $businessDevelopmentFund
     * @return float
     */
    public function getFundsSpent(BusinessDevelopmentFund $businessDevelopmentFund): float
    {
        $id = $businessDevelopmentFund->getId();
        if (!isset($this->fundsSpent[$id])) {
            $fundsSpend = $this->doctrine
                ->getRepository(CoOpRequest::class)
                ->getSumOfSpentRequests(
                    $businessDevelopmentFund->getFundYear(),
                    $businessDevelopmentFund->getCustomer()
                );

            $this->fundsSpent[$id] = $fundsSpend ?? 0;
        }

        return $this->fundsSpent[$id];
    }

    /**
     * @param BusinessDevelopmentFund $businessDevelopmentFund
     * @return string
     */
    public function getMaxFundAllocated(BusinessDevelopmentFund $businessDevelopmentFund)
    {
        $purchases = $businessDevelopmentFund->getPriorYearNetPurchases() ?? (float) 0;
        /** @var Customer $customer */
        $customer = $businessDevelopmentFund->getCustomer();
        $billingType = $customer->getDtBillingType()
            ? $customer->getDtBillingType()->getId()
            : null;

        $customer = $billingType === EnumValues::DT_CUSTOMER_BILLING_TYPE_S && $customer->getParent() ?
            $customer->getParent() :
            $customer;
        //Customer type level
        $max = $customer->getDtCoOpFundsPercentage() * $purchases;
        $result = $customer->getDtEntityType()->getName();

        //run through the Sub, Rollup and Group types
        for ($i = 0; $i < 3; $i++) {
            if (!$customer->getParent()) {
                return $result;
            }
            $customer = $customer->getParent();
            $fund = $customer->getDtCoOpFundsPercentage() * $purchases;
            if ($max < $fund) {
                $max = $fund;
                $result = $customer->getDtEntityType()->getName();
            }
        }

        return $result;
    }

    /**
     * @param Customer $customer
     * @return string|null
     */
    protected function getCustomerEntityType(Customer $customer)
    {
        return $customer->getDtEntityType()
            ? $customer->getDtEntityType()->getId()
            : null;
    }

    /**
     * @param Customer|null $customer
     * @param string $type
     * @return Customer|null
     */
    protected function getCustomer(?Customer $customer, string $type): ?Customer
    {
        //get customer from Customers Hierarchy with the same type as BFD
        for ($i = 0; $i < 3; $i++) {
            if (null === $customer || $this->getCustomerEntityType($customer) === $type) {
                return $customer;
            }

            $customer = $customer->getParent();
        }

        return $customer;
    }
}
