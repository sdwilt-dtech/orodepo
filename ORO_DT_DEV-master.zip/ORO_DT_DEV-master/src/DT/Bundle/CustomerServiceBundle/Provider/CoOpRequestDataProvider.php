<?php

namespace DT\Bundle\CustomerServiceBundle\Provider;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\CustomerServiceBundle\Validator\Constraints\CoOpRequestCustomerValidator;
use DT\Bundle\EntityBundle\Entity\CoOpRequest;
use Oro\Bundle\AttachmentBundle\Entity\Attachment;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;

class CoOpRequestDataProvider
{
    public const REASON_EMPTY_REQUESTED_AMOUNT = 'empty_requested_amount';
    public const REASON_NOT_VALID_REGION = 'not_valid_region';
    public const REASON_NO_FUNDS_ALLOCATED = 'no_funds_allocated';
    public const REASON_NO_ACTIVITIES_SELECTED = 'no_activities_selected';
    public const REASON_NO_ATTACHMENTS = 'no_attachments';

    /** @var ManagerRegistry */
    protected $doctrine;

    /**
     * @param ManagerRegistry $doctrine
     */
    public function __construct(
        ManagerRegistry $doctrine
    ) {
        $this->doctrine = $doctrine;
    }

    /**
     * Returns array of reasons why Submit For Approval can not be performed.
     *
     * @param CoOpRequest $coOpRequest
     * @return array
     */
    public function getSubmitForApprovalRestrictedReasons(CoOpRequest $coOpRequest): array
    {
        $reasons = [];

        if (round($coOpRequest->getAmountRequested(), 4) === 0.0000) {
            $reasons[] = self::REASON_EMPTY_REQUESTED_AMOUNT;
        }

        $region = null;

        if ($coOpRequest->getCustomer() && $coOpRequest->getCustomer()->getDtRegion()) {
            $region = $coOpRequest->getCustomer()->getDtRegion()->getJdeId();
        }

        if (!in_array($region, CoOpRequestCustomerValidator::CUSTOMER_VALID_REGIONS, true)) {
            $reasons[] = self::REASON_NOT_VALID_REGION;
        }

        if (round($coOpRequest->getFundsAllocated(), 4) === 0.0000) {
            $reasons[] = self::REASON_NO_FUNDS_ALLOCATED;
        }

        if (!$coOpRequest->getActivities()->count()) {
            $reasons[] = self::REASON_NO_ACTIVITIES_SELECTED;
        }

        if (!$this->coOpRequestHasAttachment($coOpRequest)) {
            $reasons[] = self::REASON_NO_ATTACHMENTS;
        }

        return $reasons;
    }

    /**
     * @param CoOpRequest $coOpRequest
     * @return bool
     */
    protected function coOpRequestHasAttachment(CoOpRequest $coOpRequest): bool
    {
        $fieldName = ExtendHelper::buildAssociationName(CoOpRequest::class);

        /**
         * It enough to get a single entity to say that entity has any attachments or no
         */
        /** @var Attachment $attachment */
        $attachment = $this->doctrine
            ->getRepository(Attachment::class)
            ->findOneBy(
                [
                    $fieldName => $coOpRequest->getId()
                ]
            );

        return null !== $attachment;
    }

    /**
     * @param CoOpRequest $coOpRequest
     * @return float
     */
    public function calculateAmountAvailable(CoOpRequest $coOpRequest): float
    {
        return $coOpRequest->getFundsRemaining() + $coOpRequest->getAmountRequested();
    }
}
