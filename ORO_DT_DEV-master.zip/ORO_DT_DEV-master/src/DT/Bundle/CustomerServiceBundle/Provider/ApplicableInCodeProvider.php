<?php

namespace DT\Bundle\CustomerServiceBundle\Provider;

use Doctrine\Bundle\DoctrineBundle\Registry;
use DT\Bundle\EntityBundle\Entity\InCode;
use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\EntityBundle\Entity\Repository\InCodeRepository;
use DT\Bundle\SetupBundle\Model\EnumValues;

class ApplicableInCodeProvider
{
    protected Registry $registry;

    /**
     * @param Registry $registry
     */
    public function __construct(Registry $registry)
    {
        $this->registry = $registry;
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return InCode|null
     */
    public function getInCodeByOrderErrorCase(OrderErrorCase $orderErrorCase): ?InCode
    {
        if (null === $orderErrorCase->getCreditRequestReason()) {
            return null;
        }

        $creditRequestReasonId = $orderErrorCase->getCreditRequestReason()->getId();
        $inCodeRepository = $this->getInCodeRepository();
        $inCodeId = $inCodeRepository->getMatchedSingleActiveInCodeId(
            $creditRequestReasonId,
            $this->getReplaceCodeIdsByOrderErrorRequest($orderErrorCase),
            $this->getReturnCodeIdsByOrderErrorRequest($orderErrorCase)
        );

        if (null === $inCodeId) {
            return null;
        }

        return $this->registry->getManagerForClass(InCode::class)->getReference(InCode::class, $inCodeId);
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return array
     */
    protected function getReturnCodeIdsByOrderErrorRequest(OrderErrorCase $orderErrorCase): array
    {
        if (null === $orderErrorCase->getIsReturn()) {
            return [EnumValues::DT_IN_CODE_RETURN_NOT_APPLICABLE];
        }

        if ($orderErrorCase->getIsReturn()) {
            return [EnumValues::DT_IN_CODE_RETURN_NOT_APPLICABLE, EnumValues::DT_IN_CODE_RETURN_YES];
        }

        return [EnumValues::DT_IN_CODE_RETURN_NOT_APPLICABLE, EnumValues::DT_IN_CODE_RETURN_NO];
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @return array
     */
    protected function getReplaceCodeIdsByOrderErrorRequest(OrderErrorCase $orderErrorCase): array
    {
        if (null === $orderErrorCase->getIsReplace()) {
            return [EnumValues::DT_IN_CODE_REPLACE_NOT_APPLICABLE];
        }

        if ($orderErrorCase->getIsReplace()) {
            return [EnumValues::DT_IN_CODE_REPLACE_NOT_APPLICABLE, EnumValues::DT_IN_CODE_REPLACE_YES];
        }

        return [EnumValues::DT_IN_CODE_REPLACE_NOT_APPLICABLE, EnumValues::DT_IN_CODE_REPLACE_NO];
    }

    /**
     * @return InCodeRepository
     */
    protected function getInCodeRepository(): InCodeRepository
    {
        return $this->registry->getRepository(InCode::class);
    }
}
