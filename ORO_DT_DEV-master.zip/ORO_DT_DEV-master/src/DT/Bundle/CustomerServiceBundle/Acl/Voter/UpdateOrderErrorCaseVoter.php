<?php

namespace DT\Bundle\CustomerServiceBundle\Acl\Voter;

use DT\Bundle\EntityBundle\Entity\OrderErrorCase;
use DT\Bundle\EntityBundle\Entity\OrderErrorCaseLineItem;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\AttachmentBundle\Entity\Attachment;
use Oro\Bundle\SecurityBundle\Acl\BasicPermission;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Security\Acl\Domain\ObjectIdentity;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\VoterInterface;

class UpdateOrderErrorCaseVoter implements VoterInterface
{
    /** @var string[] */
    protected $disabledUpdateStatusIds = [
        EnumValues::DT_ORDER_ERROR_CASE_STATUS_SUBMITTED,
        EnumValues::DT_ORDER_ERROR_CASE_STATUS_CLOSED,
    ];

    /**
     * @var RequestStack
     */
    protected $requestStack;

    /**
     * @param RequestStack $requestStack
     */
    public function __construct(RequestStack $requestStack)
    {
        $this->requestStack = $requestStack;
    }

    /**
     * @param TokenInterface $token
     * @param mixed $object
     * @param array $attributes
     * @return int|void
     */
    public function vote(TokenInterface $token, $object, array $attributes)
    {
        /**
         * Forbids adding/changing/removing attachments on view page, it's part of update logic
         */
        if ($object instanceof ObjectIdentity) {
            return $this->processVotingForObjectIdentity($object, $attributes);
        }

        /**
         * In case when OrderErrorCaseLineItem doesn't allow to edit,
         * then OrderErrorCaseLineItem also must be closed on edit
         */
        if ($object instanceof OrderErrorCaseLineItem && $object->getOrderErrorCase()) {
            $object = $object->getOrderErrorCase();
        }

        if (!$object instanceof OrderErrorCase || null === $object->getStatus()) {
            return self::ACCESS_ABSTAIN;
        }

        if (!\in_array(BasicPermission::EDIT, $attributes, true)) {
            return self::ACCESS_ABSTAIN;
        }

        if (\in_array($object->getStatus()->getId(), $this->disabledUpdateStatusIds, true)) {
            return self::ACCESS_DENIED;
        }

        return self::ACCESS_ABSTAIN;
    }

    /**
     * @param ObjectIdentity $objectIdentity
     * @param array $attributes
     * @return int
     */
    protected function processVotingForObjectIdentity(ObjectIdentity $objectIdentity, array $attributes): int
    {
        $masterRequest = $this->requestStack->getMasterRequest();
        if ($masterRequest &&
            $objectIdentity->getType() === Attachment::class &&
            $masterRequest->get('_route') === 'dt_cs_order_error_case_view' &&
            $masterRequest->attributes->get('orderErrorCase') instanceof OrderErrorCase) {
            return $this->voteForOrderErrorCaseAttachmentPermissions(
                $masterRequest->attributes->get('orderErrorCase'),
                $attributes
            );
        }

        return self::ACCESS_ABSTAIN;
    }

    /**
     * @param OrderErrorCase $orderErrorCase
     * @param array $attributes
     * @return int
     */
    protected function voteForOrderErrorCaseAttachmentPermissions(
        OrderErrorCase $orderErrorCase,
        array $attributes
    ): int {
        if (null === $orderErrorCase->getStatus()) {
            return self::ACCESS_ABSTAIN;
        }

        $targetStatuses = \array_intersect(
            [BasicPermission::EDIT, BasicPermission::CREATE, BasicPermission::DELETE],
            $attributes
        );

        if (0 === count($targetStatuses)) {
            return self::ACCESS_ABSTAIN;
        }

        if (\in_array($orderErrorCase->getStatus()->getId(), $this->disabledUpdateStatusIds, true)) {
            return self::ACCESS_DENIED;
        }

        return self::ACCESS_ABSTAIN;
    }
}
