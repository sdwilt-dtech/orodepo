<?php

namespace DT\Bundle\CustomerServiceBundle\Acl\Voter;

use DT\Bundle\EntityBundle\Entity\WarrantyClaim;
use DT\Bundle\EntityBundle\Entity\WarrantyProductClaimItem;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\AttachmentBundle\Entity\Attachment;
use Oro\Bundle\SecurityBundle\Acl\BasicPermission;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Security\Acl\Domain\ObjectIdentity;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\VoterInterface;

class UpdateWarrantyClaimVoter implements VoterInterface
{
    /** @var string[] */
    protected $disabledUpdateStatusIds = [
        EnumValues::DT_WARRANTY_CLAIM_STATUS_PENDING_APPROVAL,
        EnumValues::DT_WARRANTY_CLAIM_STATUS_APPROVED,
        EnumValues::DT_WARRANTY_CLAIM_STATUS_DECLINED,
        EnumValues::DT_WARRANTY_CLAIM_STATUS_CLOSED,
    ];

    protected RequestStack $requestStack;

    /**
     * @param RequestStack $requestStack
     */
    public function __construct(RequestStack $requestStack)
    {
        $this->requestStack = $requestStack;
    }

    /**
     * @param TokenInterface $token
     * @param mixed $object
     * @param array $attributes
     * @return int|void
     */
    public function vote(TokenInterface $token, $object, array $attributes)
    {
        /**
         * Forbids adding/changing/removing attachments on view page, it's part of update logic
         */
        if ($object instanceof ObjectIdentity) {
            return $this->processVotingForObjectIdentity($object, $attributes);
        }

        /**
         * In case when WarrantyClaim doesn't allow to edit,
         * then WarrantyProductClaimItem also must be closed on edit
         */
        if ($object instanceof WarrantyProductClaimItem && $object->getWarrantyClaim()) {
            $object = $object->getWarrantyClaim();
        }

        if (!$object instanceof WarrantyClaim || null === $object->getStatus()) {
            return self::ACCESS_ABSTAIN;
        }

        if (!\in_array(BasicPermission::EDIT, $attributes, true)) {
            return self::ACCESS_ABSTAIN;
        }

        if (\in_array($object->getStatus()->getId(), $this->disabledUpdateStatusIds, true)) {
            return self::ACCESS_DENIED;
        }

        return self::ACCESS_ABSTAIN;
    }

    /**
     * @param ObjectIdentity $objectIdentity
     * @param array $attributes
     * @return int
     */
    protected function processVotingForObjectIdentity(ObjectIdentity $objectIdentity, array $attributes): int
    {
        $masterRequest = $this->requestStack->getMasterRequest();
        if ($masterRequest &&
            $objectIdentity->getType() === Attachment::class &&
            $masterRequest->get('_route') === 'dt_cs_warranty_claim_view' &&
            $masterRequest->attributes->get('warrantyClaim') instanceof WarrantyClaim) {
            return $this->voteForWarrantyClaimAttachmentPermissions(
                $masterRequest->attributes->get('warrantyClaim'),
                $attributes
            );
        }

        return self::ACCESS_ABSTAIN;
    }

    /**
     * @param WarrantyClaim $warrantyClaim
     * @param array $attributes
     * @return int
     */
    protected function voteForWarrantyClaimAttachmentPermissions(WarrantyClaim $warrantyClaim, array $attributes): int
    {
        if (null === $warrantyClaim->getStatus()) {
            return self::ACCESS_ABSTAIN;
        }

        $targetStatuses = \array_intersect(
            [BasicPermission::EDIT, BasicPermission::CREATE, BasicPermission::DELETE],
            $attributes
        );

        if (0 === count($targetStatuses)) {
            return self::ACCESS_ABSTAIN;
        }

        if (\in_array($warrantyClaim->getStatus()->getId(), $this->disabledUpdateStatusIds, true)) {
            return self::ACCESS_DENIED;
        }

        return self::ACCESS_ABSTAIN;
    }
}
