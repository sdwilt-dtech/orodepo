<?php

namespace DT\Bundle\CustomerServiceBundle\Acl\Voter;

use DT\Bundle\EntityBundle\Entity\CoOpRequest;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\AttachmentBundle\Entity\Attachment;
use Oro\Bundle\SecurityBundle\Acl\BasicPermission;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Security\Acl\Domain\ObjectIdentity;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\VoterInterface;

class UpdateCoOpRequestVoter implements VoterInterface
{
    /** @var string[] */
    protected $disabledUpdateStatusIds = [
        EnumValues::DT_CO_OP_REQUEST_STATUS_PENDING_APPROVAL,
        EnumValues::DT_CO_OP_REQUEST_STATUS_CLOSED,
        EnumValues::DT_CO_OP_REQUEST_STATUS_APPROVED,
        EnumValues::DT_CO_OP_REQUEST_STATUS_REJECTED,
    ];

    protected RequestStack $requestStack;

    /**
     * @param RequestStack $requestStack
     */
    public function __construct(RequestStack $requestStack)
    {
        $this->requestStack = $requestStack;
    }

    /**
     * @param TokenInterface $token
     * @param mixed $object
     * @param array $attributes
     * @return int|void
     */
    public function vote(TokenInterface $token, $object, array $attributes)
    {
        /**
         * Forbids adding/changing/removing attachments on view page, it's part of update logic
         */
        if ($object instanceof ObjectIdentity) {
            return $this->processVotingForObjectIdentity($object, $attributes);
        }

        if (!$object instanceof CoOpRequest) {
            return self::ACCESS_ABSTAIN;
        }

        if ($object->getStatus() === null || !\in_array(BasicPermission::EDIT, $attributes, true)) {
            return self::ACCESS_ABSTAIN;
        }

        if (\in_array($object->getStatus()->getId(), $this->disabledUpdateStatusIds, true)) {
            return self::ACCESS_DENIED;
        }

        return self::ACCESS_ABSTAIN;
    }

    /**
     * @param ObjectIdentity $objectIdentity
     * @param array $attributes
     * @return int
     */
    protected function processVotingForObjectIdentity(ObjectIdentity $objectIdentity, array $attributes): int
    {
        $masterRequest = $this->requestStack->getMasterRequest();
        if ($masterRequest &&
            $objectIdentity->getType() === Attachment::class &&
            $masterRequest->get('_route') === 'dt_cs_co_op_request_view' &&
            $masterRequest->attributes->get('coOpRequest') instanceof CoOpRequest) {
            return $this->voteForCoOpRequestAttachmentPermissions(
                $masterRequest->attributes->get('coOpRequest'),
                $attributes
            );
        }

        return self::ACCESS_ABSTAIN;
    }

    /**
     * @param CoOpRequest $coOpRequest
     * @param array $attributes
     * @return int
     */
    protected function voteForCoOpRequestAttachmentPermissions(CoOpRequest $coOpRequest, array $attributes): int
    {
        if (null === $coOpRequest->getStatus()) {
            return self::ACCESS_ABSTAIN;
        }

        $targetStatuses = \array_intersect(
            [BasicPermission::EDIT, BasicPermission::CREATE, BasicPermission::DELETE],
            $attributes
        );

        if (0 === count($targetStatuses)) {
            return self::ACCESS_ABSTAIN;
        }

        if (\in_array($coOpRequest->getStatus()->getId(), $this->disabledUpdateStatusIds, true)) {
            return self::ACCESS_DENIED;
        }

        return self::ACCESS_ABSTAIN;
    }
}
