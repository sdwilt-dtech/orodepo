<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerServiceBundle\Migrations\Data\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use DT\Bundle\EntityBundle\Entity\QualityCase;
use Oro\Bundle\EmailBundle\Entity\EmailTemplate;
use Oro\Bundle\MigrationBundle\Fixture\VersionedFixtureInterface;
use Oro\Bundle\NotificationBundle\Entity\EmailNotification;
use Oro\Bundle\NotificationBundle\Entity\Event;
use Oro\Bundle\NotificationBundle\Entity\RecipientList;
use Oro\Bundle\WorkflowBundle\Entity\WorkflowDefinition;
use Oro\Bundle\WorkflowBundle\Migrations\Data\ORM\LoadWorkflowNotificationEvents;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerAwareTrait;

class LoadQualityCaseWorkflowNotificationRules extends AbstractFixture implements
    DependentFixtureInterface,
    ContainerAwareInterface,
    VersionedFixtureInterface
{
    use ContainerAwareTrait;
    const WORKFLOW_NAME = 'quality_case_flow';

    protected static array $notificationRulesData = [
        [
            'template' => 'dt_qc_sent_to_quality',
            'transition' => 'send_to_quality',
            'email' => 'kris@example.com',
            'email_association' => null,
        ],
        [
            'template' => 'dt_qc_acknowledged',
            'transition' => 'require_acknowledge',
            'email' => null,
            'email_association' => ['csr'],
        ],
        [
            'template' => 'dt_qc_rma_received',
            'transition' => 'assign_rma',
            'email' => null,
            'email_association' => ['qualityTeamMember'],
        ],
        [
            'template' => 'dt_qc_engineering_review_required',
            'transition' => 'start_engineering_review',
            'email' => 'generic@example.com',
            'email_association' => null,
        ],
        [
            'template' => 'dt_qc_engineering_review_complete',
            'transition' => 'finish_engineering_review',
            'email' => null,
            'email_association' => ['qualityTeamMember'],
        ],
        [
            'template' => 'dt_qc_investigation_completed',
            'transition' => 'finish_investigation',
            'email' => null,
            'email_association' => ['csr'],
        ],
    ];

    /**
     * {@inheritdoc}
     */
    public function getDependencies()
    {
        return [LoadQualityCaseEmailTemplates::class];
    }

    /**
     * {@inheritdoc}
     */
    public function getVersion()
    {
        return '1.0';
    }

    /**
     * {@inheritdoc}
     */
    public function load(ObjectManager $manager)
    {
        $event = $this->getEvent($manager);
        $workflow = $this->getWorkflowDefinition($manager);

        foreach (self::$notificationRulesData as $data) {
            $emailTemplate = $this->getEmailTemplate($manager, $data['template']);

            $recipientList = new RecipientList();
            if ($data['email']) {
                $recipientList->setEmail($data['email']);
            }
            if ($data['email_association']) {
                $recipientList->setAdditionalEmailAssociations($data['email_association']);
            }

            $manager->persist($recipientList);

            $entity = new EmailNotification();
            $entity->setEntityName(QualityCase::class)
                ->setEvent($event)
                ->setTemplate($emailTemplate)
                ->setRecipientList($recipientList)
                ->setWorkflowDefinition($workflow)
                ->setWorkflowTransitionName($data['transition']);

            $manager->persist($entity);
        }

        $manager->flush();
    }

    /**
     * @param ObjectManager $manager
     *
     * @return object|WorkflowDefinition
     */
    private function getWorkflowDefinition(ObjectManager $manager)
    {
        $workflow = $manager->getRepository(WorkflowDefinition::class)->findOneBy(['name' => self::WORKFLOW_NAME]);

        if (!$workflow) {
            throw new \RuntimeException(sprintf('Required workflow definition "%s" not found', self::WORKFLOW_NAME));
        }

        return $workflow;
    }

    /**
     * @param ObjectManager $manager
     *
     * @return object|Event
     */
    private function getEvent(ObjectManager $manager)
    {
        $event = $manager->getRepository(Event::class)
            ->findOneBy(['name' => LoadWorkflowNotificationEvents::TRANSIT_EVENT]);

        if (!$event) {
            throw new \RuntimeException(
                sprintf('Required notification event "%s" not found', LoadWorkflowNotificationEvents::TRANSIT_EVENT)
            );
        }

        return $event;
    }

    /**
     * @param ObjectManager $manager
     * @param string $templateName
     *
     * @return object|EmailTemplate
     */
    private function getEmailTemplate(ObjectManager $manager, $templateName)
    {
        $template = $manager->getRepository(EmailTemplate::class)->findOneBy(['name' => $templateName]);

        if (!$template) {
            throw new \RuntimeException(sprintf('Required email template "%s" not found', $templateName));
        }

        return $template;
    }
}
