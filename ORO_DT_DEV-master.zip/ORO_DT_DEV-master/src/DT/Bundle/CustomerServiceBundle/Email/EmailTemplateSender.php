<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerServiceBundle\Email;

use Doctrine\Persistence\ManagerRegistry;
use Oro\Bundle\ConfigBundle\Config\ConfigManager;
use Oro\Bundle\EmailBundle\Async\Topics;
use Oro\Bundle\EmailBundle\Tools\EmailAddressHelper;
use Oro\Component\MessageQueue\Client\MessageProducerInterface;
use Oro\Component\MessageQueue\Transport\Exception\Exception;
use Symfony\Component\Security\Acl\Util\ClassUtils;

class EmailTemplateSender
{
    private MessageProducerInterface $messageProducer;

    private ConfigManager $configManager;

    private ManagerRegistry $registry;

    private EmailAddressHelper $emailAddressHelper;

    public function __construct(
        MessageProducerInterface $messageProducer,
        ConfigManager $configManager,
        ManagerRegistry $registry,
        EmailAddressHelper $emailAddressHelper
    ) {
        $this->messageProducer = $messageProducer;
        $this->configManager = $configManager;
        $this->registry = $registry;
        $this->emailAddressHelper = $emailAddressHelper;
    }

    /**
     * @throws Exception
     */
    public function send($entity, string $template, array $recipients)
    {
        $senderEmail = $this->configManager->get('oro_notification.email_notification_sender_email');
        $senderName = $this->configManager->get('oro_notification.email_notification_sender_name');

        foreach ($recipients as $recipient) {
            $this->messageProducer->send(
                Topics::SEND_EMAIL_TEMPLATE,
                [
                    'from' => $this->emailAddressHelper->buildFullEmailAddress($senderEmail, $senderName),
                    'templateName' => $template,
                    'recipients' => [$recipient],
                    'entity' => [ClassUtils::getRealClass($entity), $this->getEntityIdentifier($entity)],
                ]
            );
        }
    }

    /**
     * @param $entity
     *
     * @return mixed|null
     */
    private function getEntityIdentifier($entity)
    {
        if (method_exists($entity, 'getId')) {
            return $entity->getId();
        }

        $className = ClassUtils::getRealClass($entity);
        $classMetadata = $this->registry->getManagerForClass($className)->getClassMetadata($className);
        $identifier = $classMetadata->getIdentifierValues($entity);

        return $identifier ? reset($identifier) : null;
    }
}
