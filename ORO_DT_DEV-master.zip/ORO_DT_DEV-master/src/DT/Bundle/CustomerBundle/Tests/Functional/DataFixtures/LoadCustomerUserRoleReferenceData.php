<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerBundle\Tests\Functional\DataFixtures;

use Doctrine\Common\Persistence\ObjectManager;
use Oro\Bundle\CustomerBundle\Entity\CustomerUserRole;
use Oro\Component\Test\DataFixtures\AbstractFixture;

class LoadCustomerUserRoleReferenceData extends AbstractFixture
{
    /**
     * {@inheritdoc}
     */
    public function load(ObjectManager $manager)
    {
        $roles = $manager->getRepository(CustomerUserRole::class)->findAll();

        /** @var CustomerUserRole $role */
        foreach ($roles as $role) {
            $this->setReference(sprintf('dt_customer.role.%s', $role->getRole()), $role);
        }
    }
}
