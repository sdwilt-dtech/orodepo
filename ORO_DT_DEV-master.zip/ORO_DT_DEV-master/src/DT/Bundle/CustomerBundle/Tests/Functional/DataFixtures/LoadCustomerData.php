<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerBundle\Tests\Functional\DataFixtures;

use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use DT\Bundle\EntityBundle\Tests\Functional\DataFixtures\AbstractYmlFixture;
use DT\Bundle\EntityBundle\Tests\Functional\DataFixtures\LoadCommissionScheduleData;
use DT\Bundle\EntityBundle\Tests\Functional\DataFixtures\LoadEnumReferences;

class LoadCustomerData extends AbstractYmlFixture implements DependentFixtureInterface
{
    protected function getFilename(): string
    {
        return __DIR__ . '/data/customer.yml';
    }

    /**
     * {@inheritdoc}
     */
    public function getDependencies()
    {
        return [
            LoadEnumReferences::class,
            LoadCommissionScheduleData::class,
        ];
    }
}
