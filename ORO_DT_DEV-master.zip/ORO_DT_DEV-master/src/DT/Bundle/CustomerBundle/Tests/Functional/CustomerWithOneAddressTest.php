<?php

namespace DT\Bundle\CustomerBundle\Tests\Functional;

use Doctrine\ORM\EntityManager;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use Oro\Bundle\AddressBundle\Tests\Functional\DataFixtures\LoadAddressTypes;
use Oro\Bundle\AddressBundle\Tests\Functional\DataFixtures\LoadCountriesAndRegions;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\CustomerBundle\Entity\CustomerAddress;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\TestFrameworkBundle\Test\WebTestCase;
use Oro\Bundle\TestFrameworkBundle\Tests\Functional\DataFixtures\LoadUser;
use Oro\Bundle\UserBundle\Entity\User;

/**
 * @dbIsolationPerTest
 */
class CustomerWithOneAddressTest extends WebTestCase
{
    protected function setUp()
    {
        $this->initClient();
        $this->loadFixtures([
            LoadUser::class, LoadCountriesAndRegions::class, LoadAddressTypes::class
        ]);
    }

    /**
     * @expectedException \Doctrine\DBAL\Exception\UniqueConstraintViolationException
     * @expectedExceptionMessageRegExp /oro_customer_address_frontend_owner_id_uidx/
     */
    public function testCustomerAddressFrontendOwnerDbUniqueConstraint()
    {
        [$customer, $address1, $address2] = $this->getGenericCustomerDataSet();

        $customer->addAddress($address1);
        $customer->addAddress($address2);

        $em = $this->getEntityManager();

        $em->persist($address1);
        $em->persist($address2);
        $em->persist($customer);
        $em->flush();
    }

    public function testCustomerAddressFrontendOwnerUniqueConstraint()
    {
        [$customer, $address1, $address2] = $this->getGenericCustomerDataSet();

        $customer->addAddress($address1);

        $em = $this->getEntityManager();

        $em->persist($address1);
        $em->persist($customer);
        $em->flush();

        $customer->addAddress($address2);

        $violationsList = $this->getValidator()->validate($address2, null, ['Default']);
        self::assertContains('Customer can have only one address', (string)$violationsList);
    }

    /**
     * @dataProvider customerNameToAddressOrganizationDataProvider
     * @param string $customerName
     */
    public function testCustomerAddressOrganizationIsSetAccordingToCustomerName(string $customerName)
    {
        [$customer, $address] = $this->getGenericCustomerDataSet();

        $em = $this->getEntityManager();

        $customer->setName($customerName);
        $customer->addAddress($address);

        $em->persist($address);
        $em->persist($customer);
        $em->flush();

        self::assertEquals($address->getOrganization(), $customer->getName());
    }

    /**
     * @return array
     */
    public function customerNameToAddressOrganizationDataProvider(): array
    {
        return [
            ['Customer First'],
            ['Customer Second'],
            ['Customer Third']
        ];
    }

    /**
     * @dataProvider customerAddressTypeIsSetAccordingToCustomerNameDataProvider
     * @param string $customerBillingTypeCode
     * @param array $expectedAddressTypeNames
     */
    public function testCustomerAddressTypeIsSetAccordingToCustomerName(
        string $customerBillingTypeCode,
        array $expectedAddressTypeNames
    ) {
        [$customer, $address] = $this->getGenericCustomerDataSet();

        $em = $this->getEntityManager();

        $className = ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_BILLING_TYPE);
        $customerBillingType = $em->getRepository($className)->find($customerBillingTypeCode);

        // checking automatic address type setup on customer with dt_entity type 'group'
        $className = ExtendHelper::buildEnumValueClassName(ReservedEnumCodes::DT_CUSTOMER_ENTITY_TYPE);
        $customerEntityType = $em->getRepository($className)->find('group');

        $customer->setDtBillingType($customerBillingType);
        $customer->setDtEntityType($customerEntityType);
        $customer->addAddress($address);

        $em->persist($address);
        $em->persist($customer);
        $em->flush();

        $actualAddressTypeNames= [];
        foreach ($address->getTypes() as $addressType) {
            $actualAddressTypeNames[] = $addressType->getName();
        }

        self::assertEquals(asort($expectedAddressTypeNames), asort($actualAddressTypeNames));
    }

    /**
     * @return array
     */
    public function customerAddressTypeIsSetAccordingToCustomerNameDataProvider(): array
    {
        return [
            ['S', ['shipping']],
            ['B', ['billing']],
            ['X', ['shipping', 'billing']],
            ['Z', []]
        ];
    }

    /**
     * @return array
     */
    private function getGenericCustomerDataSet(): array
    {
        /** @var User $owner */
        $owner = $this->getReference('user');

        $customer = new Customer();
        $customer->setName('Customer 1');
        $customer->setOwner($owner);
        $customer->setOrganization($owner->getOrganization());

        $address1 = new CustomerAddress();
        $address1->setCountry($this->getReference('country_usa'))
            ->setRegion($this->getReference('region_usa_california'))
            ->setCity('New York')
            ->setPostalCode('23412');

        $address2 = new CustomerAddress();
        $address2->setCountry($this->getReference('country_usa'))
            ->setFirstName('First Name 2')
            ->setLastName('Last Name 2')
            ->setStreet('Street Name, 123')
            ->setRegion($this->getReference('region_usa_california'))
            ->setCity('Portland')
            ->setPostalCode('34523');

        return [$customer, $address1, $address2];
    }

    /**
     * @return EntityManager
     */
    private function getEntityManager()
    {
        return $this->getContainer()->get('doctrine')->getManager();
    }

    private function getValidator()
    {
        return $this->getContainer()->get('validator');
    }
}
