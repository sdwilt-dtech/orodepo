<?php

declare(strict_types=1);

namespace DT\Bundle\CustomerBundle\Tests\Functional\DataFixtures;

use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use DT\Bundle\EntityBundle\Tests\Functional\DataFixtures\AbstractYmlFixture;

class LoadCustomerUserData extends AbstractYmlFixture implements DependentFixtureInterface
{
    protected function getFilename(): string
    {
        return __DIR__ . '/data/customer_user.yml';
    }

    /**
     * {@inheritdoc}
     */
    public function getDependencies()
    {
        return [
            LoadCustomerData::class,
            LoadCustomerUserRoleReferenceData::class,
        ];
    }
}
