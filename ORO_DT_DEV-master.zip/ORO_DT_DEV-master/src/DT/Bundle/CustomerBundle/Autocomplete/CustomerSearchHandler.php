<?php

namespace DT\Bundle\CustomerBundle\Autocomplete;

use Oro\Bundle\FormBundle\Autocomplete\SearchHandler;

/**
 * Decorator for customer autocomplete search handler to expand with customer's additional information.
 */
class CustomerSearchHandler extends SearchHandler
{
    use CustomerAdditionalInformationTrait;

    /**
     * @param mixed $item
     * @return array
     */
    public function convertItem($item): array
    {
        $result = parent::convertItem($item);
        $result['additional_info'] = $this->getCustomerAdditionalInfo($item);

        return $result;
    }
}
