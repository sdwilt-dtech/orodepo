<?php

namespace DT\Bundle\CustomerBundle\Autocomplete;

use DT\Bundle\SetupBundle\Model\CustomerFields;
use Oro\Bundle\SearchBundle\Engine\Indexer;
use Oro\Bundle\SearchBundle\Query\Criteria\Criteria;
use Oro\Bundle\SearchBundle\Query\Query;

class CustomerTypeCustomerSearchHandler extends CustomerSearchHandler
{
    /**
     * {@inheritdoc}
     */
    protected function searchIds($search, $firstResult, $maxResults)
    {
        $queryObj = $this->indexer->select()->from($this->entitySearchAlias);
        $queryObj->getCriteria()
            ->setMaxResults((int)$maxResults)
            ->setFirstResult((int)$firstResult);

        $field = Criteria::implodeFieldTypeName(
            Query::TYPE_TEXT,
            CustomerFields::DT_BILLING_TYPE
        );
        $queryObj->getCriteria()->andWhere(
            Criteria::expr()->in($field, ['B', 'S', 'X'])
        );

        $field = Criteria::implodeFieldTypeName(
            Query::TYPE_TEXT,
            CustomerFields::DT_ENTITY_TYPE
        );
        $queryObj->getCriteria()->andWhere(
            Criteria::expr()->eq($field, 'customer')
        );

        if ($search) {
            $field = Criteria::implodeFieldTypeName(Query::TYPE_TEXT, Indexer::TEXT_ALL_DATA_FIELD);
            $queryObj->getCriteria()->andWhere(Criteria::expr()->contains($field, $search));
        }

        $ids      = [];
        $result   = $this->indexer->query($queryObj);
        $elements = $result->getElements();

        foreach ($elements as $element) {
            $ids[] = $element->getRecordId();
        }

        return $ids;
    }
}
