<?php

namespace DT\Bundle\CustomerBundle\Autocomplete ;

use DT\Bundle\SetupBundle\Model\CustomerFields;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\CustomerBundle\Entity\CustomerAddress;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Trait to retrieve additional customer information:
 *  - entity type
 *  - billing type
 *  - address city and region
 */
trait CustomerAdditionalInformationTrait
{
    /** @var TranslatorInterface */
    private $translator;

    /**
     * @param TranslatorInterface $translator
     * @return $this
     */
    public function setTranslator(TranslatorInterface $translator): self
    {
        $this->translator = $translator;

        return $this;
    }

    /**
     * @return TranslatorInterface
     */
    public function getTranslator(): TranslatorInterface
    {
        if (!$this->translator) {
            throw new \RuntimeException('TranslatorInterface is not injected');
        }

        return $this->translator;
    }

    /**
     * @param Customer $customer
     * @return array
     */
    protected function getCustomerAdditionalInfo(Customer $customer): array
    {
        $info = [];

        /** @var AbstractEnumValue $entityType */
        $entityType = $this->getPropertyValue(CustomerFields::DT_ENTITY_TYPE, $customer);
        if ($entityType && $entityType->getId() !== EnumValues::DT_CUSTOMER_ENTITY_TYPE_CUSTOMER) {
            $info['entity_type'] = [
                'label' => $this->getTranslator()->trans('oro.customer.dt_entity_type.label'),
                'value' => $entityType->getName()
            ];
        }

        if ($billingType = $this->getPropertyValue(CustomerFields::DT_BILLING_TYPE, $customer)) {
            $info['billing_type'] = [
                'label' => $this->getTranslator()->trans('oro.customer.dt_billing_type.label'),
                'value' => $billingType->getName(),
            ];
        }

        /** @var CustomerAddress|null $address */
        $address = $customer->getAddresses()->first();

        if ($address && $address->getCity()) {
            $info['city'] = [
                'label' => $this->getTranslator()->trans('oro.customer.customeraddress.city.label'),
                'value' => $address->getCity(),
            ];
        }

        if ($address && $address->getRegionName()) {
            $info['state'] = [
                'label' => $this->getTranslator()->trans('oro.customer.customeraddress.region.label'),
                'value' => $address->getRegionCode() ?: $address->getRegionName(),
            ];
        }

        return $info;
    }

    /**
     * @param string $propertyPath
     * @param object|array $item
     * @return mixed
     */
    abstract protected function getPropertyValue($propertyPath, $item);
}
