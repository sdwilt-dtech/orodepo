<?php

namespace DT\Bundle\CustomerBundle\Model;

/**
 * Storage with field sets to separate customer information(view/edit pages)
 */
final class CustomerFieldsets
{
    public const ACCOUNT_DETAIL_FIELDSET            = 'account-details';
    public const ACCOUNT_CLASSIFICATION_FIELDSET    = 'account-classification';
    public const ACCOUNT_TEAM_FIELDSET              = 'account-team';
    public const TERMS_CONDITIONS_FIELDSET          = 'terms-conditions';
    public const SYSTEM_INFORMATION_FIELDSET        = 'system-information';
    public const MORRIS_INFORMATION_FIELDSET        = 'morris-information';
    public const CO_OP_INFORMATION_FIELDSET         = 'co-op-information';
    public const SALES_INFORMATION_FIELDSET         = 'sales-information';
    public const MISCELLANEOUS_INFORMATION_FIELDSET = 'miscellaneous-information';

    /** @var array */
    public static $fieldsetWidgetTemplateMap = [
        self::ACCOUNT_DETAIL_FIELDSET            => 'account_details',
        self::ACCOUNT_CLASSIFICATION_FIELDSET    => 'account_classification',
        self::ACCOUNT_TEAM_FIELDSET              => 'account_team',
        self::TERMS_CONDITIONS_FIELDSET          => 'terms_conditions',
        self::SYSTEM_INFORMATION_FIELDSET        => 'system_information',
        self::MORRIS_INFORMATION_FIELDSET        => 'morris_information',
        self::CO_OP_INFORMATION_FIELDSET         => 'co_op_information',
        self::SALES_INFORMATION_FIELDSET         => 'sales_information',
        self::MISCELLANEOUS_INFORMATION_FIELDSET => 'miscellaneous_information'
    ];
}
