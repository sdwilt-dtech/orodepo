<?php

namespace DT\Bundle\CustomerBundle\Interactor\Translator;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\CustomerBundle\DTO\CustomerProductPriceLookupDTO;
use DT\Bundle\CustomerBundle\DTO\CustomerProductPriceLookupRequestResult;
use DT\Bundle\JdeApiIntegrationBundle\BoundedContext\Price\DTO\CustomerProductPriceResponse;
use DT\Bundle\JdeApiIntegrationBundle\Gateway\DataTransfer\Price\DTO\CustomerProductPriceCriteriaDTO;
use DT\Bundle\PricingBundle\Provider\ProductPriceBasePriceListProvider;
use DT\Bundle\PricingBundle\Provider\ProductPriceListPriceProvider;
use Oro\Bundle\CatalogBundle\Entity\Category;
use Oro\Bundle\PricingBundle\Entity\ProductPrice;
use Oro\Bundle\ProductBundle\Entity\Product;
use Psr\Log\LoggerAwareTrait;

class JdeCustomerPriceResponseTranslator
{
    use LoggerAwareTrait;

    /** @var string */
    private const DEFAULT_CURRENCY = 'USD';
    /** @var int */
    private const DEFAULT_QTY = 1;

    protected ManagerRegistry $registry;
    protected ProductPriceListPriceProvider $productListPriceProvider;
    protected ProductPriceBasePriceListProvider $productBasePriceProvider;

    /**
     * @param ManagerRegistry                   $registry
     * @param ProductPriceListPriceProvider     $productListPriceProvider
     * @param ProductPriceBasePriceListProvider $productBasePriceProvider
     */
    public function __construct(
        ManagerRegistry $registry,
        ProductPriceListPriceProvider $productListPriceProvider,
        ProductPriceBasePriceListProvider $productBasePriceProvider
    ) {
        $this->registry = $registry;
        $this->productListPriceProvider = $productListPriceProvider;
        $this->productBasePriceProvider = $productBasePriceProvider;
    }

    /**
     * @param CustomerProductPriceResponse    $customerProductPriceResponse
     * @param CustomerProductPriceCriteriaDTO $priceCriteriaDTO
     *
     * @return CustomerProductPriceLookupRequestResult
     */
    public function translate(
        CustomerProductPriceResponse $customerProductPriceResponse,
        CustomerProductPriceCriteriaDTO $priceCriteriaDTO
    ): CustomerProductPriceLookupRequestResult {
        if ($customerProductPriceResponse->isSuccess()) {
            $lookupData = $this->translateCustomerPriceToLookupDTO(
                $customerProductPriceResponse->getPrice(),
                $priceCriteriaDTO
            );

            return new CustomerProductPriceLookupRequestResult(
                true,
                $lookupData,
                null
            );
        }

        return new CustomerProductPriceLookupRequestResult(
            false,
            null,
            $customerProductPriceResponse->getErrorMessage()
        );
    }

    /**
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    private function translateCustomerPriceToLookupDTO(
        ?float $jdePrice,
        CustomerProductPriceCriteriaDTO $priceCriteriaDTO
    ): CustomerProductPriceLookupDTO {
        $basePrice = $this->getProductBasePrice($priceCriteriaDTO);
        $isContractedPrice = null;
        if (null !== $jdePrice || null !== $basePrice) {
            $isContractedPrice = $jdePrice === $basePrice;
        }

        $listPrice = $this->getProductListPrice($priceCriteriaDTO);
        $product = $priceCriteriaDTO->getProduct();

        $description = '' === (string)$product->getDefaultDescription()
            ? null
            : \strip_tags($product->getDefaultDescription());

        $description2 = '' === (string)$product->getDefaultShortDescription()
            ? null
            : \strip_tags($product->getDefaultShortDescription());

        $primaryUnitPrecision = $product->getPrimaryUnitPrecision()->getProductUnitCode();

        $categoryTitle = null;
        $superCategoryTitle = null;
        $category = $product->getCategory();
        if ($category instanceof Category) {
            $categoryTitle = (string)$category->getDefaultTitle();

            if ($category->getParentCategory()) {
                $superCategoryTitle = (string)$category->getParentCategory()->getDefaultTitle();
            }
        }

        return new CustomerProductPriceLookupDTO(
            $jdePrice,
            $basePrice,
            $isContractedPrice,
            $listPrice,
            $description,
            $description2,
            $categoryTitle,
            $superCategoryTitle,
            $this->getProductDtStockingType($product),
            $primaryUnitPrecision,
            $this->getProductDtShippableUom($product),
            $this->getProductDtHazOrNonHaz($product)
        );
    }

    /**
     * Get value from enum dynamically imported to the product
     *
     * @param Product $product
     *
     * @return string
     */
    protected function getProductDtStockingType(Product $product): string
    {
        if (method_exists($product, 'getDtStockingType')) {
            return $product->getDtStockingType() ? $product->getDtStockingType()->getName() : '';
        } else {
            return '';
        }
    }

    /**
     * Get value from enum dynamically imported to the product
     *
     * @param Product $product
     *
     * @return string
     */
    protected function getProductDtShippableUom(Product $product): string
    {
        if (method_exists($product, 'getDtShippableUom')) {
            return $product->getDtShippableUom() ? $product->getDtShippableUom()->getName() : '';
        } else {
            return '';
        }
    }

    /**
     * Get value from enum dynamically imported to the product
     *
     * @param Product $product
     *
     * @return bool
     */
    protected function getProductDtHazOrNonHaz(Product $product): bool
    {
        $isHazardous = false;
        if (method_exists($product, 'getDtHazOrNonHaz')) {
            $isHazardous = false;
            if ($product->getDtHazOrNonHaz() && $product->getDtHazOrNonHaz()->getId() == 'haz_item') {
                $isHazardous = true;
            }
        }
        return $isHazardous;
    }

    /**
     * @param CustomerProductPriceCriteriaDTO $priceCriteriaDTO
     *
     * @return float|null
     */
    protected function getProductListPrice(CustomerProductPriceCriteriaDTO $priceCriteriaDTO): ?float
    {
        $product = $priceCriteriaDTO->getProduct();

        $productPrices = $this->productListPriceProvider->getProductPricesByProduct($product);

        /** @var ProductPrice|null $productPrice */
        $productPrice = current($productPrices);
        return $productPrice ? $productPrice->getPrice()->getValue() : null;
    }

    /**
     * @param CustomerProductPriceCriteriaDTO $priceCriteriaDTO
     *
     * @return float|null
     */
    protected function getProductBasePrice(CustomerProductPriceCriteriaDTO $priceCriteriaDTO): ?float
    {
        $product = $priceCriteriaDTO->getProduct();

        $productPrices = $this->productBasePriceProvider->getProductPricesByProduct($product);

        /** @var ProductPrice|null $productPrice */
        $productPrice = current($productPrices);
        return $productPrice ? $productPrice->getPrice()->getValue() : null;
    }
}
