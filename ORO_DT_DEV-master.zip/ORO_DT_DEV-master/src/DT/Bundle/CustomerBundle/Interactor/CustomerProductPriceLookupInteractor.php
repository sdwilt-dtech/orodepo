<?php

namespace DT\Bundle\CustomerBundle\Interactor;

use DT\Bundle\CustomerBundle\DTO\CustomerProductPriceLookupRequestResult;
use DT\Bundle\CustomerBundle\Interactor\Translator\JdeCustomerPriceResponseTranslator;
use DT\Bundle\JdeApiIntegrationBundle\BoundedContext\Price\PriceInteractor;
use DT\Bundle\JdeApiIntegrationBundle\Gateway\DataTransfer\Price\DTO\CustomerProductPriceCriteriaDTO;

class CustomerProductPriceLookupInteractor
{
    private PriceInteractor $priceInteractor;

    /**
     * @var JdeCustomerPriceResponseTranslator
     */
    private JdeCustomerPriceResponseTranslator $jdeCustomerPriceResponseTranslator;

    /**
     * @param PriceInteractor                    $priceInteractor
     * @param JdeCustomerPriceResponseTranslator $jdeCustomerPriceResponseTranslator
     */
    public function __construct(
        PriceInteractor $priceInteractor,
        JdeCustomerPriceResponseTranslator $jdeCustomerPriceResponseTranslator
    ) {
        $this->priceInteractor = $priceInteractor;
        $this->jdeCustomerPriceResponseTranslator = $jdeCustomerPriceResponseTranslator;
    }

    public function getProductPrice(
        CustomerProductPriceCriteriaDTO $priceCriteriaDTO
    ): CustomerProductPriceLookupRequestResult {
        $customerPrice = $this->priceInteractor->getProductPrice($priceCriteriaDTO);

        return $this->jdeCustomerPriceResponseTranslator
            ->translate($customerPrice, $priceCriteriaDTO);
    }
}
