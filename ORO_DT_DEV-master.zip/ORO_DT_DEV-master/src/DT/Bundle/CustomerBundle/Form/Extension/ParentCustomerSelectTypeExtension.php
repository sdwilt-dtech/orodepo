<?php

namespace DT\Bundle\CustomerBundle\Form\Extension;

use Oro\Bundle\CustomerBundle\Form\Type\ParentCustomerSelectType;
use Symfony\Component\Form\AbstractTypeExtension;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Parent customer select form type extension to override autocomplete suggestions appearance.
 */
class ParentCustomerSelectTypeExtension extends AbstractTypeExtension
{
    /**
     * @return iterable
     */
    public static function getExtendedTypes(): iterable
    {
        return [ParentCustomerSelectType::class];
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefault('configs', [
            'component' => 'autocomplete-entity-parent',
            'placeholder' => 'oro.customer.customer.form.choose_parent',
            'result_template_twig' => 'DTCustomerBundle:Customer:Autocomplete/result.html.twig',
            'selection_template_twig' => 'DTCustomerBundle:Customer:Autocomplete/selection.html.twig'
        ]);
    }
}
