<?php

namespace DT\Bundle\CustomerBundle\Form\Extension;

use Oro\Bundle\CustomerBundle\Form\Type\CustomerType;
use Symfony\Component\Form\AbstractTypeExtension;
use Symfony\Component\Form\FormBuilderInterface;

/**
 * Customer form extension to remove address
 */
class CustomerTypeExtension extends AbstractTypeExtension
{
    /**
     * @return iterable
     */
    public static function getExtendedTypes(): iterable
    {
        return [CustomerType::class];
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->remove('addresses');
        $builder->remove('customer_association_account');
    }
}
