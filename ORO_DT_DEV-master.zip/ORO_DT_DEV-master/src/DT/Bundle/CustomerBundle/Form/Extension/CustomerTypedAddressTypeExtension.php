<?php

namespace DT\Bundle\CustomerBundle\Form\Extension;

use Oro\Bundle\CustomerBundle\Form\Type\CustomerTypedAddressType;
use Oro\Bundle\FormBundle\Form\Extension\StripTagsExtension;
use Symfony\Component\Form\AbstractTypeExtension;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;

/**
 * Customer address form extension to handle needed(customized) fields sets
 */
class CustomerTypedAddressTypeExtension extends AbstractTypeExtension
{
    /**
     * @return iterable
     */
    public static function getExtendedTypes(): iterable
    {
        return [CustomerTypedAddressType::class];
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add(
                'organization',
                HiddenType::class,
                [
                    'required' => false,
                    'label' => 'oro.address.organization.label',
                    StripTagsExtension::OPTION_NAME => true
                ]
            )
            ->remove('namePrefix')
            ->remove('nameSuffix')
            ->remove('middleName')
            ->remove('phone')
            ->remove('types')
            ->remove('primary')
            ->remove('defaults')
            ->addEventListener(FormEvents::PRE_SUBMIT, [$this, 'preSubmit']);
    }

    /**
     * Workaround to set 'N/A' organization value if it's empty one
     *
     * @param FormEvent $event
     */
    public function preSubmit(FormEvent $event)
    {
        $data = $event->getData();
        $data['organization'] = !empty($data['organization']) ? $data['organization'] : 'N/A';
        $event->setData($data);
    }
}
