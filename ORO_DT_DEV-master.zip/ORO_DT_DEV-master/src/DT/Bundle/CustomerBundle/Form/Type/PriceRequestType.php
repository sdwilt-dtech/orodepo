<?php

namespace DT\Bundle\CustomerBundle\Form\Type;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\CustomerBundle\DTO\PriceRequestDTO;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\FormBundle\Form\DataTransformer\EntityToIdTransformer;
use Oro\Bundle\ProductBundle\Form\Type\ProductSelectType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class PriceRequestType extends AbstractType
{
    private ManagerRegistry $registry;

    /**
     * @param ManagerRegistry $registry
     */
    public function __construct(ManagerRegistry $registry)
    {
        $this->registry = $registry;
    }

    /**
     *{@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add(
            'product',
            ProductSelectType::class,
            [
                'required' => true,
                'create_enabled' => false,
                'constraints' => [new NotBlank()],
            ]
        );

        $builder->add('customer', HiddenType::class);
        $builder->get('customer')->addModelTransformer(
            new EntityToIdTransformer(
                $this->registry->getManagerForClass(Customer::class),
                Customer::class
            )
        );
    }

    /**
     *{@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => PriceRequestDTO::class
        ]);
    }

    /**
     *{@inheritdoc}
     */
    public function getName()
    {
        return $this->getBlockPrefix();
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'dt_customer_price_request';
    }
}
