<?php

namespace DT\Bundle\CustomerBundle\Form\Type;

use Oro\Bundle\FormBundle\Form\Type\OroEntitySelectOrCreateInlineType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CustomerTypeCustomerSelectType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'autocomplete_alias' => 'dt_customer_type_customer',
                'create_form_route' => 'oro_customer_customer_create',
                'configs' => [
                    'placeholder' => 'oro.customer.customer.form.choose',
                    'result_template_twig' => 'DTCustomerBundle:Customer:Autocomplete/result.html.twig',
                    'selection_template_twig' => 'DTCustomerBundle:Customer:Autocomplete/selection.html.twig',
                ],
                'attr' => [
                    'class' => 'customer-type-customer-select',
                ],
                'grid_name' => 'dt-customer-type-customer-select-grid'
            ]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return OroEntitySelectOrCreateInlineType::class;
    }
}
