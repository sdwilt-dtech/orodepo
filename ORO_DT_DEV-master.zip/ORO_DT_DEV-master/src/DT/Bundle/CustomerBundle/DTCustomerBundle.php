<?php

namespace DT\Bundle\CustomerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DTCustomerBundle extends Bundle
{
}
