<?php

namespace DT\Bundle\CustomerBundle\Provider;

use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;

/**
 * Provides customer of certain hierarchy level from tree
 * for given customer
 */
class CustomerHierarchy
{
    public const DEFAULT_CUSTOMER_LEVEL = EnumValues::DT_CUSTOMER_ENTITY_TYPE_GROUP;

    /** @var array */
    private $flatCustomersTree = [];

    /**
     * Finds customer of certain level in customer tree for given
     * customer entity
     *
     * @param Customer $customer
     * @param string $level
     * @return Customer|null
     */
    public function getCustomerForLevel(
        Customer $customer,
        string $level = self::DEFAULT_CUSTOMER_LEVEL
    ): ?Customer {
        if ($this->isLevelCustomer($customer, $level)) {
            return $customer;
        }
        $parent = $customer->getParent();
        while ($parent) {
            if ($this->isLevelCustomer($parent, $level)) {
                return $parent;
            }
            $parent = $parent->getParent();
        }

        foreach ($customer->getChildren() as $childCustomer) {
            if ($this->isLevelCustomer($childCustomer, $level)) {
                return $childCustomer;
            }
        }

        return null;
    }

    /**
     * Gets flat customers tree involving all hierarchy customers
     * for the customer given
     *
     * @param Customer $customer
     * @return array
     */
    public function getFlatTree(Customer $customer): array
    {
        if (!array_key_exists($customer->getId(), $this->flatCustomersTree)) {
            $this->flatCustomersTree[$customer->getId()] = $this->doGetFlatTree($customer);
        }

        return $this->flatCustomersTree[$customer->getId()];
    }

    /**
     * @param Customer $customer
     * @return array
     */
    private function doGetFlatTree(Customer $customer): array
    {
        $tree = [];
        $parent = $customer->getParent();
        while ($parent) {
            array_unshift($tree, $parent);
            $parent = $parent->getParent();
        }

        $tree = array_merge($tree, $this->getFlatChildrenTree($customer));

        return $tree;
    }

    /**
     * Provides flattened customer tree
     *
     * @param Customer $customer
     * @return Customer[]|array
     */
    private function getFlatChildrenTree(Customer $customer): array
    {
        $customers = [$customer];
        foreach ($customer->getChildren() as $child) {
            $customers = array_merge($customers, $this->getFlatChildrenTree($child));
        }

        return $customers;
    }

    /**
     * @param Customer $customer
     * @param string $level
     * @return bool
     */
    private function isLevelCustomer(Customer $customer, string $level): bool
    {
        return $customer->getDtEntityType()
            && ($customer->getDtEntityType()->getId() === $level);
    }

    /**
     * Returns first matched customer matching any of given billing types
     *
     * @param Customer $customer
     */
    public function getCustomerForBillingType(Customer $customer, array $billingTypes = ['X', 'B']): ?Customer
    {
        if ($this->isBillingCustomer($customer, $billingTypes)) {
            return $customer;
        }
        $parent = $customer->getParent();
        while ($parent) {
            if ($this->isBillingCustomer($parent, $billingTypes)) {
                return $parent;
            }
            $parent = $parent->getParent();
        }

        foreach ($customer->getChildren() as $childCustomer) {
            if ($this->isBillingCustomer($childCustomer, $billingTypes)) {
                return $childCustomer;
            }
        }

        return null;
    }

    /**
     * @param Customer $customer
     * @param array $billingTypes
     * @return bool
     */
    private function isBillingCustomer(Customer $customer, array $billingTypes): bool
    {
        $billingType = $customer->getDtBillingType();
        return $billingType && in_array($billingType->getId(), $billingTypes);
    }
}
