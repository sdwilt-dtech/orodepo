<?php

namespace DT\Bundle\CustomerBundle\Provider;

use DT\Bundle\AccountPlanBundle\Provider\Enums\KcgCustomerSegment;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;

/**
 * Provides customer's segment name for customer. For legacy customer,
 * detects the segment from historic global customer types. Expect to
 * have the value defined for new customers.
 */
class CustomerSegmentProvider
{
    private const TYPE_NATNL = 'NATNL';
    private const TYPE_STRAT = 'STRAT';

    public const SEGMENT_NATIONAL = KcgCustomerSegment::SEGMENT_NATIONAL;
    public const SEGMENT_STRATEGIC = KcgCustomerSegment::SEGMENT_STRATEGIC;
    public const SEGMENT_CORE = KcgCustomerSegment::SEGMENT_CORE;

    /**
     * Provides customer's segment name or null if cannot be detected
     *
     * @param Customer $customer
     * @return string|null
     */
    public function getCustomerSegment(Customer $customer): ?string
    {
        /** @var AbstractEnumValue $segment */
        if (null !== ($segment = $customer->getDtKcgCustomerSegment())) {
            return $segment->getId();
        }
        $globalType = $customer->getDtHistGlobalCustomerType();
        return $globalType ? $this->calculateSegment($customer->getDtHistGlobalCustomerType()) : null;
    }

    /**
     * Calculates customer type
     *
     * @param string $globalCustomerType
     * @return string
     */
    private function calculateSegment(string $globalCustomerType): string
    {
        switch ($globalCustomerType) {
            case self::TYPE_NATNL:
                return self::SEGMENT_NATIONAL;
            case self::TYPE_STRAT:
                return self::SEGMENT_STRATEGIC;
            default:
                return self::SEGMENT_CORE;
        }
    }
}
