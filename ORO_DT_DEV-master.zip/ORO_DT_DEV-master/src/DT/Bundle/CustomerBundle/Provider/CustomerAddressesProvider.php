<?php

namespace DT\Bundle\CustomerBundle\Provider;

use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\CustomerBundle\Entity\CustomerAddress;
use Oro\Bundle\CustomerBundle\Entity\Repository\CustomerRepository;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;

/**
 * Class to provide customer parent and all children addresses with next entity types:
 *  - rollup
 *  - sub
 *  - customer
 */
class CustomerAddressesProvider
{
    /** @var DoctrineHelper */
    protected $doctrineHelper;

    /**
     * CustomerAddressesProvider constructor.
     * @param DoctrineHelper $doctrineHelper
     */
    public function __construct(DoctrineHelper $doctrineHelper)
    {
        $this->doctrineHelper = $doctrineHelper;
    }

    /**
     * @param Customer $customer
     * @return array
     */
    public function getCustomerAddresses(Customer $customer): array
    {
        if (!$this->isAddressBookAvailable($customer)) {
            return [];
        }

        $parentAddresses = $this->getParentAddresses($customer);
        $ownAddresses = $customer->getAddresses()->toArray();
        $childrenAddresses = $this->getChildrenAddresses($customer);

        return array_merge($parentAddresses, $ownAddresses, $childrenAddresses);
    }

    /**
     * @param Customer $customer
     * @return array|int[]
     */
    public function getCustomerAddressesFrontendOwnerIds(Customer $customer): array
    {
        $customerIds = [0];

        if (!$this->isAddressBookAvailable($customer)) {
            return $customerIds;
        }

        $customerIds[] = $customer->getId();
        if ($customer->getParent()) {
            $customerIds[] = $customer->getParent()->getId();
        }
        $repository = $this->doctrineHelper->getEntityRepositoryForClass(Customer::class);
        if ($childIds = $repository->getChildrenIds($customer->getId())) {
            $customerIds = array_merge($customerIds, $childIds);
        }

        return $customerIds;
    }

    /**
     * If customer is not applicable, do not show any addresses in address book at all.
     *
     * @param Customer $customer
     *
     * @return bool
     */
    protected function isAddressBookAvailable(Customer $customer): bool
    {
        $customerEntityType = $customer->getDtEntityType()
            ? $customer->getDtEntityType()->getId()
            : null;

        $supportedEntityTypes = [
            EnumValues::DT_CUSTOMER_ENTITY_TYPE_CUSTOMER,
            EnumValues::DT_CUSTOMER_ENTITY_TYPE_SUB,
            EnumValues::DT_CUSTOMER_ENTITY_TYPE_ROLLUP,
        ];

        return in_array($customerEntityType, $supportedEntityTypes, true);
    }

    /**
     * Show addresses of parent customer in case if customer has billing type "S".
     *
     * @param Customer $customer
     *
     * @return CustomerAddress[]
     */
    protected function getParentAddresses(Customer $customer): array
    {
        $customerEntityType = $customer->getDtEntityType()
            ? $customer->getDtEntityType()->getId()
            : null;

        $customerBillingType = $customer->getDtBillingType()
            ? $customer->getDtBillingType()->getId()
            : null;

        $parentAddresses = [];

        if ($customerEntityType === EnumValues::DT_CUSTOMER_ENTITY_TYPE_CUSTOMER &&
            $customerBillingType === 'S' &&
            $customer->getParent()
        ) {
            $parentAddresses = $customer->getParent()->getAddresses()->toArray();
        }

        return $parentAddresses;
    }

    /**
     * @param Customer $customer
     *
     * @return CustomerAddress[]
     */
    protected function getChildrenAddresses(Customer $customer): array
    {
        /** @var CustomerRepository $repository */
        $repository = $this->doctrineHelper->getEntityRepositoryForClass(Customer::class);
        $childIds = $repository->getChildrenIds($customer->getId());

        $qb = $this->doctrineHelper->getEntityRepositoryForClass(CustomerAddress::class)
            ->createQueryBuilder('ca');

        $qb->addOrderBy('ca.frontendOwner', 'ASC')
            ->where($qb->expr()->in('ca.frontendOwner', ':customerIds'))
            ->setParameter('customerIds', $childIds);

        return $qb->getQuery()->getResult();
    }
}
