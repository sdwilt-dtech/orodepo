define(function(require) {
    'use strict';

    const productData1stColumnTemplate = require('text-loader!dtcustomer/templates/price/product-dynamic-data-1st-column.html');
    const productData2ndColumnTemplate = require('text-loader!dtcustomer/templates/price/product-dynamic-data-2nd-column.html');
    const BaseComponent = require('oroui/js/app/components/base/component');
    const routing = require('routing');
    const _ = require('underscore');
    const $ = require('jquery');
    const NumberFormatter = require('orolocale/js/formatter/number');
    const mediator = require('oroui/js/mediator');
    const __ = require('orotranslation/js/translator');
    const LoadingMaskView = require('oroui/js/app/views/loading-mask-view');

    const PriceRequestComponent = BaseComponent.extend({
        /**
         * @property {jQuery}
         */
        $form: null,

        /**
         * @property {jQuery}
         */
        $productField: null,

        /**
         * @property {jQuery}
         */
        $productData1stColumn: null,

        /**
         * @property {jQuery}
         */
        $productData2ndColumn: null,

        /**
         * @property {String}
         */
        route: 'dt_customer_price_request',

        /**
         * @property {Object}
         */
        formFieldNameToDataKeyMapping: {},

        /**
         * @property {LoadingMaskView}
         */
        loadingMaskView: null,

        /**
         * @inheritDoc
         */
        constructor: function PriceRequestComponent(options) {
            PriceRequestComponent.__super__.constructor.call(this, options);
        },

        /**
         * @constructor
         * @param {Object} options
         */
        initialize: function (options) {
            PriceRequestComponent.__super__.initialize.call(this, options);
            this.assertObjectByOptionsKeys(options, ['selectors', 'formFieldNameToDataKeyMapping']);
            this.formFieldNameToDataKeyMapping = options.formFieldNameToDataKeyMapping;

            this.assertAllSelectorsExist(
                options,
                [
                    'productFieldSelector',
                    'productData1stColumnSelector',
                    'productData2ndColumnSelector'
                ]
            );

            this.$form = options._sourceElement.find('form');
            this.$productField = options._sourceElement.find(options.selectors.productFieldSelector);
            this.$productData1stColumn = options._sourceElement.find(options.selectors.productData1stColumnSelector);
            this.$productData2ndColumn = options._sourceElement.find(options.selectors.productData2ndColumnSelector);

            this.loadingMaskView = new LoadingMaskView({
                container: options._sourceElement
            });

            this.assertAllElementsFound([
               '$form',
               '$productField',
               '$productData1stColumn',
               '$productData2ndColumn',
            ]);
            this.assertAllMappedFieldNamesExist();

            this.renderTemplates({success: true, data:{}});
            this.$productField.on('change', _.bind(this.onProductFieldChange, this));
        },

        /**
         * @param {Object} options
         * @param {Array} keys
         */
        assertObjectByOptionsKeys: function (options, keys) {
            let notObjectKeysOption = _.filter(keys, function (key) {
                return false === _.isObject(options[key]);
            });

            if (_.size(notObjectKeysOption) > 0) {
                throw new Error('We got non objects under next keys in options: ' + notObjectKeysOption.join(', '));
            }
        },

        /**
         * @param {Object} options
         * @param {Array} keys
         */
        assertAllSelectorsExist(options, keys) {
            let missedKeys = _.difference(keys, _.keys(options.selectors));
            if (_.size(missedKeys) > 0) {
                throw new Error('Missed next selectors: ' + missedKeys.join(', '));
            }
        },

        /**
         * @param {Array} keys
         */
        assertAllElementsFound(keys) {
            let missedElements = _.filter(keys, _.bind(function (key) {
                return 0 === this[key].length;
            }, this));

            if (_.size(missedElements) > 0) {
                throw new Error('Missed elements: ' + missedElements.join(', '));
            }
        },

        assertAllMappedFieldNamesExist: function () {
            let formData = this.$form.serializeArray();
            let formDataKeys = _.pluck(formData, 'name');
            let mappedFormDataKeys = _.keys(this.formFieldNameToDataKeyMapping);
            let missedFormElements = _.difference(mappedFormDataKeys, formDataKeys);
            if (_.size(missedFormElements) > 0) {
                throw new Error('Missed form elements: ' + missedFormElements.join(', '));
            }
        },

        /**
         * @return {String}
         */
        getRequestUrl: function () {
            let formData = this.$form.serializeArray();
            let routeParams = {};
            _.each(this.formFieldNameToDataKeyMapping, function (routeParameterKey, formFieldName) {
                let formFieldData = _.first(
                    _.where(formData, {name: formFieldName})
                );
                routeParams[routeParameterKey] = formFieldData.value;
            })

            return routing.generate(this.route, routeParams);
        },

        onProductFieldChange: function(e) {
            this.$form.validate();
            if (this.$form.valid()) {
                $.ajax({
                    async: true,
                    type: 'GET',
                    url: this.getRequestUrl(),
                    beforeSend: _.bind(function() {
                        this.loadingMaskView.show();
                    }, this),
                    complete: _.bind(function() {
                        this.loadingMaskView.hide();
                    }, this),
                    success: _.bind(this.renderTemplates, this)
                });
            }
        },

        /**
         * @param {Object} data
         */
        renderTemplates: function (data) {
            if (!data.success) {
                if (data.errorMessage) {
                    mediator.execute(
                        'showFlashMessage',
                        'error',
                        data.errorMessage
                    );
                } else {
                    mediator.execute('showFlashMessage', 'error', 'Could not get product price');
                }

                return;
            }

            let productData1stColumnHtml = _.template(productData1stColumnTemplate)({
                item: data.data,
                __:__,
                NumberFormatter: NumberFormatter
            });

            let productData2ndColumnHtml = _.template(productData2ndColumnTemplate)({
                item: data.data,
                __:__,
                NumberFormatter: NumberFormatter
            });

            this.$productData1stColumn.html(productData1stColumnHtml);
            this.$productData2ndColumn.html(productData2ndColumnHtml);

            mediator.trigger('layout:reposition');
        }
    });

    return PriceRequestComponent;
});
