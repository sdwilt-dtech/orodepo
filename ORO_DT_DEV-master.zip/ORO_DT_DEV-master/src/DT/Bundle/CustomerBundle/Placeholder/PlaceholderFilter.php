<?php

namespace DT\Bundle\CustomerBundle\Placeholder;

use Oro\Bundle\CustomerBundle\Entity\Customer;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class PlaceholderFilter
{
    protected ValidatorInterface $validator;

    /**
     * @param ValidatorInterface $validator
     */
    public function __construct(ValidatorInterface $validator)
    {
        $this->validator = $validator;
    }

    /**
     * @param mixed $entity
     * @return bool
     */
    public function isApplicableToMakeJdeCustomerPriceRequest($entity): bool
    {
        if (!$entity instanceof Customer) {
            return false;
        }

        $violationList = $this->validator->validate($entity, null, ['jdePrice']);
        return 0 === $violationList->count();
    }
}
