<?php

namespace DT\Bundle\CustomerBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * Constraint to disallow customers with billing type 'S' to have children of billing types 'B' and 'X'
 */
class CustomerBillingTypeHierarchy extends Constraint
{
    /** @var string */
    public $entityTypeInvalidMessage = 'dt.customer.customer_hierarchy.constraint.entity_type_invalid';

    /** @var string */
    public $billingTypeShouldNotBeBlankMessage =
        'dt.customer.customer_hierarchy.constraint.billing_type_should_not_be_blank';

    /** @var string */
    public $groupParentShouldBeBlankMessage = 'dt.customer.customer_hierarchy.constraint.group_parent_should_be_blank';

    /** @var string */
    public $parentShouldNotBeBlankMessage = 'dt.customer.customer_hierarchy.constraint.parent_should_not_be_blank';

    /** @var string */
    public $rollupParentInvalidMessage = 'dt.customer.customer_hierarchy.constraint.rollup_parent_invalid';

    /** @var string */
    public $subParentInvalidMessage = 'dt.customer.customer_hierarchy.constraint.sub_parent_invalid';

    /** @var string */
    public $billToParentInvalidMessage = 'dt.customer.customer_hierarchy.constraint.bill_to_parent_invalid';

    /** @var string */
    public $shipToParentInvalidMessage = 'dt.customer.customer_hierarchy.constraint.ship_to_parent_invalid';

    /**
     * The validator must be defined as a service with this name.
     *
     * @return string
     */
    public function validatedBy()
    {
        return 'dt_customer.validator_constraints.customer_hierarchy_validator';
    }

    /**
     * {@inheritdoc}
     */
    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
