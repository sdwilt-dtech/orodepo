<?php

namespace DT\Bundle\CustomerBundle\Validator\Constraints;

use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

/**
 * Validator of constraint check customer hierarchy setup
 * correspondingly to 'dt_entity_type' and 'dt_billing_type' attributes values
 */
class CustomerHierarchyValidator extends ConstraintValidator
{
    /** @var DoctrineHelper */
    private $doctrineHelper;

    /**
     * @param DoctrineHelper      $doctrineHelper
     */
    public function __construct(DoctrineHelper $doctrineHelper)
    {
        $this->doctrineHelper = $doctrineHelper;
    }

    /**
     * @param mixed                                   $entity
     * @param Constraint|CustomerBillingTypeHierarchy $constraint
     */
    public function validate($entity, Constraint $constraint): void
    {
        if (!$entity instanceof Customer) {
            throw new \InvalidArgumentException(
                sprintf(
                    'Value must be instance of "%s", "%s" given',
                    Customer::class,
                    is_object($entity) ? get_class($entity) : gettype($entity)
                )
            );
        }

        $customerBillingType = $this->getBillingType($entity);
        $customerEntityType = $this->getEntityType($entity);

        $parent = $entity->getParent();
        $parentBillingType = $this->getBillingType($parent);
        $parentEntityType = $this->getEntityType($parent);

        if ($customerEntityType === EnumValues::DT_CUSTOMER_ENTITY_TYPE_CUSTOMER) {
            $this->validateCustomerEntityTypeCase(
                $customerBillingType,
                $parentEntityType,
                $parentBillingType,
                $parent,
                $constraint
            );
        } elseif ($customerEntityType === EnumValues::DT_CUSTOMER_ENTITY_TYPE_SUB) {
            $this->validateSubEntityTypeCase($parentEntityType, $parent, $constraint);
        } elseif ($customerEntityType === EnumValues::DT_CUSTOMER_ENTITY_TYPE_ROLLUP) {
            $this->validateRollupEntityTypeCase($parentEntityType, $parent, $constraint);
        } elseif ($customerEntityType === EnumValues::DT_CUSTOMER_ENTITY_TYPE_GROUP) {
            $this->validateGroupEntityTypeCase($parent, $constraint);
        } else {
            $this->addViolation($constraint->entityTypeInvalidMessage);
        }
    }

    /**
     * @param string|null                  $customerBillingType
     * @param string|null                  $parentEntityType
     * @param string|null                  $parentBillingType
     * @param Customer|null                $parent
     * @param CustomerBillingTypeHierarchy $constraint
     */
    private function validateCustomerEntityTypeCase(
        ?string $customerBillingType,
        ?string $parentEntityType,
        ?string $parentBillingType,
        ?Customer $parent,
        CustomerBillingTypeHierarchy $constraint
    ): void {
        if ($parent === null) {
            $this->addViolation($constraint->parentShouldNotBeBlankMessage);
        }

        if ($customerBillingType === null) {
            $this->addViolation($constraint->billingTypeShouldNotBeBlankMessage, 'dt_billing_type');
        }

        if ($customerBillingType === 'S') {
            if ($parentEntityType !== EnumValues::DT_CUSTOMER_ENTITY_TYPE_CUSTOMER ||
                !in_array($parentBillingType, ['B', 'X'], true)
            ) {
                $this->addViolation($constraint->shipToParentInvalidMessage);
            }
        } elseif (in_array($customerBillingType, ['B', 'X'])) {
            if ($parentEntityType !== EnumValues::DT_CUSTOMER_ENTITY_TYPE_SUB) {
                $this->addViolation($constraint->billToParentInvalidMessage);
            }
        }
    }

    /**
     * @param string|null                  $parentEntityType
     * @param Customer|null                $parent
     * @param CustomerBillingTypeHierarchy $constraint
     *
     * @return array
     */
    private function validateSubEntityTypeCase(
        ?string $parentEntityType,
        ?Customer $parent,
        CustomerBillingTypeHierarchy $constraint
    ): void {
        if ($parent === null) {
            $this->addViolation($constraint->parentShouldNotBeBlankMessage);
        } elseif ($parentEntityType !== EnumValues::DT_CUSTOMER_ENTITY_TYPE_ROLLUP) {
            $this->addViolation($constraint->subParentInvalidMessage);
        }
    }

    /**
     * @param string|null                  $parentEntityType
     * @param Customer|null                $parent
     * @param CustomerBillingTypeHierarchy $constraint
     */
    private function validateRollupEntityTypeCase(
        ?string $parentEntityType,
        ?Customer $parent,
        CustomerBillingTypeHierarchy $constraint
    ): void {
        if ($parent === null) {
            $this->addViolation($constraint->parentShouldNotBeBlankMessage);
        } elseif ($parentEntityType !== EnumValues::DT_CUSTOMER_ENTITY_TYPE_GROUP) {
            $this->addViolation($constraint->rollupParentInvalidMessage);
        }
    }

    /**
     * @param Customer|null                $parent
     * @param CustomerBillingTypeHierarchy $constraint
     */
    private function validateGroupEntityTypeCase(
        ?Customer $parent,
        CustomerBillingTypeHierarchy $constraint
    ): void {
        if ($parent !== null) {
            $this->addViolation($constraint->groupParentShouldBeBlankMessage);
        }
    }

    /**
     * @param Customer|null $customer
     *
     * @return string|null
     */
    private function getEntityType(?Customer $customer): ?string
    {
        return $customer && $customer->getDtEntityType() ? $customer->getDtEntityType()->getId() : null;
    }

    /**
     * @param Customer|null $customer
     *
     * @return string|null
     */
    private function getBillingType(?Customer $customer): ?string
    {
        return $customer && $customer->getDtBillingType() ? $customer->getDtBillingType()->getId() : null;
    }

    /**
     * @param string $errorMessage
     * @param string $path
     */
    private function addViolation(string $errorMessage, $path = 'parent'): void
    {
        $this->context->buildViolation($errorMessage)->atPath($path)->addViolation();
    }
}
