<?php

namespace DT\Bundle\CustomerBundle\Validator\Constraints;

use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

class CustomerAllowToMakePriceRequestValidator extends ConstraintValidator
{
    /** @var string */
    public const BILLING_TYPE_X = 'X';

    /** @var string */
    public const BILLING_TYPE_S = 'S';

    /**
     * @var string[]
     */
    protected array $allowedBillingTypes = [
       self::BILLING_TYPE_X,
       self::BILLING_TYPE_S
    ];

    /**
     * @param Customer $value
     * @param CustomerAllowToMakePriceRequest $constraint
     */
    public function validate($value, Constraint $constraint)
    {
        if (!$value instanceof Customer) {
            return;
        }

        $this->validateBillingType($value, $constraint);
        $this->validateEntityType($value, $constraint);
        $this->validateCustomerSynchronized($value, $constraint);
    }

    private function validateBillingType(Customer $value, CustomerAllowToMakePriceRequest $constraint)
    {
        if (!$value->getDtBillingType() ||
            !\in_array($value->getDtBillingType()->getId(), $this->allowedBillingTypes, true)) {
            $givenBillingType = $value->getDtBillingType() ? $value->getDtBillingType()->getId() : 'none';
            $this
                ->context
                ->buildViolation(
                    $constraint->incorrectBillingTypeMessage,
                    [
                        '{{ allowedBillingTypes }}' => \implode(', ', $this->allowedBillingTypes),
                        '{{ givenBillingType }}' => $givenBillingType
                    ]
                )
                ->addViolation();
        }
    }

    private function validateEntityType(Customer $value, CustomerAllowToMakePriceRequest $constraint)
    {
        $customerEntityType = $value->getDtEntityType()
            ? $value->getDtEntityType()->getId()
            : null;

        if (!$customerEntityType || $customerEntityType !== EnumValues::DT_CUSTOMER_ENTITY_TYPE_CUSTOMER) {
            $givenCustomerType = $customerEntityType ?? 'none';
            $this
                ->context
                ->buildViolation(
                    $constraint->incorrectEntityTypeMessage,
                    [
                        '{{ allowedEntityType }}' => EnumValues::DT_CUSTOMER_ENTITY_TYPE_CUSTOMER,
                        '{{ givenEntityType  }}' => $givenCustomerType
                    ]
                )
                ->addViolation();
        }
    }

    private function validateCustomerSynchronized(Customer $value, CustomerAllowToMakePriceRequest $constraint)
    {
        if (null === $value->getDtJdeId()) {
            $this
                ->context
                ->buildViolation($constraint->missedAccountNumberMessage)
                ->addViolation();
        }
    }
}
