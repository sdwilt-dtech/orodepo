<?php

namespace DT\Bundle\CustomerBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

class CustomerAllowToMakePriceRequest extends Constraint
{
    /** @var string */
    public $incorrectBillingTypeMessage =
        'dt.customer.validators.customer_allow_to_make_price_request.incorrect_billing_type.message';

    /** @var string */
    public $incorrectEntityTypeMessage =
        'dt.customer.validators.customer_allow_to_make_price_request.incorrect_entity_type.message';

    /** @var string */
    public $missedAccountNumberMessage =
        'dt.customer.validators.customer_allow_to_make_price_request.missed_account_number.message';

    /**
     * {@inheritdoc}
     */
    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }

    /**
     * {@inheritdoc}
     */
    public function validatedBy()
    {
        return CustomerAllowToMakePriceRequestValidator::class;
    }
}
