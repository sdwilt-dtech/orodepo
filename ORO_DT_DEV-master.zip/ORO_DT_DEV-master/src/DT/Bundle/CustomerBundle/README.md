DTCustomerBundle
=============

Overview
--------

This bundle is added to override existing services in `OroCustomerBundle` to add customizations.


Customizations
--------------

### Datagrid with related contacts

Added datagrid with related Contacts on Customer view page. See datagrids.yml and [overridden template](../../../../templates/bundles/OroCustomerBundle/Customer/view.html.twig).
