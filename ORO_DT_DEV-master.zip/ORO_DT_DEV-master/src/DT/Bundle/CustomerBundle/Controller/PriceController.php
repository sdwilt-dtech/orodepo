<?php

namespace DT\Bundle\CustomerBundle\Controller;

use DT\Bundle\CustomerBundle\DTO\PriceRequestDTO;
use DT\Bundle\CustomerBundle\Form\Type\PriceRequestType;
use DT\Bundle\CustomerBundle\Interactor\CustomerProductPriceLookupInteractor;
use DT\Bundle\JdeApiIntegrationBundle\Gateway\DataTransfer\Price\DTO\CustomerProductPriceCriteriaDTO;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\ProductBundle\Entity\Product;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

class PriceController extends AbstractController
{
    /**
     * @Route(
     *      "/price-request-widget/{id}",
     *      name="dt_customer_price_request_widget",
     *      requirements={"id"="\d+"}
     * )
     * @Template("DTCustomerBundle:Price/widget:price-request.html.twig")
     * @AclAncestor("dt_jde_customer_price_request")
     *
     * @param Customer $entity
     */
    public function priceRequestWidgetAction(Customer $entity)
    {
        $formFactory = $this->get('form.factory');
        $form = $formFactory->createNamed(
            'dt_customer_price_request',
            PriceRequestType::class,
            new PriceRequestDTO($entity)
        );

        return [
            'entity' => $entity,
            'form' => $form->createView()
        ];
    }

    /**
     * @Route(
     *      "/price-request/customer/{customerId}/product/{productId}",
     *      name="dt_customer_price_request",
     *      requirements={"customerId"="\d+", "productId"="\d+"},
     *      options={"expose"=true}
     * )
     * @ParamConverter("customer", class="OroCustomerBundle:Customer", options={"id" = "customerId"})
     * @ParamConverter("product", class="OroProductBundle:Product", options={"id" = "productId"})
     * @AclAncestor("dt_jde_customer_price_request")
     *
     * @param Customer $customer
     * @param Product $product
     *
     * @return JsonResponse
     */
    public function priceRequestAction(Customer $customer, Product $product)
    {
        /** @var CustomerProductPriceLookupInteractor $priceInteractor */
        $priceInteractor = $this->get('dt_customer.interactor.product_price_lookup');

        $customerProductPriceLookupRequestResult = $priceInteractor
            ->getProductPrice(new CustomerProductPriceCriteriaDTO($customer, $product));

        return new JsonResponse($customerProductPriceLookupRequestResult);
    }

    /**
     * @return array|string[]
     */
    public static function getSubscribedServices()
    {
        $services = parent::getSubscribedServices();
        $services['dt_customer.interactor.product_price_lookup'] = CustomerProductPriceLookupInteractor::class;
        return $services;
    }
}
