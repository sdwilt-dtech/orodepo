<?php

namespace DT\Bundle\CustomerBundle\Controller\Api\Rest;

use FOS\RestBundle\Controller\Annotations\NamePrefix;
use Oro\Bundle\CustomerBundle\Controller\Api\Rest\CommerceCustomerAddressController
    as OroCommerceCustomerAddressController;
use Oro\Bundle\CustomerBundle\Entity\Customer;

/**
 * Overridden Rest API controller for customer address entity.
 *
 * This customization is added to show children addresses in address book
 * on a view page of customer with next entity types:
 * - rollup
 * - sub
 * - customer
 *
 * @NamePrefix("oro_api_customer_")
 */
class CommerceCustomerAddressController extends OroCommerceCustomerAddressController
{
    /**
     * @param mixed $entity
     * @param array $resultFields
     * @return array|void
     */
    protected function getPreparedItem($entity, $resultFields = [])
    {
        $result = parent::getPreparedItem($entity, $resultFields);

        $result['frontendOwnerId'] = $entity->getFrontendOwner()
            ? $entity->getFrontendOwner()->getId()
            : null;

        return $result;
    }

    /**
     * @param Customer $customer
     * @return array
     */
    protected function getCustomerAddresses(Customer $customer)
    {
        return $this->get('dt_customer.provider.customer_addresses')
            ->getCustomerAddresses($customer);
    }
}
