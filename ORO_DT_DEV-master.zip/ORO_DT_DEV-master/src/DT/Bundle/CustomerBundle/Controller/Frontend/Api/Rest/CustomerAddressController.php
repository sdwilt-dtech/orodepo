<?php

namespace DT\Bundle\CustomerBundle\Controller\Frontend\Api\Rest;

use DT\Bundle\CustomerBundle\Controller\Api\Rest\CommerceCustomerAddressController;
use FOS\RestBundle\Controller\Annotations\NamePrefix;
use Oro\Bundle\CustomerBundle\Entity\Customer;

/**
 * Overridden Rest API controller for customer address entity.
 *
 * This customization is added to show children addresses in address book
 * on a view page of customer with next entity types:
 * - rollup
 * - sub
 * - customer
 *
 * @NamePrefix("oro_api_customer_frontend_")
 */
class CustomerAddressController extends CommerceCustomerAddressController
{
}
