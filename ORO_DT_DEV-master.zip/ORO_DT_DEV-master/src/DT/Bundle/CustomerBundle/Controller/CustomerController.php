<?php

namespace DT\Bundle\CustomerBundle\Controller;

use DT\Bundle\CustomerBundle\Model\CustomerFieldsets;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Additional customer info widget action to provide separation by different field sets
 */
class CustomerController extends AbstractController
{
    /**
     * @Route(
     *     "/info/{id}/{fieldset}",
     *     name="oro_customer_info_by_fieldset",
     *     requirements={"id"="\d+", "fieldset"="[\w_-]+"}
     * )
     *
     * @AclAncestor("oro_customer_view")
     *
     * @param Request $request
     * @param Customer $customer
     * @param string  $fieldset
     *
     * @return array|RedirectResponse
     */
    public function infoAction(Request $request, Customer $customer, string $fieldset)
    {
        $fieldsetWidgetTemplate = CustomerFieldsets::$fieldsetWidgetTemplateMap[$fieldset] ?? null;

        if (!$request->get('_wid') && $fieldsetWidgetTemplate ===null) {
            return $this->redirect($this->get('router')->generate('oro_contact_view', ['id' => $customer->getId()]));
        }

        return $this->render(
            sprintf('@DTCustomer/Customer/widget/info/%s.html.twig', $fieldsetWidgetTemplate),
            ['entity' => $customer]
        );
    }
}
