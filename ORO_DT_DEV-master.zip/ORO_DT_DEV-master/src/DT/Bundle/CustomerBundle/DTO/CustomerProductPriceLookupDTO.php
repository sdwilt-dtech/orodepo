<?php

namespace DT\Bundle\CustomerBundle\DTO;

class CustomerProductPriceLookupDTO
{
    protected ?float $jdePrice;
    protected ?float $basePrice;
    protected ?bool $isContractedPrice;
    protected ?float $listPrice;
    protected ?string $description;
    protected ?string $description2;
    protected ?string $categoryTitle;
    protected ?string $superCategoryTitle;
    protected ?string $stockingType;
    protected ?string $primaryUOM;
    protected ?string $shippableUOM;
    protected bool $isHazardous;

    /**
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     * @param float|null $jdePrice
     * @param float|null $basePrice
     * @param bool|null $isContractedPrice
     * @param float|null $listPrice
     * @param string|null $description
     * @param string|null $description2
     * @param string|null $categoryTitle
     * @param string|null $superCategoryTitle
     * @param string|null $stockingType
     * @param string|null $primaryUOM
     * @param string|null $shippableUOM
     * @param bool $isHazardous
     */
    public function __construct(
        ?float $jdePrice,
        ?float $basePrice,
        ?bool $isContractedPrice,
        ?float $listPrice,
        ?string $description,
        ?string $description2,
        ?string $categoryTitle,
        ?string $superCategoryTitle,
        ?string $stockingType,
        ?string $primaryUOM,
        ?string $shippableUOM,
        bool $isHazardous
    ) {
        $this->jdePrice = $jdePrice;
        $this->basePrice = $basePrice;
        $this->isContractedPrice = $isContractedPrice;
        $this->listPrice = $listPrice;
        $this->description = $description;
        $this->description2 = $description2;
        $this->categoryTitle = $categoryTitle;
        $this->superCategoryTitle = $superCategoryTitle;
        $this->stockingType = $stockingType;
        $this->primaryUOM = $primaryUOM;
        $this->shippableUOM = $shippableUOM;
        $this->isHazardous = $isHazardous;
    }

    /**
     * @return float|null
     */
    public function getJdePrice(): ?float
    {
        return $this->jdePrice;
    }

    /**
     * @return float|null
     */
    public function getBasePrice(): ?float
    {
        return $this->basePrice;
    }

    /**
     * @return bool|null
     */
    public function isContractedPrice(): ?bool
    {
        return $this->isContractedPrice;
    }

    /**
     * @return float|null
     */
    public function getListPrice(): ?float
    {
        return $this->listPrice;
    }

    /**
     * @return string|null
     */
    public function getDescription(): ?string
    {
        return $this->description;
    }

    /**
     * @return string|null
     */
    public function getDescription2(): ?string
    {
        return $this->description2;
    }

    /**
     * @return string|null
     */
    public function getCategoryTitle(): ?string
    {
        return $this->categoryTitle;
    }

    /**
     * @return string|null
     */
    public function getSuperCategoryTitle(): ?string
    {
        return $this->superCategoryTitle;
    }

    /**
     * @return string|null
     */
    public function getStockingType(): ?string
    {
        return $this->stockingType;
    }

    /**
     * @return string|null
     */
    public function getPrimaryUOM(): ?string
    {
        return $this->primaryUOM;
    }

    /**
     * @return string|null
     */
    public function getShippableUOM(): ?string
    {
        return $this->shippableUOM;
    }

    /**
     * @return bool
     */
    public function isHazardous(): bool
    {
        return $this->isHazardous;
    }

    public function toArray(): array
    {
        return [
            'basePrice' => $this->getBasePrice(),
            'jdePrice' => $this->getJdePrice(),
            'description' => $this->getDescription(),
            'description2' => $this->getDescription2(),
            'shippableUOM' => $this->getShippableUOM(),
            'listPrice' => $this->getListPrice(),
            'primaryUOM' => $this->getPrimaryUOM(),
            'superCategoryTitle' => $this->getSuperCategoryTitle(),
            'categoryTitle' => $this->getCategoryTitle(),
            'stockingType' => $this->getStockingType(),
            'isHazardous' => $this->isHazardous(),
        ];
    }
}
