<?php

namespace DT\Bundle\CustomerBundle\DTO;

use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\ProductBundle\Entity\Product;

class PriceRequestDTO
{
    private ?Customer $customer;
    private ?Product $product;

    /**
     * @param Customer|null $customer
     * @param Product|null  $product
     */
    public function __construct(Customer $customer = null, Product $product = null)
    {
        $this->customer = $customer;
        $this->product = $product;
    }

    /**
     * @return Customer|null
     */
    public function getCustomer(): ?Customer
    {
        return $this->customer;
    }

    /**
     * @param Customer|null $customer
     * @return $this
     */
    public function setCustomer(?Customer $customer): self
    {
        $this->customer = $customer;
        return $this;
    }

    /**
     * @return Product|null
     */
    public function getProduct(): ?Product
    {
        return $this->product;
    }

    /**
     * @param Product|null $product
     * @return $this
     */
    public function setProduct(?Product $product): self
    {
        $this->product = $product;
        return $this;
    }
}
