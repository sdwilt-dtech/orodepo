<?php

namespace DT\Bundle\CustomerBundle\DTO;

class CustomerProductPriceLookupRequestResult implements \JsonSerializable
{
    private bool $success;
    private ?CustomerProductPriceLookupDTO $data;
    private ?string $errorMessage;

    /**
     * @param bool                               $success
     * @param CustomerProductPriceLookupDTO|null $data
     * @param string|null                        $errorMessage
     */
    public function __construct(bool $success, ?CustomerProductPriceLookupDTO $data, ?string $errorMessage)
    {
        $this->success = $success;
        $this->data = $data;
        $this->errorMessage = $errorMessage;
    }

    /**
     * @return bool
     */
    public function isSuccess(): bool
    {
        return $this->success;
    }

    /**
     * @return CustomerProductPriceLookupDTO|null
     */
    public function getData(): ?CustomerProductPriceLookupDTO
    {
        return $this->data;
    }

    /**
     * @return string|null
     */
    public function getErrorMessage(): ?string
    {
        return $this->errorMessage;
    }

    /**
     * {@inheritdoc}
     */
    public function jsonSerialize()
    {
        return [
            'success'      => $this->isSuccess(),
            'errorMessage' => $this->getErrorMessage(),
            'data'         => $this->getData() ? $this->getData()->toArray() : null
        ];
    }
}
