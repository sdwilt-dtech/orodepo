<?php

namespace DT\Bundle\CustomerBundle\EventListener;

use Oro\Bundle\CustomerBundle\Entity\CustomerUser;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Http\Event\InteractiveLoginEvent;

/**
 * Customer user login success event listener to redirect to its profile page
 */
class LoginListener
{
    /** @var UrlGeneratorInterface  */
    private $router;

    public function __construct(UrlGeneratorInterface $router)
    {
        $this->router = $router;
    }

    /**
     * @param InteractiveLoginEvent $event
     */
    public function onSecurityInteractiveLogin(InteractiveLoginEvent $event)
    {
        if ($event->getAuthenticationToken()->getUser() instanceof CustomerUser) {
            $request = $event->getRequest();

            $request->attributes->set(
                '_target_path',
                $this->router->generate('oro_customer_frontend_customer_user_profile')
            );
        }
    }
}
