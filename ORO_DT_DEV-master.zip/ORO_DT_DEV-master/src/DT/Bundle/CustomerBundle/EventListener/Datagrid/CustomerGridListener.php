<?php

namespace DT\Bundle\CustomerBundle\EventListener\Datagrid;

use DT\Bundle\SetupBundle\Model\CustomerFields;
use Oro\Bundle\DataGridBundle\Datagrid\Common\DatagridConfiguration;
use Oro\Bundle\DataGridBundle\Event\BuildAfter;
use Oro\Bundle\DataGridBundle\Event\BuildBefore;
use Oro\Bundle\DataGridBundle\Extension\Formatter\Configuration;
use Oro\Bundle\SalesBundle\Datagrid\Extension\Customers\AccountExtension;
use Oro\Bundle\TaxBundle\EventListener\TaxCodeGridListener;
use Oro\Component\DataGrid\GridModifierHelperTrait;

/**
 * Customer grid event listener to customize initial columns similar to salesforce.
 */
class CustomerGridListener
{
    use GridModifierHelperTrait;

    /**
     * @param BuildBefore $event
     */
    public function onBuildBefore(BuildBefore $event): void
    {
        $config = $event->getDatagrid()->getConfig();

        $this->showDynamicFieldColumns($config, $this->getConfigOfDynamicFieldsColumnsToShow());
        $this->addOwnerColumn($config);
        $this->addAddressColumns($config);
    }

    /**
     * @param BuildAfter $event
     */
    public function onBuildAfter(BuildAfter $event): void
    {
        $config = $event->getDatagrid()->getConfig();

        $this->setColumnVisibility($this->getColumnsToHide(), $config, false);
        $this->setFiltersVisibility($this->getFiltersToHide(), $config, false);
        $this->setFiltersVisibility($this->getFiltersToShow(), $config, true);
        $this->sortColumns($this->getColumnsOrder(), $config);
        $this->sortFilters($this->getFiltersOrder(), $config);
    }

    /**
     * Adds customer owner name to grid.
     * No sorters included so far(DIV-594).
     *
     * @param DatagridConfiguration $config
     */
    private function addOwnerColumn(DatagridConfiguration $config): void
    {
        $query = $config->getOrmQuery();

        $query->addLeftJoin($query->getRootAlias() . '.owner', 'o');
        $config->addColumn(
            'ownerName',
            ['label' => 'dt.customer.grid.customers.owner_name.label'],
            "CONCAT(o.firstName, ' ' , o.lastName) as ownerName",
            [],
            ['type' => 'string', 'data_name' => 'ownerName']
        );
    }

    /**
     * Adds primary address information to grid
     *
     * @param DatagridConfiguration $config
     */
    private function addAddressColumns(DatagridConfiguration $config): void
    {
        $query = $config->getOrmQuery();

        $query->addLeftJoin($query->getRootAlias() . '.addresses', 'ca', 'WITH', 'ca.primary = true');
        $query->addLeftJoin('ca.region', 'car');

        $config->addColumn(
            'address_city',
            ['label' => 'dt.customer.grid.customers.address_city.label'],
            "ca.city as address_city",
            [],
            ['type' => 'string', 'data_name' => 'address_city']
        );
        $config->addColumn(
            'address_region',
            ['label' => 'dt.customer.grid.customers.address_region.label'],
            "COALESCE(car.name, ca.regionText) as address_region",
            [],
            ['type' => 'string', 'data_name' => 'address_region']
        );
    }

    /**
     * @return array
     */
    private function getColumnsToHide(): array
    {
        return [
            'group_name',
            TaxCodeGridListener::DATA_NAME,
            AccountExtension::COLUMN_NAME,
            'internal_rating_name',
            'payment_term_7c4f1e8e',
            'parent_name'
        ];
    }

    /**
     * @return array
     */
    private function getFiltersToHide(): array
    {
        return array_merge(
            $this->getColumnsToHide(),
            ['price_list', 'customerGroupTaxCode']
        );
    }

    /**
     * @return array
     */
    private function getFiltersToShow(): array
    {
        return ['parent_name'];
    }

    /**
     * @return array
     */
    private function getConfigOfDynamicFieldsColumnsToShow(): array
    {
        return [
            CustomerFields::DT_JDE_ID => [],
            CustomerFields::DT_PHONE => ['frontend_type' => 'phone'],
            CustomerFields::DT_ENTITY_TYPE => [Configuration::TYPE_KEY => 'twig'],
            CustomerFields::DT_BILLING_TYPE => [Configuration::TYPE_KEY => 'twig'],
            CustomerFields::DT_CUSTOMER_TYPE => [Configuration::TYPE_KEY => 'twig'],
            CustomerFields::DT_REGION => []
        ];
    }

    /**
     * @return array
     */
    private function getColumnsOrder(): array
    {
        return [
            CustomerFields::DT_JDE_ID,
            'name',
            CustomerFields::DT_ENTITY_TYPE,
            CustomerFields::DT_BILLING_TYPE,
            'address_city',
            'address_region',
            CustomerFields::DT_PHONE,
            CustomerFields::DT_CUSTOMER_TYPE,
            CustomerFields::DT_REGION,
            'ownerName',
        ];
    }

    /**
     * @return array
     */
    private function getFiltersOrder(): array
    {
        return [
            CustomerFields::DT_JDE_ID,
            'name',
            CustomerFields::DT_ENTITY_TYPE,
            CustomerFields::DT_BILLING_TYPE,
            'address_city',
            'address_region',
            'parent_name',
            CustomerFields::DT_PHONE,
            CustomerFields::DT_CUSTOMER_TYPE,
            CustomerFields::DT_REGION,
            'ownerName',
        ];
    }
}
