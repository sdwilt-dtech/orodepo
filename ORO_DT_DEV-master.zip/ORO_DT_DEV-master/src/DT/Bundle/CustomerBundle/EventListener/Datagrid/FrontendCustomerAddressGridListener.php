<?php

namespace DT\Bundle\CustomerBundle\EventListener\Datagrid;

use DT\Bundle\CustomerBundle\Provider\CustomerAddressesProvider;
use Oro\Bundle\CustomerBundle\Entity\CustomerUser;
use Oro\Bundle\DataGridBundle\Datagrid\Common\DatagridConfiguration;
use Oro\Bundle\DataGridBundle\Event\BuildBefore;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

/**
 * Listener added for the next reasons:
 * - Adds additional column to grid "frontend-customer-customer-address-grid".
 * - Remove "show map" action
 */
class FrontendCustomerAddressGridListener
{
    /** @var CustomerAddressesProvider */
    private $addressProvider;

    /** @var TokenStorageInterface */
    private $tokenStorage;

    /**
     * @param CustomerAddressesProvider $addressesProvider
     */
    public function __construct(
        CustomerAddressesProvider $addressesProvider,
        TokenStorageInterface $tokenStorage
    ) {
        $this->addressProvider = $addressesProvider;
        $this->tokenStorage = $tokenStorage;
    }

    /**
     * @param BuildBefore $event
     */
    public function onBuildBefore(BuildBefore $event)
    {
        $config = $event->getDatagrid()->getConfig();
        $config->addColumn(
            'organization',
            [
                'label' => 'oro.customer.customeraddress.organization.label',
                'order' => -1,
            ]
        );
        $config->offsetUnsetByPath('[actions][show_map]');

        $user = $this->tokenStorage->getToken()->getUser();
        if ($user instanceof CustomerUser && $customer = $user->getCustomer()) {
            $config->offsetSetByPath(DatagridConfiguration::DATASOURCE_SKIP_ACL_APPLY_PATH, true);

            $query = $config->getOrmQuery();
            $query->addLeftJoin('address.frontendOwner', 'fo')
                ->addAndWhere('fo.id IN (:frontendOwnerIds)');
            $config->offsetSetByPath(
                DatagridConfiguration::DATASOURCE_BIND_PARAMETERS_PATH,
                ['frontendOwnerIds']
            );

            $datagrid = $event->getDatagrid();
            $datagrid->getParameters()->set(
                'frontendOwnerIds',
                $this->addressProvider->getCustomerAddressesFrontendOwnerIds($customer)
            );
        }
    }
}
