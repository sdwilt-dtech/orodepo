<?php

namespace DT\Bundle\CustomerBundle\EventListener\Datagrid;

use Oro\Bundle\DataGridBundle\Datagrid\Common\DatagridConfiguration;
use Oro\Bundle\DataGridBundle\Event\BuildAfter;
use Oro\Component\DataGrid\GridModifierHelperTrait;

/**
 * Customer contacts grid event listener to customize initial columns similar to salesforce.
 */
class CustomerContactsGridListener
{
    use GridModifierHelperTrait;

    /**
     * @param BuildAfter $event
     */
    public function onBuildAfter(BuildAfter $event): void
    {
        $config = $event->getDatagrid()->getConfig();

        $this->removeColumns($this->getColumnsToRemove(), $config);
        $this->removeFilters($this->getFiltersToRemove(), $config);
        $this->disableLineEditing($config);
    }

    /**
     * @param DatagridConfiguration $config
     */
    private function disableLineEditing(DatagridConfiguration $config): void
    {
        $config->offsetSetByPath('[inline_editing][enable]', false);
    }

    /**
     * @return array
     */
    private function getColumnsToRemove(): array
    {
        return ['customerDtJdeId', 'customerName'];
    }

    /**
     * @return array
     */
    private function getFiltersToRemove(): array
    {
        return $this->getColumnsToRemove();
    }
}
