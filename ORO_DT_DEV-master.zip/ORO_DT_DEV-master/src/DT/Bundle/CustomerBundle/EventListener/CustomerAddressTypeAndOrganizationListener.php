<?php

namespace DT\Bundle\CustomerBundle\EventListener;

use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Event\OnClearEventArgs;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Event\PostFlushEventArgs;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Oro\Bundle\AddressBundle\Entity\AddressType;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\CustomerBundle\Entity\CustomerAddress;

/**
 * Customer address entity listener to setup organization name and type based on specific customer info
 */
class CustomerAddressTypeAndOrganizationListener
{
    /** @var AddressType */
    private $billingAddressType;

    /** @var AddressType */
    private $shippingAddressType;

    /** @var array */
    private $nameChangedCustomers = [];

    /** @var array */
    private $billingTypeChangedCustomers = [];

    public function onClear(OnClearEventArgs $clearEventArgs)
    {
        if ($clearEventArgs->clearsAllEntities() || $clearEventArgs->getEntityClass() == AddressType::class) {
            $this->billingAddressType = null;
            $this->shippingAddressType = null;
        }
    }

    /**
     * @param OnFlushEventArgs $eventArgs
     */
    public function onFlush(OnFlushEventArgs $eventArgs)
    {
        $em = $eventArgs->getEntityManager();
        $uow = $em->getUnitOfWork();

        $scheduledEntities = array_merge(
            $uow->getScheduledEntityInsertions(),
            $uow->getScheduledEntityUpdates()
        );

        foreach ($scheduledEntities as $entity) {
            if ($entity instanceof Customer) {
                $changeSet = $uow->getEntityChangeSet($entity);

                if (isset($changeSet['name'])) {
                    $this->nameChangedCustomers[(int)$entity->getId()] = $entity;
                }
                if (isset($changeSet['dt_billing_type'])) {
                    $this->billingTypeChangedCustomers[(int)$entity->getId()] = $entity;
                }
            }

            if ($entity instanceof CustomerAddress && !$entity->getId()
                && $customer = $entity->getFrontendOwner()
            ) {
                $this->nameChangedCustomers[(int)$customer->getId()] = $customer;
                $this->billingTypeChangedCustomers[(int)$customer->getId()] = $customer;
            }
        }
    }

    /**
     * @param PostFlushEventArgs $event
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function postFlush(PostFlushEventArgs $event): void
    {
        if (!count($this->nameChangedCustomers) && !count($this->billingTypeChangedCustomers)) {
            return;
        }

        $em = $event->getEntityManager();

        foreach ($this->nameChangedCustomers as $customer) {
            $this->updateCustomerAddressesOrganization($customer, $em);
        }
        foreach ($this->billingTypeChangedCustomers as $customer) {
            $this->updateCustomerAddressesType($customer, $em);
        }

        $this->nameChangedCustomers = $this->billingTypeChangedCustomers = [];
        $em->flush();
    }

    /**
     * @param Customer $customer
     * @param EntityManager $em
     * @throws ORMException
     */
    private function updateCustomerAddressesOrganization(Customer $customer, EntityManager $em): void
    {
        foreach ($customer->getAddresses() as $address) {
            $address->setOrganization($customer->getName());
        }
    }

    /**
     * @param Customer $customer
     * @param EntityManager $em
     * @throws ORMException
     */
    private function updateCustomerAddressesType(Customer $customer, EntityManager $em): void
    {
        $customerBillingType = $customer->getDtBillingType() !== null
            ? $customer->getDtBillingType()->getId()
            : null;

        $this->ensureAddressTypeLoaded($em);

        foreach ($customer->getAddresses() as $address) {
            switch ($customerBillingType) {
                case 'X':
                    $address->addType($this->billingAddressType);
                    $address->addType($this->shippingAddressType);
                    break;
                case 'B':
                    $address->addType($this->billingAddressType);
                    $address->removeType($this->shippingAddressType);
                    break;
                case 'S':
                    $address->addType($this->shippingAddressType);
                    $address->removeType($this->billingAddressType);
                    break;
                default:
                    $address->removeType($this->billingAddressType);
                    $address->removeType($this->shippingAddressType);
            }

            $em->persist($address);
        }
    }

    private function ensureAddressTypeLoaded(EntityManager $entityManager)
    {
        $addressTypeRepository = $entityManager->getRepository(AddressType::class);
        if (null === $this->billingAddressType) {
            $this->billingAddressType = $addressTypeRepository->findOneBy(['name' => AddressType::TYPE_BILLING]);
        }
        if (null === $this->shippingAddressType) {
            $this->shippingAddressType = $addressTypeRepository->findOneBy(['name' => AddressType::TYPE_SHIPPING]);
        }
    }
}
