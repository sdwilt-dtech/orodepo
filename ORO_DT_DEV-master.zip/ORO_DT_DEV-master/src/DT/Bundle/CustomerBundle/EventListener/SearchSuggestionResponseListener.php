<?php

namespace DT\Bundle\CustomerBundle\EventListener;

use Doctrine\ORM\EntityManager;
use DT\Bundle\SetupBundle\Model\CustomerFields;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\CustomerBundle\Entity\CustomerAddress;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\PropertyAccess\Exception\NoSuchPropertyException;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Event listener to handle 'oro_search_suggestion' route and
 * expand its response with additional customer data if customer result items are present.
 */
class SearchSuggestionResponseListener
{
    /** @var EntityManager */
    private $entityManager;

    /** @var PropertyAccessorInterface */
    private $propertyAccessor;

    /** @var TranslatorInterface */
    private $translator;

    /**
     * @param EntityManager $entityManager
     * @param PropertyAccessorInterface $propertyAccessor
     * @param TranslatorInterface $translator
     */
    public function __construct(
        EntityManager $entityManager,
        PropertyAccessorInterface $propertyAccessor,
        TranslatorInterface $translator
    ) {
        $this->entityManager    = $entityManager;
        $this->propertyAccessor = $propertyAccessor;
        $this->translator       = $translator;
    }

    /**
     * @param ResponseEvent $event
     */
    public function onKernelResponse(ResponseEvent $event): void
    {
        $request  = $event->getRequest();
        $response = $event->getResponse();

        if ($request->attributes->get('_route') !== 'oro_search_suggestion'
            && !($response instanceof JsonResponse)
        ) {
            return;
        }

        $data = json_decode($response->getContent(), true);

        $customerIdToRecordIndexMap = [];
        $items = $data['data'] ?? [];
        foreach ((is_array($items) ? $items : []) as $index => $item) {
            $entityName = $item['entity_name'] ?? null;
            $entityId   = $item['record_id'] ?? null;
            if ($entityName !== Customer::class || !$entityId) {
                continue;
            }

            $customerIdToRecordIndexMap[$entityId] = $index;
        }

        if (!count($customerIdToRecordIndexMap)) {
            return;
        }

        $queryBuilder = $this->entityManager->getRepository(Customer::class)
            ->createQueryBuilder('c');
        $queryBuilder->where($queryBuilder->expr()->in('c.id', ':customerIds'));
        $queryBuilder->setParameter('customerIds', array_keys($customerIdToRecordIndexMap));

        foreach ($queryBuilder->getQuery()->getResult() as $customer) {
            $customerAdditionalInfo = $this->getCustomerAdditionalInfo($customer);
            $recordIndex = $customerIdToRecordIndexMap[$customer->getId()];

            $this->propertyAccessor->setValue(
                $data,
                sprintf('[data][%d][record_additional_info]', $recordIndex),
                $customerAdditionalInfo
            );
        }

        $response->setData($data);
    }

    /**
     * @param Customer $customer
     * @return array
     */
    private function getCustomerAdditionalInfo(Customer $customer): array
    {
        $info = [];

        /** @var AbstractEnumValue $entityType */
        $entityType = $this->getValue($customer, CustomerFields::DT_ENTITY_TYPE);
        if ($entityType && $entityType->getId() !== EnumValues::DT_CUSTOMER_ENTITY_TYPE_CUSTOMER) {
            $info['entity_type'] = [
                'label' => $this->translator->trans('oro.customer.dt_entity_type.label'),
                'value' => $entityType->getName()
            ];
        }

        if ($billingType = $this->getValue($customer, CustomerFields::DT_BILLING_TYPE)) {
            $info['billing_type'] = [
                'label' => $this->translator->trans('oro.customer.dt_billing_type.label'),
                'value' => $billingType->getName(),
            ];
        }

        /** @var CustomerAddress|null $address */
        $address = $customer->getAddresses()->first();

        if ($address && $address->getCity()) {
            $info['city'] = [
                'label' => $this->translator->trans('oro.customer.customeraddress.city.label'),
                'value' => $address->getCity(),
            ];
        }

        if ($address && $address->getRegionName()) {
            $info['state'] = [
                'label' => $this->translator->trans('oro.customer.customeraddress.region.label'),
                'value' => $address->getRegionCode() ?: $address->getRegionName(),
            ];
        }

        return $info;
    }

    /**
     * @param object|array $obj
     * @param string $property
     * @return mixed|null
     */
    private function getValue($obj, $property)
    {
        try {
            $value = $this->propertyAccessor->getValue($obj, $property);
        } catch (NoSuchPropertyException $e) {
            $value = null;
        }

        return $value;
    }
}
