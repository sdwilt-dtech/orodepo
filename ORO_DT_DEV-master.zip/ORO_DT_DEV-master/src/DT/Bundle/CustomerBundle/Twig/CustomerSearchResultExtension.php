<?php

namespace DT\Bundle\CustomerBundle\Twig;

use DT\Bundle\SetupBundle\Model\CustomerAddressFields;
use DT\Bundle\SetupBundle\Model\CustomerFields;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Symfony\Component\PropertyAccess\Exception\NoSuchPropertyException;
use Symfony\Component\PropertyAccess\PropertyAccessor;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

/**
 * Provides Twig function to retrieve prepared info for customer search result item
 *   - dt_customer_search_result_additional_info
 */
class CustomerSearchResultExtension extends AbstractExtension
{
    /** @var PropertyAccessor */
    private $propertyAccessor;

    /**
     * @param PropertyAccessor $propertyAccessor
     */
    public function __construct(
        PropertyAccessor $propertyAccessor
    ) {
        $this->propertyAccessor = $propertyAccessor;
    }

    /**
     * {@inheritdoc}
     */
    public function getFunctions(): array
    {
        return [
            new TwigFunction(
                'dt_customer_search_result_additional_info',
                [$this, 'getCustomerSearchResultAdditionalInfo']
            ),
        ];
    }

    /**
     * @param object $entity
     * @return array|null
     */
    public function getCustomerSearchResultAdditionalInfo($entity): ?array
    {
        if (!$entity instanceof Customer) {
            return null;
        }

        $info = [];

        if ($entityType = $this->getValue($entity, CustomerFields::DT_ENTITY_TYPE)) {
            $info['entity_type'] = $entityType->getName();
        }
        if ($billingType = $this->getValue($entity, CustomerFields::DT_BILLING_TYPE)) {
            $info['billing_type'] = $billingType->getName();
        }

        $address = $entity->getAddresses()->first();
        if ($address) {
            $street = array_filter(
                [
                    $address->getStreet(),
                    $address->getStreet2(),
                    $this->getValue($address, CustomerAddressFields::DT_STREET3),
                    $this->getValue($address, CustomerAddressFields::DT_STREET4)
                ],
                function ($streetPart) {
                    return (bool)trim($streetPart);
                }
            );

            $info['street'] = implode(' ', $street);
            $info['city']   = $address->getCity();
            $info['state']  = $address->getRegionName() ?: $address->getRegionCode();
            $info['zip']    = $address->getPostalCode();
        }

        return count($info) ? $info : null;
    }

    /**
     * @param object $obj
     * @param string $property
     * @return mixed|null
     */
    private function getValue($obj, $property)
    {
        try {
            $value = $this->propertyAccessor->getValue($obj, $property);
        } catch (NoSuchPropertyException $e) {
            $value = null;
        }

        return $value;
    }
}
