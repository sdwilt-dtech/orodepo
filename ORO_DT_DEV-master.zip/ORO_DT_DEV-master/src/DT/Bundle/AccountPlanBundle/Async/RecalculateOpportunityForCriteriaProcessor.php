<?php

namespace DT\Bundle\AccountPlanBundle\Async;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider\Criteria;
use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\OpportunityProviderInterface;
use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use DT\Bundle\EntityBundle\Entity\Region;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Component\Log\ContextFactory;
use Oro\Component\MessageQueue\Client\MessageProducerInterface;
use Oro\Component\MessageQueue\Client\TopicSubscriberInterface;
use Oro\Component\MessageQueue\Consumption\MessageProcessorInterface;
use Oro\Component\MessageQueue\Transport\MessageInterface;
use Oro\Component\MessageQueue\Transport\SessionInterface;
use Oro\Component\MessageQueue\Util\JSON;
use Psr\Log\LoggerInterface;

class RecalculateOpportunityForCriteriaProcessor implements MessageProcessorInterface, TopicSubscriberInterface
{
    /** @var LoggerInterface  */
    private $logger;

    /** @var ManagerRegistry */
    private $doctrine;

    /** @var OpportunityProviderInterface */
    private $opportunityProvider;

    /** @var MessageProducerInterface */
    private $messageProducer;

    /**
     * @param LoggerInterface $logger
     * @param ManagerRegistry $doctrine
     * @param MessageProducerInterface $messageProducer
     * @param OpportunityProviderInterface $opportunityProvider
     */
    public function __construct(
        LoggerInterface $logger,
        ManagerRegistry $doctrine,
        MessageProducerInterface $messageProducer,
        OpportunityProviderInterface $opportunityProvider
    ) {
        $this->logger = $logger;
        $this->doctrine = $doctrine;
        $this->messageProducer = $messageProducer;
        $this->opportunityProvider = $opportunityProvider;
    }

    /**
     * {@inheritdoc}
     */
    public function process(MessageInterface $message, SessionInterface $session)
    {
        $body = JSON::decode($message->getBody());
        if (!$this->isMessageValid($body)) {
            $this->logger->critical(
                'Message body has incorrect data.',
                $body
            );

            return self::REJECT;
        }
        try {
            return $this->doProcess($body);
        } catch (\Throwable $exc) {
            $this->logger->critical(
                sprintf(
                    'Error occured during Opportunity from criteria update. Error message: %s',
                    $exc->getMessage()
                ),
                ContextFactory::createForThrowable(
                    $exc,
                    $body
                )
            );
        }
    }

    /**
     * Returns entity for PK by class name
     *
     * @param string $className
     * @param int $id
     */
    private function get(string $className, int $id)
    {
        return $this
            ->doctrine
            ->getManagerForClass($className)
            ->getRepository($className)
            ->find($id);
    }

    /**
     * @param array $body
     * @return string
     */
    private function doProcess(array $body): string
    {
        if (!($region = $this->get(Region::class, $body[Criteria::KEY_REGION]))) {
            $this->logger->warning(sprintf('Could not find region for ID %s', $body[Criteria::KEY_REGION]));

            return self::REJECT;
        }
        if (!($customer = $this->get(Customer::class, $body[Criteria::KEY_CUSTOMER]))) {
            $this->logger->warning(sprintf('Could not find customer for ID %s', $body[Criteria::KEY_CUSTOMER]));

            return self::REJECT;
        }
        /** @var ProductCategoryCode $productCategoryCode */
        $productCategoryCode = $this
            ->get(ProductCategoryCode::class, $body[Criteria::KEY_PRODUCT_CATEGORY_CODE]);
        if (!$productCategoryCode) {
            $this->logger->warning(sprintf(
                'Could not find productCategoryCode for ID %s',
                $body[Criteria::KEY_PRODUCT_CATEGORY_CODE]
            ));

            return self::REJECT;
        }

        $criteria = new Criteria($region, $customer, $productCategoryCode, $body[Criteria::KEY_YEAR]);
        if (!($opportunity = $this->opportunityProvider->getOpportunity($criteria))) {
            $this->logger->warning('Could not find opportunity matching criteria', $criteria->toArray());

            return self::REJECT;
        }

        $this->messageProducer->send(Topics::UPDATE_OPPORTUNITY, [
            'opportunity_id' => $opportunity->getId()
        ]);

        return self::ACK;
    }

    /**
     * @param array $body
     * @return bool
     */
    private function isMessageValid(array $body): bool
    {
        return isset($body[Criteria::KEY_REGION])
            && isset($body[Criteria::KEY_PRODUCT_CATEGORY_CODE])
            && isset($body[Criteria::KEY_CUSTOMER])
            && isset($body[Criteria::KEY_YEAR]);
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedTopics()
    {
        return [
            Topics::UPDATE_OPPORTUNITY_BY_CRITERIA
        ];
    }
}
