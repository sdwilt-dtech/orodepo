<?php

namespace DT\Bundle\AccountPlanBundle\Async;

use Doctrine\ORM\EntityRepository;
use DT\Bundle\AccountPlanBundle\Command\RecalculateAccountPlansCommand;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\Repository\GoAccountPlanRepository;
use Oro\Bundle\ActionBundle\Model\ActionData;
use Oro\Bundle\ActionBundle\Model\ActionGroupRegistry;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Oro\Component\Log\ContextFactory;
use Oro\Component\MessageQueue\Client\TopicSubscriberInterface;
use Oro\Component\MessageQueue\Consumption\MessageProcessorInterface;
use Oro\Component\MessageQueue\Job\Job;
use Oro\Component\MessageQueue\Job\JobRunner;
use Oro\Component\MessageQueue\Transport\MessageInterface;
use Oro\Component\MessageQueue\Transport\SessionInterface;
use Oro\Component\MessageQueue\Util\JSON;
use Psr\Log\LoggerInterface;

class RecalculateAccountPlanMessageProcessor implements MessageProcessorInterface, TopicSubscriberInterface
{
    /** @var DoctrineHelper */
    private $doctrineHelper;

    /** @var ActionGroupRegistry */
    private $actionGroupRegistry;

    /** @var JobRunner */
    private $jobRunner;

    /** @var LoggerInterface  */
    private $logger;

    /**
     * @param DoctrineHelper $doctrineHelper
     * @param ActionGroupRegistry $actionGroupRegistry
     * @param JobRunner $jobRunner
     * @param LoggerInterface $logger
     */
    public function __construct(
        DoctrineHelper $doctrineHelper,
        ActionGroupRegistry $actionGroupRegistry,
        JobRunner $jobRunner,
        LoggerInterface $logger
    ) {
        $this->doctrineHelper = $doctrineHelper;
        $this->actionGroupRegistry = $actionGroupRegistry;
        $this->jobRunner = $jobRunner;
        $this->logger = $logger;
    }

    /**
     * {@inheritdoc}
     */
    public function process(MessageInterface $message, SessionInterface $session): string
    {
        $body = JSON::decode($message->getBody());

        if (!$this->isMessageValid($body)) {
            $this->logger->critical(
                'Message body has incorrect data.  Parameter "account_plan_id" must be provided',
                $body
            );

            return self::REJECT;
        }

        $result = $this->jobRunner->runUnique(
            $message->getMessageId(),
            Topics::RECALCULATE_ACCOUNT_PLAN . ':' . $body['account_plan_id'],
            function (JobRunner $jobRunner, Job $job) use ($body) {
                try {
                    $accountPlan = $this->getAccountPlanRepository()->find($body['account_plan_id']);
                    $actionGroup = $this->actionGroupRegistry->get(
                        RecalculateAccountPlansCommand::RECALCULATE_ACTION_GROUP_NAME
                    );
                    $actionData = (new ActionData())
                        ->set('account_plan', $accountPlan);

                    $actionGroup->execute($actionData);
                } catch (\Throwable $e) {
                    $this->logger->critical(
                        sprintf('Error occurs during AccountPlan recalculation. Error message: %s', $e->getMessage()),
                        ContextFactory::createForThrowable(
                            $e,
                            [ 'account_plan_id' => $body['account_plan_id'] ]
                        )
                    );
                    return false;
                }

                return true;
            }
        );

        return $result ? self::ACK : self::REJECT;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedTopics(): array
    {
        return [Topics::RECALCULATE_ACCOUNT_PLAN];
    }

    /**
     * @param array $body
     * @return bool
     */
    private function isMessageValid(array $body): bool
    {
        return isset($body['account_plan_id']);
    }

    /**
     * @return GoAccountPlanRepository|EntityRepository
     */
    private function getAccountPlanRepository(): GoAccountPlanRepository
    {
        return $this->doctrineHelper->getEntityRepositoryForClass(GoAccountPlan::class);
    }
}
