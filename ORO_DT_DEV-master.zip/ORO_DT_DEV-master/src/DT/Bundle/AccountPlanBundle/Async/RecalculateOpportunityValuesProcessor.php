<?php

namespace DT\Bundle\AccountPlanBundle\Async;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Manager\OpportunityUpdate;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Component\Log\ContextFactory;
use Oro\Component\MessageQueue\Client\TopicSubscriberInterface;
use Oro\Component\MessageQueue\Consumption\MessageProcessorInterface;
use Oro\Component\MessageQueue\Job\Job;
use Oro\Component\MessageQueue\Job\JobRunner;
use Oro\Component\MessageQueue\Transport\MessageInterface;
use Oro\Component\MessageQueue\Transport\SessionInterface;
use Oro\Component\MessageQueue\Util\JSON;
use Psr\Log\LoggerInterface;

class RecalculateOpportunityValuesProcessor implements MessageProcessorInterface, TopicSubscriberInterface
{
    /** @var LoggerInterface  */
    private $logger;

    /** @var ManagerRegistry */
    private $doctrine;

    /** @var OpportunityUpdate */
    private $opportunityUpdate;

    /** @var JobRunner */
    private $jobRunner;

    /**
     * @param LoggerInterface $logger
     * @param ManagerRegistry $doctrine
     * @param OpportunityUpdate $opportunityUpdate
     * @param JobRunner $jobRunner
     */
    public function __construct(
        LoggerInterface $logger,
        ManagerRegistry $doctrine,
        OpportunityUpdate $opportunityUpdate,
        JobRunner $jobRunner
    ) {
        $this->doctrine = $doctrine;
        $this->logger = $logger;
        $this->opportunityUpdate = $opportunityUpdate;
        $this->jobRunner = $jobRunner;
    }

    /**
     * {@inheritdoc}
     */
    public function process(MessageInterface $message, SessionInterface $session)
    {
        $body = JSON::decode($message->getBody());
        if (!$this->isMessageValid($body)) {
            $this->logger->critical(
                'Message body has incorrect data.  Parameter "account_plan_id" must be provided',
                $body
            );

            return self::REJECT;
        }

        return $this->doProcess($body, $message);
    }

    /**
     * @param array $body
     * @param MessageInterface $message
     * @return string
     */
    private function doProcess(array $body, MessageInterface $message): string
    {
        $result = $this->jobRunner->runUnique(
            $message->getMessageId(),
            Topics::UPDATE_OPPORTUNITY . ':' . $body['opportunity_id'],
            function (JobRunner $jobRunner, Job $job) use ($body) {
                try {
                    /** @var GoOpportunity $opportunity */
                    $opportunity = $this
                        ->doctrine
                        ->getManagerForClass(GoOpportunity::class)
                        ->getRepository(GoOpportunity::class)
                        ->find($body['opportunity_id']);

                    if (!$opportunity) {
                        $this->logger->warning(sprintf(
                            'Opportunity with ID %s not found.',
                            $body['opportunity_id']
                        ));

                        return false;
                    }

                    $this->opportunityUpdate->update($opportunity);
                } catch (\Throwable $exc) {
                    $this->logger->critical(
                        sprintf(
                            'Error occured during Opportunity values update. Error message: %s',
                            $exc->getMessage()
                        ),
                        ContextFactory::createForThrowable(
                            $exc,
                            [ 'opportunity_id' => $body['opportunity_id'] ]
                        )
                    );

                    return false;
                }

                return true;
            }
        );

        return $result ? self::ACK : self::REJECT;
    }

    /**
     * @param array $body
     * @return bool
     */
    private function isMessageValid(array $body): bool
    {
        return isset($body['opportunity_id']);
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedTopics()
    {
        return [
            Topics::UPDATE_OPPORTUNITY
        ];
    }
}
