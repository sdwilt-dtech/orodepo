<?php

namespace DT\Bundle\AccountPlanBundle\Async;

class Topics
{
    public const RECALCULATE_ACCOUNT_PLAN = 'dt.account_plan_bundle.recalculate_account_plan';
    public const UPDATE_OPPORTUNITY_BY_CRITERIA = 'dt.account_plan_bundle.update_criteria_opportunity';
    public const UPDATE_OPPORTUNITY = 'dt.account_plan_bundle.update_opportunity';
}
