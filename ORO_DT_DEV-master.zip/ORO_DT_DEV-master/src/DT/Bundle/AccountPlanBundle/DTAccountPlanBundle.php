<?php

namespace DT\Bundle\AccountPlanBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * DTAccountPlanBundle bundle class
 */
class DTAccountPlanBundle extends Bundle
{
}
