<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Unit\Provider\GoAccountPlan;

use DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan\PercentageChangeValueProvider;
use DT\Bundle\AccountPlanBundle\Tests\Unit\Provider\AbstractMetricTestCase;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use PHPUnit\Framework\MockObject\MockObject;

class PercentageChangeValueProviderTest extends AbstractMetricTestCase
{
    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        parent::setUp();
        $this->metric = new PercentageChangeValueProvider();
        $this->metric->setMetricsProvider($this->metricsProvider);
    }

    /**
     * @param float $expectedGrowth
     * @param float $priorSales
     * @param float|null $expectedResult
     * @dataProvider testGetPercentageChangeData
     */
    public function testGetPercentageChangeValue(
        float $expectedActualYtd,
        float $expectedPriorYtd,
        ?float $expectedResult
    ): void {
        /** @var MockObject|GoAccountPlan $entity */
        $entity = $this->getMockBuilder(GoAccountPlan::class)->getMock();
        $entity->expects($this->once())->method('getActualYtd')->willReturn($expectedActualYtd);
        $entity->expects($this->once())->method('getPriorYtd')->willReturn($expectedPriorYtd);

        $this->assertEquals($expectedResult, $this->metric->calculateValue($entity));
    }

    /**
     * @return float[][]
     */
    public function testGetPercentageChangeData(): array
    {
        return [
            [0.00, 0.00, null],
            [1000.00, 0.00, null],
            [2000.00, 1000.00, 1],
            [4000.00, 1000.00, 3],
            [1000.00, 2000.00, -0.5]
        ];
    }
}
