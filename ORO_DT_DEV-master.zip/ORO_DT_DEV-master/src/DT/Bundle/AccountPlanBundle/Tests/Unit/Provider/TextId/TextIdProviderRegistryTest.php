<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Unit\Provider\TextId;

use DT\Bundle\AccountPlanBundle\Provider\TextId\TextIdProviderInterface;
use DT\Bundle\AccountPlanBundle\Provider\TextId\TextIdProviderRegistry;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpFoundation\Request;

class TextIdProviderRegistryTest extends TestCase
{
    /** @var TextIdProviderRegistry */
    private $textIdProviderRegistry;

    public function testMetricsProvider(): void
    {
        $request = Request::createFromGlobals();
        /** @var MockObject|TextIdProviderInterface $provider1 */
        $provider1 = $this->getMockBuilder(TextIdProviderInterface::class)->getMock();
        $provider1->expects($this->exactly(1))
            ->method('getTextId')
            ->with($request)
            ->willReturn('test1234');
        $provider1->expects($this->exactly(1))
            ->method('getHandledClass')
            ->willReturn(GoOpportunity::class);

        /** @var MockObject|TextIdProviderInterface $provider2 */
        $provider2 = $this->getMockBuilder(TextIdProviderInterface::class)->getMock();
        $provider2->expects($this->never())
            ->method('getTextId');
        $provider2->expects($this->exactly(1))
            ->method('getHandledClass')
            ->willReturn(GoOpportunityGroup::class);

        $this->textIdProviderRegistry = new TextIdProviderRegistry([
            $provider1
        ]);
        $this->textIdProviderRegistry->addProvider($provider2);

        $resultTextId = $this->textIdProviderRegistry->getProvider(GoOpportunity::class)->getTextId($request);
        $this->assertEquals('test1234', $resultTextId);
    }
}
