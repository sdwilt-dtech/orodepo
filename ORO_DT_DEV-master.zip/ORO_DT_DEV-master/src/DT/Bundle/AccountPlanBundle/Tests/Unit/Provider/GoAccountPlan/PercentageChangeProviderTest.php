<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Unit\Provider\GoAccountPlan;

use DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan\PercentageChangeProvider;
use DT\Bundle\AccountPlanBundle\Tests\Unit\Provider\AbstractMetricTestCase;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use PHPUnit\Framework\MockObject\MockObject;

class PercentageChangeProviderTest extends AbstractMetricTestCase
{
    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        parent::setUp();
        $this->metric = new PercentageChangeProvider();
        $this->metric->setMetricsProvider($this->metricsProvider);
    }
    /**
     * @param float|null $expectedResult
     * @param float|null $expectedValue
     * @dataProvider testGetPercentageData
     */
    public function testGetPercentageValue(
        ?float $expectedValue,
        ?float $expectedResult
    ): void {
        /** @var MockObject|GoAccountPlan $entity */
        $entity = $this->getMockBuilder(GoAccountPlan::class)->getMock();

        $this->metricsProvider->expects($this->once())->method('getMetric')
            ->with($entity, 'PercentageChangeValue')
            ->willReturn($expectedValue);

        $this->assertEquals($expectedResult, $this->metric->calculateValue($entity));
    }

    /**
     * @return float[][]
     */
    public function testGetPercentageData(): array
    {
        return [
            [null, null],
            [1, 100],
            [3, 300],
            [-0.5, -50]
        ];
    }
}
