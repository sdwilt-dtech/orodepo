<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Unit\Provider\GoAccountPlan;

use DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan\MarketGrowthDollarsProvider;
use DT\Bundle\AccountPlanBundle\Provider\MarketGrowthProviderInterface;
use DT\Bundle\AccountPlanBundle\Tests\Unit\Provider\AbstractMetricTestCase;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use PHPUnit\Framework\MockObject\MockObject;

class MarketGrowthDollarsProviderTest extends AbstractMetricTestCase
{
    /** @var \PHPUnit\Framework\MockObject\MockObject|MarketGrowthProviderInterface */
    private $growthProvider;

    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        parent::setUp();
        $this->growthProvider = $this->getMockBuilder(MarketGrowthProviderInterface::class)->getMock();
        $this->metric = new MarketGrowthDollarsProvider($this->growthProvider);
        $this->metric->setMetricsProvider($this->metricsProvider);
    }

    /**
     * @param float $expectedGrowth
     * @param float $priorSales
     * @param float $expectedResult
     * @dataProvider getMarketGrowthDollarsData
     */
    public function testGetMarketGrowthDollars(float $expectedGrowth, float $priorSales, float $expectedResult): void
    {
        $this->growthProvider->expects($this->once())
            ->method('getMarketGrowthPercentage')
            ->willReturn($expectedGrowth);

        /** @var MockObject|GoAccountPlan $entity */
        $entity = $this->getMockBuilder(GoAccountPlan::class)->getMock();
        $entity->expects($this->once())->method('getTotalPriorYearSales')->willReturn($priorSales);

        $this->assertEquals($expectedResult, $this->metric->calculateValue($entity));
    }

    /**
     * @return float[][]
     */
    public function getMarketGrowthDollarsData(): array
    {
        return [
            [0.00, 1000.00, 0.00],
            [0.00, 4000.00, 0.00],
            [4.00, 1000.00, 40],
            [3.00, 1000.00, 30],
            [0.5, 10000.00, 50]
        ];
    }
}
