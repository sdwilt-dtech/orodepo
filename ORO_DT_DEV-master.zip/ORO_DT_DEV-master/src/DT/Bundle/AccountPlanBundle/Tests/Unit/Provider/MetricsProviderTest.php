<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Unit\Provider;

use DT\Bundle\AccountPlanBundle\Provider\MetricProviderInterface;
use DT\Bundle\AccountPlanBundle\Provider\MetricsProvider;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class MetricsProviderTest extends TestCase
{
    /** @var MetricsProvider */
    protected $metricsProvider;

    public function testMetricsProvider(): void
    {
        /** @var MockObject|MetricsAwareInterface $entity */
        $entity = $this->getMockBuilder(MetricsAwareInterface::class)->getMock();

        /** @var MockObject|MetricProviderInterface $metric1 */
        $metric1 = $this->getMockBuilder(MetricProviderInterface::class)->getMock();
        $metric1->expects($this->any())
            ->method('getName')
            ->willReturn('TestMetric1');
        $metric1->expects($this->once())
            ->method('calculateValue')
            ->with($entity)
            ->willReturn('TestValue1');
        $metric1->expects($this->any())
            ->method('supports')
            ->with($entity)
            ->willReturn(true);

        /** @var MockObject|MetricProviderInterface $metric2 */
        $metric2 = $this->getMockBuilder(MetricProviderInterface::class)->getMock();
        $metric2->expects($this->any())
            ->method('getName')
            ->willReturn('TestMetric2');
        $metric2->expects($this->once())
            ->method('calculateValue')
            ->with($entity)
            ->willReturn('TestValue2');
        $metric2->expects($this->any())
            ->method('supports')
            ->with($entity)
            ->willReturn(true);

        $metricsProvider = new MetricsProvider([
            $metric1
        ]);

        $this->assertSame($metricsProvider, $metricsProvider->addMetricProvider($metric2));
        $this->assertEquals('TestValue1', $metricsProvider->getMetric($entity, 'TestMetric1'));
        $this->assertEquals('TestValue2', $metricsProvider->getMetric($entity, 'TestMetric2'));
        $this->assertNull($metricsProvider->getMetric($entity, 'NonExistingMetric'));
    }
}
