<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Unit\Provider;

use DT\Bundle\AccountPlanBundle\Provider\MetricProviderInterface;
use DT\Bundle\AccountPlanBundle\Provider\MetricsProvider;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

abstract class AbstractMetricTestCase extends TestCase
{
    /** @var MetricsProvider|MockObject */
    protected $metricsProvider;

    /** @var MetricProviderInterface */
    protected $metric;

    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        $this->metricsProvider = $this->getMockBuilder(MetricsProvider::class)
            ->disableOriginalConstructor()
            ->getMock();
    }
}
