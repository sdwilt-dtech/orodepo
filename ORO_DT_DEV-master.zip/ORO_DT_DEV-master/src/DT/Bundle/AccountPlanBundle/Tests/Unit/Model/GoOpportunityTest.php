<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Unit\Model;

use DT\Bundle\AccountPlanBundle\Model\GoOpportunity;
use DT\Bundle\AccountPlanBundle\Provider\MetricsProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity as GoOpportunityEntity;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class GoOpportunityTest extends TestCase
{
    /** @var GoOpportunity */
    private $model;

    /** @var GoOpportunityEntity|MockObject */
    private $entity;

    /** @var MetricsProvider|MockObject */
    protected $metricsProvider;

    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        $this->entity = $this->createMock(GoOpportunityEntity::class);
        $this->metricsProvider = $this->getMockBuilder(MetricsProvider::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->model = new GoOpportunity($this->metricsProvider, $this->entity);
    }

    /**
     * Tests if existing metric value is properly fetched
     */
    public function testMetricValue(): void
    {
        $this->entity->expects($this->never())->method('getProbability');
        $this->metricsProvider->expects($this->once())
            ->method('getMetric')
            ->with($this->entity, 'Probability')
            ->willReturn(100);

        $this->assertEquals(100, $this->model->getProbability());
    }

    /**
     * Tests if existing entity value is properly fetched
     */
    public function testEntityValue(): void
    {
        $this->entity->expects($this->once())
            ->method('getProbability')
            ->willReturn(100);
        $this->metricsProvider->expects($this->once())
            ->method('getMetric')
            ->with($this->entity, 'Probability')
            ->willReturn(null);

        $this->assertEquals(100, $this->model->getProbability());
    }
}
