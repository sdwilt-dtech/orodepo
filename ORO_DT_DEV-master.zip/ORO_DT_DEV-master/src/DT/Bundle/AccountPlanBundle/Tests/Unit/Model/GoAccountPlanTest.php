<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Unit\Model;

use DT\Bundle\AccountPlanBundle\Model\GoAccountPlan;
use DT\Bundle\AccountPlanBundle\Provider\MetricsProvider;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan as GoAccountPlanEntity;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class GoAccountPlanTest extends TestCase
{
    /** @var GoAccountPlan */
    private $model;

    /** @var GoAccountPlanEntity|MockObject */
    private $entity;

    /** @var MetricsProvider|MockObject */
    protected $metricsProvider;

    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        $this->entity = $this->createMock(GoAccountPlanEntity::class);
        $this->metricsProvider = $this->getMockBuilder(MetricsProvider::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->model = new GoAccountPlan($this->metricsProvider, $this->entity);
    }

    /**
     * Tests if existing metric value is properly fetched
     */
    public function testMetricValue(): void
    {
        $this->entity->expects($this->never())->method('getTotalPriorYearSales');
        $this->metricsProvider->expects($this->once())
            ->method('getMetric')
            ->with($this->entity, 'TotalPriorYearSales')
            ->willReturn(1000.00);

        $this->assertEquals(1000.00, $this->model->getTotalPriorYearSales());
    }

    /**
     * Tests if existing entity value is properly fetched
     */
    public function testEntityValue(): void
    {
        $this->entity->expects($this->once())
            ->method('getTotalPriorYearSales')
            ->willReturn(1000.00);
        $this->metricsProvider->expects($this->once())
            ->method('getMetric')
            ->with($this->entity, 'TotalPriorYearSales')
            ->willReturn(null);

        $this->assertEquals(1000.00, $this->model->getTotalPriorYearSales());
    }
}
