<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\Provider\TextId;

use DT\Bundle\EntityBundle\Entity\GoRegionRep;

class RegionRepTextIdProviderTest extends AbstractTextIdProviderTest
{
    /**
     * Tests generation of text ID from request params
     */
    public function testTextIdGeneratedCorrectly(): void
    {
        $this->assertEquals(
            'CRCore1012020',
            $this->getProvider(GoRegionRep::class)->getTextId($this->getRequestMock())
        );
    }

    /**
     * {@inheritdoc}
     */
    protected function getRequestMap(): array
    {
        return [
            [
                'region',
                null,
                $this->getRegion()->getId()
            ],
            [
                'repCode',
                null,
                $this->getRepCode()->getId()
            ],
            [
                'kcg_customer_segment',
                null,
                'Core'
            ],
            [
                'fiscalYear',
                null,
                2020
            ]
        ];
    }
}
