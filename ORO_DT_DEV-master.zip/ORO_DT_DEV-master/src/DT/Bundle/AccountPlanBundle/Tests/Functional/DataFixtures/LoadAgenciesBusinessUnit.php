<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\DataFixtures;

use Doctrine\Common\Persistence\ObjectManager;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Oro\Bundle\TestFrameworkBundle\Test\DataFixtures\InitialFixtureInterface;
use Oro\Component\Test\DataFixtures\AbstractFixture;

/**
 * Loads Business Units as Sales Agencies
 */
class LoadAgenciesBusinessUnit extends AbstractFixture implements InitialFixtureInterface
{
    /**
     * {@inheritdoc}
     */
    public function load(ObjectManager $manager)
    {
        $businessUnit = new BusinessUnit();
        $businessUnit->setName('Sales Agency')
            ->setOrganization($this->getReference('organization'))
            ->setDtIsAgency(true);
        $businessUnit->setDtAgencyRepCode($this->getReference('rep_code_101'));

        $manager->persist($businessUnit);
        $manager->flush();
        $this->addReference('sales_agency', $businessUnit);
    }
}
