<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\Provider;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\CustomerOpportunityPlanDataProvider;
use DT\Bundle\AccountPlanBundle\Provider\CustomerPlanDataProviderInterface;
use Oro\Component\Test\AbstractTestCase;
use PHPUnit\Framework\MockObject\MockObject;

class CustomerOpportunityPlanDataProviderTest extends AbstractTestCase
{
    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        parent::setUp();
        $this->loadFixtures([
            '@DTAccountPlanBundle/Tests/Functional/DataFixtures/go_opportunities_base_data.yml'
        ]);
    }

    /**
     * Tests provider methods for the plan data gathered
     * from plan related opportunities
     */
    public function testProviderMethods(): void
    {
        /** @var CustomerPlanDataProviderInterface|CustomerOpportunityPlanDataProvider $planDataProvider */
        $planDataProvider = $this
            ->getContainer()
            ->get('dt.account_plan_bundle.provider.opportunity_account_plan_data_provider');
        $stagesProvider = $this
            ->getContainer()
            ->get('dt.account_plan_bundle.provider.stage_values');

        /** @var ManagerRegistry|MockObject $doctrine */
        $doctrine = $this->getMockBuilder(ManagerRegistry::class)->disableOriginalConstructor()->getMock();
        $doctrine->expects($this->once())
            ->method('getManagerForClass')
            ->withAnyParameters()
            ->willReturn($this->em);

        $planDataProvider->setManagerRegistry($doctrine);
        $stagesProvider->setManagerRegistry($doctrine);

        $planDataProvider
            ->setCustomerAccount($this->getReference('llc_supply'))
            ->setFiscalYear(2020);

        $this->assertNull($planDataProvider->getCurrentYearValuePipeline());
        $this->assertNull($planDataProvider->getCurrentYearValueNpi());
        $this->assertEquals(1000.00, $planDataProvider->getCurrentYearValueGrow());
        $this->assertEquals(1000.00, $planDataProvider->getCurrentYearValueConvert());
        $this->assertEquals(1000.00, $planDataProvider->getCurrentYearValueKeep());
        $this->assertEquals(16000.00, $planDataProvider->getPriorYearSales());
        $this->assertEquals(16000.00, $planDataProvider->getPriorYtd());
        $this->assertEquals(2000.00, $planDataProvider->getActualYtd());

        $this->assertCount(4, $planDataProvider->getOpportunities());
    }
}
