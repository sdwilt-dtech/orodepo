<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\Provider\TextId;

use DT\Bundle\AccountPlanBundle\Provider\TextId\TextIdProviderInterface;
use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Component\Test\AbstractTestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Symfony\Component\HttpFoundation\ParameterBag;
use Symfony\Component\HttpFoundation\Request;

abstract class AbstractTextIdProviderTest extends AbstractTestCase
{
    /** @var Customer */
    protected $customer;

    /** @var ProductCategoryCode */
    protected $categoryCode;

    /** @var Region */
    protected $region;

    /** @var RepCode */
    protected $repCode;

    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        parent::setUp();
        $this->loadFixtures([
            '@DTAccountPlanBundle/Tests/Functional/DataFixtures/go_opportunities_base_data.yml'
        ]);
    }

    /**
     * Returns provider for certain class name
     *
     * @param string $className
     * @return TextIdProviderInterface
     */
    protected function getProvider(string $className): TextIdProviderInterface
    {
        return $this
            ->getContainer()
            ->get('dt.account_plan_bundle.provider.text_id.registry')
            ->getProvider($className);
    }

    /**
     * @return Customer
     */
    protected function getCustomer(): Customer
    {
        if (null === $this->customer) {
            $this->customer = $this->getReference('llc_supply');
        }

        return $this->customer;
    }

    /**
     * @return Region
     */
    protected function getRegion(): Region
    {
        if (null === $this->region) {
            $this->region = $this->getReference('region_cr');
        }

        return $this->region;
    }

    /**
     * @return RepCode
     */
    protected function getRepCode(): RepCode
    {
        if (null === $this->repCode) {
            $this->repCode = $this->getReference('rep_code_101');
        }

        return $this->repCode;
    }

    /**
     * @return ProductCategoryCode
     */
    protected function getCategoryCode(): ProductCategoryCode
    {
        if (null === $this->categoryCode) {
            $this->categoryCode = $this->getReference('category_code_T11');
        }

        return $this->categoryCode;
    }

    /**
     * @return Request|MockObject
     */
    protected function getRequestMock()
    {
        /** @var Request|MockObject $request */
        $request = $this->getMockBuilder(Request::class)->getMock();
        $request->request = $this->getMockBuilder(ParameterBag::class)->getMock();
        $map = $this->getRequestMap();
        $request->request->expects($this->exactly(count($map)))->method('get')->willReturnMap($map);

        return $request;
    }

    /**
     * Returns map for request call to Request::request->get() method
     *
     * @return array
     */
    abstract protected function getRequestMap(): array;
}
