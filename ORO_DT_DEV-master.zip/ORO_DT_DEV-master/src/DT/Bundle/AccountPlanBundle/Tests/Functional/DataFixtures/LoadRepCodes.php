<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\DataFixtures;

use Doctrine\Common\Persistence\ObjectManager;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\TestFrameworkBundle\Test\DataFixtures\InitialFixtureInterface;
use Oro\Component\Test\DataFixtures\AbstractFixture;

/**
 * Loads all rep codes
 */
class LoadRepCodes extends AbstractFixture implements InitialFixtureInterface
{
    /**
     * {@inheritdoc}
     */
    public function load(ObjectManager $manager)
    {
        /** @var RepCode $repCode */
        foreach ($manager->getRepository(RepCode::class)->findAll() as $repCode) {
            $this->addReference(sprintf('rep_code_%s', $repCode->getCode()), $repCode);
        }
    }
}
