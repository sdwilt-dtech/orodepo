<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\DataFixtures;

use Doctrine\Common\Persistence\ObjectManager;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\TestFrameworkBundle\Test\DataFixtures\InitialFixtureInterface;
use Oro\Component\Test\DataFixtures\AbstractFixture;

/**
 * Loads enum codes for groups and opportunities
 */
class LoadEnums extends AbstractFixture implements InitialFixtureInterface
{
    /**
     * {@inheritdoc}
     */
    public function load(ObjectManager $manager)
    {
        $groupYearClass = ExtendHelper::buildEnumValueClassName(GoOpportunityGroup::ENUM_OPPORTUNITY_YEAR);
        foreach ($manager->getRepository($groupYearClass)->findAll() as $groupYear) {
            $this->setReference(sprintf('group_type_%s', strtolower($groupYear->getId())), $groupYear);
        }

        $opportunitySalesTypeClass = ExtendHelper::buildEnumValueClassName(
            GoOpportunity::ENUM_SALES_OPPORTUNITY_TYPE
        );
        foreach ($manager->getRepository($opportunitySalesTypeClass)->findAll() as $salesOppType) {
            $this->setReference(
                sprintf(
                    'sales_opportunity_type_%s',
                    strtolower(str_replace(' ', '_', $salesOppType->getId()))
                ),
                $salesOppType
            );
        }
        $customerEntityTypeClass = ExtendHelper::buildEnumValueClassName(
            ReservedEnumCodes::DT_CUSTOMER_ENTITY_TYPE
        );

        foreach ($manager->getRepository($customerEntityTypeClass)->findAll() as $customerEntityType) {
            $this->setReference(
                sprintf(
                    'customer_entity_type_%s',
                    strtolower(str_replace(' ', '_', $customerEntityType->getId()))
                ),
                $customerEntityType
            );
        }

        $oppRecordTypeClass = ExtendHelper::buildEnumValueClassName(GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE);
        foreach ($manager->getRepository($oppRecordTypeClass)->findAll() as $oppRecordType) {
            $this->setReference(
                sprintf(
                    'opportunity_record_type_%s',
                    strtolower(str_replace(' ', '_', $oppRecordType->getId()))
                ),
                $oppRecordType
            );
        }
    }
}
