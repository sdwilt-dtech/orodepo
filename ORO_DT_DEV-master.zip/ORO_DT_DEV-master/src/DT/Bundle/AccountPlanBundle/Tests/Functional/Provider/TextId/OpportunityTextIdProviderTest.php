<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\Provider\TextId;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;

class OpportunityTextIdProviderTest extends AbstractTextIdProviderTest
{
    /**
     * Tests generation of text ID from request params
     */
    public function testTextIdGeneratedCorrectly(): void
    {
        $this->assertEquals(
            'CR101222T112020',
            $this->getProvider(GoOpportunity::class)->getTextId($this->getRequestMock())
        );
    }

    /**
     * {@inheritdoc}
     */
    protected function getRequestMap(): array
    {
        return [
            [
                'region',
                null,
                $this->getRegion()->getId()
            ],
            [
                'customer',
                null,
                $this->getCustomer()->getId()
            ],
            [
                'repCode',
                null,
                $this->getRepCode()->getId()
            ],
            [
                'productCategoryCode',
                null,
                $this->getCategoryCode()->getId(),
            ],
            [
                'fiscalYear',
                null,
                2020
            ]
        ];
    }
}
