<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\Import;

use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\OpportunityDataProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Oro\Component\Test\AbstractTestCase;
use Oro\Component\Test\MessageQueue\TestMessageQueueProcessorAwareTestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Symfony\Component\Security\Acl\Util\ClassUtils;

class FinancialDataImportTest extends AbstractTestCase
{
    use TestMessageQueueProcessorAwareTestCase;

    /** @var MockObject|OpportunityDataProvider */
    private $opportunityDataProvider;

    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        $this->opportunityDataProvider = $this->getOpportunityDataProviderMock();
        parent::setUp();
        $this
            ->getContainer()
            ->set(
                'dt.account_plan_bundle.provider.go_opportunity.data_provider',
                $this->opportunityDataProvider
            );
        $this->initializeTestMessageQueueProcessor(self::$container);
    }

    /**
     * Performs test import for Yearly XLSX data import to check
     * existence and integrity of records:
     *
     * - Go Opportunity Groups
     * - Go Opportunities
     * - Region Reps
     */
    public function testFinancialFileImport(): void
    {
        $this->loadFixtures([
            '@DTAccountPlanBundle/Tests/Functional/DataFixtures/go_opportunities_base_data.yml'
        ]);

        $this->importFile(sprintf('%s/data/LAST_PHASE-GoPlanOpportunityByRegion.xlsx', __DIR__));
        $this->processMessageQueue();
        $this->doTestIntegrity();
    }

    private function doTestIntegrity(): void
    {
        $regionRep = $this->checkRegionRep();
        $opportunityGroup = $this->checkOpportunityGroup($regionRep);
        $this->checkOpportunity($opportunityGroup);
    }

    /**
     * @param GoOpportunityGroup $opportunityGroup
     */
    private function checkOpportunity(GoOpportunityGroup $opportunityGroup): void
    {
        /** @var GoOpportunity $opportunity */
        $opportunity = $this->em->getRepository(GoOpportunity::class)->findOneBy([
            'textId' => 'CR10158279T112021'
        ]);
        $this->assertNotNull($opportunity);
        $this->assertEquals('CR10158279T112021', $opportunity->getTextId());
        $this->assertEquals(2021, $opportunity->getFiscalYear());
        $this->assertEquals('CR-101-ABC Supply Co-Wet Switch-2021', $opportunity->getName());
        $this->assertInstanceOf(RepCode::class, $opportunity->getRepCode());
        $this->assertEquals('101', $opportunity->getRepCode()->getCode());
        $this->assertInstanceOf(Region::class, $opportunity->getRegion());
        $this->assertEquals('CR', $opportunity->getRegion()->getJdeId());
        $this->assertSame($opportunityGroup, $opportunity->getOpportunityGroup());
        $this->assertSame($opportunityGroup->getCustomer(), $opportunity->getCustomer());
        $this->assertNotNull($opportunity->getOpportunityRecordType());
        $this->assertEquals('HVAC Go Plan', $opportunity->getOpportunityRecordType()->getName());
        $this->assertNotNull($opportunity->getStage());
        $this->assertEquals('0. Pipeline', $opportunity->getStage()->getName());
        $this->assertEquals(0, $opportunity->getProbability());
        // Amounts
        $this->assertEquals(1500.0, $opportunity->getCalculatedOpportunityValue());
        $this->assertEquals(1500.0, $opportunity->getVerifiedTotalCategoryValue());
        $this->assertEquals(2000.0, $opportunity->getTargetedOpportunityValue());
        $this->assertEquals(10000.00, $opportunity->getPy());
        $this->assertEquals(10000.00, $opportunity->getYtd());
    }

    /**
     * @param GoRegionRep $regionRep
     * @return GoOpportunityGroup
     */
    private function checkOpportunityGroup(GoRegionRep $regionRep): GoOpportunityGroup
    {
        /** @var GoOpportunityGroup $opportunityGroup */
        $opportunityGroup = $this->em->getRepository(GoOpportunityGroup::class)->findOneBy([
            'textId' => 'CR101582792021'
        ]);
        $this->assertNotNull($opportunityGroup);
        $this->assertEquals(2021, $opportunityGroup->getFiscalYear());
        $this->assertEquals('CR101582792021', $opportunityGroup->getTextId());
        $this->assertEquals('CR-Sales Agency-ABC Supply Co-2021', $opportunityGroup->getName());
        $this->assertInstanceOf(RepCode::class, $opportunityGroup->getRepCode());
        $this->assertEquals('101', $opportunityGroup->getRepCode()->getCode());
        $this->assertInstanceOf(Region::class, $opportunityGroup->getRegion());
        $this->assertEquals('CR', $opportunityGroup->getRegion()->getJdeId());
        $this->assertInstanceOf(BusinessUnit::class, $opportunityGroup->getSalesAgency());
        $this->assertSame($opportunityGroup->getSalesAgency(), $opportunityGroup->getBusinessUnit());
        $this->assertSame($regionRep, $opportunityGroup->getRegionRep());
        $this->assertNotNull($opportunityGroup->getOpportunityYear());
        $this->assertEquals('Current', $opportunityGroup->getOpportunityYear()->getName());

        $this->assertCount(1, $opportunityGroup->getOpportunities());

        return $opportunityGroup;
    }

    /**
     * @return GoRegionRep
     */
    private function checkRegionRep(): GoRegionRep
    {
        /** @var GoRegionRep $regionRep */
        $regionRep = $this->em->getRepository(GoRegionRep::class)->findOneBy([
            'textId' => 'CRStrategic1012021'
        ]);
        $this->assertNotNull($regionRep);
        $this->assertEquals('CRStrategic1012021', $regionRep->getTextId());
        $this->assertEquals('CR-Sales Agency-Strategic-2021', $regionRep->getName());
        $this->assertInstanceOf(RepCode::class, $regionRep->getRepCode());
        $this->assertEquals('101', $regionRep->getRepCode()->getCode());
        $this->assertInstanceOf(Region::class, $regionRep->getRegion());
        $this->assertEquals('CR', $regionRep->getRegion()->getJdeId());
        $this->assertEquals(BusinessUnit::class, ClassUtils::getRealClass($regionRep->getSalesAgency()));
        $this->assertSame($regionRep->getSalesAgency(), $regionRep->getBusinessUnit());

        $this->assertCount(1, $regionRep->getOpportunityGroups());

        return $regionRep;
    }

    /**
     * @param string $filePath
     */
    private function importFile(string $filePath): void
    {
        $this->runCommand('oro:import:file', [
            $filePath,
            sprintf('--jobName=%s', 'yearly_region_reps_import_from_xslx'),
            sprintf('--processor=%s', 'region_rep_yearly.add_or_replace'),
            sprintf('--email=%s', 'import_user@example.com')
        ]);
    }

    /**
     * @return MockObject|OpportunityDataProvider
     */
    private function getOpportunityDataProviderMock(): MockObject
    {
        $mock = $this
            ->getMockBuilder(OpportunityDataProvider::class)
            ->disableOriginalConstructor()
            ->getMock();
        $mock->expects($this->exactly(2))
            ->method('getData')
            ->withAnyParameters()
            ->willReturn(10000);

        return $mock;
    }
}
