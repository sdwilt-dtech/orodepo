<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\GoOpportunity;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Component\Test\AbstractTestCase;
use PHPUnit\Framework\MockObject\MockObject;

class GoOpportunityStageChangeTest extends AbstractTestCase
{
    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        parent::setUp();
        $this->loadFixtures([
            '@DTAccountPlanBundle/Tests/Functional/DataFixtures/go_opportunities_base_data.yml'
        ]);
    }

    /**
     * Tests how stage changes reflect changes of probability and
     * forecast category
     */
    public function testStageChanges(): void
    {
        $stagesProvider = $this->getContainer()->get('dt.account_plan_bundle.provider.stage_values');

        /** @var ManagerRegistry|MockObject $doctrine */
        $doctrine = $this->getMockBuilder(ManagerRegistry::class)->disableOriginalConstructor()->getMock();
        $doctrine->expects($this->once())
            ->method('getManagerForClass')
            ->withAnyParameters()
            ->willReturn($this->em);

        $stagesProvider->setManagerRegistry($doctrine);

        /** @var GoOpportunity $opportunity */
        $opportunity = $this->getReference('go_opp_1');

        foreach ($stagesProvider->getStageValues(OpportunityRecordType::TYPE_HVAC_GO_PLAN) as $stage) {
            $opportunity->setStage($stage);
            $opportunity->setProbability(null);
            $this->em->persist($opportunity);
            $this->em->flush();

            $this->assertEquals($stage->getProbability(), $opportunity->getProbability());
            $this->assertEquals($stage->getForecastCategory(), $opportunity->getForecastCategory());
        }
    }
}
