<?php

namespace DT\Bundle\AccountPlanBundle\Tests\Functional\Provider\TextId;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;

class OpportunityGroupTextIdProviderTest extends AbstractTextIdProviderTest
{
    /**
     * Tests generation of text ID from request params
     */
    public function testTextIdGeneratedCorrectly(): void
    {
        $this->assertEquals(
            'CR1012222020',
            $this->getProvider(GoOpportunityGroup::class)->getTextId($this->getRequestMock())
        );
    }

    /**
     * {@inheritdoc}
     */
    protected function getRequestMap(): array
    {
        return [
            [
                'region',
                null,
                $this->getRegion()->getId()
            ],
            [
                'account',
                null,
                $this->getCustomer()->getId()
            ],
            [
                'repCode',
                null,
                $this->getRepCode()->getId()
            ],
            [
                'fiscalYear',
                null,
                2020
            ]
        ];
    }
}
