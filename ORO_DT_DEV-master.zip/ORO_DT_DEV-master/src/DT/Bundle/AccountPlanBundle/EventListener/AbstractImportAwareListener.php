<?php

namespace DT\Bundle\AccountPlanBundle\EventListener;

use DT\Bundle\AccountPlanBundle\ImportExport\YearlyImportContextRegistry;
use DT\Bundle\SalesforceImportBundle\Import\ContextRegistry;

/**
 * Abstraction for yearly import/Sf import-aware event listeners, provides
 * information if current execution is in import context
 */
abstract class AbstractImportAwareListener
{
    /** @var ContextRegistry */
    private $importContextRegistry;

    /** @var YearlyImportContextRegistry */
    private $yearlyImportRegistry;

    /**
     * @param ContextRegistry $importContextRegistry
     */
    public function __construct(ContextRegistry $importContextRegistry)
    {
        $this->importContextRegistry = $importContextRegistry;
    }

    /**
     * Sets yearlyImportRegistry property
     *
     * @param YearlyImportContextRegistry $yearlyImportRegistry
     * @return self
     */
    public function setYearlyImportRegistry(YearlyImportContextRegistry $yearlyImportRegistry): self
    {
        $this->yearlyImportRegistry = $yearlyImportRegistry;
        return $this;
    }

    /**
     * Detects if current listener runs in initial import context
     *
     * @return bool
     */
    protected function isImport(): bool
    {
        try {
            $context = $this->importContextRegistry->getRegisteredContext();
            if ($context) {
                return true;
            }
            if (null !== $this->yearlyImportRegistry) {
                $this->yearlyImportRegistry->getRegisteredContext();
            }
            return true;
        } catch (\LogicException $exc) {
            return false;
        }
    }
}
