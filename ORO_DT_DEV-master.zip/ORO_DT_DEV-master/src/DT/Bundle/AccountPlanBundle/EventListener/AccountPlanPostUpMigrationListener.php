<?php

namespace DT\Bundle\AccountPlanBundle\EventListener;

use DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_11\AccountPlanImportExportConfig;
use Oro\Bundle\MigrationBundle\Event\PostMigrationEvent;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerAwareTrait;

class AccountPlanPostUpMigrationListener implements ContainerAwareInterface
{
    use ContainerAwareTrait;

    /**
     * @param PostMigrationEvent $event
     */
    public function onPostUp(PostMigrationEvent $event)
    {
        if (!$this->container->hasParameter('installed') || !$this->container->getParameter('installed')) {
            $event->addMigration(
                new AccountPlanImportExportConfig()
            );
        }
    }
}
