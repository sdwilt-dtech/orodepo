<?php

namespace DT\Bundle\AccountPlanBundle\EventListener\Datagrid;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\MetricsProvider;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\Repository\GoAccountPlanRepository;
use Oro\Bundle\DataGridBundle\Datasource\ResultRecordInterface;
use Oro\Bundle\DataGridBundle\Event\OrmResultAfter;

class AccountPlanHealthcheckListener
{
    /** @var ManagerRegistry */
    private $doctrine;

    /** @var MetricsProvider */
    private $metricsProvider;

    /**
     * @param ManagerRegistry $doctrine
     * @param MetricsProvider $metricsProvider
     */
    public function __construct(ManagerRegistry $doctrine, MetricsProvider $metricsProvider)
    {
        $this->doctrine = $doctrine;
        $this->metricsProvider = $metricsProvider;
    }

    /**
     * @param OrmResultAfter $event
     */
    public function onResultAfter(OrmResultAfter $event): void
    {
        $this->addRealData($event);
        $this->addHealthData($event);
    }

    /**
     * @param OrmResultAfter $event
     */
    private function addHealthData(OrmResultAfter $event): void
    {
        foreach ($event->getRecords() as $record) {
            if ($entity = $record->getValue('entity')) {
                $record
                    ->setValue('projection_health', $this->metricsProvider->getMetric($entity, 'ProjectionHealth'));
                $record
                    ->setValue('plan_health', $this->metricsProvider->getMetric($entity, 'PlanHealth'));
            }
        }
    }

    /**
     * @param OrmResultAfter $event
     */
    private function addRealData(OrmResultAfter $event): void
    {
        $plansIds = array_filter(array_map(function (ResultRecordInterface $record) {
            return !$record->getValue('entity') ? $record->getValue('id') : null;
        }, $event->getRecords()));

        if (count($plansIds)) {
            $this->addEntities($event, $plansIds);
        }
    }

    /**
     * @param OrmResultAfter $event
     * @param array $plansIds
     */
    private function addEntities(OrmResultAfter $event, array $plansIds): void
    {
        /** @var GoAccountPlanRepository $repo */
        $repo = $this->doctrine
            ->getManagerForClass(GoAccountPlan::class)
            ->getRepository(GoAccountPlan::class);

        /** @var GoAccountPlan[] $plans */
        $plans = $repo->findBy([
            'id' => array_unique($plansIds)
        ]);

        foreach ($event->getRecords() as $record) {
            foreach ($plans as $plan) {
                if ($plan->getId() == $record->getValue('id')) {
                    $record->setValue('entity', $plan);
                }
            }
        }
    }
}
