<?php

namespace DT\Bundle\AccountPlanBundle\EventListener\Datagrid;

use Oro\Bundle\DataGridBundle\Event\BuildBefore;

class AccountPlanOpportunitiesGridListener
{
    /** @var array */
    protected static $scopes = [];

    /**
     * Handles custom name of the grid component
     *
     * @param BuildBefore $event
     */
    public function onBuildBefore(BuildBefore $event): void
    {
        $scope = sprintf('opportunity-grid-%s', $this->generateScope());
        $event->getDatagrid()->setScope($scope);
    }

    /**
     * @return int
     */
    private function generateScope(): int
    {
        do {
            $scope = $this->doGenerateScope();
        } while (in_array($scope, self::$scopes));
        self::$scopes[] = $scope;

        return $scope;
    }

    /**
     * @return int
     */
    private function doGenerateScope(): int
    {
        return mt_rand(1000000, 9999999);
    }
}
