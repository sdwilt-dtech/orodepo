<?php

namespace DT\Bundle\AccountPlanBundle\EventListener\Entity;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;

/**
 * Handles stage related attributes to set on the opportunity entity
 */
class GoOpportunityStageListener
{
    /**
     * Handles pre-persist event
     *
     * @param GoOpportunity $opportunity
     */
    public function onPrePersist(GoOpportunity $opportunity): void
    {
        $this->handleStageValues($opportunity);
    }

    /**
     * Handles pre-update event
     *
     * @param GoOpportunity $opportunity
     */
    public function onPreUpdate(GoOpportunity $opportunity): void
    {
        $this->handleStageValues($opportunity);
    }

    /**
     * Handles stage values:
     * - stores forecast category
     * - stores probablility, if one is not set in opportunity
     *
     * @param GoOpportunity $opportunity
     */
    private function handleStageValues(GoOpportunity $opportunity): void
    {
        if (($stage = $opportunity->getStage())) {
            $this->doHandleStageValues($opportunity, $stage);
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @param GoOpportunityStage $stage
     */
    private function doHandleStageValues(GoOpportunity $opportunity, GoOpportunityStage $stage): void
    {
        $opportunityProbability = $opportunity->getProbability();
        $stageProbability = $stage->getProbability();

        if (null === $opportunityProbability) {
            $opportunity->setProbability($stageProbability);
        }
        if ($stage->getForecastCategory()) {
            $opportunity->setForecastCategory($stage->getForecastCategory());
        }
    }
}
