<?php

namespace DT\Bundle\AccountPlanBundle\EventListener\Entity;

use DT\Bundle\AccountPlanBundle\EventListener\AbstractImportAwareListener;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunitySalesType;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityStageType;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;

/**
 * Sets likehood for opportunity based on stage type
 */
class GoOpportunityLikehoodListener extends AbstractImportAwareListener
{
    /**
     * Handles pre-persist event
     *
     * @param GoOpportunity $opportunity
     */
    public function onPrePersist(GoOpportunity $opportunity): void
    {
        $this->handleLikehoodValues($opportunity);
    }

    /**
     * Handles pre-update event
     *
     * @param GoOpportunity $opportunity
     */
    public function onPreUpdate(GoOpportunity $opportunity): void
    {
        $this->handleLikehoodValues($opportunity);
    }

    /**
     * Handles stage values:
     * - stores forecast category
     * - stores probablility, if one is not set in opportunity
     *
     * @param GoOpportunity $opportunity
     */
    private function handleLikehoodValues(GoOpportunity $opportunity): void
    {
        if (!$this->isImport() && ($stage = $opportunity->getStage()) && $stage->getType()) {
            $this->doHandleLikehoodValues($opportunity, $stage);
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @param GoOpportunityStage $stage
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    private function doHandleLikehoodValues(GoOpportunity $opportunity, GoOpportunityStage $stage): void
    {
        $type = $stage->getType()->getId();
        $salesType = $opportunity->getSalesOpportunityType()
            ? $opportunity->getSalesOpportunityType()->getId()
            : null;
        switch (true) {
            case ($salesType === OpportunitySalesType::TYPE_KEEP) && ($type == OpportunityStageType::TYPE_CLOSED_LOST):
            case ($salesType !== OpportunitySalesType::TYPE_KEEP) && ($type == OpportunityStageType::TYPE_CLOSED_WON):
                $opportunity->setLikehood(100);
                break;
            case ($salesType === OpportunitySalesType::TYPE_KEEP) && ($type == OpportunityStageType::TYPE_CLOSED_WON):
            case ($salesType !== OpportunitySalesType::TYPE_KEEP) && ($type == OpportunityStageType::TYPE_CLOSED_LOST):
                $opportunity->setLikehood(0);
                break;
            default:
                break;
        }
    }
}
