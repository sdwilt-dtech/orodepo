<?php

namespace DT\Bundle\AccountPlanBundle\EventListener\Entity;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;

/**
 * Handles assignment of redundant field values from relations when
 * opportunity is created/updated
 */
class GoOpportunityFieldsListener
{
    /**
     * @param GoOpportunity $opportunity
     */
    public function onPrePersist(GoOpportunity $opportunity): void
    {
        $this->handleRedundantFields($opportunity);
    }

    /**
     * @param GoOpportunity $opportunity
     */
    public function onPreUpdate(GoOpportunity $opportunity): void
    {
        $this->handleRedundantFields($opportunity);
    }

    /**
     * @param GoOpportunity $opportunity
     */
    protected function handleRedundantFields(GoOpportunity $opportunity): void
    {
        if (null !== ($oppGroup = $opportunity->getOpportunityGroup())) {
            if (!$opportunity->getRegion()) {
                $opportunity->setRegion($oppGroup->getRegion());
            }
            if (!$opportunity->getRepCode()) {
                $opportunity->setRepCode($oppGroup->getRepCode());
            }
        }
    }
}
