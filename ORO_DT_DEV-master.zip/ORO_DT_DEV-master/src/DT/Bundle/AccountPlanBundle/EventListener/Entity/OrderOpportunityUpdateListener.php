<?php

namespace DT\Bundle\AccountPlanBundle\EventListener\Entity;

use DT\Bundle\AccountPlanBundle\Async\Topics;
use DT\Bundle\AccountPlanBundle\EventListener\AbstractImportAwareListener;
use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider\Criteria;
use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\OpportunityProviderInterface;
use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use DT\Bundle\SalesforceImportBundle\Import\ContextRegistry;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Component\MessageQueue\Client\MessageProducerInterface;

/**
 * Handle lifecycle events for Order, performs values updates on matching
 * opportunity. Only post-delete action done synchronously.
 */
class OrderOpportunityUpdateListener extends AbstractImportAwareListener
{
    /** @var MessageProducerInterface */
    private $messageProducer;

    /** @var OpportunityProviderInterface */
    private $opportunityProvider;

    /**
     * @param ContextRegistry $importContextRegistry
     * @param MessageProducerInterface $messageProducer
     * @param OpportunityProviderInterface $opportunityProvider
     */
    public function __construct(
        ContextRegistry $importContextRegistry,
        MessageProducerInterface $messageProducer,
        OpportunityProviderInterface $opportunityProvider
    ) {
        $this->messageProducer = $messageProducer;
        $this->opportunityProvider = $opportunityProvider;
        parent::__construct($importContextRegistry);
    }

    /**
     * @param Order $order
     */
    public function onCreate(Order $order): void
    {
        $this->handleOpportunityValues($order);
    }

    /**
     * @param Order $order
     */
    public function onUpdate(Order $order): void
    {
        $this->handleOpportunityValues($order);
    }

    /**
     * @param Order $order
     * @throws \Oro\Component\MessageQueue\Transport\Exception\Exception
     */
    public function onRemove(Order $order): void
    {
        if ($this->isApplicable($order)) {
            foreach ($this->buildCriteria($order) as $criteria) {
                if ($opportunity = $this->opportunityProvider->getOpportunity($criteria)) {
                    $this->messageProducer->send(Topics::UPDATE_OPPORTUNITY, [
                        'opportunity_id' => $opportunity->getId()
                    ]);
                }
            }
        }
    }

    /**
     * @param Order $order
     */
    private function handleOpportunityValues(Order $order): void
    {
        if ($this->isApplicable($order)) {
            $this->doHandleOpportunityValues($order);
        }
    }

    /**
     * @param Order $order
     * @return bool
     */
    private function isApplicable(Order $order): bool
    {
        return !$this->isImport() && $order->getDtRegion() && $order->getCustomer();
    }

    /**
     * @param Order $order
     */
    private function doHandleOpportunityValues(Order $order): void
    {
        foreach ($this->buildCriteria($order) as $criteria) {
            $this->messageProducer->send(Topics::UPDATE_OPPORTUNITY_BY_CRITERIA, $criteria->toArray());
        }
    }

    /**
     * Builds criteria
     *
     * @param Order $order
     * @return Criteria[]|array
     */
    private function buildCriteria(Order $order): array
    {
        return array_map(function (ProductCategoryCode $productCategoryCode) use ($order) {
            return new Criteria(
                $order->getDtRegion(),
                $order->getCustomer(),
                $productCategoryCode,
                $order->getCreatedAt()->format('Y')
            );
        }, $this->getOrderProductCategoryCodes($order));
    }

    /**
     * @param Order $order
     * @return array|ProductCategoryCode[]
     */
    private function getOrderProductCategoryCodes(Order $order): array
    {
        $codes = [];
        foreach ($order->getLineItems() as $lineItem) {
            /** @var ProductCategoryCode $productCategoryCode */
            $productCategoryCode = $lineItem->getDtProductCategory();
            if ($productCategoryCode && !array_key_exists($productCategoryCode->getCode(), $codes)) {
                $codes[$productCategoryCode->getCode()] = $productCategoryCode;
            }
        }

        return array_values($codes);
    }
}
