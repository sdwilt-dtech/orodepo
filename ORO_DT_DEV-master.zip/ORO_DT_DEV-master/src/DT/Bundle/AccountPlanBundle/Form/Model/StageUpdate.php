<?php

namespace DT\Bundle\AccountPlanBundle\Form\Model;

use Doctrine\Common\Collections\Collection;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;

class StageUpdate
{
    /** @var GoOpportunityStage|null */
    private $stage;

    /** @var int|null */
    private $probability;

    /** @var float */
    private $verifiedTotalCategoryValue;

    /** @var Collection */
    private $competitors;

    /** @var string|null */
    private $otherCompetitor;

    /**
     * Sets competitors property
     *
     * @param Collection|AbstractEnumValue[]|null $competitors
     * @return self
     */
    public function setCompetitors(?Collection $competitors): self
    {
        $this->competitors = $competitors;
        return $this;
    }

    /**
     * Gets competitors property
     *
     * @return Collection|AbstractEnumValue[]|null
     */
    public function getCompetitors(): ?Collection
    {
        return $this->competitors;
    }

    /**
     * Gets verifiedTotalCategoryValue property
     *
     * @return float|null
     */
    public function getVerifiedTotalCategoryValue(): ?float
    {
        return $this->verifiedTotalCategoryValue;
    }

    /**
     * Sets verifiedTotalCategoryValue property
     *
     * @param float|null $value
     * @return self
     */
    public function setVerifiedTotalCategoryValue(?float $value): self
    {
        $this->verifiedTotalCategoryValue = $value;
        return $this;
    }

    /**
     * Gets stage property
     *
     * @return GoOpportunityStage|null
     */
    public function getStage(): ?GoOpportunityStage
    {
        return $this->stage;
    }

    /**
     * Sets stage property
     *
     * @param GoOpportunityStage|null $stage
     * @return self
     */
    public function setStage(?GoOpportunityStage $stage): self
    {
        $this->stage = $stage;
        return $this;
    }

    /**
     * Gets probability property
     *
     * @return int|null
     */
    public function getProbability(): ?int
    {
        return $this->probability;
    }

    /**
     * Sets probability property
     *
     * @param int|null $probability
     * @return self
     */
    public function setProbability(?int $probability): self
    {
        $this->probability = $probability;
        return $this;
    }

    /**
     * Sets other competitor property
     *
     * @param string|null $otherCompetitor
     * @return self
     */
    public function setOtherBusinessChallenger(?string $otherCompetitor): self
    {
        $this->otherCompetitor = $otherCompetitor;
        return $this;
    }

    /**
     * Gets other competitor property
     *
     * @return string|null
     */
    public function getOtherBusinessChallenger(): ?string
    {
        return $this->otherCompetitor;
    }
}
