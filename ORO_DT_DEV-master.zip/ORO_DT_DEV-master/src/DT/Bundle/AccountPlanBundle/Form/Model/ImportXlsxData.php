<?php

namespace DT\Bundle\AccountPlanBundle\Form\Model;

use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Overridden form model data to handle XLSX file upload via
 * backoffice uploader
 */
class ImportXlsxData
{
    /**
     * @var UploadedFile
     *
     * @Assert\File(mimeTypes = {
     *     "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetapplication/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
     *     "application/vnd.ms-excel",
     *     "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
     * })
     * @Assert\NotBlank()
     */
    protected $file;

    /**
     * @var string
     *
     * @Assert\NotBlank()
     */
    protected $processorAlias;

    /**
     * @param UploadedFile $file
     */
    public function setFile($file): void
    {
        $this->file = $file;
    }

    /**
     * @return null|UploadedFile
     */
    public function getFile(): ?UploadedFile
    {
        return $this->file;
    }

    /**
     * @param string $processorAlias
     */
    public function setProcessorAlias(string $processorAlias): void
    {
        $this->processorAlias = $processorAlias;
    }

    /**
     * @return string|null
     */
    public function getProcessorAlias(): ?string
    {
        return $this->processorAlias;
    }
}
