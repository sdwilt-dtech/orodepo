<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\EntityBundle\Entity\RepCode;
use DT\Bundle\EntityBundle\EntityProperty\RepCodeAwareInterface;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RepCodeSelectType extends AbstractSelectType
{
    public const NAME = 'dt_rep_code_select';

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'autocomplete_alias' => 'dt_rep_code',
                'create_enabled'  => false,
                'grid_name' => 'dt-rep-codes-grid',
                'configs'            => [
                    'placeholder'             => 'dt.entity.goopportunity.rep_code.select_label',
                    'result_template_twig'    => 'OroFormBundle:Autocomplete:fullName/result.html.twig',
                    'selection_template_twig' => 'OroFormBundle:Autocomplete:fullName/selection.html.twig'
                ],
            ]
        );
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $form->getData();
            if (null === $data && ($repCode = $this->getRepCodeFromRequest())) {
                $form->setData($repCode);
            }
        });
    }

    /**
     * @return BusinessUnit|null
     */
    private function getRepCodeFromRequest(): ?RepCode
    {
        foreach ($this->getRepCodeRelationData() as $requestProperty => $className) {
            if ($id = $this->requestStack->getMasterRequest()->get($requestProperty)) {
                $repCode = $this->getRelationRepCode($id, $className);
                if ($repCode) {
                    return $repCode;
                }
            }
        }

        return null;
    }

    /**
     * @param int $id
     * @param string $className
     * @return RepCode|null
     */
    private function getRelationRepCode(int $id, string $className): ?RepCode
    {
        /** @var RepCodeAwareInterface|BusinessUnit $entity */
        $entity = $this
            ->doctrine
            ->getManagerForClass($className)
            ->getRepository($className)
            ->find($id);

        if ($entity instanceof BusinessUnit) {
            return $entity->getDtAgencyRepCode();
        }

        return $entity ? $entity->getRepCode() : null;
    }

    /**
     * @return string[]
     */
    private function getRepCodeRelationData(): array
    {
        return [
            'groupId' => GoOpportunityGroup::class,
            'regionRepId' => GoRegionRep::class,
            'businessUnitId' => BusinessUnit::class
        ];
    }
}
