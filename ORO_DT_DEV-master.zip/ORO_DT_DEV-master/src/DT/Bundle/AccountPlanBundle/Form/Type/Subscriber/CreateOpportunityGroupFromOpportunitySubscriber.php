<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

use DT\Bundle\AccountPlanBundle\Api\Processor\Exception\DataErrorException;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use DT\Bundle\AccountPlanBundle\Provider\OpportunityGroupProviderInterface;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Handles creation of opportunity group in case one does not exist or/and is not selected
 */
class CreateOpportunityGroupFromOpportunitySubscriber implements EventSubscriberInterface
{
    /** @var OpportunityGroupProviderInterface */
    private $groupOpportunityProvider;

    /** @var TranslatorInterface */
    private $translator;

    /** @var SessionInterface */
    private $session;

    /**
     * @param OpportunityGroupProviderInterface $groupFromOpportunityProvider
     * @param TranslatorInterface $translator
     * @param SessionInterface $session
     */
    public function __construct(
        OpportunityGroupProviderInterface $groupFromOpportunityProvider,
        TranslatorInterface $translator,
        SessionInterface $session
    ) {
        $this->groupOpportunityProvider = $groupFromOpportunityProvider;
        $this->translator = $translator;
        $this->session = $session;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [ FormEvents::SUBMIT => 'onSubmit' ];
    }

    /**
     * Handles creation of opportunity group on post-form submission
     *
     * @param FormEvent $event
     */
    public function onSubmit(FormEvent $event): void
    {
        if ($this->isApplicable($event->getData())) {
            $this->process($event);
        }
    }

    /**
     * @param null|mixed|GoOpportunity $opportunity
     * @return bool
     */
    private function isApplicable($opportunity = null): bool
    {
        return $opportunity instanceof GoOpportunity
            && $opportunity->getOpportunityRecordType()
            && ($opportunity->getOpportunityRecordType()->getId() === OpportunityRecordType::TYPE_HVAC_GO_PLAN);
    }

    /**
     * @param FormEvent $event
     */
    private function process(FormEvent $event): void
    {
        /** @var GoOpportunity $opportunity */
        $opportunity = $event->getData();
        $form = $event->getForm();
        if (!$opportunity->getOpportunityGroup()) {
            try {
                $this->manageOpportunityGroup($opportunity);
            } catch (DataErrorException $exc) {
                $form->get('opportunityGroup')->addError(
                    new FormError($exc->getDescription())
                );
            } catch (\RuntimeException $exc) {
                $form->get('opportunityGroup')->addError(new FormError(
                    $this->translator->trans(
                        'dt.entity.goopportunity.error.opportunity_group_not_available',
                        [],
                        'validators'
                    )
                ));
            }
        }
    }

    /**
     * @param GoOpportunity $opportunity
     */
    private function manageOpportunityGroup(GoOpportunity $opportunity): void
    {
        $opportunity->setOpportunityGroup(
            $group = $this->groupOpportunityProvider->getOpportunityGroup($opportunity)
        );
        if (!$group->getId()) {
            $this->session->getFlashBag()->add(
                'success',
                $this->translator->trans('dt.entity.goopportunity.opportunity_group.created_new.label')
            );
        }
        if (!$group->getRegionRep()->getId()) {
            $this->session->getFlashBag()->add(
                'success',
                $this->translator->trans('dt.entity.goopportunity.region_rep.created_new.label')
            );
        }
    }
}
