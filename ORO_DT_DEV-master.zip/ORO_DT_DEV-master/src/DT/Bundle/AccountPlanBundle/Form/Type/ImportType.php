<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Oro\Bundle\ImportExportBundle\Form\Type\ImportType as BaseImportType;
use Oro\Bundle\ImportExportBundle\Processor\ProcessorRegistry;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Decorates base import type to handle import strategy choices
 * by certain alias if defined
 */
class ImportType extends BaseImportType
{
    private const DEFAULT_ALIAS_TO_STRATEGIES = [
        'region_rep_yearly' => [
            'region_rep_yearly.add_or_replace'
        ],
        'dt_go_region_rep' => [
            'dt_go_region_rep'
        ]
    ];

    /** @var RequestStack */
    private $requestStack;

    /** @var array[] */
    private $aliasToStrategies = self::DEFAULT_ALIAS_TO_STRATEGIES;

    /**
     * @param ProcessorRegistry $processorRegistry
     * @param RequestStack $requestStack
     */
    public function __construct(ProcessorRegistry $processorRegistry, RequestStack $requestStack)
    {
        $this->requestStack = $requestStack;
        parent::__construct($processorRegistry);
    }

    /**
     * Sets alias to strategies map
     *
     * @param array[] $aliasToStrategies
     * @return self
     */
    public function setAliasToStrategies(array $aliasToStrategies): self
    {
        $this->aliasToStrategies = $aliasToStrategies;
        return $this;
    }

    /**
     * Adds alias-to-strategies mapping value
     *
     * @param string $alias
     * @param array $strategies
     * @return self
     */
    public function addAliasToStrategiesMapping(string $alias, array $strategies): self
    {
        $this->aliasToStrategies[$alias] = $strategies;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    protected function getImportProcessorsChoices(string $entityName): array
    {
        $choices = parent::getImportProcessorsChoices($entityName);
        $alias = $this->requestStack->getCurrentRequest()->get('alias', null);
        if ($alias && array_key_exists($alias, $this->aliasToStrategies)) {
            $resultChoices = [];
            foreach ($choices as $key => $choice) {
                if (in_array($choice, $this->aliasToStrategies[$alias])) {
                    $resultChoices[$key] = $choice;
                }
            }

            return $resultChoices;
        }

        return $choices;
    }
}
