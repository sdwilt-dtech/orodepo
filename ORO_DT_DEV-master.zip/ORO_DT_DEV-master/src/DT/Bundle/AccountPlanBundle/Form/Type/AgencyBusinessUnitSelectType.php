<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\EntityBundle\Entity\RepCode;
use DT\Bundle\EntityBundle\EntityProperty\SalesAgencyAwareInterface;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AgencyBusinessUnitSelectType extends AbstractSelectType
{
    public const NAME = 'dt_agency_business_unit_select';

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'autocomplete_alias' => 'dt_agency_business_unit',
                'create_enabled'  => false,
                'grid_name' => 'dt-agency-business-units-grid',
                'configs'            => [
                    'placeholder'             => 'dt.entity.goopportunity.agency.select_label',
                    'result_template_twig'    => 'OroFormBundle:Autocomplete:fullName/result.html.twig',
                    'selection_template_twig' => 'OroFormBundle:Autocomplete:fullName/selection.html.twig'
                ],
            ]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $form->getData();

            if (null === $data && ($businessUnit = $this->getAgencyFromRequest())) {
                $form->setData($businessUnit);
            }
        });
    }

    /**
     * @return BusinessUnit|null
     */
    private function getAgencyFromRequest(): ?BusinessUnit
    {
        foreach ($this->getAgencyRelationData() as $requestProperty => $className) {
            if ($id = $this->requestStack->getMasterRequest()->get($requestProperty)) {
                $businessUnit = $this->getRelationAgency($id, $className);
                if ($businessUnit) {
                    return $businessUnit;
                }
            }
        }

        if ($repCodeId = $this->requestStack->getMasterRequest()->get('repCodeId')) {
            $repCode = $this
                ->doctrine
                ->getManagerForClass(RepCode::class)
                ->getRepository(RepCode::class)
                ->find($repCodeId);
            if (null !== $repCode) {
                $businessUnits = $this
                    ->doctrine
                    ->getManagerForClass(BusinessUnit::class)
                    ->getRepository(BusinessUnit::class)
                    ->findBy([
                        'dt_agency_rep_code' => $repCode
                    ]);

                // Only return business unit for exact match of the rep code
                return count($businessUnits) === 1
                    ? $businessUnits[0]
                    : null;
            }
        }

        return null;
    }

    /**
     * @param int $id
     * @param string $className
     * @return BusinessUnit|null
     */
    private function getRelationAgency(int $id, string $className): ?BusinessUnit
    {
        /** @var SalesAgencyAwareInterface $entity */
        $entity = $this
            ->doctrine
            ->getManagerForClass($className)
            ->getRepository($className)
            ->find($id);

        return $entity ? $entity->getSalesAgency() : null;
    }

    /**
     * @return string[]
     */
    private function getAgencyRelationData(): array
    {
        return [
            'groupId' => GoOpportunityGroup::class,
            'regionRepId' => GoRegionRep::class,
        ];
    }
}
