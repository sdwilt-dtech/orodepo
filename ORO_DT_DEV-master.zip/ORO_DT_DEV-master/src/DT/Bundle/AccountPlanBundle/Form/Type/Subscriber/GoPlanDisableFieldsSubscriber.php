<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use DT\Bundle\AccountPlanBundle\Provider\RepsAccessProviderInterface;
use DT\Bundle\AccountPlanBundle\Validator\Constraints\NotChanged;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Validator\Constraints\NotBlank;

class GoPlanDisableFieldsSubscriber implements EventSubscriberInterface
{
    /** @var RepsAccessProviderInterface */
    private $repsAccessProvider;

    /**
     * @param RepsAccessProviderInterface $repsAccessProvider
     */
    public function __construct(RepsAccessProviderInterface $repsAccessProvider)
    {
        $this->repsAccessProvider = $repsAccessProvider;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            FormEvents::PRE_SET_DATA => 'disableFields'
        ];
    }

    /**
     * @param FormEvent $event
     */
    public function disableFields(FormEvent $event): void
    {
        /** @var GoOpportunity $opportunity */
        $opportunity = $event->getData();
        if ($this->isAvailable($opportunity)) {
            $this->doDisableFields($event);
        }
        if ($this->isGoPlan($opportunity)) {
            $this->disableName($event);
        }
    }

    /**
     * @param FormEvent $event
     */
    private function disableName(FormEvent $event): void
    {
        $form = $event->getForm();
        $fieldForm = $form->get('name');
        $typeClass = get_class($fieldForm->getConfig()->getType()->getInnerType());
        $options = $fieldForm->getConfig()->getOptions();
        $options = array_merge($options, [
            'attr' => [
                'readonly' => true,
                'class' => 'disabled'
            ],
            'constraints' => [
                new NotBlank()
            ]
        ]);

        $form->remove('name');
        $form->add('name', $typeClass, $options);
    }

    /**
     * @return string[]
     */
    private function getFieldsToDisable(): array
    {
        return [
            'closeDate',
            'opportunityGroup',
            'targetedOpportunityValue',
            'opportunity_record_type'
        ];
    }

    /**
     * @param FormEvent $event
     */
    public function doDisableFields(FormEvent $event): void
    {
        /** @var GoOpportunity $opportunity */
        $opportunity = $event->getData();
        foreach ($this->getFieldsToDisable() as $field) {
            $getter = $this->resolveGetter($opportunity, $field);
            if (null === $getter) {
                continue;
            }
            if ($value = $opportunity->{$getter}()) {
                $form = $event->getForm();
                $fieldForm = $form->get($field);
                $typeClass = get_class($fieldForm->getConfig()->getType()->getInnerType());
                $options = $fieldForm->getConfig()->getOptions();
                $options['constraints'] = array_merge($options['constraints'] ?? [], [
                    new NotChanged([
                        'field' => $field,
                        'value' => $value,
                        'className' => \DT\Bundle\AccountPlanBundle\Model\GoOpportunity::class
                    ])
                ]);
                $options['attr'] = $options['attr'] ?? [];
                $options['attr']['readonly'] = true;
                $options['attr']['class'] = ($options['attr']['class'] ?? '') . ' ' . 'disabled';
                $form->remove($field);
                $form->add($field, $typeClass, $options);
            }
        }
    }

    /**
     * @param object $entity
     * @param string $fieldName
     * @return string
     */
    private function resolveGetter($entity, string $fieldName): ?string
    {
        $checks = [
            ucfirst($fieldName),
            $this->camelize($fieldName)
        ];
        foreach ($checks as $field) {
            $getter = sprintf('%s%s', 'get', ucfirst($field));
            if (method_exists($entity, $getter)) {
                return $getter;
            }
        }

        return null;
    }

    /**
     * Camelizes a given string.
     *
     * @param string $field
     * @return string
     */
    private function camelize(string $field): string
    {
        return str_replace(' ', '', ucwords(str_replace('_', ' ', $field)));
    }

    /**
     * @param mixed|GoOpportunity $opportunity
     * @return bool
     */
    private function isAvailable($opportunity): bool
    {
        if (!$opportunity instanceof GoOpportunity) {
            return false;
        }

        if ($this->repsAccessProvider->isInternalUser()) {
            return false;
        }

        return $this->isGoPlan($opportunity);
    }

    /**
     * Returns true if opportunity represents go plan instance
     *
     * @param GoOpportunity|null $opportunity
     * @return bool
     */
    public function isGoPlan(?GoOpportunity $opportunity): bool
    {
        return $opportunity && ($type = $opportunity->getOpportunityRecordType())
            && in_array($type, [
                OpportunityRecordType::TYPE_HVAC_GO_PLAN,
                OpportunityRecordType::TYPE_HVAC_OLD_GP
            ]);
    }
}
