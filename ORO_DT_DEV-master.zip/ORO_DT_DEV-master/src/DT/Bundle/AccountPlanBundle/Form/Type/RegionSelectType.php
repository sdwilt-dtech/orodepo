<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\EntityProperty\RegionAwareInterface;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RegionSelectType extends AbstractSelectType
{
    public const NAME = 'dt_region_select';

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'autocomplete_alias' => 'dt_region',
                'create_enabled' => false,
                'grid_name' => 'dt-regions-grid',
                'configs' => [
                    'placeholder' => 'dt.entity.goopportunity.region.select_label',
                    'result_template_twig' => 'OroFormBundle:Autocomplete:fullName/result.html.twig',
                    'selection_template_twig' => 'OroFormBundle:Autocomplete:fullName/selection.html.twig'
                ],
            ]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $form->getData();

            if (null === $data && ($region = $this->getRegionFromRequest())) {
                $form->setData($region);
            }
        });
    }

    /**
     * @return Region|null
     */
    private function getRegionFromRequest(): ?Region
    {
        foreach ($this->getRegionRelationData() as $requestProperty => $className) {
            if ($id = $this->requestStack->getMasterRequest()->get($requestProperty)) {
                $region = $this->getRelationRegion($id, $className);
                if ($region) {
                    return $region;
                }
            }
        }

        return null;
    }

    /**
     * @param int $id
     * @param string $className
     * @return Region|null
     */
    private function getRelationRegion(int $id, string $className): ?Region
    {
        /** @var RegionAwareInterface|Customer $entity */
        $entity = $this
            ->doctrine
            ->getManagerForClass($className)
            ->getRepository($className)
            ->find($id);

        if ($entity instanceof Customer) {
            return $entity->getDtRegion();
        }

        return $entity ? $entity->getRegion() : null;
    }

    /**
     * @return string[]
     */
    private function getRegionRelationData(): array
    {
        return [
            'groupId' => GoOpportunityGroup::class,
            'regionRepId' => GoRegionRep::class,
            'customerId' => Customer::class
        ];
    }
}
