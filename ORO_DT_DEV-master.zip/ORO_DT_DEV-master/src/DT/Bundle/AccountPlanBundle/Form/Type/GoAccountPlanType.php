<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use Oro\Bundle\CustomerBundle\Form\Type\CustomerSelectType;
use Oro\Bundle\FormBundle\Form\Type\CheckboxType;
use Oro\Bundle\FormBundle\Form\Type\OroMoneyType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class GoAccountPlanType extends AbstractType
{
    public const NAME = 'dt_go_plan_account_plan';

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('name', TextType::class, [
            'label' => 'dt.entity.goaccountplan.name.label',
            'required' => true
        ]);
        $builder->add('accountDollar', OroMoneyType::class, [
            'label' => 'dt.entity.goaccountplan.account_dollar.label',
            'tooltip' => 'dt.entity.goaccountplan.account_dollar.tooltip',
            'required' => true
        ]);
        $builder->add('totalPriorYearSales', OroMoneyType::class, [
            'label' => 'dt.entity.goaccountplan.total_prior_year_sales.label',
            'required' => false
        ]);
        $builder->add('actualYtd', OroMoneyType::class, [
            'label' => 'dt.entity.goaccountplan.actual_ytd.label',
            'required' => false
        ]);
        $builder->add('priorYtd', OroMoneyType::class, [
            'label' => 'dt.entity.goaccountplan.prior_ytd.label',
            'required' => false
        ]);
        $builder->add('track', CheckboxType::class, [
            'label' => 'dt.entity.goaccountplan.track.label',
            'required' => false
        ]);
        $builder->add('customer', CustomerSelectType::class, [
            'label' => 'dt.entity.goopportunity.customer.label',
            'create_enabled' => false,
            'required' => true
        ]);
        $builder->add('currentYearValueKeep', OroMoneyType::class, [
            'label' => 'dt.entity.goaccountplan.current_year_value_keep.label',
            'required' => false
        ]);
        $builder->add('currentYearValueGrow', OroMoneyType::class, [
            'label' => 'dt.entity.goaccountplan.current_year_value_grow.label',
            'required' => false
        ]);
        $builder->add('currentYearValueConvert', OroMoneyType::class, [
            'label' => 'dt.entity.goaccountplan.current_year_value_convert.label',
            'required' => false
        ]);
        $builder->add('currentYearValueNpi', OroMoneyType::class, [
            'label' => 'dt.entity.goaccountplan.current_year_value_npi.label',
            'required' => false
        ]);
        $builder->add('fiscalYear', SelectYearType::class, [
            'label' => 'dt.entity.goopportunity.fiscal_year.label',
            'required' => true,
            'placeholder' => false,
            'constraints' => [
                new NotBlank()
            ]
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => GoAccountPlan::class
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
