<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Oro\Bundle\ContactBundle\Form\Type\ContactSelectType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\Options;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CustomerContactSelectType extends AbstractSelectType
{
    public const NAME = 'dt_customer_contact';

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'autocomplete_alias' => 'dt_customer_contact',
                'customer_id' => null,
                'create_enabled'  => false,
                'grid_name' => 'dt-customer-contacts-select-grid',
                'configs'            => [
                    'placeholder'             => 'dt.entity.goopportunity.notify_customer.select_label',
                    'result_template_twig'    => 'OroFormBundle:Autocomplete:fullName/result.html.twig',
                    'selection_template_twig' => 'OroFormBundle:Autocomplete:fullName/selection.html.twig',
                    'component'               => 'customer-contact'
                ],
            ]
        );

        $resolver->setNormalizer('customer_id', function (Options $options, $customerId) {
            $customerId = $customerId ?: $this->getCustomerId($options);
            return $customerId;
        });

        $resolver->setNormalizer('grid_parameters', function (Options $options, array $gridParameters) {
            $customerId = $options->offsetExists('customer_id') && $options->offsetGet('customer_id')
                ?   $options->offsetGet('customer_id')
                :   $this->getCustomerId($options);
            if ($customerId) {
                $gridParameters['customerId'] = $customerId;
            } else {
                $gridParameters['customerId'] = 0;
            }

            return $gridParameters;
        });
    }

    /**
     * {@inheritdoc}
     */
    public function finishView(FormView $view, FormInterface $form, array $options)
    {
        $view->vars['customer_id'] = $options['customer_id'];
        $view->vars['component_options']['customer_id'] = $options['customer_id'];
    }

    /**
     * @param Options $options
     * @return int
     */
    private function getCustomerId(Options $options): int
    {
        if ($customerId = $this->requestStack->getMasterRequest()->get('customerId')) {
            return (int)$customerId;
        }

        return 0;
    }

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return ContactSelectType::class;
    }
}
