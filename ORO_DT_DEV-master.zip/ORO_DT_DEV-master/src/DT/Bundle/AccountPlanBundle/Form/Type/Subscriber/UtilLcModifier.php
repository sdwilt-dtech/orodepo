<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use Symfony\Component\Form\FormInterface;

/**
 * Modifies opportunity form to prepare Util-LC
 * type form
 */
class UtilLcModifier extends AbstractModifier
{
    /**
     * {@inheritdoc}
     */
    public function canHandle(?string $type): bool
    {
        return OpportunityRecordType::TYPE_UTIL_LC === $type;
    }

    /**
     * {@inheritdoc}
     */
    protected function getNames(FormInterface $form = null): array
    {
        return [
            'name' => true,
            'customer' => true,
            'owner' => true,
            'opportunity_type' => true,
            'calculatedOpportunityValue' => false,
            'targetedOpportunityValue' => true,
            'stage_name' => true,
            'closeDate' => true,
            'probability' => false,
            'dollarAmountWon' => false,
            'opportunity_record_type' => true,
            'reason_closed_lost' => false,
            'currency' => true
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function getViewTemplate(): string
    {
        return 'DTAccountPlanBundle:Opportunity:utilLcView.html.twig';
    }

    /**
     * {@inheritdoc}
     */
    public function getFormTemplate(): string
    {
        return 'DTAccountPlanBundle:Opportunity:utilLcUpdate.html.twig';
    }

    /**
     * {@inheritdoc}
     */
    public function getOrdering(): int
    {
        return 20;
    }

    /**
     * {@inheritdoc}
     */
    public function getAvailableFields(): array
    {
        return array_keys($this->getNames());
    }
}
