<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Symfony\Component\OptionsResolver\OptionsResolver;

class ProductCategoryCodeSelectType extends AbstractSelectType
{
    public const NAME = 'dt_product_category_code_select';

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'autocomplete_alias' => 'dt_product_category_code',
                'create_enabled'  => false,
                'grid_name' => 'dt-product-category-codes-grid',
                'configs'            => [
                    'placeholder'             => 'dt.entity.goopportunity.category.select_label',
                    'result_template_twig'    => 'OroFormBundle:Autocomplete:fullName/result.html.twig',
                    'selection_template_twig' => 'OroFormBundle:Autocomplete:fullName/selection.html.twig'
                ],
            ]
        );
    }
}
