<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class GoAccountPlanSelectType extends AbstractSelectType
{
    public const NAME = 'dt_go_plan_account_plan_select';

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'autocomplete_alias' => 'dt_go_plan_account_plan',
                'create_enabled'  => false,
                'grid_name' => 'go-plan-account-plan-grid',
                'configs'            => [
                    'placeholder'             => 'dt.entity.goaccountplan.select_label',
                    'result_template_twig'    => 'OroFormBundle:Autocomplete:fullName/result.html.twig',
                    'selection_template_twig' => 'OroFormBundle:Autocomplete:fullName/selection.html.twig'
                ],
            ]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $form->getData();
            if (null === $data && ($entity = $this->findCustomerAwareEntity(GoAccountPlan::class))) {
                $parentForm = $form->getParent();
                $formName = $form->getName();
                $typeClass = get_class($form->getConfig()->getType()->getInnerType());
                $options = $form->getConfig()->getOptions();
                $parentForm->remove($formName);
                $options['attr'] = $options['attr'] ?? [];
                $options['attr']['readonly'] = true;
                $options['attr']['class'] = ($options['attr']['class'] ?? '') . ' ' . 'disabled';
                $options['data'] = $entity;
                $parentForm->add($formName, $typeClass, $options);
            }
        });
    }
}
