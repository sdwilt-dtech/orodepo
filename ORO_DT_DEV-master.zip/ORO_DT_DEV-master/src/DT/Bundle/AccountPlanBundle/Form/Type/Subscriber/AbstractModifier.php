<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

use Symfony\Component\Form\FormInterface;
use Symfony\Component\Validator\Constraints\NotBlank;

abstract class AbstractModifier implements FormModifierInterface
{
    /**
     * {@inheritdoc}
     */
    public function modify(FormInterface $form): void
    {
        $names = $this->getNames($form);
        /** @var FormInterface $item */
        foreach (clone $form as $item) {
            if (!in_array($item->getName(), array_keys($names))) {
                $form->remove($item->getName());
            } else {
                $this->modifyRequired($form, $item->getName(), $names[$item->getName()]);
            }
        }
    }

    /**
     * Returns form fields to keep and required indicator
     *
     * @return array
     */
    protected function getNames(FormInterface $form): array
    {
        $results = [];
        /** @var FormInterface $field */
        foreach (clone $form as $field) {
            $results[$field->getName()] = $field->isRequired();
        }

        return $results;
    }

    /**
     * Modifies required/non-required value
     *
     * @param FormInterface $form
     * @param string $name
     * @param bool $isRequired
     */
    protected function modifyRequired(FormInterface $form, string $name, bool $isRequired): void
    {
        $fieldForm = $form->get($name);
        $typeClass = get_class($fieldForm->getConfig()->getType()->getInnerType());
        $options = $fieldForm->getConfig()->getOptions();
        $options['required'] = $isRequired;
        if ($isRequired) {
            $options['constraints'] = array_merge($options['constraints'] ?? [], [
                new NotBlank()
            ]);
        } else {
            foreach ($options['constraints'] as $key => $constraint) {
                if ($constraint instanceof NotBlank) {
                    unset($options['constraints'][$key]);
                }
            }
        }
        $form->remove($name);
        $form->add($name, $typeClass, $options);
    }
}
