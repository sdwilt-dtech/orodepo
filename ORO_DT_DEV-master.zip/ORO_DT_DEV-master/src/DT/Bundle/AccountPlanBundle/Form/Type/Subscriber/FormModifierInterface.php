<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

use Symfony\Component\Form\FormInterface;

interface FormModifierInterface
{
    /**
     * Returns record type name supported by modifier
     *
     * @param string|null $type
     * @return bool
     */
    public function canHandle(?string $type): bool;

    /**
     * Modifies the form
     *
     * @param FormInterface $form
     */
    public function modify(FormInterface $form): void;

    /**
     * Returns template name used to display opportunity
     *
     * @return string
     */
    public function getViewTemplate(): string;

    /**
     * Returns form template to display opportunity
     *
     * @return string
     */
    public function getFormTemplate(): string;

    /**
     * Returns ordering value - the lower the earlier the
     * modifier will be used
     *
     * @return int
     */
    public function getOrdering(): int;

    /**
     * Returns set of available fields for certain type
     *
     * @return array
     */
    public function getAvailableFields(): array;
}
