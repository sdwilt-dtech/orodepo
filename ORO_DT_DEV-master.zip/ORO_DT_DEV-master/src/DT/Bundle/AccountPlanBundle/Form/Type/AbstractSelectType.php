<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\EntityBundle\Entity\Repository\CustomerAwareRepositoryInterface;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\FormBundle\Form\Type\OroEntitySelectOrCreateInlineType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\HttpFoundation\RequestStack;

abstract class AbstractSelectType extends AbstractType
{
    public const NAME = null;

    /** @var RequestStack */
    protected $requestStack;

    /** @var ManagerRegistry */
    protected $doctrine;

    /**
     * @param RequestStack $requestStack
     * @param ManagerRegistry $doctrine
     */
    public function __construct(RequestStack $requestStack, ManagerRegistry $doctrine)
    {
        $this->requestStack = $requestStack;
        $this->doctrine = $doctrine;
    }

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return OroEntitySelectOrCreateInlineType::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return $this->getBlockPrefix();
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return static::NAME;
    }

    /**
     * @param string $className
     * @return mixed|null
     */
    protected function findCustomerAwareEntity(string $className)
    {
        if (null !== ($customer = $this->getCustomer())) {
            /** @var CustomerAwareRepositoryInterface $repo */
            $repo = $this
                ->doctrine
                ->getManagerForClass($className)
                ->getRepository($className);
            if (!$repo instanceof CustomerAwareRepositoryInterface) {
                return null;
            }
            $fiscalYear = $this->requestStack->getMasterRequest()->get('fiscalYear', date('Y'));
            $queryBuilder = $repo->getCustomerAwareQueryBuilder($customer, $fiscalYear);

            $results = $queryBuilder ? $queryBuilder->getQuery()->execute() : [];

            return count($results) ? $results[0] : null;
        }

        return null;
    }

    /**
     * @return Customer|null
     */
    protected function getCustomer(): ?Customer
    {
        if ($customerId = $this->requestStack->getMasterRequest()->get('customerId')) {
            /** @var Customer $customer */
            $customer = $this
                ->doctrine
                ->getManagerForClass(Customer::class)
                ->getRepository(Customer::class)
                ->find($customerId);

            return $customer;
        }

        return null;
    }
}
