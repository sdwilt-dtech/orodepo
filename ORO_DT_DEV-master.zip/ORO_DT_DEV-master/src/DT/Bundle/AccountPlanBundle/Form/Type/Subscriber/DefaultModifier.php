<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

use Symfony\Component\Form\FormInterface;

class DefaultModifier extends AbstractModifier
{
    /**
     * {@inheritdoc}
     */
    public function canHandle(?string $type): bool
    {
        return null !== $type;
    }

    /**
     * {@inheritdoc}
     */
    protected function getNames(FormInterface $form = null): array
    {
        return [
            'name' => true,
            'customer' => true,
            'owner' => true,
            'priorityRating' => false,
            'calculatedOpportunityValue' => false,
            'targetedOpportunityValue' => true,
            'stage_name' => true,
            'closeDate' => true,
            'probability' => false,
            'nextStep' => false,
            'dollarAmountWon' => false,
            'opportunity_record_type' => true,
            'reason_closed_lost' => false,
            'opportunity_type' => true,
            'opportunity_source' => false,
            'sales_initiative_type' => false,
            'hvac_competitor' => false,
            'jobQuote' => false,
            'jobQuoteName' => false,
            'productCategoryCode' => false,
            'situationDescription' => false,
            'dateSampleSent' => false,
            'currency' => true,
            'notifySalesRep' => false,
            'notifyRsm' => false,
            'notifyCustomerContact' => false
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function getViewTemplate(): string
    {
        return 'DTAccountPlanBundle:Opportunity:defaultView.html.twig';
    }

    /**
     * {@inheritdoc}
     */
    public function getFormTemplate(): string
    {
        return 'DTAccountPlanBundle:Opportunity:defaultUpdate.html.twig';
    }

    /**
     * {@inheritdoc}
     */
    public function getOrdering(): int
    {
        return 30;
    }

    /**
     * {@inheritdoc}
     */
    public function getAvailableFields(): array
    {
        return array_keys($this->getNames());
    }
}
