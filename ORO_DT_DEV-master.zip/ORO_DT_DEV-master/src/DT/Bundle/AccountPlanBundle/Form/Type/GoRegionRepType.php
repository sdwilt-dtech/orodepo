<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\EntityExtendBundle\Form\Type\EnumSelectType;
use Oro\Bundle\FormBundle\Form\Type\OroMoneyType;
use Oro\Bundle\FormBundle\Utils\FormUtils;
use Oro\Bundle\UserBundle\Form\Type\UserSelectType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CurrencyType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class GoRegionRepType extends AbstractType
{
    public const NAME = 'dt_go_plan_region_rep';

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('name', TextType::class, [
            'label' => 'dt.entity.goregionrep.name.label',
            'required' => true,
            'constraints' => [
                new NotBlank()
            ]
        ]);

        $builder->add('textId', TextType::class, [
            'label' => 'dt.entity.goregionrep.text_id.label',
            'tooltip' => 'dt.entity.goregionrep.text_id.tooltip',
            'required' => true,
            'attr' => [
                'readonly' => true,
                'class' => 'disabled'
            ]
        ]);
        $builder->add('agency_tier', EnumSelectType::class, [
            'label' => 'dt.entity.goregionrep.agency_tier.label',
            'required' => false,
            'enum_code' => GoRegionRep::ENUM_AGENCY_TIER
        ]);
        $builder->add('agencyTierLevel', IntegerType::class, [
            'label' => 'dt.entity.goregionrep.agency_tier_level.label',
            'required' => false
        ]);
        $builder->add('kcg_customer_segment', EnumSelectType::class, [
            'label' => 'dt.entity.goregionrep.customer_segment.label',
            'required' => false,
            'enum_code' => GoRegionRep::ENUM_KCG_CUSTOMER_SEGMENT
        ]);
        $builder->add('region', RegionSelectType::class, [
            'label' => 'dt.entity.goregionrep.region_name.label',
            'required' => true
        ]);
        $builder->add('repCode', RepCodeSelectType::class, [
            'label' => 'dt.entity.goregionrep.rep_code_code.label',
            'required' => true
        ]);
        $builder->add('salesAgency', AgencyBusinessUnitSelectType::class, [
            'label' => 'dt.entity.goregionrep.business_unit.label',
            'required' => true
        ]);
        $builder->add('owner', UserSelectType::class, [
            'label' => 'oro.ui.owner',
            'required' => false,
            'create_enabled' => false,
        ]);
        $builder->add('currency', CurrencyType::class, [
            'label' => 'dt.entity.goregionrep.currency.label',
            'required' => false,
        ]);
        $builder->add('regionalTarget', OroMoneyType::class, [
            'label' => 'dt.entity.goregionrep.regional_target.label',
            'required' => false
        ]);
        $builder->add('agencyTarget', OroMoneyType::class, [
            'label' => 'dt.entity.goregionrep.agency_target.label',
            'required' => false
        ]);
        $builder->add('fiscalYear', SelectYearType::class, [
            'label' => 'dt.entity.goopportunitygroup.fiscal_year.label',
            'tooltip' => 'dt.entity.goopportunitygroup.fiscal_year.tooltip',
            'required' => false,
            'placeholder' => false,
            'mapped' => false
        ]);

        $builder->addEventListener(FormEvents::PRE_SET_DATA, $this->getOwnerAvailabilityListener());
    }

    /**
     * @return callable
     */
    private function getOwnerAvailabilityListener(): callable
    {
        return function (FormEvent $event) {
            /** @var GoRegionRep $regionRep */
            $regionRep = $event->getData();
            if (!$regionRep instanceof GoRegionRep) {
                return;
            }

            if ($regionRep->getOwner()) {
                $form = $event->getForm();
                $ownerField = $form->get('owner');
                $options = $ownerField->getConfig()->getOptions();
                $options['attr'] = $options['attr'] ?? [];
                $options['attr']['readonly'] = true;
                FormUtils::replaceField($form, 'owner', $options);
            }
        };
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => GoRegionRep::class
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
