<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Symfony\Component\OptionsResolver\OptionsResolver;

class GoRegionRepSelectType extends AbstractSelectType
{
    public const NAME = 'dt_region_rep_select';

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'autocomplete_alias' => 'dt_region_rep',
                'create_enabled'  => false,
                'grid_name' => 'go-plan-region-rep-grid',
                'configs'            => [
                    'placeholder'             => 'dt.entity.goopportunitygroup.region_rep.select_label',
                    'result_template_twig'    => 'OroFormBundle:Autocomplete:fullName/result.html.twig',
                    'selection_template_twig' => 'OroFormBundle:Autocomplete:fullName/selection.html.twig'
                ],
            ]
        );
    }
}
