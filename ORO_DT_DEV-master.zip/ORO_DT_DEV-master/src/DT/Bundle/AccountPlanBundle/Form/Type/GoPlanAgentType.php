<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\GoPlanAgent;
use Oro\Bundle\EntityExtendBundle\Form\Type\EnumSelectType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class GoPlanAgentType extends AbstractDisabledFieldsAwareType
{
    public const NAME = 'dt_go_plan_plan_agent';

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('name', TextType::class, [
            'label' => 'dt.entity.goplanagent.name.label',
            'required' => true
        ]);

        $builder->add('agent', SalesRepUserSelectType::class, [
            'label' => 'dt.entity.goplanagent.agent.label',
            'required' => false
        ]);

        $builder->add('opportunityGroup', GoOpportunityGroupSelectType::class, [
            'label' => 'dt.entity.goplanagent.opportunity_group_name.label',
            'required' => true
        ]);

        $builder->add('opportunityPercent', IntegerType::class, [
            'label' => 'dt.entity.goplanagent.opportunity_percent.label',
            'required' => false
        ]);

        $builder->add('record_type', EnumSelectType::class, [
            'label' => 'dt.entity.goplanagent.record_type.label',
            'required' => true,
            'placeholder' => false,
            'enum_code' => GoPlanAgent::ENUM_RECORD_TYPE
        ]);

        $builder->addEventListener(FormEvents::PRE_SET_DATA, $this->getFieldsAvailabilityListener());
    }

    protected function isEntityApplicable($entity): bool
    {
        return ($entity instanceof GoPlanAgent);
    }

    /**
     * {@inheritdoc}
     */
    protected function getFieldsToDisable(): array
    {
        return ['record_type', 'opportunityGroup'];
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => GoPlanAgent::class
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
