<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

use Symfony\Component\Form\FormInterface;

class EmptyModifier implements FormModifierInterface
{
    /**
     * {@inheritdoc}
     */
    public function canHandle(?string $type): bool
    {
        return null === $type;
    }

    /**
     * {@inheritdoc}
     */
    public function modify(FormInterface $form): void
    {
        /** @var FormInterface $item */
        foreach ($form as $item) {
            if ($item->getName() !== 'opportunity_record_type') {
                $form->remove($item->getName());
            }
        }
    }

    /**
     * {@inheritdoc}
     */
    public function getViewTemplate(): string
    {
        throw new \LogicException('The view template is not available for empty opportunity type!');
    }

    /**
     * {@inheritdoc}
     */
    public function getFormTemplate(): string
    {
        return 'DTAccountPlanBundle:Opportunity:emptyUpdate.html.twig';
    }

    /**
     * {@inheritdoc}
     */
    public function getOrdering(): int
    {
        return 0;
    }

    /**
     * {@inheritdoc}
     */
    public function getAvailableFields(): array
    {
        return [];
    }
}
