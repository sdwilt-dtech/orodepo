<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\AccountPlanBundle\Form\Type\Subscriber\GoPlanDisableFieldsSubscriber;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\CustomerBundle\Form\Type\CustomerSelectType;
use Oro\Bundle\EntityExtendBundle\Form\Type\EnumSelectType;
use Oro\Bundle\FormBundle\Form\Type\CheckboxType;
use Oro\Bundle\FormBundle\Form\Type\OroDateType;
use Oro\Bundle\FormBundle\Form\Type\OroMoneyType;
use Oro\Bundle\UserBundle\Form\Type\UserSelectType;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\Extension\Core\Type\CurrencyType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Type;

class GoOpportunityType extends AbstractDisabledFieldsAwareType
{
    public const NAME = 'dt_go_plan_opportunity';

    /** @var array|EventSubscriberInterface[] */
    private $eventSubscribers = [];

    /**
     * @param EventSubscriberInterface[]|iterable $eventSubscribers
     */
    public function __construct(iterable $eventSubscribers)
    {
        foreach ($eventSubscribers as $eventSubscriber) {
            $this->addEventSubscriber($eventSubscriber);
        }
    }

    /**
     * @param string $className
     * @return EventSubscriberInterface
     */
    protected function getSubscriberByClass(string $className): EventSubscriberInterface
    {
        if (!array_key_exists($className, $this->eventSubscribers)) {
            throw new \InvalidArgumentException(sprintf(
                'Subscriber with class name %s not registered!',
                $className
            ));
        }

        return $this->eventSubscribers[$className];
    }

    /**
     * @param EventSubscriberInterface $eventSubscriber
     * @return self
     */
    public function addEventSubscriber(EventSubscriberInterface $eventSubscriber): self
    {
        $this->eventSubscribers[get_class($eventSubscriber)] = $eventSubscriber;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $this->addFields($builder);
        $this->addSubscribers($builder);
        $this->addListeners($builder);
    }

    /**
     * @param FormBuilderInterface $builder
     */
    private function addSubscribers(FormBuilderInterface $builder): void
    {
        foreach ($this->eventSubscribers as $eventSubscriber) {
            $builder->addEventSubscriber($eventSubscriber);
        }
    }

    /**
     * @param FormBuilderInterface $builder
     */
    private function addListeners(FormBuilderInterface $builder): void
    {
        $builder->addEventListener(FormEvents::PRE_SET_DATA, $this->getFieldsAvailabilityListener());
        $builder->addEventListener(FormEvents::PRE_SET_DATA, $this->getAddStageListener());

        // Bind customer ID to fields that are aware of the customer
        $builder->addEventListener(FormEvents::PRE_SET_DATA, $customerListener = $this->getCustomerListener());
        $builder->addEventListener(FormEvents::PRE_SUBMIT, $customerListener);
    }

    /**
     * @param FormBuilderInterface $builder
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    private function addFields(FormBuilderInterface $builder): void
    {
        $builder->add('name', TextType::class, [
            'label' => 'dt.entity.goopportunity.name.label',
            'required' => true
        ]);
        $builder->add('textId', TextType::class, [
            'label' => 'dt.entity.goopportunity.text_id.label',
            'tooltip' => 'dt.entity.goopportunity.text_id.tooltip',
            'required' => true,
            'attr' => [
                'readonly' => true,
                'class' => 'disabled'
            ],
            'constraints' => [
                new NotBlank()
            ]
        ]);
        $builder->add('sales_opportunity_type', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunity.sales_opportunity_type.label',
            'required' => true,
            'tooltip' => 'dt.entity.goopportunity.sales_opportunity_type.tooltip',
            'enum_code' => GoOpportunity::ENUM_SALES_OPPORTUNITY_TYPE,
            'constraints' => [
                new NotBlank()
            ]
        ]);
        $builder->add('askQuarter', QuarterType::class, [
            'label' => 'dt.entity.goopportunity.ask_quarter.label',
            'required' => true,
            'tooltip' => 'dt.entity.goopportunity.ask_quarter.tooltip',
            'placeholder' => false
        ]);
        $builder->add('fiscalQuarter', QuarterType::class, [
            'label' => 'dt.entity.goopportunity.fiscal_quarter.label',
            'required' => false,
            'placeholder' => false
        ]);
        $builder->add('fiscalYear', SelectYearType::class, [
            'label' => 'dt.entity.goopportunity.fiscal_year.label',
            'required' => true,
            'placeholder' => false
        ]);
        $builder->add('business_challenger', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunity.business_challenger.label',
            'tooltip' => 'dt.entity.goopportunity.business_challenger.tooltip',
            'required' => false,
            'multiple' => true,
            'enum_code' => GoOpportunity::ENUM_BUSINESS_CHALLENGER
        ]);
        $builder->add('productCategoryCode', ProductCategoryCodeSelectType::class, [
            'label' => 'dt.entity.goopportunity.category.label',
            'required' => true,
            'constraints' => [
                new NotBlank()
            ]
        ]);
        $builder->add('otherBusinessChallenger', TextType::class, [
            'label' => 'dt.entity.goopportunity.other_business_challenger.label',
            'tooltip' => 'dt.entity.goopportunity.other_business_challenger.tooltip',
            'required' => false
        ]);
        $builder->add('calculatedOpportunityValue', OroMoneyType::class, [
            'label' => 'dt.entity.goopportunity.calculated_opportunity_value.label',
            'required' => false
        ]);
        $builder->add('verifiedTotalCategoryValue', OroMoneyType::class, [
            'label' => 'dt.entity.goopportunity.verified_total_category_value.label',
            'tooltip' => 'dt.entity.goopportunity.verified_total_category_value.tooltip',
            'required' => false
        ]);
        $builder->add('targetedOpportunityValue', OroMoneyType::class, [
            'label' => 'dt.entity.goopportunity.targeted_opportunity_value.label',
            'tooltip' => 'dt.entity.goopportunity.targeted_opportunity_value.tooltip',
            'required' => false
        ]);
        $builder->add('likehood', LikehoodType::class, [
            'label' => 'dt.entity.goopportunity.likehood.label',
            'required' => true,
            'placeholder' => false
        ]);
        $builder->add('probability', ProbabilityType::class, [
            'label' => 'dt.entity.goopportunity.probability.label',
            'required' => false,
            'constraints' => [
                new Type([
                    'type' => 'integer'
                ])
            ]
        ]);
        $builder->add('revenueStartDate', RevenueStartDate::class, [
            'label' => 'dt.entity.goopportunity.revenue_start_date.label',
            'required' => false,
        ]);
        $builder->add('opportunityGroup', GoOpportunityGroupSelectType::class, [
            'label' => 'dt.entity.goopportunity.opportunity_group.label',
            'required' => false,
        ]);
        $builder->add('py', OroMoneyType::class, [
            'label' => 'dt.entity.goopportunity.py.label',
            'required' => false
        ]);
        $builder->add('ytd', OroMoneyType::class, [
            'label' => 'dt.entity.goopportunity.ytd.label',
            'required' => false
        ]);
        $builder->add('notes', TextareaType::class, [
            'label' => 'dt.entity.goopportunity.notes.label',
            'required' => false
        ]);
        $builder->add('reason_closed_lost', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunity.reason_closed_lost.label',
            'tooltip' => 'dt.entity.goopportunity.reason_closed_lost.tooltip',
            'required' => false,
            'enum_code' => GoOpportunity::ENUM_REASON_FOR_CLOSED_LOST
        ]);
        $builder->add('explanationForLoss', TextareaType::class, [
            'label' => 'dt.entity.goopportunity.explanation_for_loss.label',
            'required' => false
        ]);
        $builder->add('hvac_competitor', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunity.hvac_competitor.label',
            'required' => false,
            'enum_code' => GoOpportunity::ENUM_BUSINESS_CHALLENGER
        ]);
        $builder->add('otherHvacCompetitor', TextType::class, [
            'label' => 'dt.entity.goopportunity.other_hvac_competitor.label',
            'required' => false
        ]);
        $builder->add('closeDate', OroDateType::class, [
            'label' => 'dt.entity.goopportunity.close_date.label',
            'tooltip' => 'dt.entity.goopportunity.close_date.tooltip',
            'required' => true
        ]);
        $builder->add('gpCloseDate', OroDateType::class, [
            'label' => 'dt.entity.goopportunity.gp_close_date.label',
            'required' => true
        ]);
        $builder->add('accountPlan', GoAccountPlanSelectType::class, [
            'label' => 'dt.entity.goopportunity.account_plan.label',
            'required' => false
        ]);
        $builder->add('customer', CustomerSelectType::class, [
            'label' => 'dt.entity.goopportunity.customer.label',
            'create_enabled' => false,
            'required' => true
        ]);
        $builder->add('region', RegionSelectType::class, [
            'label' => 'dt.entity.goopportunity.region.label',
            'required' => false
        ]);
        $builder->add('businessUnit', AgencyBusinessUnitSelectType::class, [
            'label' => 'dt.entity.goopportunity.agency.label',
            'required' => false
        ]);
        $builder->add('repCode', RepCodeSelectType::class, [
            'label' => 'dt.entity.goopportunity.rep_code.label',
            'required' => false
        ]);
        $builder->add('owner', UserSelectType::class, [
            'label' => 'oro.ui.owner',
            'required' => false,
            'create_enabled' => false,
        ]);
        $builder->add('opportunity_record_type', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunity.opportunity_record_type.label',
            'required' => false,
            'enum_code' => GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE
        ]);

        $builder->add('opportunity_type', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunity.opportunity_type.label',
            'required' => true,
            'enum_code' => GoOpportunity::ENUM_OPPORTUNITY_TYPE
        ]);
        $builder->add('opportunity_source', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunity.opportunity_source.label',
            'required' => true,
            'enum_code' => GoOpportunity::ENUM_OPPORTUNITY_SOURCE
        ]);
        $builder->add('sales_initiative_type', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunity.sales_initiative_type.label',
            'required' => true,
            'enum_code' => GoOpportunity::ENUM_SALES_INITIATIVE_TYPE
        ]);

        $builder->add('dollarAmountWon', OroMoneyType::class, [
            'label' => 'dt.entity.goopportunity.dollar_amount_won.label',
            'required' => false
        ]);
        $builder->add('currency', CurrencyType::class, [
            'label' => 'dt.entity.goregionrep.currency.label',
            'required' => true,
        ]);
        $builder->add('priorityRating', PriorityRatingType::class, [
            'label' => 'dt.entity.goopportunity.priority_rating.label',
            'required' => false,
        ]);
        $builder->add('jobQuote', CheckboxType::class, [
            'label' => 'dt.entity.goopportunity.job_quote.label',
            'required' => false,
        ]);
        $builder->add('jobQuoteName', TextType::class, [
            'label' => 'dt.entity.goopportunity.job_quote_name.label',
            'required' => false,
        ]);
        $builder->add('nextStep', TextType::class, [
            'label' => 'dt.entity.goopportunity.next_step.label',
            'required' => false,
        ]);
        $builder->add('dateSampleSent', OroDateType::class, [
            'label' => 'dt.entity.goopportunity.date_sample_sent.label',
            'required' => false
        ]);

        $builder->add('notifyCustomerContact', CustomerContactSelectType::class, [
            'label' => 'dt.entity.goopportunity.notify_customer.label',
            'create_enabled' => false,
            'required' => false
        ]);

        $builder->add('notifyRsm', UserSelectType::class, [
            'label' => 'dt.entity.goopportunity.notify_rsm.label',
            'required' => false,
            'create_enabled' => false
        ]);

        $builder->add('notifySalesRep', SalesRepUserSelectType::class, [
            'label' => 'dt.entity.goopportunity.notify_sales_rep.label',
            'required' => false
        ]);

        $builder->add('situationDescription', TextareaType::class, [
            'label' => 'dt.entity.goopportunity.situation_description.label',
            'required' => false
        ]);
    }

    /**
     * @return callable
     */
    private function getAddStageListener(): callable
    {
        return function (FormEvent $event) {
            $opportunity = $event->getData();
            if (!$opportunity instanceof GoOpportunity) {
                return;
            }
            if ($opportunity->getOpportunityRecordType()) {
                $form = $event->getForm();
                $form->add('stage', GoOpportunityStageChooseType::class, [
                    'opportunity_record_type' => $opportunity->getOpportunityRecordType()->getId(),
                    'required' => true
                ]);
            }
        };
    }

    /**
     * Returns callable for customer-aware fields modification
     *
     * @return callable
     */
    private function getCustomerListener(): callable
    {
        return function (FormEvent $event) {
            $opportunity = $event->getData();
            if (!$opportunity instanceof GoOpportunity) {
                return;
            }
            $customer = $opportunity->getAccount();
            if (!$customer instanceof Customer || !($customer->getId())) {
                return;
            }

            $form = $event->getForm();
            /** @var FormInterface $fieldForm */
            foreach (clone $form as $fieldForm) {
                if ($fieldForm->getConfig()->hasOption('customer_id')) {
                    $typeClass = get_class($fieldForm->getConfig()->getType()->getInnerType());
                    $name = $fieldForm->getName();
                    $options = $fieldForm->getConfig()->getOptions();
                    $options['customer_id'] = $customer->getId();
                    $form->remove($name);
                    $form->add($name, $typeClass, $options);
                }
            }
        };
    }

    /**
     * {@inheritdoc}
     */
    public function finishView(FormView $view, FormInterface $form, array $options)
    {
        $view->vars['fiscalYear'] = $form->has('fiscalYear')
            ? ($form->get('fiscalYear')->getData() ? $form->get('fiscalYear')->getData() : date('Y'))
            : null;
        $view->vars['isGoPlan'] = $this
            ->getSubscriberByClass(GoPlanDisableFieldsSubscriber::class)
            ->isGoPlan($form->getData());
        if ($form->has('opportunity_record_type') && !$form->get('opportunity_record_type')->getData()) {
            $view->vars['method'] = Request::METHOD_GET;
        }
    }

    /**
     * {@inheritdoc}
     */
    protected function isEntityApplicable($entity): bool
    {
        return $entity instanceof GoOpportunity;
    }

    /**
     * {@inheritdoc}
     */
    protected function getFieldsToDisable(): array
    {
        return ['owner', 'opportunity_record_type', 'gpCloseDate'];
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => GoOpportunity::class
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
