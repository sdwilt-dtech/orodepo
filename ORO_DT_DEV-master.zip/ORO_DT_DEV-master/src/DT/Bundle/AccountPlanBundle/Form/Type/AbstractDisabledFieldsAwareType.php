<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\AccountPlanBundle\Model\GoOpportunity;
use DT\Bundle\AccountPlanBundle\Validator\Constraints\NotChanged;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormEvent;

abstract class AbstractDisabledFieldsAwareType extends AbstractType
{
    /**
     * Returns callable for fields read-only fields
     *
     * @return callable
     */
    protected function getFieldsAvailabilityListener(): callable
    {
        return function (FormEvent $event) {
            $entity = $event->getData();
            if (!$this->isEntityApplicable($entity)) {
                return;
            }

            foreach ($this->getFieldsToDisable() as $field) {
                $getter = $this->resolveGetter($entity, $field);
                if (null === $getter) {
                    continue;
                }
                if ($value = $entity->{$getter}()) {
                    $form = $event->getForm();
                    $fieldForm = $form->get($field);
                    $typeClass = get_class($fieldForm->getConfig()->getType()->getInnerType());
                    $options = $fieldForm->getConfig()->getOptions();
                    $options['constraints'] = array_merge($options['constraints'] ?? [], [
                        new NotChanged([
                            'field' => $field,
                            'value' => $value,
                            'className' => GoOpportunity::class
                        ])
                    ]);
                    $options['attr'] = $options['attr'] ?? [];
                    $options['attr']['readonly'] = true;
                    $options['attr']['class'] = ($options['attr']['class'] ?? '') . ' ' . 'disabled';
                    $form->remove($field);
                    $form->add($field, $typeClass, $options);
                }
            }
        };
    }

    /**
     * @param object $entity
     * @param string $fieldName
     * @return string
     */
    private function resolveGetter($entity, string $fieldName): ?string
    {
        $checks = [
            ucfirst($fieldName),
            $this->camelize($fieldName)
        ];
        foreach ($checks as $field) {
            $getter = sprintf('%s%s', 'get', ucfirst($field));
            if (method_exists($entity, $getter)) {
                return $getter;
            }
        }

        return null;
    }

    /**
     * Camelizes a given string.
     *
     * @param string $field
     * @return string
     */
    private function camelize(string $field): string
    {
        return str_replace(' ', '', ucwords(str_replace('_', ' ', $field)));
    }

    /**
     * @return array|string[]
     */
    abstract protected function getFieldsToDisable(): array;

    /**
     * Checks if entity is applicable for disabling it's form fields
     * by current implementation of this abstraction
     *
     * @param mixed $entity
     * @return bool
     */
    abstract protected function isEntityApplicable($entity): bool;
}
