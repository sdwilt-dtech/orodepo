<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

/**
 * Registry keeps modifiers instances and provides one by type
 */
class ModifiersRegistry
{
    /** @var array|FormModifierInterface[] */
    private $formModifiers = [];

    /**
     * @param iterable|FormModifierInterface[] $formModifiers
     */
    public function __construct(iterable $formModifiers)
    {
        foreach ($formModifiers as $formModifier) {
            $this->addFormModifier($formModifier);
        }
    }

    /**
     * Registers form modifier
     *
     * @param FormModifierInterface $formModifier
     * @return self
     */
    public function addFormModifier(FormModifierInterface $formModifier): self
    {
        $this->formModifiers[] = $formModifier;
        return $this;
    }

    /**
     * @param null|string $type
     * @return FormModifierInterface
     * @throw \InvalidArgumentException
     */
    public function getModifier(?string $type): FormModifierInterface
    {
        foreach ($this->getOrderedModifiers() as $modifier) {
            if ($modifier->canHandle($type)) {
                return $modifier;
            }
        }

        throw new \InvalidArgumentException(sprintf('Not supported type %s', $type));
    }

    /**
     * @return array
     */
    private function getOrderedModifiers(): array
    {
        $modifiers = $this->formModifiers;
        usort($modifiers, function (FormModifierInterface $modifier1, FormModifierInterface $modifier2) {
            $ordering1 = $modifier1->getOrdering();
            $ordering2 = $modifier2->getOrdering();

            if ($ordering1 == $ordering2) {
                return 0;
            }

            return $ordering1 < $ordering2 ? -1 : 1;
        });

        return $modifiers;
    }
}
