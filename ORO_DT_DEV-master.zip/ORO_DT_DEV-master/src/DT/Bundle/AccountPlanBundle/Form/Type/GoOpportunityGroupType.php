<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use Oro\Bundle\CustomerBundle\Form\Type\CustomerSelectType;
use Oro\Bundle\EntityExtendBundle\Form\Type\EnumChoiceType;
use Oro\Bundle\UserBundle\Form\Type\UserSelectType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class GoOpportunityGroupType extends AbstractDisabledFieldsAwareType
{
    public const NAME = 'dt_go_plan_opportunity_group';

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->add('name', TextType::class, [
            'label' => 'dt.entity.goopportunitygroup.name.label',
            'required' => true,
            'attr' => [
                'readonly' => true,
                'class' => 'disabled'
            ],
            'constraints' => [
                new NotBlank()
            ]
        ])
            ->add('textId', TextType::class, [
                'label' => 'dt.entity.goopportunitygroup.text_id.label',
                'tooltip' => 'dt.entity.goopportunitygroup.text_id.tooltip',
                'required' => true,
                'attr' => [
                    'readonly' => true,
                    'class' => 'disabled'
                ]
            ])
            ->add('regionRep', GoRegionRepSelectType::class, [
                'label' => 'dt.entity.goopportunitygroup.region_rep.label',
                'required' => false,
            ])
            ->add('regionalManagerEmail', EmailType::class, [
                'label' => 'dt.entity.goopportunitygroup.regional_manager_email.label',
                'required' => false
            ])
            ->add('salesSupportEmail', EmailType::class, [
                'label' => 'dt.entity.goopportunitygroup.sales_support_email.label',
                'required' => false
            ])
            ->add('owner', UserSelectType::class, [
                'label' => 'oro.ui.owner',
                'required' => false,
                'create_enabled' => false,
            ])
            ->add('businessUnit', AgencyBusinessUnitSelectType::class, [
                'label' => 'dt.entity.goopportunitygroup.business_unit.label',
                'required' => false
            ])->add('region', RegionSelectType::class, [
                'label' => 'dt.entity.goopportunitygroup.region.label',
                'required' => false
            ])->add('repCode', RepCodeSelectType::class, [
                'label' => 'dt.entity.goopportunitygroup.rep_code.label',
                'required' => false
            ])->add('account', CustomerSelectType::class, [
                'label' => 'dt.entity.goopportunitygroup.account.label',
                'create_enabled' => false,
                'required' => true
            ])->add('opportunityYear', EnumChoiceType::class, [
                'label' => 'dt.entity.goopportunitygroup.opportunity_year.label',
                'enum_code' => 'dt_opportunity_year',
                'required' => true
            ])->add('fiscalYear', SelectYearType::class, [
                'label' => 'dt.entity.goopportunitygroup.fiscal_year.label',
                'tooltip' => 'dt.entity.goopportunitygroup.fiscal_year.tooltip',
                'required' => true,
                'placeholder' => false,
                'constraints' => [
                    new NotBlank()
                ]
            ]);
        $builder->addEventListener(FormEvents::PRE_SET_DATA, $this->getFieldsAvailabilityListener());
    }

    /**
     * {@inheritdoc}
     */
    protected function isEntityApplicable($entity): bool
    {
        return $entity instanceof GoOpportunityGroup;
    }

    /**
     * {@inheritdoc}
     */
    protected function getFieldsToDisable(): array
    {
        return ['owner', 'opportunityYear', 'fiscalYear'];
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => GoOpportunityGroup::class
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix(): string
    {
        return self::NAME;
    }
}
