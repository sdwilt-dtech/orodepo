<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;
use Oro\Bundle\EntityExtendBundle\Form\Type\EnumSelectType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class GoOpportunityStageType extends AbstractType
{
    public const NAME = 'dt_go_plan_opportunity_stage';

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('name', TextType::class, [
            'label' => 'dt.entity.goopportunitystage.name.label',
            'required' => true
        ]);
        $builder->add('probability', IntegerType::class, [
            'label' => 'dt.entity.goopportunitystage.probability.label',
            'required' => true
        ]);
        $builder->add('forecast_category', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunitystage.forecast_category.label',
            'required' => true,
            'enum_code' => GoOpportunity::ENUM_FORECAST_CATEGORY
        ]);
        $builder->add('type', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunitystage.type.label',
            'required' => true,
            'enum_code' => GoOpportunityStage::ENUM_OPPORTUNITY_STAGE_TYPE
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => GoOpportunityStage::class
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
