<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\ChoiceList\Loader\CallbackChoiceLoader;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class QuarterType extends AbstractType
{
    public const NAME = 'dt_go_plan_opportunity_quarter';

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return ChoiceType::class;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'choice_loader' => new CallbackChoiceLoader(function () {
                return $this->getChoices();
            }),
            'placeholder' => 'dt.form.choice.empty.placeholder'
        ]);
    }

    /**
     * @return array
     */
    private function getChoices(): array
    {
        return [
            'dt.entity.goopportunity.ask_quarter.q1' => 1,
            'dt.entity.goopportunity.ask_quarter.q2' => 2,
            'dt.entity.goopportunity.ask_quarter.q3' => 3,
            'dt.entity.goopportunity.ask_quarter.q4' => 4,
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
