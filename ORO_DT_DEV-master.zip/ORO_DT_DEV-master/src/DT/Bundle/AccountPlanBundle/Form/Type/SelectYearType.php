<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\Options;
use Symfony\Component\OptionsResolver\OptionsResolver;

class SelectYearType extends AbstractType
{
    public const NAME = 'dt_select_year';

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined('years_back');
        $resolver->setDefined('years_ahead');
        $resolver->setAllowedTypes('years_back', 'int');
        $resolver->setAllowedTypes('years_ahead', 'int');

        $resolver->setDefaults([
            'years_back' => 5,
            'years_ahead' => 5,
        ]);

        $resolver->addNormalizer('choices', function (Options $options, $choices) {
            $results = [];
            $year = (int)date('Y');
            $yearStart = $year - $options['years_back'];
            $yearEnd = $year + $options['years_back'];
            for ($yearValue = $yearStart; $yearValue <= $yearEnd; $yearValue++) {
                $results[$yearValue] = $yearValue;
            }

            return $results;
        });
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();
            if (!$form->getData()) {
                $form->setData(date('Y'));
            }
        });
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return ChoiceType::class;
    }
}
