<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\OptionsResolver\OptionsResolver;

class GoOpportunityGroupSelectType extends AbstractSelectType
{
    public const NAME = 'dt_go_plan_opportunity_group_select';

    /** @var CustomerHierarchy */
    private $customerHierarchyProvider;

    /**
     * @param RequestStack $requestStack
     * @param ManagerRegistry $doctrine
     * @param CustomerHierarchy $customerHierarchyProvider
     */
    public function __construct(
        RequestStack $requestStack,
        ManagerRegistry $doctrine,
        CustomerHierarchy $customerHierarchyProvider
    ) {
        $this->customerHierarchyProvider = $customerHierarchyProvider;
        parent::__construct($requestStack, $doctrine);
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'autocomplete_alias' => 'dt_go_plan_opportunity_group',
                'create_enabled'  => false,
                'grid_name' => 'go-plan-opportunity-group-grid',
                'configs'            => [
                    'placeholder'             => 'dt.entity.goopportunitygroup.select_label',
                    'result_template_twig'    => 'OroFormBundle:Autocomplete:fullName/result.html.twig',
                    'selection_template_twig' => 'OroFormBundle:Autocomplete:fullName/selection.html.twig'
                ],
            ]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $form->getData();
            if (null === $data && ($group = $this->findCustomerAwareEntity(GoOpportunityGroup::class))) {
                $parentForm = $form->getParent();
                $formName = $form->getName();
                $typeClass = get_class($form->getConfig()->getType()->getInnerType());
                $options = $form->getConfig()->getOptions();
                $parentForm->remove($formName);
                $options['attr'] = $options['attr'] ?? [];
                $options['attr']['readonly'] = true;
                $options['attr']['class'] = ($options['attr']['class'] ?? '') . ' ' . 'disabled';
                $options['data'] = $group;
                $parentForm->add($formName, $typeClass, $options);
            }
        });
    }

    /**
     * {@inheritdoc}
     */
    protected function getCustomer(): ?Customer
    {
        $customer = parent::getCustomer();
        return $customer
            ? $this->customerHierarchyProvider->getCustomerForLevel($customer)
            : null;
    }
}
