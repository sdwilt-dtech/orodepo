<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\AccountPlanBundle\Form\Model\StageUpdate;
use DT\Bundle\AccountPlanBundle\Provider\StageNumberProvider;
use DT\Bundle\AccountPlanBundle\Provider\StageValuesProvider;
use DT\Bundle\AccountPlanBundle\Validator\Constraints\HigherStageValue;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\EntityExtendBundle\Form\Type\EnumSelectType;
use Oro\Bundle\FormBundle\Form\Type\OroMoneyType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\Range;

class StageUpdateType extends AbstractType
{
    public const NAME = 'dt_stage_update';

    /** @var StageValuesProvider */
    private $stageValuesProvider;

    /** @var StageNumberProvider */
    private $stageNumberProvider;

    /**
     * @param StageValuesProvider $stageValuesProvider
     * @param StageNumberProvider $stageNumberProvider
     */
    public function __construct(StageValuesProvider $stageValuesProvider, StageNumberProvider $stageNumberProvider)
    {
        $this->stageValuesProvider = $stageValuesProvider;
        $this->stageNumberProvider = $stageNumberProvider;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined(['opportunity_record_type']);
        $resolver->setAllowedTypes('opportunity_record_type', 'string');
        $resolver->setRequired(['opportunity_record_type']);

        $resolver->setDefaults([
            'data_class' => StageUpdate::class
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('stage', GoOpportunityStageChooseType::class, [
            'opportunity_record_type' => $options['opportunity_record_type'],
            'label' => 'dt.entity.goopportunity.stage_name.label',
            'required' => true
        ]);

        $builder->add('probability', IntegerType::class, [
            'label' => 'dt.entity.goopportunity.probability.label',
            'rounding_mode' => \NumberFormatter::ROUND_HALFEVEN,
            'required' => false,
            'constraints' => [
                new Range(['min' => 0, 'max' => '100']),
            ]
        ]);
        $builder->add('competitors', EnumSelectType::class, [
            'label' => 'dt.entity.goopportunity.business_challenger.label',
            'required' => true,
            'multiple' => true,
            'enum_code' => GoOpportunity::ENUM_BUSINESS_CHALLENGER
        ]);
        $builder->add('otherBusinessChallenger', TextType::class, [
            'label' => 'dt.entity.goopportunity.other_business_challenger.label',
            'required' => false,
            'constraints' => [
                new Length(['max' => '255']),
            ]
        ]);
        $builder->add('verifiedTotalCategoryValue', OroMoneyType::class, [
            'label' => 'dt.entity.goopportunity.verified_total_category_value.label',
            'required' => true
        ]);

        $builder->addEventListener(FormEvents::POST_SUBMIT, function (FormEvent $event) {
            /** @var StageUpdate $stageUpdate */
            $stageUpdate = $event->getData();
            $form = $event->getForm();

            if ($this->stageNumberProvider->getStageNumber($stageUpdate->getStage()) <
                HigherStageValue::DEFAULT_STAGE) {
                return;
            }
            if (!$stageUpdate->getVerifiedTotalCategoryValue()) {
                $form->get('verifiedTotalCategoryValue')->addError(
                    new FormError("Please Enter the Agent Assigned Value to the Opportunity")
                );
            }
            if ($stageUpdate->getCompetitors()->isEmpty()) {
                $form->get('competitors')->addError(
                    new FormError("Please Enter the Business Challenger to the Opportunity")
                );
            }
        });
    }

    /**
     * {@inheritdoc}
     */
    public function finishView(FormView $view, FormInterface $form, array $options)
    {
        $view->vars['stages'] = [];
        foreach ($this->stageValuesProvider->getStageValues($options['opportunity_record_type']) as $stage) {
            $view->vars['stages'][$stage->getId()] = $stage->toArray();
        }
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
