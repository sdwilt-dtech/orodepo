<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use DT\Bundle\AccountPlanBundle\Provider\StageValuesProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\CallbackTransformer;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\Options;
use Symfony\Component\OptionsResolver\OptionsResolver;

class GoOpportunityStageChooseType extends AbstractType
{
    public const NAME = 'dt_go_plan_opportunity_stage';

    /** @var StageValuesProvider */
    private $stageValuesProvider;

    /**
     * @param StageValuesProvider $stageValuesProvider
     */
    public function __construct(StageValuesProvider $stageValuesProvider)
    {
        $this->stageValuesProvider = $stageValuesProvider;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->addModelTransformer(new CallbackTransformer(
                function (?GoOpportunityStage $stage) {
                    return $stage ? $stage->getId() : null;
                },
                function (?int $stageId) {
                    return $stageId ? $this->stageValuesProvider->getStageById($stageId) : null;
                }
            ));
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined('opportunity_record_type');
        $resolver->setAllowedTypes('opportunity_record_type', 'string');
        $resolver->setRequired('opportunity_record_type');

        $resolver->addNormalizer('choices', function (Options $options, $choices) {
            $recordType = $options['opportunity_record_type'];
            $results = [];
            foreach ($this->stageValuesProvider->getStageValues($recordType) as $stage) {
                $results[$stage->getName()] = $stage->getId();
            }

            return $results;
        });
    }

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return ChoiceType::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
