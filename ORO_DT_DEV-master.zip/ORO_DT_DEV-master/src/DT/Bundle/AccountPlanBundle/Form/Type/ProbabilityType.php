<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\CallbackTransformer;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;

class ProbabilityType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->addModelTransformer(new CallbackTransformer(
                function ($probability) {
                    return null === $probability ? (int)$probability : null;
                },
                function ($probability) {
                    return null === $probability ? null : (int)$probability;
                }
            ));

        $builder
            ->addViewTransformer(new CallbackTransformer(
                function ($probability) {
                    return null === $probability ? (int)$probability : null;
                },
                function ($probability) {
                    return null === $probability ? null : (int)$probability;
                }
            ));
    }

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return TextType::class;
    }
}
