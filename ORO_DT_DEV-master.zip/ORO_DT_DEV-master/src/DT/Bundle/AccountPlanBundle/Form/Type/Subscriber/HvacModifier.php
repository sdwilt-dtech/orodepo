<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use Symfony\Component\Form\FormInterface;

class HvacModifier implements FormModifierInterface
{
    /**
     * {@inheritdoc}
     */
    public function canHandle(?string $type): bool
    {
        return $type && in_array($type, [
            OpportunityRecordType::TYPE_HVAC_GO_PLAN,
            OpportunityRecordType::TYPE_HVAC_OLD_GP,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function modify(FormInterface $form): void
    {
        $form->remove('opportunity_type');
        $form->remove('dollarAmountWon');
        $form->remove('currency');
        $form->remove('priorityRating');
        $form->remove('opportunity_source');
        $form->remove('sales_initiative_type');
        $form->remove('jobQuote');
        $form->remove('jobQuoteName');
        $form->remove('notifyCustomerContact');
        $form->remove('situationDescription');
        $form->remove('nextStep');
        $form->remove('notifyCustomerContact');
        $form->remove('notifyRsm');
        $form->remove('notifySalesRep');
    }

    /**
     * {@inheritdoc}
     */
    public function getAvailableFields(): array
    {
        return [
            'name',
            'textId',
            'sales_opportunity_type',
            'askQuarter',
            'fiscalQuarter',
            'fiscalYear',
            'business_challenger',
            'productCategoryCode',
            'otherBusinessChallenger',
            'calculatedOpportunityValue',
            'verifiedTotalCategoryValue',
            'targetedOpportunityValue',
            'likehood',
            'probability',
            'revenueStartDate',
            'opportunityGroup',
            'py',
            'ytd',
            'notes',
            'reason_closed_lost',
            'explanationForLoss',
            'hvac_competitor',
            'otherHvacCompetitor',
            'closeDate',
            'gpCloseDate',
            'accountPlan',
            'customer',
            'region',
            'businessUnit',
            'repCode',
            'owner',
            'opportunity_record_type',
            'opportunity_type',
            'currency'
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function getViewTemplate(): string
    {
        return 'DTAccountPlanBundle:Opportunity:goPlanView.html.twig';
    }

    /**
     * {@inheritdoc}
     */
    public function getFormTemplate(): string
    {
        return 'DTAccountPlanBundle:Opportunity:goPlanUpdate.html.twig';
    }

    /**
     * {@inheritdoc}
     */
    public function getOrdering(): int
    {
        return 10;
    }
}
