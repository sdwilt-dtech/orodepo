<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type\Subscriber;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;

/**
 * Handles certain type form fields availability/visibility
 */
class OpportunityRecordTypeSubscriber implements EventSubscriberInterface
{
    /** @var ModifiersRegistry */
    private $modifiersRegistry;

    /**
     * @param ModifiersRegistry $modifiersRegistry
     */
    public function __construct(ModifiersRegistry $modifiersRegistry)
    {
        $this->modifiersRegistry = $modifiersRegistry;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            FormEvents::PRE_SET_DATA => 'customizeForm'
        ];
    }

    /**
     * @param FormEvent $event
     */
    public function customizeForm(FormEvent $event): void
    {
        $form = $event->getForm();
        $opportunity = $event->getData();
        if (!$opportunity instanceof GoOpportunity) {
            return;
        }
        $this->doCustomizeForm($form, $opportunity->getOpportunityRecordType());
    }

    /**
     * @param FormInterface $form
     * @param AbstractEnumValue|null $type
     */
    private function doCustomizeForm(FormInterface $form, ?AbstractEnumValue $type): void
    {
        $modifier = $this->modifiersRegistry->getModifier($type ? $type->getId() : null);
        $modifier->modify($form);
    }
}
