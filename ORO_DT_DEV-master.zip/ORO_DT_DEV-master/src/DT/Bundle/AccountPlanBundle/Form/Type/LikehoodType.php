<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\ChoiceList\Loader\CallbackChoiceLoader;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LikehoodType extends AbstractType
{
    public const NAME = 'dt_go_plan_opportunity_likehood';

    private const DEFAULT_CHOICES = [0, 10, 20, 40, 60, 80, 95, 100];

    /** @var array|int[] */
    protected $map = self::DEFAULT_CHOICES;

    /**
     * Sets custom values map
     *
     * @param array $map
     * @return self
     */
    public function setMap(array $map): self
    {
        $this->map = $map;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return ChoiceType::class;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'choice_loader' => new CallbackChoiceLoader(function () {
                return $this->getChoices();
            }),
            'placeholder' => 'dt.form.choice.empty.placeholder'
        ]);
    }

    /**
     * @return array
     */
    private function getChoices(): array
    {
        $results = [];
        foreach ($this->map as $choice) {
            $results[(string)$choice] = $choice;
        }

        return $results;
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
