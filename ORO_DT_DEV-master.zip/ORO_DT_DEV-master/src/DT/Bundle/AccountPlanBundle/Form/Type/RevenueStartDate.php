<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\ChoiceList\Loader\CallbackChoiceLoader;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RevenueStartDate extends AbstractType
{
    public const NAME = 'dt_go_plan_opportunity_revenue_start_date';

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return ChoiceType::class;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'choice_loader' => new CallbackChoiceLoader(function () {
                return $this->getChoices();
            }),
            'placeholder' => 'dt.form.choice.empty.placeholder'
        ]);
    }

    /**
     * @return array
     */
    private function getChoices(): array
    {
        $results = [];
        for ($i = 1; $i <= 12; $i++) {
            $monthFill = sprintf('%s%d', (strlen($i) === 1 ? '0' : ''), $i);
            $month = date('M', strtotime(sprintf('01.%s.2020', $monthFill)));
            $results[$month] = $i;
        }

        return $results;
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
