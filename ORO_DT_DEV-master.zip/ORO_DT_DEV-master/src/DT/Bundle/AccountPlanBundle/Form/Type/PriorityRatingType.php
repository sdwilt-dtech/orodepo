<?php

namespace DT\Bundle\AccountPlanBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\ChoiceList\Loader\CallbackChoiceLoader;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PriorityRatingType extends AbstractType
{
    public const NAME = 'dt_priority_rating';

    /** @var int[] */
    private $priorities = [1, 2, 3, 4];

    /**
     * Sets custom priorities
     *
     * @param array $priorities
     * @return self
     */
    public function setPriorities(array $priorities): self
    {
        $this->priorities = $priorities;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getParent()
    {
        return ChoiceType::class;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'choice_loader' => new CallbackChoiceLoader(function () {
                return $this->getChoices();
            }),
            'placeholder' => 'dt.form.choice.empty.placeholder'
        ]);
    }

    /**
     * @return array
     */
    private function getChoices(): array
    {
        $results = [];
        foreach ($this->priorities as $priority) {
            $results[$priority] = $priority;
        }

        return $results;
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return self::NAME;
    }
}
