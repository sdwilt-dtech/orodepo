<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor\Exception;

use Throwable;

class DataErrorException extends \RuntimeException
{
    /** @var string */
    private $description;

    /**
     * @param string $message
     * @param string $description
     * @param Throwable|null $previous
     */
    public function __construct(string $message, string $description, Throwable $previous = null)
    {
        $this->description = $description;
        parent::__construct($message, 0, $previous);
    }

    /**
     * Gets description property
     *
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }
}
