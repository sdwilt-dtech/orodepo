<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Api\Processor\Exception\DataErrorException;
use DT\Bundle\AccountPlanBundle\Provider\OpportunityGroupProviderInterface;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\ApiBundle\Model\Error;
use Oro\Bundle\ApiBundle\Processor\Create\CreateContext;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Creates opportunity group from the opportunity entity,
 * if all required attributes and relations are present.
 */
class CreateGroupFromOpportunityProcessor implements ProcessorInterface
{
    protected const OPERATION_NAME = 'dt_opportunity_group_relation_added';

    /** @var OpportunityGroupProviderInterface */
    private $groupOpportunityProvider;

    /** @var TranslatorInterface */
    private $translator;

    /**
     * @param OpportunityGroupProviderInterface $groupOpportunityProvider
     * @param TranslatorInterface $translator
     */
    public function __construct(
        OpportunityGroupProviderInterface $groupOpportunityProvider,
        TranslatorInterface $translator
    ) {
        $this->groupOpportunityProvider = $groupOpportunityProvider;
        $this->translator = $translator;
    }

    /**
     * {@inheritdoc}
     */
    public function process(ContextInterface $context)
    {
        /** @var CreateContext $context */
        if ($context->isProcessed(self::OPERATION_NAME)) {
            return;
        }

        $opportunity = $context->getResult();
        if (!($opportunity instanceof GoOpportunity) || $opportunity->getOpportunityGroup()) {
            return;
        }

        try {
            $this->doProcess($opportunity);
        } catch (DataErrorException $exc) {
            $context->addError(
                Error::createValidationError(
                    $exc->getMessage(),
                    $exc->getDescription()
                )
            );
        } catch (\RuntimeException $exc) {
            $context->addError(
                Error::createValidationError(
                    $this->translator->trans('dt.api.goopportunity.opportunity_group.error.message'),
                    $exc->getMessage()
                )
            );
        }
        $context->setProcessed(self::OPERATION_NAME);
    }

    /**
     * @param GoOpportunity $opportunity
     */
    private function doProcess(GoOpportunity $opportunity): void
    {
        $group = $this->groupOpportunityProvider->getOpportunityGroup($opportunity);
        $opportunity->setOpportunityGroup($group);
    }
}
