<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor\GoOpportunity;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\Repository\GoAccountPlanRepository;
use DT\Bundle\EntityBundle\Entity\Repository\GoOpportunityGroupRepository;
use Oro\Bundle\ApiBundle\Processor\ContextInterface as ApiContext;
use Oro\Bundle\ApiBundle\Request\JsonApi\JsonApiDocumentBuilder;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;
use Oro\Component\ChainProcessor\ContextInterface;
use Symfony\Component\PropertyAccess\Exception\UnexpectedTypeException;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Assign customer related Account Plan and opportunity group to
 * Go Opportunity if applicable
 */
class NormalizeGoPlanDataProcessor extends AbstractRecordTypeAwareProcessor
{
    /** @var ManagerRegistry */
    private $doctrine;

    /** @var CustomerHierarchy */
    private $customerHierarchy;

    /**
     * @param TranslatorInterface $translator
     * @param EnumValueProvider $enumValueProvider
     * @param ManagerRegistry $doctrine
     * @param CustomerHierarchy $customerHierarchy
     */
    public function __construct(
        TranslatorInterface $translator,
        EnumValueProvider $enumValueProvider,
        ManagerRegistry $doctrine,
        CustomerHierarchy $customerHierarchy
    ) {
        $this->doctrine = $doctrine;
        $this->customerHierarchy = $customerHierarchy;
        parent::__construct($translator, $enumValueProvider);
    }

    /**
     * {@inheritdoc}
     * @param ApiContext $context
     */
    public function process(ContextInterface $context)
    {
        if ($this->validateData($data = $context->getRequestData(), $context)) {
            $this->doProcess($context);
        }
    }

    /**
     * @param ApiContext $context
     */
    private function doProcess(ApiContext $context): void
    {
        $data = $context->getRequestData();
        $recordType = $this
            ->propertyAccessor->getValue($data, sprintf('[data][attributes][%s]', self::RECORD_TYPE_KEY));
        if (OpportunityRecordType::TYPE_HVAC_GO_PLAN === $recordType) {
            $this->loadRelations($context);
        }
    }

    /**
     * @param ApiContext $context
     */
    private function loadRelations(ApiContext $context): void
    {
        $data = $context->getRequestData();
        try {
            $customerId = $this->propertyAccessor->getValue($data, '[data][relationships][customer][data][id]');
        } catch (UnexpectedTypeException $exc) {
            $customerId = null;
        }
        try {
            $fiscalYear = $this->propertyAccessor->getValue($data, '[data][attributes][fiscalYear]');
        } catch (UnexpectedTypeException $exc) {
            $fiscalYear = null;
        }

        if ($fiscalYear && $customerId && ($customer = $this->getCustomer($customerId))) {
            if ($accountPlan = $this->getAccountPlan($customer, $fiscalYear)) {
                $this->propertyAccessor->setValue($data, '[data][relationships][accountPlan][data]', [
                    JsonApiDocumentBuilder::TYPE => 'dtgo_account_plans',
                    JsonApiDocumentBuilder::ID => $accountPlan->getId()
                ]);
            }
            if ($opportunityGroup = $this->getOpportunityGroup($customer, $fiscalYear)) {
                $this->propertyAccessor->setValue($data, '[data][relationships][opportunityGroup][data]', [
                    JsonApiDocumentBuilder::TYPE => 'dtgo_opportunity_groups',
                    JsonApiDocumentBuilder::ID => (string)$opportunityGroup->getId()
                ]);
            }

            $context->setRequestData($data);
        }
    }

    /**
     * @param string $fiscalYear
     * @param Customer $customer
     * @return GoAccountPlan|null
     */
    private function getAccountPlan(Customer $customer, string $fiscalYear): ?GoAccountPlan
    {
        /** @var GoAccountPlanRepository $repo */
        $repo = $this
            ->doctrine
            ->getManagerForClass(GoAccountPlan::class)
            ->getRepository(GoAccountPlan::class);

        $queryBuilder = $repo->getCustomerAwareQueryBuilder($customer, $fiscalYear);
        $results = $queryBuilder ? $queryBuilder->getQuery()->execute() : [];

        return count($results) ? $results[0] : null;
    }

    /**
     * @param string $fiscalYear
     * @param Customer $customer
     * @return GoOpportunityGroup|null
     */
    private function getOpportunityGroup(Customer $customer, string $fiscalYear): ?GoOpportunityGroup
    {
        /** @var GoOpportunityGroupRepository $repo */
        $repo = $this
            ->doctrine
            ->getManagerForClass(GoOpportunityGroup::class)
            ->getRepository(GoOpportunityGroup::class);

        $groupCustomer = $this->customerHierarchy->getCustomerForLevel($customer);
        if (null === $groupCustomer) {
            return null;
        }

        $queryBuilder = $repo->getCustomerAwareQueryBuilder($groupCustomer, $fiscalYear);
        $results = $queryBuilder ? $queryBuilder->getQuery()->execute() : [];

        return count($results) ? $results[0] : null;
    }

    /**
     * @param int $customerId
     * @return Customer|null
     */
    private function getCustomer($customerId): ?Customer
    {
        if (ctype_digit($customerId)) {
            /** @var Customer $customer */
            $customer = $this
                ->doctrine
                ->getManagerForClass(Customer::class)
                ->getRepository(Customer::class)->find($customerId);

            return $customer;
        }

        return null;
    }
}
