<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\TextId\TextIdProviderRegistry;
use DT\Bundle\CustomerBundle\Provider\CustomerSegmentProvider;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Component\ChainProcessor\ContextInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;

/**
 * Generates missing TextID for region rep
 */
class GenerateRegionRepTextIdProcessor extends AbstractGenerateTextIdProcessor
{
    /** @var ManagerRegistry */
    private $doctrine;

    /** @var CustomerSegmentProvider */
    private $customerSegmentProvider;

    /**
     * @param TextIdProviderRegistry $textIdProviderRegistry
     * @param ManagerRegistry $doctrine
     * @param CustomerSegmentProvider $customerSegmentProvider
     * @param PropertyAccessorInterface|null $propertyAccessor
     */
    public function __construct(
        TextIdProviderRegistry $textIdProviderRegistry,
        ManagerRegistry $doctrine,
        CustomerSegmentProvider $customerSegmentProvider,
        PropertyAccessorInterface $propertyAccessor = null
    ) {
        $this->doctrine = $doctrine;
        $this->customerSegmentProvider = $customerSegmentProvider;
        parent::__construct($textIdProviderRegistry, $propertyAccessor);
    }

    /**
     * {@inheritdoc}
     */
    protected function getClassName(): string
    {
        return GoRegionRep::class;
    }

    /**
     * {@inheritdoc}
     */
    public function process(ContextInterface $context)
    {
        parent::process($context);
        $data = $context->getRequestData();
        if ($attributes = $this->getPropertyValue($data, '[data][attributes]')) {
            unset($attributes['fiscalYear']);
            $this->propertyAccessor->setValue($data, '[data][attributes]', $attributes);
            $context->setRequestData($data);
        }
    }

    /**
     * {@inheritdoc}
     */
    protected function prepareRequest(array $data): ?Request
    {
        $textIdParts = [];
        if ($region = $this->getPropertyValue($data, '[data][relationships][region][data][id]')) {
            $textIdParts['region'] = $region;
        }
        $customerSegment = $this
            ->getPropertyValue($data, '[data][relationships][kcg_customer_segment][data][id]');
        if (null !== $customerSegment) {
            $textIdParts['kcg_customer_segment'] = $customerSegment;
        }
        if ($repCode = $this->getPropertyValue($data, '[data][relationships][repCode][data][id]')) {
            $textIdParts['repCode'] = $repCode;
        }

        if ($fiscalYear = $this->getPropertyValue($data, '[data][attributes][fiscalYear]')) {
            $textIdParts['fiscalYear'] = $fiscalYear;
        }


        if (count($textIdParts) !== 4) {
            return null;
        }

        return new Request([], $textIdParts);
    }
}
