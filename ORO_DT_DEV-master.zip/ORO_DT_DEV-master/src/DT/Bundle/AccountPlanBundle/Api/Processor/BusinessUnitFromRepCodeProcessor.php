<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\ApiBundle\Request\JsonApi\JsonApiDocumentBuilder;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Component\PropertyAccess\Exception\UnexpectedTypeException;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;

/**
 * Resolves business unit by rep code
 */
class BusinessUnitFromRepCodeProcessor implements ProcessorInterface
{
    public const JDE_ID = 'jdeId';

    /** @var PropertyAccessorInterface */
    protected $propertyAccessor;

    /** @var ManagerRegistry */
    protected $doctrine;

    /**
     * @param ManagerRegistry $doctrine
     * @param PropertyAccessorInterface|null $propertyAccessor
     */
    public function __construct(ManagerRegistry $doctrine, PropertyAccessorInterface $propertyAccessor = null)
    {
        $this->doctrine = $doctrine;
        $this->propertyAccessor = $propertyAccessor ?: PropertyAccess::createPropertyAccessor();
    }

    /**
     * {@inheritdoc}
     */
    public function process(ContextInterface $context)
    {
        $data = $context->getRequestData();
        $propertyPath = sprintf('[data][relationships][businessUnit][data][%s]', self::JDE_ID);
        if (!$this->getPropertyValue($data, '[data][relationships][businessUnit]')) {
            $this->processWithRepCode($context);
        } elseif ($code = $this->getPropertyValue($data, $propertyPath)) {
            $this->processWithJdeId($context, $code);
        }
    }

    /**
     * @param ContextInterface $context
     */
    private function processWithRepCode(ContextInterface $context): void
    {
        $data = $context->getRequestData();
        if ($id = $this->getPropertyValue($data, '[data][relationships][repCode][data][id]')) {
            $repCode = $this
                ->doctrine
                ->getManagerForClass(RepCode::class)
                ->getRepository(RepCode::class)
                ->find($id);
            if (null !== $repCode) {
                if ($businessUnit = $this->findBusinessUnitByRepCode($repCode)) {
                    $this->propertyAccessor->setValue($data, '[data][relationships][businessUnit][data]', [
                        JsonApiDocumentBuilder::ID => (string)$businessUnit->getId(),
                        JsonApiDocumentBuilder::TYPE => 'businessunits'
                    ]);

                    $context->setRequestData($data);
                }
            }
        }
    }

    /**
     * @param RepCode $repCode
     * @return BusinessUnit|null
     */
    private function findBusinessUnitByRepCode(RepCode $repCode): ?BusinessUnit
    {
        return $this
            ->doctrine
            ->getManagerForClass(BusinessUnit::class)
            ->getRepository(BusinessUnit::class)
            ->findOneBy([
                'dt_agency_rep_code' => $repCode
            ]);
    }

    /**
     * @param ContextInterface $context
     * @param string $code
     */
    private function processWithJdeId(ContextInterface $context, string $code): void
    {
        $repCode = $this
            ->doctrine
            ->getManagerForClass(RepCode::class)
            ->getRepository(RepCode::class)
            ->findOneBy([
                'code' => $code
            ]);
        if (null !== $repCode) {
            if ($businessUnit = $this->findBusinessUnitByRepCode($repCode)) {
                $this->propertyAccessor->setValue($data, '[data][relationships][businessUnit][data]', [
                    JsonApiDocumentBuilder::ID => (string)$businessUnit->getId(),
                    JsonApiDocumentBuilder::TYPE => 'businessunits'
                ]);

                $context->setRequestData($data);
            }
        }
    }

    /**
     * @param array $data
     * @param string $propertyPath
     * @param mixed $default
     * @return mixed|null
     */
    protected function getPropertyValue(array $data, string $propertyPath, $default = null)
    {
        try {
            return $this->propertyAccessor->getValue($data, $propertyPath);
        } catch (UnexpectedTypeException $exc) {
            return $default;
        }
    }
}
