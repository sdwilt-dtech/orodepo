<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor;

use DT\Bundle\AccountPlanBundle\Provider\TextId\NameAwareTextIdProviderInterface;
use DT\Bundle\AccountPlanBundle\Provider\TextId\TextIdProviderRegistry;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\PropertyAccess\Exception\UnexpectedTypeException;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;

/**
 * Generates Text ID if all mandatory records are available
 */
abstract class AbstractGenerateTextIdProcessor implements ProcessorInterface
{
    /** @var TextIdProviderRegistry */
    protected $textIdProviderRegistry;

    /** @var PropertyAccessorInterface */
    protected $propertyAccessor;

    /**
     * @param TextIdProviderRegistry $textIdProviderRegistry
     * @param PropertyAccessorInterface|null $propertyAccessor
     */
    public function __construct(
        TextIdProviderRegistry $textIdProviderRegistry,
        PropertyAccessorInterface $propertyAccessor = null
    ) {
        $this->textIdProviderRegistry = $textIdProviderRegistry;
        $this->propertyAccessor = $propertyAccessor ?: PropertyAccess::createPropertyAccessor();
    }

    /**
     * {@inheritdoc}
     */
    public function process(ContextInterface $context)
    {
        $data = $context->getRequestData();
        if (null === $this->getPropertyValue($data, '[data][attributes][textId]')) {
            $this->doProcessTextId($context);
        }
        if (null === $this->getPropertyValue($data, '[data][attributes][name]')) {
            $this->doProcessName($context);
        }
    }

    /**
     * @param ContextInterface $context
     */
    private function doProcessName(ContextInterface $context): void
    {
        $data = $context->getRequestData();
        if ($request = $this->prepareRequest($data)) {
            $provider = $this->textIdProviderRegistry->getProvider($this->getClassName());
            if ($provider instanceof NameAwareTextIdProviderInterface) {
                $name = $provider->getName($request);
                $this->propertyAccessor->setValue($data, '[data][attributes][name]', $name);
                $context->setRequestData($data);
            }
        }
    }

    /**
     * @param ContextInterface $context
     */
    private function doProcessTextId(ContextInterface $context): void
    {
        $data = $context->getRequestData();
        if ($request = $this->prepareRequest($data)) {
            $textId = $this->textIdProviderRegistry->getProvider($this->getClassName())->getTextId($request);
            $this->propertyAccessor->setValue($data, '[data][attributes][textId]', $textId);
            $context->setRequestData($data);
        }
    }

    /**
     * Creates request for TextID generator
     *
     * @param array $data
     * @return Request|null
     */
    abstract protected function prepareRequest(array $data): ?Request;

    /**
     * Returns handled class name
     *
     * @return string
     */
    abstract protected function getClassName(): string;

    /**
     * @param array $data
     * @param string $propertyPath
     * @param mixed $default
     * @return mixed|null
     */
    protected function getPropertyValue(array $data, string $propertyPath, $default = null)
    {
        try {
            return $this->propertyAccessor->getValue($data, $propertyPath);
        } catch (UnexpectedTypeException $exc) {
            return $default;
        }
    }
}
