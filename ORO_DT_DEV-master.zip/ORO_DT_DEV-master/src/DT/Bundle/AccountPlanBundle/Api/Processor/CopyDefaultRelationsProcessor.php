<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor;

use Doctrine\Common\Util\ClassUtils;
use Doctrine\Persistence\ManagerRegistry;
use Oro\Bundle\ApiBundle\Request\JsonApi\JsonApiDocumentBuilder;
use Oro\Bundle\EntityBundle\ORM\EntityAliasResolver;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Component\PropertyAccess\Exception\UnexpectedTypeException;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;

/**
 * Copies relation from parent class to child class given by constructor
 * params setup
 */
class CopyDefaultRelationsProcessor implements ProcessorInterface
{
    /** @var string */
    private $relationSource;

    /** @var string */
    private $relationDestination;

    /** @var string */
    private $className;

    /** @var ManagerRegistry */
    private $doctrine;

    /** @var PropertyAccessorInterface */
    private $propertyAccessor;

    /** @var EntityAliasResolver */
    private $aliasResolver;

    /** @var string */
    private $relationName;

    /**
     * @param ManagerRegistry $doctrine
     * @param EntityAliasResolver $aliasResolver
     * @param string $relationSource
     * @param string $relationDestination
     * @param string $relationName
     * @param string $className
     */
    public function __construct(
        ManagerRegistry $doctrine,
        EntityAliasResolver $aliasResolver,
        string $relationSource,
        string $relationDestination,
        string $relationName,
        string $className
    ) {
        $this->doctrine = $doctrine;
        $this->aliasResolver = $aliasResolver;
        $this->relationSource = $relationSource;
        $this->relationDestination = $relationDestination;
        $this->className = $className;
        $this->relationName = $relationName;
        $this->propertyAccessor = PropertyAccess::createPropertyAccessor();
    }

    /**
     * {@inheritdoc}
     */
    public function process(ContextInterface $context)
    {
        $data = $context->getRequestData();
        if (($entity = $this->getParentEntity($data)) && ($relation = $this->getRelation($entity))) {
            $relationAlias = $this->aliasResolver->getPluralAlias(ClassUtils::getRealClass(get_class($relation)));
            $relationId = $relation->getId();
            if (null === $this->getPropertyValue($data, $this->relationDestination)) {
                $this->propertyAccessor->setValue($data, $this->relationDestination, [
                    JsonApiDocumentBuilder::TYPE => $relationAlias,
                    JsonApiDocumentBuilder::ID => (string)$relationId
                ]);

                $context->setRequestData($data);
            }
        }
    }

    /**
     * @param array $data
     * @return object|null
     */
    private function getParentEntity(array $data)
    {
        return ($id = $this->getParentEntityId($data))
            ? $this->doctrine->getManagerForClass($this->className)->getRepository($this->className)->find($id)
            : null;
    }

    /**
     * @param array $data
     * @return null|int
     */
    private function getParentEntityId(array $data): ?int
    {
        return $this->getPropertyValue($data, $this->relationSource);
    }

    /**
     * @param array $data
     * @param string $propertyPath
     * @param mixed $default
     * @return mixed|null
     */
    private function getPropertyValue(array $data, string $propertyPath, $default = null)
    {
        try {
            return $this->propertyAccessor->getValue($data, $propertyPath);
        } catch (UnexpectedTypeException $exc) {
            return $default;
        }
    }

    /**
     * Returns relation entity
     *
     * @param mixed $entity
     * @return mixed
     */
    protected function getRelation($entity)
    {
        $getter = sprintf('%s%s', 'get', ucfirst($this->relationName));
        return method_exists($entity, $getter)
            ? $entity->{$getter}()
            : null;
    }
}
