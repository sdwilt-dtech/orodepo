<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Form\Type\Subscriber\ModifiersRegistry;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;

class NormalizeGoPlanFormatProcessor implements ProcessorInterface
{
    /** @var ModifiersRegistry */
    private $modifiersRegistry;

    /** @var PropertyAccessorInterface */
    protected $propertyAccessor;

    /**
     * @param ModifiersRegistry $modifiersRegistry
     * @param null|PropertyAccessorInterface $propertyAccessor
     */
    public function __construct(
        ModifiersRegistry $modifiersRegistry,
        PropertyAccessorInterface $propertyAccessor = null
    ) {
        $this->modifiersRegistry = $modifiersRegistry;
        $this->propertyAccessor = $propertyAccessor ?: PropertyAccess::createPropertyAccessor();
    }

    /**
     * {@inheritdoc}
     */
    public function process(ContextInterface $context)
    {
        $result = $context->getResult();
        if (count($result)) {
            $this->doProcess($context);
        }
    }

    /**
     * @param ContextInterface $context
     */
    private function doProcess(ContextInterface $context): void
    {
        $result = $context->getResult();
        $isList = isset($result[0]);
        $collection = $this->format($isList ? $result : [$result]);

        $context->setResult($isList ? $collection : $collection[0]);
    }

    /**
     * @param array $collection
     * @return array
     */
    private function format(array $collection): array
    {
        $results = [];
        foreach ($collection as $record) {
            $results[] = $this->formatRecord($record);
        }

        return $results;
    }

    /**
     * @param array $record
     * @return array
     */
    private function formatRecord(array $record): array
    {
        $recordType = $this
            ->propertyAccessor
            ->getValue($record, '[data][relationships][opportunity_record_type][data][id]');
        if (null === $recordType) {
            return $record;
        }

        $availableFields = $this->getAvailableFields($recordType);
        $attributes = $this->propertyAccessor->getValue($record, '[data][attributes]');
        $relationships = $this->propertyAccessor->getValue($record, '[data][relationships]');
        $resultAttributes = $resultRelationships = [];
        foreach ($attributes as $field => $value) {
            if (in_array($field, $availableFields)) {
                $resultAttributes[$field] = $value;
            }
        }
        foreach ($relationships as $field => $value) {
            if (in_array($field, $availableFields)) {
                $resultRelationships[$field] = $value;
            }
        }

        $resultAttributes['opportunity_record_type'] = $recordType;
        $this->propertyAccessor->setValue($record, '[data][attributes]', $resultAttributes);
        $this->propertyAccessor->setValue($record, '[data][relationships]', $resultRelationships);

        return $record;
    }

    private function getAvailableFields(string $recordType): array
    {
        return array_merge($this->modifiersRegistry->getModifier($recordType)->getAvailableFields(), [
            'id',
            'stage'
        ]);
    }
}
