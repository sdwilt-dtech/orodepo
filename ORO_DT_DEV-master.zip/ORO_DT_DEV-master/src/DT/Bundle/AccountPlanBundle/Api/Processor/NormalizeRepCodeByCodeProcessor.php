<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\ApiBundle\Processor\ContextInterface as ApiContext;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Component\PropertyAccess\Exception\UnexpectedTypeException;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;

/**
 * Normalizes RepCode relation allowing call for the Rep Code by code value
 */
class NormalizeRepCodeByCodeProcessor implements ProcessorInterface
{
    public const CODE = 'code';

    /** @var PropertyAccessorInterface */
    protected $propertyAccessor;

    /** @var ManagerRegistry */
    protected $doctrine;

    /**
     * @param ManagerRegistry $doctrine
     * @param PropertyAccessorInterface|null $propertyAccessor
     */
    public function __construct(ManagerRegistry $doctrine, PropertyAccessorInterface $propertyAccessor = null)
    {
        $this->doctrine = $doctrine;
        $this->propertyAccessor = $propertyAccessor ?: PropertyAccess::createPropertyAccessor();
    }

    /**
     * {@inheritdoc}
     * @param ApiContext $context
     */
    public function process(ContextInterface $context)
    {
        $data = $context->getRequestData();
        $propertyPath = sprintf('[data][relationships][repCode][data][%s]', self::CODE);
        try {
            $code = $this->propertyAccessor->getValue($data, $propertyPath);
        } catch (UnexpectedTypeException $exc) {
            $code = null;
        }
        if ($code && ($repCode = $this->getRepCode($code))) {
            $this
                ->propertyAccessor
                ->setValue($data, '[data][relationships][repCode][data][id]', (string)$repCode->getId());
            $context->setRequestData($data);
        }
    }

    /**
     * @param string $code
     * @return Customer|null
     */
    private function getRepCode(string $code): ?RepCode
    {
        $repo = $this->doctrine->getManagerForClass(RepCode::class)->getRepository(RepCode::class);
        /** @var RepCode $repCode */
        $repCode = $repo->findOneBy([
            'code' => $code
        ]);

        return $repCode;
    }
}
