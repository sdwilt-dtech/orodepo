<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Form\Type\Subscriber\ModifiersRegistry;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\ApiBundle\Processor\FormContext;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;
use Oro\Component\ChainProcessor\ContextInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Modifies request data adding/removing form elements depending on request type.
 * Uses ModifiersRegistry to execute modifiers against the input form
 */
class ModifyFormByRecordTypeProcessor extends AbstractRecordTypeAwareProcessor
{
    /** @var ModifiersRegistry */
    private $modifiersRegistry;

    /**
     * @param TranslatorInterface $translator
     * @param EnumValueProvider $enumValueProvider
     * @param ModifiersRegistry $modifiersRegistry
     */
    public function __construct(
        TranslatorInterface $translator,
        EnumValueProvider $enumValueProvider,
        ModifiersRegistry $modifiersRegistry
    ) {
        $this->modifiersRegistry = $modifiersRegistry;
        parent::__construct($translator, $enumValueProvider);
    }

    /**
     * {@inheritdoc}
     * @param FormContext $context
     */
    public function process(ContextInterface $context)
    {
        if (null !== $context->getForm()) {
            $this->doProcess($context);
        }
    }

    /**
     * @param ContextInterface|FormContext $context
     */
    private function doProcess(ContextInterface $context): void
    {
        $form = $context->getForm();
        $data = $context->getRequestData();

        if ($form->isSubmitted()) {
            $this->doProcessSubittedForm($form, $data);
        } else {
            $this->doProcessRequestForm($form, $context, $data);
        }
    }

    /**
     * @param FormInterface $form
     * @param array $data
     */
    private function doProcessSubittedForm(FormInterface $form, array $data): void
    {
        $recordTypeName = $this->propertyAccessor->getValue($data, $this->getRecordTypePropertyPath());
        $recordType = $this
            ->enumProvider
            ->getEnumValueByCode(GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE, $recordTypeName);
        $form->get(self::RECORD_TYPE_KEY)->setData($recordType);
    }

    /**
     * @param FormInterface $form
     * @param FormContext $context
     * @param array|null $data
     */
    private function doProcessRequestForm(FormInterface $form, FormContext $context, array $data): void
    {
        if ($this->validateData($data, $context, null)) {
            $recordType = $this->propertyAccessor->getValue($data, $this->getRecordTypePropertyPath());
            $this->doProcessForm($form, $recordType);
        }
    }

    /**
     * @param FormInterface $form
     * @param string $recordType
     */
    private function doProcessForm(FormInterface $form, string $recordType): void
    {
        $this
            ->modifiersRegistry
            ->getModifier($recordType)->modify($form);
    }
}
