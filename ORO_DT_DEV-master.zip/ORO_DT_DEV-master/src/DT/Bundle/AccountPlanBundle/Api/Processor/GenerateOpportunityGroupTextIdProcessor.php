<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use Symfony\Component\HttpFoundation\Request;

/**
 * Generates missing TextID for opportunity group
 */
class GenerateOpportunityGroupTextIdProcessor extends AbstractGenerateTextIdProcessor
{
    /**
     * {@inheritdoc}
     */
    protected function getClassName(): string
    {
        return GoOpportunityGroup::class;
    }

    /**
     * {@inheritdoc}
     */
    protected function prepareRequest(array $data): ?Request
    {
        $textIdParts = [];
        if ($region = $this->getPropertyValue($data, '[data][relationships][region][data][id]')) {
            $textIdParts['region'] = $region;
        }
        if ($customer = $this->getPropertyValue($data, '[data][relationships][customer][data][id]')) {
            $textIdParts['customer'] = $customer;
        }
        if ($repCode = $this->getPropertyValue($data, '[data][relationships][repCode][data][id]')) {
            $textIdParts['repCode'] = $repCode;
        }

        if ($fiscalYear = $this->getPropertyValue($data, '[data][attributes][fiscalYear]')) {
            $textIdParts['fiscalYear'] = $fiscalYear;
        }


        if (count($textIdParts) !== 4) {
            return null;
        }

        return new Request([], $textIdParts);
    }
}
