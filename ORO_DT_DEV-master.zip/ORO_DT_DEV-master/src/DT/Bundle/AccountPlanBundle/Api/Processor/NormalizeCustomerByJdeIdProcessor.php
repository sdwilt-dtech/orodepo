<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor;

use Doctrine\Persistence\ManagerRegistry;
use Oro\Bundle\ApiBundle\Processor\ContextInterface as ApiContext;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\CustomerBundle\Entity\Repository\CustomerRepository;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Component\PropertyAccess\Exception\UnexpectedTypeException;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;

/**
 * Normalizes customer relation allowing call for the customer by JDE ID
 */
class NormalizeCustomerByJdeIdProcessor implements ProcessorInterface
{
    public const JDE_ID = 'jdeId';

    /** @var PropertyAccessorInterface */
    protected $propertyAccessor;

    /** @var ManagerRegistry */
    protected $doctrine;

    /**
     * @param ManagerRegistry $doctrine
     * @param PropertyAccessorInterface|null $propertyAccessor
     */
    public function __construct(ManagerRegistry $doctrine, PropertyAccessorInterface $propertyAccessor = null)
    {
        $this->doctrine = $doctrine;
        $this->propertyAccessor = $propertyAccessor ?: PropertyAccess::createPropertyAccessor();
    }

    /**
     * {@inheritdoc}
     * @param ApiContext $context
     */
    public function process(ContextInterface $context)
    {
        $data = $context->getRequestData();
        $propertyPath = sprintf('[data][relationships][customer][data][%s]', self::JDE_ID);
        try {
            $customerId = $this->propertyAccessor->getValue($data, $propertyPath);
        } catch (UnexpectedTypeException $exc) {
            $customerId = null;
        }
        if ($customerId && ($customer = $this->getCustomer($customerId))) {
            $this
                ->propertyAccessor
                ->setValue($data, '[data][relationships][customer][data][id]', (string)$customer->getId());
            $context->setRequestData($data);
        }
    }

    /**
     * @param string $customerId
     * @return Customer|null
     */
    private function getCustomer(string $customerId): ?Customer
    {
        /** @var CustomerRepository $repo */
        $repo = $this->doctrine->getManagerForClass(Customer::class)->getRepository(Customer::class);
        /** @var Customer $customer */
        $customer = $repo->findOneBy([
            'dt_jde_id' => $customerId
        ]);

        return $customer;
    }
}
