<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Api\Processor\Exception\DataErrorException;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\ApiBundle\Model\Error;
use Oro\Bundle\ApiBundle\Processor\ContextInterface;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Abstraction for Opportunity processors that manipulate
 * Opportunity Record Type dependent data
 */
abstract class AbstractRecordTypeAwareProcessor implements ProcessorInterface
{
    public const RECORD_TYPE_KEY = 'opportunity_record_type';

    /** @var TranslatorInterface */
    protected $translator;

    /** @var EnumValueProvider */
    protected $enumProvider;

    /** @var PropertyAccessorInterface */
    protected $propertyAccessor;

    /**
     * @param TranslatorInterface $translator
     * @param EnumValueProvider $enumValueProvider
     * @param PropertyAccessorInterface $propertyAccessor
     */
    public function __construct(
        TranslatorInterface $translator,
        EnumValueProvider $enumValueProvider,
        PropertyAccessorInterface $propertyAccessor = null
    ) {
        $this->translator = $translator;
        $this->enumProvider = $enumValueProvider;
        $this->propertyAccessor = $propertyAccessor ?: PropertyAccess::createPropertyAccessor();
    }

    /**
     * @param array $data
     * @param ContextInterface $context
     * @param string|null $propertyPath
     * @return bool
     */
    protected function validateData(
        array $data,
        ContextInterface $context,
        ?string $propertyPath = '[data][attributes]'
    ): bool {
        $attributes = $propertyPath
            ? $this->propertyAccessor->getValue($data, $propertyPath) ?: []
            : $data;
        try {
            $this->doValidateData($attributes);
        } catch (DataErrorException $exc) {
            $context->addError(
                Error::createValidationError(
                    $exc->getMessage(),
                    $exc->getDescription()
                )
            );

            return false;
        }

        return true;
    }

    /**
     * @param array $data
     * @throw DataErrorException
     */
    private function doValidateData(array $data): void
    {
        if (!array_key_exists(self::RECORD_TYPE_KEY, $data)) {
            throw new DataErrorException(
                $this->translator->trans('dt.api.goopportunity.opportunity_record_type.attribute_required.message'),
                $this->translator->trans('dt.api.goopportunity.opportunity_record_type.attribute_required.description')
            );
        }

        $value = is_array($data[self::RECORD_TYPE_KEY])
            ? $this->propertyAccessor->getValue($data, $this->getRecordTypePropertyPath())
            : $data[self::RECORD_TYPE_KEY];

        try {
            $enum = $this
                ->enumProvider
                ->getEnumValueByCode(
                    GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE,
                    $value
                );
        } catch (\Exception $exc) {
            $enum = null;
        } finally {
            if (null === $enum) {
                throw new DataErrorException(
                    $this->translator->trans('dt.api.goopportunity.opportunity_record_type.attribute_invalid.message'),
                    $this->translator->trans(
                        'dt.api.goopportunity.opportunity_record_type.attribute_invalid.description'
                    ),
                    $exc ?? null
                );
            }
        }
    }

    /**
     * @return string
     */
    protected function getRecordTypePropertyPath(): string
    {
        return sprintf('[%s][id]', self::RECORD_TYPE_KEY);
    }
}
