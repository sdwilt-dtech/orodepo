<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Api\Processor\Exception\DataErrorException;
use Oro\Bundle\ApiBundle\Model\Error;
use Oro\Bundle\ApiBundle\Processor\ContextInterface as ApiContext;
use Oro\Bundle\ApiBundle\Request\JsonApi\JsonApiDocumentBuilder;
use Oro\Component\ChainProcessor\ContextInterface;

/**
 * Checks for Opportunity record type and modifies `relationships`
 * property with proper datum type
 */
class NormalizeRecordTypeProcessor extends AbstractRecordTypeAwareProcessor
{
    /**
     * {@inheritdoc}
     * @param ApiContext $context
     */
    public function process(ContextInterface $context)
    {
        if ($this->validateData($context->getRequestData(), $context)) {
            $this->doProcess($context);
        }
    }

    /**
     * @param ApiContext $context
     * @param string|null $recordType
     */
    private function doProcess(ApiContext $context): void
    {
        $data = $context->getRequestData();
        $attributes = $this->propertyAccessor->getValue($data, '[data][attributes]');
        $relationships = $this->propertyAccessor->getValue($data, '[data][relationships]');
        $recordType = $attributes[self::RECORD_TYPE_KEY];
        if (array_key_exists(self::RECORD_TYPE_KEY, $relationships)) {
            try {
                $this->validateRelationship($relationships[self::RECORD_TYPE_KEY], $recordType);
            } catch (DataErrorException $exc) {
                $context->addError(
                    Error::createValidationError(
                        $exc->getMessage(),
                        $exc->getDescription()
                    )
                );
                return;
            }
        }

        $this
            ->propertyAccessor
            ->setValue($data, sprintf('[data][relationships][%s]', self::RECORD_TYPE_KEY), [
                JsonApiDocumentBuilder::DATA => [
                    JsonApiDocumentBuilder::TYPE => 'dtgo_opportunity_record_types',
                    JsonApiDocumentBuilder::ID => $recordType
                ]
            ]);

        $context->setRequestData($data);
    }

    /**
     * @param mixed|array $relationshipData
     * @return void
     */
    private function validateRelationship($relationshipData, string $recordType): void
    {
        if (!$this->isValid($relationshipData, $recordType)) {
            $message = $this
                ->translator->trans('dt.api.goopportunity.opportunity_record_type.relationship_invalid.message');
            $dsc = $this
                ->translator->trans('dt.api.goopportunity.opportunity_record_type.relationship_invalid.description');
            throw new DataErrorException($message, $dsc);
        }
    }

    /**
     * @param mixed|array $relationshipData
     * @param string $recordType
     * @return bool
     */
    private function isValid($relationshipData, string $recordType): bool
    {
        return is_array($relationshipData)
            && isset($relationshipData[JsonApiDocumentBuilder::DATA])
            && isset($relationshipData[JsonApiDocumentBuilder::DATA][JsonApiDocumentBuilder::TYPE])
            && isset($relationshipData[JsonApiDocumentBuilder::DATA][JsonApiDocumentBuilder::ID])
            && $relationshipData[JsonApiDocumentBuilder::DATA][JsonApiDocumentBuilder::ID] === $recordType;
    }
}
