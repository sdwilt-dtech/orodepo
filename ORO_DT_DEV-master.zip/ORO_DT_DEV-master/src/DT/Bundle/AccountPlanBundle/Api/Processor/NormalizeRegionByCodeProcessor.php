<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\Entity\Repository\RegionRepository;
use Oro\Bundle\ApiBundle\Processor\ContextInterface as ApiContext;
use Oro\Bundle\ApiBundle\Request\JsonApi\JsonApiDocumentBuilder;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Component\PropertyAccess\Exception\UnexpectedTypeException;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;

/**
 * Normalizes region relation allowing call for the by JDE code.
 * Falls back also to customer region - if applicable
 */
class NormalizeRegionByCodeProcessor implements ProcessorInterface
{
    public const CODE = 'code';

    /** @var PropertyAccessorInterface */
    protected $propertyAccessor;

    /** @var ManagerRegistry */
    protected $doctrine;

    /**
     * @param ManagerRegistry $doctrine
     * @param PropertyAccessorInterface|null $propertyAccessor
     */
    public function __construct(ManagerRegistry $doctrine, PropertyAccessorInterface $propertyAccessor = null)
    {
        $this->doctrine = $doctrine;
        $this->propertyAccessor = $propertyAccessor ?: PropertyAccess::createPropertyAccessor();
    }

    /**
     * @param array $data
     * @param string $propertyPath
     * @param mixed $default
     * @return mixed|null
     */
    protected function getPropertyValue(array $data, string $propertyPath, $default = null)
    {
        try {
            return $this->propertyAccessor->getValue($data, $propertyPath);
        } catch (UnexpectedTypeException $exc) {
            return $default;
        }
    }

    /**
     * {@inheritdoc}
     * @param ApiContext $context
     */
    public function process(ContextInterface $context)
    {
        $data = $context->getRequestData();
        $propertyPath = sprintf('[data][relationships][region][data][%s]', self::CODE);
        $code = $this->getPropertyValue($data, $propertyPath);

        if ($code && ($region = $this->getRegion($code))) {
            $this
                ->propertyAccessor
                ->setValue($data, '[data][relationships][region][data][id]', (string)$region->getId());
            $context->setRequestData($data);
        } else {
            $this->assignCustomerRegion($context);
        }
    }

    /**
     * @param ContextInterface $context
     */
    private function assignCustomerRegion(ContextInterface $context): void
    {
        $data = $context->getRequestData();
        if (!$this->getPropertyValue($data, '[data][relationships][region][data]')) {
            $propertyPath = '[data][relationships][customer][data][id]';
            try {
                $customerId = $this->propertyAccessor->getValue($data, $propertyPath);
            } catch (UnexpectedTypeException $exc) {
                $customerId = null;
            }
            /** @var Customer $customer */
            $customer = $customerId
                ? $this
                    ->doctrine
                    ->getManagerForClass(Customer::class)
                    ->getRepository(Customer::class)
                    ->find($customerId)
                : null;
            if ($customer && $customer->getDtRegion()) {
                $this
                    ->propertyAccessor
                    ->setValue($data, '[data][relationships][region][data]', [
                        JsonApiDocumentBuilder::ID => (string)$customer->getDtRegion()->getId(),
                        JsonApiDocumentBuilder::TYPE => 'dt_regions'
                    ]);
                $context->setRequestData($data);
            }
        }
    }

    /**
     * @param string $code
     * @return Region|null
     */
    private function getRegion(string $code): ?Region
    {
        /** @var RegionRepository $repo */
        $repo = $this->doctrine->getManagerForClass(Region::class)->getRepository(Region::class);
        /** @var Region $region */
        $region = $repo->findOneBy([
            'jdeId' => $code
        ]);

        return $region;
    }
}
