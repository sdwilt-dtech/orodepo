<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Api\Processor\Exception\DataErrorException;
use DT\Bundle\AccountPlanBundle\Provider\StageValuesProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;
use Oro\Bundle\ApiBundle\Model\Error;
use Oro\Bundle\ApiBundle\Processor\ContextInterface as ApiContext;
use Oro\Bundle\ApiBundle\Request\JsonApi\JsonApiDocumentBuilder;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;
use Oro\Component\ChainProcessor\ContextInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Normalizes stage name to allow name/ID and
 * force valid format
 */
class NormalizeStageByNameProcessor extends AbstractRecordTypeAwareProcessor
{
    public const STAGES_PLURAL_ALIAS = 'dtgo_opportunity_stages';

    /** @var StageValuesProvider */
    private $stageProvider;

    /**
     * @param TranslatorInterface $translator
     * @param EnumValueProvider $enumValueProvider
     * @param StageValuesProvider $stageProvider
     */
    public function __construct(
        TranslatorInterface $translator,
        EnumValueProvider $enumValueProvider,
        StageValuesProvider $stageProvider
    ) {
        $this->stageProvider = $stageProvider;
        parent::__construct($translator, $enumValueProvider);
    }

    /**
     * {@inheritdoc}
     * @param ApiContext $context
     */
    public function process(ContextInterface $context)
    {
        if ($this->validateData($data = $context->getRequestData(), $context)) {
            $this->doProcess($context);
        }
    }

    /**
     * @param ApiContext $context
     */
    private function doProcess(ApiContext $context): void
    {
        $data = $context->getRequestData();
        $stageData = $this->propertyAccessor->getValue($data, '[data][relationships][stage][data]');
        $attributes = $this->propertyAccessor->getValue($data, '[data][attributes]');
        $recordType = $attributes[self::RECORD_TYPE_KEY];
        if ($stage = $this->validateGetStageData($stageData, $context, $recordType)) {
            $this->propertyAccessor->setValue($data, '[data][relationships][stage][data]', [
                JsonApiDocumentBuilder::TYPE => self::STAGES_PLURAL_ALIAS,
                JsonApiDocumentBuilder::ID => (string)$stage->getId()
            ]);
        }

        $context->setRequestData($data);
    }

    /**
     * @param array|null $stageData
     * @param ApiContext $context
     * @param string $recordType
     * @return GoOpportunityStage|null
     */
    private function validateGetStageData(
        ?array $stageData,
        ApiContext $context,
        string $recordType
    ): ?GoOpportunityStage {
        try {
            return $this->doValidateStageData($stageData ?? [], $recordType);
        } catch (DataErrorException $exc) {
            $context->addError(
                Error::createValidationError(
                    $exc->getMessage(),
                    $exc->getDescription()
                )
            );

            return null;
        }
    }

    /**
     * @param array $stageData
     * @param string $recordType
     * @return GoOpportunityStage
     */
    private function doValidateStageData(array $stageData, string $recordType): GoOpportunityStage
    {
        $id = $this->propertyAccessor->getValue($stageData, '[id]');
        $availableStages = $this->stageProvider->getStageValues($recordType);
        $currentStage = $id
            ? ($this->stageProvider->getStage($id) ?: $this->stageProvider->getStageById((int)$id))
            : null;

        if (null === $currentStage || !$this->stageExists($currentStage, $availableStages)) {
            throw new DataErrorException(
                $this->translator->trans('dt.api.goopportunity.opportunity_record_type.stage_invalid.message'),
                $this->translator->trans('dt.api.goopportunity.opportunity_record_type.stage_invalid.description')
            );
        }

        return $currentStage;
    }

    /**
     * @param GoOpportunityStage $stage
     * @param array $availableStages
     * @return bool
     */
    private function stageExists(GoOpportunityStage $stage, array $availableStages): bool
    {
        return in_array($stage->getId(), array_map(function (GoOpportunityStage $availableStage) {
            return $availableStage->getId();
        }, $availableStages));
    }
}
