<?php

namespace DT\Bundle\AccountPlanBundle\Api\Processor\GoOpportunity;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use Oro\Bundle\ApiBundle\Processor\ContextInterface as ApiContext;
use Oro\Component\ChainProcessor\ContextInterface;
use Oro\Component\ChainProcessor\ProcessorInterface;
use Symfony\Component\PropertyAccess\Exception\UnexpectedTypeException;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessorInterface;

/**
 * Assign Go Plan product category by code if key present in request
 */
class NormalizeProductCategoryProcessor implements ProcessorInterface
{
    /** @var ManagerRegistry */
    private $doctrine;

    /** @var PropertyAccessorInterface */
    protected $propertyAccessor;

    /**
     * @param ManagerRegistry $doctrine
     * @param PropertyAccessorInterface|null $propertyAccessor
     */
    public function __construct(
        ManagerRegistry $doctrine,
        PropertyAccessorInterface $propertyAccessor = null
    ) {
        $this->doctrine = $doctrine;
        $this->propertyAccessor = $propertyAccessor ?: PropertyAccess::createPropertyAccessor();
    }

    /**
     * {@inheritdoc}
     * @param ApiContext $context
     */
    public function process(ContextInterface $context)
    {
        $data = $context->getRequestData();
        try {
            $code = $this->propertyAccessor->getValue($data, '[data][relationships][productCategoryCode][data][code]');
        } catch (UnexpectedTypeException $exc) {
            $code = null;
        }
        if (null !== $code) {
            $categoryCode = $this
                ->doctrine
                ->getManagerForClass(ProductCategoryCode::class)
                ->getRepository(ProductCategoryCode::class)
                ->findOneBy([
                    'code' => $code
                ]);

            if (null !== $categoryCode) {
                $this
                    ->propertyAccessor
                    ->setValue(
                        $data,
                        '[data][relationships][productCategoryCode][data][id]',
                        (string)$categoryCode->getId()
                    );

                $context->setRequestData($data);
            }
        }
    }
}
