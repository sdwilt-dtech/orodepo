<?php

namespace DT\Bundle\AccountPlanBundle\Twig;

use Doctrine\Common\Collections\Collection;
use DT\Bundle\EntityBundle\Entity\Csr;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Symfony\Contracts\Translation\TranslatorInterface;
use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;

/**
 * Provides Twig templates available filters for view of
 * Go entities custom fields
 */
class DtFieldsExtension extends AbstractExtension
{
    /** @var TranslatorInterface */
    private $translator;

    /**
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    /**
     * {@inheritdoc}
     */
    public function getFilters()
    {
        return [
            new TwigFilter('dt_format_quarter', [ $this, 'formatAskQuarter' ]),
            new TwigFilter('dt_format_revenue_date', [ $this, 'formatRevenueDate' ]),
            new TwigFilter('dt_format_multi_enum', [ $this, 'formatMultiEnum' ]),
            new TwigFilter('dt_format_customer_representative', [ $this, 'formatCsr' ]),
            new TwigFilter('dt_format_sales_assistant', [ $this, 'formatAssistant' ]),
        ];
    }

    /**
     * @param Customer|null $customer
     * @return string|null
     */
    public function formatCsr(?Customer $customer): ?string
    {
        /** @var Csr $csr */
        if ((null === $customer) || !($csr = $customer->getDtCsr())) {
            return null;
        }

        $user = $csr->getUser();
        $name = $user ? $user->getFullName() : $csr->getName();

        return sprintf('%s %s', $name, $csr->getPhone());
    }

    /**
     * Formats integer value to month shortcut
     *
     * @return string
     */
    public function formatRevenueDate(?int $revenueDate): string
    {
        if (!$revenueDate) {
            return $this->translator->trans('N/A');
        }

        $months = $this->getMonths();

        return array_key_exists($revenueDate, $months)
            ? $months[$revenueDate]
            : $this->translator->trans('N/A');
    }

    /**
     * @return array
     */
    private function getMonths(): array
    {
        $months = [];
        for ($i = 1; $i <= 12; $i++) {
            $monthFill = sprintf('%s%d', (strlen($i) === 1 ? '0' : ''), $i);
            $month = date('M', strtotime(sprintf('01.%s.2020', $monthFill)));
            $months[$i] = $month;
        }

        return $months;
    }

    /**
     * Formats integer value to quarter number
     *
     * @return string
     */
    public function formatAskQuarter(?int $askQuarter): string
    {
        if (!$askQuarter) {
            return $this->translator->trans('N/A');
        }

        $label = sprintf('dt.entity.goopportunity.ask_quarter.q%s', $askQuarter);

        return $this->translator->trans($label);
    }

    /**
     * @param null|Collection|array|string|AbstractEnumValue $collection
     * @return string
     */
    public function formatMultiEnum($collection): string
    {
        if (!$collection) {
            return $this->translator->trans('N/A');
        }
        switch (true) {
            case $collection instanceof AbstractEnumValue:
                return $collection->getName();
            case $collection instanceof Collection:
                return $this->formatMultiEnum($collection->map(function (AbstractEnumValue $enum) {
                    return $enum->getName();
                })->toArray());
            case is_array($collection):
                return implode(', ', $collection);
            default:
                return (string)$collection;
        }
    }
}
