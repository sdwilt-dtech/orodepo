<?php

namespace DT\Bundle\AccountPlanBundle\Twig;

use Doctrine\Common\Collections\Collection;
use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Symfony\Contracts\Translation\TranslatorInterface;
use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;

class DtCategoryExtension extends AbstractExtension
{
    /** @var TranslatorInterface */
    private $translator;

    /**
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    /**
     * {@inheritdoc}
     */
    public function getFilters()
    {
        return [
            new TwigFilter('dt_group_categories_by_name', [ $this, 'groupCategoriesByName' ])
        ];
    }
    /**
     * @param null|Collection|array|string|AbstractEnumValue $categories
     * @return array
     */
    public function groupCategoriesByName($categories): array
    {
        $groupedCategories = [];
        if (!$categories) {
            return $groupedCategories;
        }

        /** @var ProductCategoryCode $category */
        foreach ($categories as $category) {
            if (!array_key_exists($this->getGlobalCategoryName($category), $groupedCategories)) {
                $groupedCategories[$this->getGlobalCategoryName($category)] = [
                    'identifiers' => [],
                    'name' => sprintf(
                        '%s',
                        $this->getGlobalCategoryName($category)
                    )
                ];
            }

            $groupedCategories[$this->getGlobalCategoryName($category)]['identifiers'][] = $category->getId();
        }
        return $groupedCategories;
    }

    /**
     * @param ProductCategoryCode $category
     * @return string
     */
    private function getGlobalCategoryName(ProductCategoryCode $category): string
    {
        $globalCategoryName = $category->getGlobalCategoryName();

        return $globalCategoryName ?? $this->translator->trans('dt.api.goopportunity.opportunity_no_category.label');
    }
}
