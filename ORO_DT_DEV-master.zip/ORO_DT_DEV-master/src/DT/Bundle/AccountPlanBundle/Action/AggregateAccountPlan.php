<?php

namespace DT\Bundle\AccountPlanBundle\Action;

use DT\Bundle\AccountPlanBundle\Provider\CustomerPlanDataProviderInterface;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Component\Action\Action\AbstractAction;
use Oro\Component\Action\Exception\InvalidParameterException;
use Oro\Component\ConfigExpression\ContextAccessor;
use Symfony\Component\PropertyAccess\PropertyPathInterface;

/**
 * Aggregates metrics from customer's assets to account plan
 *
 * Usage:
 * @aggregate_account_plan:
 *     customer_account: $.account
 *     account_plan: $.data
 *     fiscal_year: $.year
 */
class AggregateAccountPlan extends AbstractAction
{
    public const OPTION_CUSTOMER_ACCOUNT = 'customer_account';

    public const OPTION_ACCOUNT_PLAN = 'account_plan';

    public const OPTION_FISCAL_YEAR = 'fiscal_year';

    /** @var Customer|PropertyPathInterface */
    private $customerDatum;

    /** @var GoAccountPlan|PropertyPathInterface */
    private $accountPlanDatum;

    /** @var string|PropertyPathInterface */
    private $fiscalYearDatum;

    /** @var CustomerPlanDataProviderInterface */
    private $planDetailProvider;

    /**
     * @param ContextAccessor $contextAccessor
     * @param CustomerPlanDataProviderInterface $planDetailProvider
     */
    public function __construct(ContextAccessor $contextAccessor, CustomerPlanDataProviderInterface $planDetailProvider)
    {
        $this->planDetailProvider = $planDetailProvider;
        parent::__construct($contextAccessor);
    }

    /**
     * {@inheritdoc}
     */
    protected function executeAction($context)
    {
        $customer = $this->getCustomer($context);
        $accountPlan = $this->getAccountPlan($context);
        $year = $this->getFiscalYear($context);

        $this->planDetailProvider
            ->setFiscalYear($year)
            ->setCustomerAccount($customer);

        $accountPlan->setActualYtd($this->planDetailProvider->getActualYtd());
        $accountPlan->setPriorYtd($this->planDetailProvider->getPriorYtd());
        $accountPlan->setAccountDollar($this->planDetailProvider->getAccountGoal());
        $accountPlan->setTotalPriorYearSales($this->planDetailProvider->getPriorYearSales());
        $accountPlan->setCurrentYearValueKeep($this->planDetailProvider->getCurrentYearValueKeep());
        $accountPlan->setCurrentYearValueConvert($this->planDetailProvider->getCurrentYearValueConvert());
        $accountPlan->setCurrentYearValueGrow($this->planDetailProvider->getCurrentYearValueGrow());
        $accountPlan->setCurrentYearValueNpi($this->planDetailProvider->getCurrentYearValueNpi());
        $accountPlan->setCurrentYearValuePipeline($this->planDetailProvider->getCurrentYearValuePipeline());

        $accountPlan->resetOpportunities();

        foreach ($this->planDetailProvider->getOpportunities() as $opportunity) {
            $accountPlan->addOpportunity($opportunity);
        }
    }

    /**
     * @param mixed $context
     * @return string|null
     */
    private function getFiscalYear($context): ?string
    {
        return $this->fiscalYearDatum instanceof PropertyPathInterface
            ? $this->contextAccessor->getValue($context, $this->fiscalYearDatum)
            : $this->fiscalYearDatum;
    }

    /**
     * @param mixed $context
     * @return GoAccountPlan
     */
    private function getAccountPlan($context): GoAccountPlan
    {
        /** @var GoAccountPlan $accountPlan */
        $accountPlan = $this->accountPlanDatum instanceof GoAccountPlan
            ? $this->accountPlanDatum
            : $this->contextAccessor->getValue($context, $this->accountPlanDatum);

        return $accountPlan;
    }

    /**
     * @param mixed $context
     * @return Customer
     */
    private function getCustomer($context): Customer
    {
        /** @var Customer $customer */
        $customer = $this->customerDatum instanceof Customer
            ? $this->customerDatum
            : $this->contextAccessor->getValue($context, $this->customerDatum);

        return $customer;
    }

    /**
     * {@inheritdoc}
     */
    public function initialize(array $options)
    {
        if (empty($options[self::OPTION_CUSTOMER_ACCOUNT])) {
            throw new InvalidParameterException('Customer account is required');
        }
        $this->customerDatum = $options[self::OPTION_CUSTOMER_ACCOUNT];

        if (empty($options[self::OPTION_ACCOUNT_PLAN])) {
            throw new InvalidParameterException('Account plan is required');
        }
        $this->accountPlanDatum = $options[self::OPTION_ACCOUNT_PLAN];

        if (empty($options[self::OPTION_FISCAL_YEAR])) {
            throw new InvalidParameterException('Year is required');
        }
        $this->fiscalYearDatum = $options[self::OPTION_FISCAL_YEAR];
    }
}
