<?php

namespace DT\Bundle\AccountPlanBundle\Manager;

use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider\Criteria;
use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\OpportunityDataProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;

/**
 * Handling update of opportunity fields
 */
class OpportunityUpdate
{
    private const DEFAULT_PROPERTIES = [
        'ytd'
    ];

    /** @var array|string[] */
    private $properties;

    /** @var OpportunityDataProvider */
    private $opportunityDataProvider;

    /**
     * @param OpportunityDataProvider $opportunityDataProvider
     * @param array|string[] $properties
     */
    public function __construct(
        OpportunityDataProvider $opportunityDataProvider,
        array $properties = self::DEFAULT_PROPERTIES
    ) {
        $this->opportunityDataProvider = $opportunityDataProvider;
        $this->properties = $properties;
    }

    /**
     * Updates defined opportunity properties using data provider
     *
     * @param GoOpportunity $opportunity
     */
    public function update(GoOpportunity $opportunity): void
    {
        if ($this->isApplicable($opportunity)) {
            $criteria = new Criteria(
                $opportunity->getRegionRelation(),
                $opportunity->getCustomerRelation(),
                $opportunity->getProductCategoryCode(),
                $opportunity->getFiscalYear()
            );
            foreach ($this->properties as $property) {
                $setter = sprintf('set%s', ucfirst($property));
                $opportunity->{$setter}($this->opportunityDataProvider->getData($criteria, $property));
            }
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @return bool
     */
    private function isApplicable(GoOpportunity $opportunity): bool
    {
        return $opportunity->getRegionRelation()
            && $opportunity->getCustomerRelation()
            && $opportunity->getProductCategoryCode()
            && $opportunity->getFiscalYear();
    }
}
