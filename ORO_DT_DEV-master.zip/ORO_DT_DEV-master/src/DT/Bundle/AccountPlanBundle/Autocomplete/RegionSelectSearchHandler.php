<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use DT\Bundle\EntityBundle\Entity\Region;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;

class RegionSelectSearchHandler extends FullNameSearchHandler
{
    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof Region) {
            return sprintf('[%s] %s', $entity->getJdeId(), $entity->getName());
        }

        return parent::getFullName($entity);
    }
}
