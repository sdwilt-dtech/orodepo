<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;
use Oro\Bundle\FormBundle\Autocomplete\SearchHandler;

class AccountPlanSearchHandler extends FullNameSearchHandler
{
    /** @var SearchHandler */
    private $customerSearchHandler;

    /**
     * @param string $entityName
     * @param array $properties
     * @param SearchHandler $customerSearchHandler
     */
    public function __construct($entityName, array $properties, SearchHandler $customerSearchHandler)
    {
        $this->customerSearchHandler = $customerSearchHandler;
        parent::__construct($entityName, $properties);
    }

    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof GoAccountPlan) {
            return $entity->getName();
        }

        return parent::getFullName($entity);
    }

    /**
     * {@inheritdoc}
     */
    public function convertItem($item)
    {
        $result = parent::convertItem($item);
        if (($item instanceof GoAccountPlan) && $item->getCustomer()) {
            $result['customer'] = $this->customerSearchHandler->convertItem($item->getCustomer());
        }

        return $result;
    }
}
