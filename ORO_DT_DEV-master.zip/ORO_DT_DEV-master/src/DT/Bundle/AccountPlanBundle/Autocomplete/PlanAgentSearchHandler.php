<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use DT\Bundle\EntityBundle\Entity\GoPlanAgent;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;

class PlanAgentSearchHandler extends FullNameSearchHandler
{
    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof GoPlanAgent) {
            return $entity->getName();
        }

        return parent::getFullName($entity);
    }
}
