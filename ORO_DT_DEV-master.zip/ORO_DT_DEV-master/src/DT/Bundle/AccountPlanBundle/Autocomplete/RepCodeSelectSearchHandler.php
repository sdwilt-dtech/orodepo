<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;

class RepCodeSelectSearchHandler extends FullNameSearchHandler
{
    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof RepCode) {
            return $entity->getCode();
        }

        return parent::getFullName($entity);
    }
}
