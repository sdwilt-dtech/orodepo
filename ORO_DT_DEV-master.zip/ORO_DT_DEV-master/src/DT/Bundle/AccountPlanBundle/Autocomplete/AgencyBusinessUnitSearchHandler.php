<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use Doctrine\ORM\QueryBuilder;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;

class AgencyBusinessUnitSearchHandler extends FullNameSearchHandler
{
    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof BusinessUnit) {
            return $entity->getName();
        }

        return parent::getFullName($entity);
    }

    /**
     * @param array $entityIds
     * @return array|int|mixed|string
     */
    protected function getEntitiesByIds(array $entityIds)
    {
        $entityIds = array_filter(
            $entityIds,
            function ($id) {
                return $id !== null && $id !== '';
            }
        );
        if ($entityIds) {
            /** @var QueryBuilder $queryBuilder */
            $queryBuilder = $this->entityRepository->createQueryBuilder('e');
            $queryBuilder->where($queryBuilder->expr()->in('e.' . $this->idFieldName, ':entityIds'));
            $queryBuilder->andWhere($queryBuilder->expr()->eq('e.dt_is_agency', ':isAgency'));
            $queryBuilder->setParameter('entityIds', $entityIds);
            $queryBuilder->setParameter('isAgency', true);

            try {
                $query = $queryBuilder->getQuery();
                return null !== $this->aclHelper
                    ? $this->aclHelper->apply($query)->getResult()
                    : $query->getResult();
            } catch (\Exception $exception) {
                if ($this->logger) {
                    $this->logger->critical($exception->getMessage());
                }
            }
        }

        return [];
    }
}
