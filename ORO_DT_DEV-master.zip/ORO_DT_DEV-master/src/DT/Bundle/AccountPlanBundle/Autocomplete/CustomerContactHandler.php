<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use Doctrine\ORM\QueryBuilder;
use Oro\Bundle\ContactBundle\Entity\Contact;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;
use Symfony\Component\HttpFoundation\RequestStack;

class CustomerContactHandler extends FullNameSearchHandler
{
    /** @var RequestStack */
    private $requestStack;

    /**
     * @param string $entityName
     * @param array $properties
     * @param RequestStack $requestStack
     */
    public function __construct($entityName, array $properties, RequestStack $requestStack)
    {
        $this->requestStack = $requestStack;
        parent::__construct($entityName, $properties);
    }

    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof Contact) {
            return $entity->getFirstName() . ' ' . $entity->getLastName();
        }

        return parent::getFullName($entity);
    }

    /**
     * {@inheritdoc}
     */
    protected function getEntitiesByIds(array $entityIds)
    {
        if (!($customerId = $this->requestStack->getMasterRequest()->get('customerId'))) {
            return [];
        }
        $entityIds = array_filter(
            $entityIds,
            function ($id) {
                return $id !== null && $id !== '';
            }
        );
        if ($entityIds) {
            /** @var QueryBuilder $queryBuilder */
            $queryBuilder = $this->entityRepository->createQueryBuilder('e');
            $queryBuilder->where($queryBuilder->expr()->in('e.' . $this->idFieldName, ':entityIds'));
            $queryBuilder->innerJoin('e.dt_customer', 'account');
            $queryBuilder->andWhere($queryBuilder->expr()->eq('account.id', ':customerId'));
            $queryBuilder->setParameter('entityIds', $entityIds);
            $queryBuilder->setParameter('customerId', $customerId);

            try {
                $query = $queryBuilder->getQuery();
                return null !== $this->aclHelper
                    ? $this->aclHelper->apply($query)->getResult()
                    : $query->getResult();
            } catch (\Exception $exception) {
                if ($this->logger) {
                    $this->logger->critical($exception->getMessage());
                }
            }
        }

        return [];
    }
}
