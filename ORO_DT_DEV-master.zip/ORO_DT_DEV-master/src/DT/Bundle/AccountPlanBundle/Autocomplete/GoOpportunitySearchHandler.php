<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;

class GoOpportunitySearchHandler extends FullNameSearchHandler
{
    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof GoOpportunity) {
            return $entity->getName();
        }

        return parent::getFullName($entity);
    }
}
