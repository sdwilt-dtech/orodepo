<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use Doctrine\ORM\QueryBuilder;
use Oro\Bundle\UserBundle\Autocomplete\UserSearchHandler;

class SalesRepUsersSearchHandler extends UserSearchHandler
{
    /**
     * @param array $entityIds
     * @return array|int|mixed|string
     */
    protected function getEntitiesByIds(array $entityIds)
    {
        $entityIds = array_filter(
            $entityIds,
            function ($id) {
                return $id !== null && $id !== '';
            }
        );
        if ($entityIds) {
            /** @var QueryBuilder $queryBuilder */
            $queryBuilder = $this->entityRepository->createQueryBuilder('e');
            $queryBuilder->where($queryBuilder->expr()->in('e.' . $this->idFieldName, ':entityIds'));
            $queryBuilder->innerJoin('e.businessUnits', 'agency');
            $queryBuilder->andWhere($queryBuilder->expr()->eq('agency.dt_is_agency', ':isAgency'));
            $queryBuilder->setParameter('entityIds', $entityIds);
            $queryBuilder->setParameter('isAgency', true);

            try {
                $query = $queryBuilder->getQuery();
                return null !== $this->aclHelper
                    ? $this->aclHelper->apply($query)->getResult()
                    : $query->getResult();
            } catch (\Exception $exception) {
                if ($this->logger) {
                    $this->logger->critical($exception->getMessage());
                }
            }
        }

        return [];
    }
}
