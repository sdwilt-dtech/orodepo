<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;

class GoOpportunityGroupSearchHandler extends FullNameSearchHandler
{
    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof GoOpportunityGroup) {
            return $entity->getName();
        }

        return parent::getFullName($entity);
    }
}
