<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;

class RegionRepSearchHandler extends FullNameSearchHandler
{
    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof GoRegionRep) {
            return $entity->getName();
        }

        return parent::getFullName($entity);
    }
}
