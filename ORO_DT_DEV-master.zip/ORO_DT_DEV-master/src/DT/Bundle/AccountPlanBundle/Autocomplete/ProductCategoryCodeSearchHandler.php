<?php

namespace DT\Bundle\AccountPlanBundle\Autocomplete;

use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use Oro\Bundle\FormBundle\Autocomplete\FullNameSearchHandler;

class ProductCategoryCodeSearchHandler extends FullNameSearchHandler
{
    /**
     * {@inheritdoc}
     */
    protected function getFullName($entity)
    {
        if ($entity instanceof ProductCategoryCode) {
            return $entity->getFullName();
        }

        return parent::getFullName($entity);
    }
}
