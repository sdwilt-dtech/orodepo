<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;

interface OpportunityRegionRepProviderInterface
{
    /**
     * Provides region rep for certain opportunity
     *
     * @param GoOpportunity $opportunity
     * @return GoRegionRep
     * @throws \RuntimeException If not found
     */
    public function getOpportunityRegionRep(GoOpportunity $opportunity): GoRegionRep;
}
