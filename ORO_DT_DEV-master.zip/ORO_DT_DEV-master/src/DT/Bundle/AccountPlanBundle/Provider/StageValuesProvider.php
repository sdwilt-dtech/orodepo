<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;
use DT\Bundle\EntityBundle\Entity\Repository\GoOpportunityStageRepository;

/**
 * Defines static map for stage values to be available by opportunity
 * record type
 */
class StageValuesProvider implements StageValuesProviderInterface
{
    /** @var ManagerRegistry */
    private $doctrine;

    private $map = [
        OpportunityRecordType::TYPE_UTIL_LC => [
            '1. Contact',
            '2. Qualify',
            '3. Information feed/Pricing Shared',
            '4. Follow-up',
            '5. Closed - Won',
            '6. Closed Lost'
        ],
        OpportunityRecordType::TYPE_UTILITIES => [
            '1. Identified',
            '2. Proposal Made',
            '3. Quoted',
            '4. Verbal Agreement',
            '5. Part Numbers Loaded',
            '6. Closed Won',
            '7. Closed Lost',
            '8. Closed RSM Declined to Pursue',
            '9. Closed Partially Won'
        ],
        OpportunityRecordType::TYPE_SAMPLE_REQUEST => [
            '1. Sample Sent',
            '2. Proposal Made',
            '3. Quoted',
            '4. Verbal Agreement',
            '5. Part Numbers Loaded',
            '6. Closed Won',
            '7. Closed Lost',
            '8. Closed RSM Declined to Pursue',
            '9. Closed Partially Won'
        ],
        OpportunityRecordType::TYPE_RSM_RECOVERY => [
            '1. Identified',
            '2. Qualify Opportunity',
            '3. Quote Sent',
            '4a. Closed Won',
            '4b. Closed Lost'
        ],
        OpportunityRecordType::TYPE_HVAC_GO_PLAN => [
            '0. Pipeline',
            '1. Identified',
            '2. Qualify Opportunity',
            '3. Quote Sent',
            '4a. Closed Won',
            '4b. Closed Lost'
        ],
        OpportunityRecordType::TYPE_HVAC_OLD_GP => [
            '0. Pipeline',
            '1. Identified',
            '2. Qualify Opportunity',
            '3. Quote Sent',
            '4a. Closed Won',
            '4b. Closed Lost'
        ],
        OpportunityRecordType::TYPE_HVAC => [
            '1. Identified',
            '2. Proposal Made',
            '3. Quoted',
            '4. Verbal Agreement',
            '5. Part Numbers Loaded',
            '6. Closed Won',
            '7. Closed Lost',
            '8. Closed RSM Declined to Pursue',
            '9. Closed Partially Won'
        ],
        OpportunityRecordType::TYPE_ELECTRICAL_SALES => [
            '1. Identified',
            '2. Proposal Made',
            '3. Quoted',
            '4. Verbal Agreement',
            '5. Part Numbers Loaded',
            '6. Closed Won',
            '7. Closed Lost',
            '8. Closed RSM Declined to Pursue',
            '9. Closed Partially Won'
        ],
        OpportunityRecordType::TYPE_EU_ACCOUNTS => [
            '1. Identified',
            '2. Proposal Made',
            '3. Quoted',
            '4. Verbal Agreement',
            '5. Part Numbers Loaded',
            '6. Closed Won',
            '7. Closed Lost',
        ]
    ];

    /**
     * Sets manager registry instance
     *
     * @param ManagerRegistry $doctrine
     * @return self
     */
    public function setManagerRegistry(ManagerRegistry $doctrine): self
    {
        $this->doctrine = $doctrine;
        return $this;
    }

    /**
     * @return GoOpportunityStageRepository
     */
    private function getRepository(): GoOpportunityStageRepository
    {
        /** @var GoOpportunityStageRepository $repository */
        $repository = $this->doctrine->getManagerForClass(GoOpportunityStage::class)
            ->getRepository(GoOpportunityStage::class);

        return $repository;
    }

    /**
     * {@inheritdoc}
     */
    public function getStageValues(string $type): array
    {
        $names = $this->getSorted($type);
        return $this->getRepository()->getSortedStages($names);
    }

    /**
     * {@inheritdoc}
     */
    public function getStage(string $name): ?GoOpportunityStage
    {
        /** @var GoOpportunityStage $stage */
        $stage = $this->getRepository()->findOneBy([
            'name' => $name
        ]);

        return $stage;
    }

    /**
     * Returns sorted array of stage names
     *
     * @param string $type
     * @return string[]
     */
    private function getSorted(string $type): array
    {
        if (!array_key_exists($type, $this->map)) {
            throw new \InvalidArgumentException(sprintf('Type %s is not defined!', $type));
        }

        $values = $this->map[$type];
        sort($values, SORT_ASC);

        return $values;
    }

    /**
     * {@inheritdoc}
     */
    public function getStageById(int $stageId): ?GoOpportunityStage
    {
        /** @var GoOpportunityStage $stage */
        $stage = $this->getRepository()->find($stageId);
        return $stage;
    }
}
