<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;

interface OpportunityGroupProviderInterface
{
    /**
     * Provides opportunity group for certain opportunity
     *
     * @param GoOpportunity $opportunity
     * @return GoOpportunityGroup
     * @throws \RuntimeException If not found
     */
    public function getOpportunityGroup(GoOpportunity $opportunity): GoOpportunityGroup;
}
