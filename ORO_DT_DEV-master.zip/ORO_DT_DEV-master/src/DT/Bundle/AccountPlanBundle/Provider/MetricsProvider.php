<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

/**
 * Provide metric calculated values for MetricsAwareInterface
 * entities
 */
class MetricsProvider
{
    /** @var MetricProviderInterface[] */
    private $metricsProviders;

    /**
     * Registers new metric provider
     *
     * @param MetricProviderInterface $metricProvider
     * @return self
     */
    public function addMetricProvider(MetricProviderInterface $metricProvider): self
    {
        $this->metricsProviders[$metricProvider->getName()] = $metricProvider;
        return $this;
    }

    /**
     * @param iterable|MetricProviderInterface[] $metricsProviders
     */
    public function __construct(iterable $metricsProviders)
    {
        foreach ($metricsProviders as $metricsProvider) {
            $this->addMetricProvider($metricsProvider);
        }
    }

    /**
     * Returns metric value
     *
     * @param MetricsAwareInterface $entity
     * @param string $name
     * @return mixed|null
     */
    public function getMetric(MetricsAwareInterface $entity, string $name)
    {
        foreach ($this->metricsProviders as $metricProvider) {
            if ($metricProvider->supports($entity) && $metricProvider->getName() === $name) {
                return $metricProvider->calculateValue($entity);
            }
        }

        return null;
    }
}
