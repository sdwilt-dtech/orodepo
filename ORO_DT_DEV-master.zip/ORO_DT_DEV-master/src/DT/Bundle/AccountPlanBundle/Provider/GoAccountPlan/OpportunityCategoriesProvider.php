<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class OpportunityCategoriesProvider extends AbstractAccountPlanMetricProvider
{
    public const NAME = 'OpportunityCategories';

    /**
     * {@inheritdoc}
     * @param GoAccountPlan $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $categories = [];
        foreach ($entity->getOpportunities() as $opportunity) {
            $category = $opportunity->getProductCategoryCode();
            if ($category && !array_key_exists($category->getCode(), $categories)) {
                $categories[$category->getCode()] = $category;
            }
        }

        return $categories;
    }
}
