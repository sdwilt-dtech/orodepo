<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class PercentageChangeValueProvider extends AbstractAccountPlanMetricProvider
{
    public const NAME = 'PercentageChangeValue';

    /**
     * {@inheritdoc}
     * @param GoAccountPlan $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $actualYtd = $entity->getActualYtd();
        $priorYtd = $entity->getPriorYtd();
        $value = $priorYtd ? (($actualYtd - $priorYtd) / $priorYtd) : null;

        return $value ?: null;
    }
}
