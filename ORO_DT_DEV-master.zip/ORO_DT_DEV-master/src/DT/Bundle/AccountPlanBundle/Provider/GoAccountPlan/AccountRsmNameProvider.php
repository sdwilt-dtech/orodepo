<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class AccountRsmNameProvider extends AbstractAccountPlanMetricProvider
{
    public const NAME = 'AccountRsmName';

    /**
     * {@inheritdoc}
     * @param GoAccountPlan $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $customer = $entity->getAccount();
        /** @var Region $region */
        $region = $customer ? $customer->getDtRegion() : null;
        $regionManager = $region ? $region->getRegionalManager() : null;

        return $regionManager ? $regionManager->getFullName() : null;
    }
}
