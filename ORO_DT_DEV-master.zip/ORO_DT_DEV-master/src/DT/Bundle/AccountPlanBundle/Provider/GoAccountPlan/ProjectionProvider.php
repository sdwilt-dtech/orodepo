<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class ProjectionProvider extends AbstractAccountPlanMetricProvider
{
    public const NAME = 'Projection';

    /**
     * {@inheritdoc}
     * @param GoAccountPlan $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $totalPriorSales = $entity->getTotalPriorYearSales();
        $percentageChange = $this->registry->getMetric($entity, 'PercentageChangeValue');

        return ($totalPriorSales * $percentageChange) + $totalPriorSales;
    }
}
