<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\AccountPlanBundle\Provider\MarketGrowthProviderInterface;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class MarketGrowthDollarsProvider extends AbstractAccountPlanMetricProvider
{
    public const NAME = 'MarketGrowthDollars';

    /** @var MarketGrowthProviderInterface */
    private $growthProvider;

    /**
     * @param MarketGrowthProviderInterface $growthProvider
     */
    public function __construct(MarketGrowthProviderInterface $growthProvider)
    {
        $this->growthProvider = $growthProvider;
    }

    /**
     * {@inheritdoc}
     * @param GoAccountPlan $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $marketGrowth = $this->growthProvider->getMarketGrowthPercentage();
        return ($marketGrowth / 100) * $entity->getTotalPriorYearSales();
    }
}
