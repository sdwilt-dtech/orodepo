<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class PlanValueProvider extends AbstractAccountPlanMetricProvider
{
    public const NAME = 'PlanValue';

    /**
     * {@inheritdoc}
     * @param GoAccountPlan $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $sumArray = [
            $entity->getCurrentYearValueConvert(),
            $entity->getCurrentYearValueGrow(),
            $entity->getCurrentYearValueKeep(),
            $entity->getCurrentYearValueNpi(),
            $entity->getTotalPriorYearSales(),
            $this->registry->getMetric($entity, MarketGrowthDollarsProvider::NAME)
        ];

        return array_sum($sumArray);
    }
}
