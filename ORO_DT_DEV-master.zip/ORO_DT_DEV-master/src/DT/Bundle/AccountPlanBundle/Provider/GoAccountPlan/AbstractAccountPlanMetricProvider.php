<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\AccountPlanBundle\Provider\AbstractMetricProvider;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

abstract class AbstractAccountPlanMetricProvider extends AbstractMetricProvider
{
    /**
     * {@inheritdoc}
     */
    public function supports(MetricsAwareInterface $entity): bool
    {
        return $entity instanceof GoAccountPlan;
    }
}
