<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class PercentageChangeProvider extends AbstractAccountPlanMetricProvider
{
    public const NAME = 'PercentageChange';

    /**
     * {@inheritdoc}
     * @param GoAccountPlan $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $value = $this->registry->getMetric($entity, PercentageChangeValueProvider::NAME);
        return $value
            ? round($value * 100)
            : null;
    }
}
