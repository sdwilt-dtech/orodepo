<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class ProjectionHealthProvider extends AbstractAccountPlanMetricProvider
{
    public const NAME = 'ProjectionHealth';

    private const CONDITION_BAD = 'red';
    private const CONDITION_GOOD = 'green';

    /**
     * {@inheritdoc}
     * @param GoAccountPlan $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $projection = $this->registry->getMetric($entity, ProjectionProvider::NAME);
        $accountDollar = $entity->getAccountDollar();

        return $projection < $accountDollar
            ? self::CONDITION_BAD
            : self::CONDITION_GOOD;
    }
}
