<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoAccountPlan;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class PlanHealthProvider extends AbstractAccountPlanMetricProvider
{
    public const NAME = 'PlanHealth';

    private const CONDITION_BAD = 'red';
    private const CONDITION_GOOD = 'green';

    /**
     * {@inheritdoc}
     * @param GoAccountPlan $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $plan = $this->registry->getMetric($entity, PlanValueProvider::NAME);
        $accountDollar = $entity->getAccountDollar();

        return $plan < $accountDollar
            ? self::CONDITION_BAD
            : self::CONDITION_GOOD;
    }
}
