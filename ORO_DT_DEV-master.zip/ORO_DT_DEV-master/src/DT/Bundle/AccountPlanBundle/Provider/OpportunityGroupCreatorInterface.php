<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;

interface OpportunityGroupCreatorInterface
{
    /**
     * Creates opportunity group for certain opportunity
     *
     * @param GoOpportunity $opportunity
     * @return GoOpportunityGroup
     * @throws \RuntimeException If could not be created
     */
    public function createOpportunityGroup(GoOpportunity $opportunity): GoOpportunityGroup;
}
