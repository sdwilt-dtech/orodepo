<?php

namespace DT\Bundle\AccountPlanBundle\Provider\TextId;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Symfony\Component\HttpFoundation\Request;

class OpportunityTextIdProvider extends AbstractTextIdProvider implements NameAwareTextIdProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function getTextId(Request $request): ?string
    {
        $regionId = $request->request->get('region');
        $customerId = $request->request->get('customer');
        $repCodeId = $request->request->get('repCode');
        $categoryCodeId = $request->request->get('productCategoryCode');
        $fiscalYear = $request->request->get('fiscalYear');

        /** @var Region $region */
        $region = $this->get(Region::class, $regionId);
        /** @var Customer $customer */
        $customer = $this->get(Customer::class, $customerId);
        /** @var RepCode $repCode */
        $repCode = $this->get(RepCode::class, $repCodeId);
        /** @var ProductCategoryCode $categoryCode */
        $categoryCode = $this->get(ProductCategoryCode::class, $categoryCodeId);

        $textIdParts = [];
        if ($region) {
            $textIdParts[] = $region->getJdeId();
        }
        if ($repCode) {
            $textIdParts[] = $repCode->getCode();
        }
        if ($customer) {
            $parentCustomer = $this->customerHierarchy->getCustomerForBillingType($customer);
            if ($parentCustomer) {
                $textIdParts[] = $parentCustomer->getDtJdeId();
            } else {
                $textIdParts[] = $customer->getDtJdeId();
            }
        }
        if ($categoryCode) {
            $textIdParts[] = $categoryCode->getCode();
        }
        if ($fiscalYear) {
            $textIdParts[] = $fiscalYear;
        }

        return count($textIdParts) === 5
            ? implode('', $textIdParts)
            : null;
    }

    /**
     * {@inheritdoc}
     */
    public function getHandledClass(): string
    {
        return GoOpportunity::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getName(Request $request): ?string
    {
        $regionId = $request->request->get('region');
        $repCodeId = $request->request->get('repCode');
        $customerId = $request->request->get('customer');
        $categoryCodeId = $request->request->get('productCategoryCode');
        $fiscalYear = $request->request->get('fiscalYear');

        /** @var Region $region */
        $region = $this->get(Region::class, $regionId);
        /** @var Customer $customer */
        $customer = $this->get(Customer::class, $customerId);
        /** @var RepCode $repCode */
        $repCode = $this->get(RepCode::class, $repCodeId);
        /** @var ProductCategoryCode $categoryCode */
        $categoryCode = $this->get(ProductCategoryCode::class, $categoryCodeId);

        /** @var BusinessUnit $businessUnit */
        $businessUnit = $repCode ? $this->getRepo(BusinessUnit::class)->findOneBy([
            'dt_is_agency' => true,
            'dt_agency_rep_code' => $repCode
        ]) : null;

        $nameParts = [];
        if ($businessUnit) {
            $nameParts[] = $region->getJdeId();
        }
        if ($businessUnit) {
            $nameParts[] = $businessUnit->getName();
        }
        if ($customer) {
            $parentCustomer = $this->customerHierarchy->getCustomerForBillingType($customer);
            if ($parentCustomer) {
                $nameParts[] = $parentCustomer->getName();
            } else {
                $nameParts[] = $customer->getName();
            }
        }
        if ($categoryCode) {
            $nameParts[] = $categoryCode->getName();
        }
        if ($fiscalYear) {
            $nameParts[] = $fiscalYear;
        }

        return count($nameParts) === 5
            ? implode('-', $nameParts)
            : null;
    }
}
