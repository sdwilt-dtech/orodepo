<?php

namespace DT\Bundle\AccountPlanBundle\Provider\TextId;

use Doctrine\Persistence\ManagerRegistry;
use Doctrine\Persistence\ObjectRepository;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;

abstract class AbstractTextIdProvider implements TextIdProviderInterface
{
    /** @var ManagerRegistry */
    protected $doctrine;

    /** @var CustomerHierarchy */
    protected $customerHierarchy;

    /** @var array */
    protected $data = [];

    /**
     * @param ManagerRegistry $doctrine
     * @param CustomerHierarchy $customerHierarchy
     */
    public function __construct(ManagerRegistry $doctrine, CustomerHierarchy $customerHierarchy)
    {
        $this->customerHierarchy = $customerHierarchy;
        $this->doctrine = $doctrine;
    }

    /**
     * Provides pre-loaded entity object
     *
     * @param string $className
     * @param int|string $id
     * @return object|null
     */
    protected function get(string $className, $id)
    {
        if (!array_key_exists($className, $this->data)) {
            $this->data[$className] = [];
        }
        if (!array_key_exists($id, $this->data[$className])) {
            $this->data[$className][$id] = $this->getRepo($className)->find($id);
        }

        return $this->data[$className][$id];
    }

    /**
     * @return ObjectRepository
     */
    protected function getRepo(string $className): ObjectRepository
    {
        return $this->doctrine->getManagerForClass($className)->getRepository($className);
    }
}
