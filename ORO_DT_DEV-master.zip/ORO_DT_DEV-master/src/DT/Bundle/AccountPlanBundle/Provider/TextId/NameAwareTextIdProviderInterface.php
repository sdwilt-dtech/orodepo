<?php

namespace DT\Bundle\AccountPlanBundle\Provider\TextId;

use Symfony\Component\HttpFoundation\Request;

/**
 * Extends TextIdProviderInterface allowing, apart from Text ID,
 * generation of name from the request data
 */
interface NameAwareTextIdProviderInterface extends TextIdProviderInterface
{
    /**
     * Provides generated name for request
     *
     * @param Request $request
     * @return string|null
     */
    public function getName(Request $request): ?string;
}
