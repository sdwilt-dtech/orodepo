<?php

namespace DT\Bundle\AccountPlanBundle\Provider\TextId;

use Symfony\Component\HttpFoundation\Request;

/**
 * Allows generation of Text ID value from the request data
 */
interface TextIdProviderInterface
{
    /**
     * Tries to build textId from given request params
     *
     * @param Request $request
     * @return string|null
     */
    public function getTextId(Request $request): ?string;

    /**
     * Returns name of handled class
     *
     * @return string
     */
    public function getHandledClass(): string;
}
