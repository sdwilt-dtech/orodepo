<?php

namespace DT\Bundle\AccountPlanBundle\Provider\TextId;

use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Symfony\Component\HttpFoundation\Request;

class RegionRepTextIdProvider extends AbstractTextIdProvider implements NameAwareTextIdProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function getTextId(Request $request): ?string
    {
        $regionId = $request->request->get('region');
        $repCodeId = $request->request->get('repCode');
        $segment = $request->request->get('kcg_customer_segment');
        $fiscalYear = $request->request->get('fiscalYear');

        /** @var Region $region */
        $region = $this->get(Region::class, $regionId);
        /** @var RepCode $repCode */
        $repCode = $this->get(RepCode::class, $repCodeId);

        $textIdParts = [];
        if ($region) {
            $textIdParts[] = $region->getJdeId();
        }
        if ($segment) {
            $textIdParts[] = $segment;
        }
        if ($repCode) {
            $textIdParts[] = $repCode->getCode();
        }
        if ($fiscalYear) {
            $textIdParts[] = $fiscalYear;
        }

        return count($textIdParts) === 4
            ? implode('', $textIdParts)
            : null;
    }

    /**
     * {@inheritdoc}
     */
    public function getName(Request $request): ?string
    {
        $regionId = $request->request->get('region');
        $repCodeId = $request->request->get('repCode');
        $segment = $request->request->get('kcg_customer_segment');
        $fiscalYear = $request->request->get('fiscalYear');

        /** @var Region $region */
        $region = $this->get(Region::class, $regionId);
        /** @var RepCode $repCode */
        $repCode = $this->get(RepCode::class, $repCodeId);

        /** @var BusinessUnit $businessUnit */
        $businessUnit = $repCode ? $this->getRepo(BusinessUnit::class)->findOneBy([
            'dt_is_agency' => true,
            'dt_agency_rep_code' => $repCode
        ]) : null;

        $nameParts = [];
        if ($region) {
            $nameParts[] = $region->getJdeId();
        }
        if ($businessUnit) {
            $nameParts[] = $businessUnit->getName();
        }
        if ($segment) {
            $nameParts[] = $segment;
        }
        if ($fiscalYear) {
            $nameParts[] = $fiscalYear;
        }

        return count($nameParts) === 4
            ? implode('-', $nameParts)
            : null;
    }

    /**
     * {@inheritdoc}
     */
    public function getHandledClass(): string
    {
        return GoRegionRep::class;
    }
}
