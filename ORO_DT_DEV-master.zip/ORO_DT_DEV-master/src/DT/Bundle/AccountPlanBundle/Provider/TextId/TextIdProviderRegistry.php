<?php

namespace DT\Bundle\AccountPlanBundle\Provider\TextId;

class TextIdProviderRegistry
{
    /** @var TextIdProviderInterface[] */
    private $providers;

    /**
     * @param iterable|TextIdProviderInterface[] $providers
     */
    public function __construct(iterable $providers)
    {
        foreach ($providers as $provider) {
            $this->addProvider($provider);
        }
    }

    /**
     * Registers provider for given class
     *
     * @param TextIdProviderInterface $provider
     * @return self
     */
    public function addProvider(TextIdProviderInterface $provider): self
    {
        $this->providers[$provider->getHandledClass()] = $provider;
        return $this;
    }

    /**
     * Returns one of registered providers for given class name
     *
     * @param string $className
     * @return TextIdProviderInterface
     */
    public function getProvider(string $className): TextIdProviderInterface
    {
        if (!array_key_exists($className, $this->providers)) {
            throw new \InvalidArgumentException(sprintf('Provider for class %s does not exist!', $className));
        }

        return $this->providers[$className];
    }
}
