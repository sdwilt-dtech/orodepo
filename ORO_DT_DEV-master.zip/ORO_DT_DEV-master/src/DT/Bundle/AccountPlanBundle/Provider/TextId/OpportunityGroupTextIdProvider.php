<?php

namespace DT\Bundle\AccountPlanBundle\Provider\TextId;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Symfony\Component\HttpFoundation\Request;

class OpportunityGroupTextIdProvider extends AbstractTextIdProvider implements NameAwareTextIdProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function getTextId(Request $request): ?string
    {
        $regionId = $request->request->get('region');
        $customerId = $request->request->get('account');
        if (null === $customerId) {
            $customerId = $request->request->get('customer');
        }
        $repCodeId = $request->request->get('repCode');
        $fiscalYear = $request->request->get('fiscalYear');

        /** @var Region $region */
        $region = $this->get(Region::class, $regionId);
        /** @var Customer $customer */
        $customer = $this->get(Customer::class, $customerId);
        /** @var RepCode $repCode */
        $repCode = $this->get(RepCode::class, $repCodeId);

        $textIdParts = [];
        if ($region) {
            $textIdParts[] = $region->getJdeId();
        }
        if ($repCode) {
            $textIdParts[] = $repCode->getCode();
        }
        if ($customer) {
            $parentCustomer = $this->customerHierarchy->getCustomerForBillingType($customer);
            if ($parentCustomer) {
                $textIdParts[] = $parentCustomer->getDtJdeId();
            } else {
                $textIdParts[] = $customer->getDtJdeId();
            }
        }
        if ($fiscalYear) {
            $textIdParts[] = $fiscalYear;
        }

        return count($textIdParts) === 4
            ? implode('', $textIdParts)
            : null;
    }

    /**
     * {@inheritdoc}
     */
    public function getName(Request $request): ?string
    {
        $regionId = $request->request->get('region');
        $customerId = $request->request->get('account');
        if (null === $customerId) {
            $customerId = $request->request->get('customer');
        }
        $repCodeId = $request->request->get('repCode');
        $fiscalYear = $request->request->get('fiscalYear');

        /** @var Region $region */
        $region = $this->get(Region::class, $regionId);
        /** @var Customer $customer */
        $customer = $this->get(Customer::class, $customerId);
        /** @var RepCode $repCode */
        $repCode = $this->get(RepCode::class, $repCodeId);

        /** @var BusinessUnit $businessUnit */
        $businessUnit = $repCode ? $this->getRepo(BusinessUnit::class)->findOneBy([
            'dt_is_agency' => true,
            'dt_agency_rep_code' => $repCode
        ]) : null;

        $nameParts = [];
        if ($region) {
            $nameParts[] = $region->getJdeId();
        }
        if ($businessUnit) {
            $nameParts[] = $businessUnit->getName();
        }
        if ($customer) {
            $parentCustomer = $this->customerHierarchy->getCustomerForBillingType($customer);
            if ($parentCustomer) {
                $nameParts[] = $parentCustomer->getName();
            } else {
                $nameParts[] = $customer->getName();
            }
        }
        if ($fiscalYear) {
            $nameParts[] = $fiscalYear;
        }

        return count($nameParts) === 4
            ? implode('-', $nameParts)
            : null;
    }

    /**
     * {@inheritdoc}
     */
    public function getHandledClass(): string
    {
        return GoOpportunityGroup::class;
    }
}
