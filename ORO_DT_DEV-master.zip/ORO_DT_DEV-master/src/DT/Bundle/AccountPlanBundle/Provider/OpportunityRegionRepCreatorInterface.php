<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;

interface OpportunityRegionRepCreatorInterface
{
    /**
     * Creates region rep for certain opportunity
     *
     * @param GoOpportunity $opportunity
     * @return GoRegionRep
     * @throws \RuntimeException If could not be created
     */
    public function createRegionRep(GoOpportunity $opportunity): GoRegionRep;
}
