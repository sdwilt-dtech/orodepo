<?php

namespace DT\Bundle\AccountPlanBundle\Provider\Enums;

class KcgCustomerSegment
{
    public const SEGMENT_NATIONAL = 'National';
    public const SEGMENT_STRATEGIC = 'Strategic';
    public const SEGMENT_CORE = 'Core';
}
