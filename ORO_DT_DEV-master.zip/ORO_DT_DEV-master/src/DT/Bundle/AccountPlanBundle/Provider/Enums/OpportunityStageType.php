<?php

namespace DT\Bundle\AccountPlanBundle\Provider\Enums;

/**
 * Keeps opportunity stages types constant
 * values
 */
class OpportunityStageType
{
    public const TYPE_OPEN = 'Open';
    public const TYPE_CLOSED_WON = 'Closed/Won';
    public const TYPE_CLOSED_LOST = 'Closed/Lost';
}
