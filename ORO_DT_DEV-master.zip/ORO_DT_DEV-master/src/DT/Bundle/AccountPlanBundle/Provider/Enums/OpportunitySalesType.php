<?php

namespace DT\Bundle\AccountPlanBundle\Provider\Enums;

class OpportunitySalesType
{
    public const TYPE_CONVERT = 'Convert';
    public const TYPE_GROW = 'Grow';
    public const TYPE_KEEP = 'Keep';
    public const TYPE_NPI = 'NPI';
    public const TYPE_PIPELINE = 'Pipeline';
    public const TYPE_GO_PLAN = 'Go Plan';
}
