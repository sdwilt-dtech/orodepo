<?php

namespace DT\Bundle\AccountPlanBundle\Provider\Enums;

class OpportunityGroupYear
{
    public const TYPE_CURRENT = 'Current';
    public const TYPE_PREVIOUS = 'Previous';
}
