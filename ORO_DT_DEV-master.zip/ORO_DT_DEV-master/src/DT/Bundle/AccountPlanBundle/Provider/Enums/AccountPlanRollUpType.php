<?php

namespace DT\Bundle\AccountPlanBundle\Provider\Enums;

class AccountPlanRollUpType
{
    public const TYPE_PARENT = 'Parent';
    public const TYPE_CUSTOMER_TYPE = 'Customer Type';
    public const TYPE_BUYING_GROUP = 'Buying Group';
}
