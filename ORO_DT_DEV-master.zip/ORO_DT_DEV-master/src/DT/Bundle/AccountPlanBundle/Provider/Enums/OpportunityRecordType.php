<?php

namespace DT\Bundle\AccountPlanBundle\Provider\Enums;

class OpportunityRecordType
{
    public const TYPE_HVAC_GO_PLAN = 'HVAC Go Plan';
    public const TYPE_HVAC = 'HVAC';
    public const TYPE_SAMPLE_REQUEST = 'Sample Request Opp';
    public const TYPE_HVAC_OLD_GP = 'HVAC Old GP';
    public const TYPE_RSM_RECOVERY = 'RSM Recovery';
    public const TYPE_UTILITIES = 'Utilities';
    public const TYPE_UTIL_LC = 'Util-LC';
    public const TYPE_EU_ACCOUNTS = 'EU Accounts';
    public const TYPE_ELECTRICAL_SALES = 'Electrical Sales';
}
