<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Query\Expr\Join;
use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\OpportunityDataProviderInterface;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Bundle\OrderBundle\Entity\Repository\OrderRepository;

/**
 * Abstraction for Opportunity data providers that are Order-aware
 */
abstract class AbstractOrderAwareDataProvider implements OpportunityDataProviderInterface
{
    /** @var ManagerRegistry */
    protected $doctrine;

    /** @var CustomerHierarchy */
    protected $customerHierarchy;

    /**
     * @param ManagerRegistry $doctrine
     * @param CustomerHierarchy $customerHierarchy
     */
    public function __construct(ManagerRegistry $doctrine, CustomerHierarchy $customerHierarchy)
    {
        $this->doctrine = $doctrine;
        $this->customerHierarchy = $customerHierarchy;
    }

    /**
     * @return OrderRepository
     */
    protected function getOrderRepository(): OrderRepository
    {
        return $this
            ->doctrine
            ->getManagerForClass(Order::class)
            ->getRepository(Order::class);
    }

    /**
     * {@inheritdoc}
     */
    public function getData(Criteria $criteria)
    {
        $queryBuilder = $this->getOrderRepository()->createQueryBuilder('o');
        $startDate = (new \DateTime(sprintf('January 1st %s', $criteria->getFiscalYear())));
        $billToCustomer = $this->customerHierarchy->getCustomerForBillingType($criteria->getCustomer())
            ?: $criteria->getCustomer();
        $endDate = (new \DateTime())
            ->setTimestamp(strtotime(sprintf('January 1st %s', (int)$criteria->getFiscalYear() + 1)) - 1);
        $queryBuilder
            ->resetDQLPart('select')
            ->select('SUM(li.quantity * li.value) AS category_sum')
            ->innerJoin(
                'o.lineItems',
                'li',
                Join::WITH,
                $queryBuilder->expr()->andX(
                    $queryBuilder->expr()->eq('li.order', 'o'),
                    $queryBuilder->expr()->eq('li.dt_product_category', ':productCategory')
                )
            )
            ->andWhere($queryBuilder->expr()->between('o.createdAt', ':dateStart', ':dateEnd'))
            ->andWhere($queryBuilder->expr()->eq('o.dt_region', ':region'))
            ->andWhere($queryBuilder->expr()->eq('o.dt_bill_to', ':billToCustomer'))
            ->setParameter('dateStart', $startDate, Types::DATETIME_MUTABLE)
            ->setParameter('dateEnd', $endDate, Types::DATETIME_MUTABLE)
            ->setParameter('region', $criteria->getRegion())
            ->setParameter('productCategory', $criteria->getProductCategoryCode())
            ->setParameter('billToCustomer', $billToCustomer);

        return (float)$queryBuilder->getQuery()->getSingleScalarResult();
    }
}
