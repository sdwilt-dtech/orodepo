<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider\Criteria;

class OpportunityDataProvider implements OpportunityDataProviderInterface
{
    /** @var OpportunityDataProviderInterface[] */
    private $providers;

    /**
     * @param iterable|OpportunityDataProviderInterface[] $providers
     */
    public function __construct(iterable $providers)
    {
        foreach ($providers as $provider) {
            $this->addProvider($provider);
        }
    }

    /**
     * Registers provider instance
     *
     * @param OpportunityDataProviderInterface $provider
     * @return self
     */
    public function addProvider(OpportunityDataProviderInterface $provider): self
    {
        $this->providers[] = $provider;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getData(Criteria $criteria, string $datumName = null)
    {
        foreach ($this->providers as $provider) {
            if ($provider->canProvide($datumName)) {
                return $provider->getData($criteria);
            }
        }

        throw new \InvalidArgumentException(sprintf(
            'Provider for datum name `%s` not found.',
            (null === $datumName) ? 'null' : $datumName
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function canProvide(string $datumName): bool
    {
        foreach ($this->providers as $provider) {
            if ($provider->canProvide($datumName)) {
                return true;
            }
        }

        return false;
    }
}
