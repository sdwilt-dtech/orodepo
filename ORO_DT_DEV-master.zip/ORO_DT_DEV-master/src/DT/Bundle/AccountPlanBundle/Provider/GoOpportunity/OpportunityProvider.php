<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider\Criteria;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\Repository\GoOpportunityRepository;

/**
 * Default implementation of OpportunityProviderInterface. Provides opportunity
 * matching criteria:
 * - Region
 * - Product Category Code
 * - Year
 * - Customer (traverses hierarchy)
 */
class OpportunityProvider implements OpportunityProviderInterface
{
    /** @var ManagerRegistry */
    private $doctrine;

    /** @var CustomerHierarchy */
    private $customerHierarchy;

    /**
     * @param ManagerRegistry $doctrine
     * @param CustomerHierarchy $customerHierarchy
     */
    public function __construct(ManagerRegistry $doctrine, CustomerHierarchy $customerHierarchy)
    {
        $this->doctrine = $doctrine;
        $this->customerHierarchy = $customerHierarchy;
    }

    /**
     * {@inheritdoc}
     */
    public function getOpportunity(Criteria $criteria): ?GoOpportunity
    {
        $queryBuilder = $this->getOpportunityRepository()->createQueryBuilder('o');
        $hierarchyFlat = $this->customerHierarchy->getFlatTree($criteria->getCustomer());
        $queryBuilder
            ->andWhere($queryBuilder->expr()->in('o.customer', ':customers'))
            ->andWhere($queryBuilder->expr()->eq('o.region', ':region'))
            ->andWhere($queryBuilder->expr()->eq('o.productCategoryCode', ':productCategoryCode'))
            ->andWhere($queryBuilder->expr()->eq('o.fiscalYear', ':fiscalYear'))
            ->setParameter('region', $criteria->getRegion())
            ->setParameter('fiscalYear', (int)$criteria->getFiscalYear())
            ->setParameter('productCategoryCode', $criteria->getProductCategoryCode())
            ->setParameter('customers', $hierarchyFlat);
        $results = $queryBuilder->getQuery()->execute();

        return count($results) ? $results[0] : null;
    }

    /**
     * Returns opportunity repository
     *
     * @return GoOpportunityRepository
     */
    private function getOpportunityRepository(): GoOpportunityRepository
    {
        return $this
            ->doctrine
            ->getManagerForClass(GoOpportunity::class)
            ->getRepository(GoOpportunity::class);
    }
}
