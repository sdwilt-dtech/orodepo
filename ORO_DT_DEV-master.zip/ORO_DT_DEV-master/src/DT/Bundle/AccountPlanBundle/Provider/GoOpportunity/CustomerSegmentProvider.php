<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use DT\Bundle\CustomerBundle\Provider\CustomerSegmentProvider as Provider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class CustomerSegmentProvider extends AbstractOpportunityMetricProvider
{
    public const NAME = 'CustomerSegment';

    /** @var Provider */
    private $customerSegmentProvider;

    /**
     * @param Provider $customerSegmentProvider
     */
    public function __construct(Provider $customerSegmentProvider)
    {
        $this->customerSegmentProvider = $customerSegmentProvider;
    }

    /**
     * {@inheritdoc}
     * @param GoOpportunity $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        if ($customer = $entity->getAccount()) {
            return $this->customerSegmentProvider->getCustomerSegment($customer);
        }

        return null;
    }
}
