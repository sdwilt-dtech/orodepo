<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider;

use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use DT\Bundle\EntityBundle\Entity\Region;
use Oro\Bundle\CustomerBundle\Entity\Customer;

/**
 * Criteria data capsule for searching opportunity data
 */
final class Criteria
{
    public const KEY_REGION = 'region_id';

    public const KEY_CUSTOMER = 'customer_id';

    public const KEY_YEAR = 'fiscal_year';

    public const KEY_PRODUCT_CATEGORY_CODE = 'product_category_code_id';

    /** @var Region */
    private $region;

    /** @var Customer */
    private $customer;

    /** @var ProductCategoryCode */
    private $productCategoryCode;

    /** @var string */
    private $fiscalYear;

    /**
     * @param Region $region
     * @param Customer $customer
     * @param ProductCategoryCode $productCategoryCode
     * @param string|null $fiscalYear
     */
    public function __construct(
        Region $region,
        Customer $customer,
        ProductCategoryCode $productCategoryCode,
        string $fiscalYear = null
    ) {
        $this->region = $region;
        $this->customer = $customer;
        $this->productCategoryCode = $productCategoryCode;
        $this->fiscalYear = $fiscalYear ?: date('Y');
    }

    /**
     * Gets customer property
     *
     * @return Customer
     */
    public function getCustomer(): Customer
    {
        return $this->customer;
    }

    /**
     * Gets productCategoryCode property
     *
     * @return ProductCategoryCode
     */
    public function getProductCategoryCode(): ProductCategoryCode
    {
        return $this->productCategoryCode;
    }

    /**
     * Gets region property
     *
     * @return Region
     */
    public function getRegion(): Region
    {
        return $this->region;
    }

    /**
     * Gets fiscalYear property
     *
     * @return string
     */
    public function getFiscalYear(): string
    {
        return $this->fiscalYear;
    }

    /**
     * Sets fiscalYear property
     *
     * @param string $fiscalYear
     * @return self
     */
    public function setFiscalYear(string $fiscalYear): self
    {
        $this->fiscalYear = $fiscalYear;
        return $this;
    }

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            self::KEY_REGION => $this->getRegion()->getId(),
            self::KEY_CUSTOMER => $this->getCustomer()->getId(),
            self::KEY_PRODUCT_CATEGORY_CODE => $this->getProductCategoryCode()->getId(),
            self::KEY_YEAR => $this->getFiscalYear()
        ];
    }
}
