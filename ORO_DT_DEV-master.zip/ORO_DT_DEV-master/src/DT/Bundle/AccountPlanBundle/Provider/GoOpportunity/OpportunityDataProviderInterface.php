<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider\Criteria;

interface OpportunityDataProviderInterface
{
    /**
     * Provides datum for given opportunity criteria
     *
     * @param Criteria $criteria
     * @return mixed
     */
    public function getData(Criteria $criteria);

    /**
     * Returns true if the implementation is aware of certain datum
     *
     * @param string $datumName
     * @return bool
     */
    public function canProvide(string $datumName): bool;
}
