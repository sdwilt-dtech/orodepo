<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

/**
 * Target acgieved defines how close one is to reaching the target in percent.
 * YTD/Target
 */
class TargetAchievedMetricProvider extends AbstractOpportunityMetricProvider
{
    public const NAME = 'TargetAchievedPercent';

    /**
     * {@inheritdoc}
     * @param GoOpportunity $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $target = $this->registry->getMetric($entity, TargetProvider::NAME);
        $ytd = $entity->getYtd();

        return $target ? $this->parsePercent($ytd / $target) : null;
    }
}
