<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

/**
 *
 */
class TargetProvider extends AbstractOpportunityMetricProvider
{
    public const NAME = 'OpportunityTarget';

    /**
     * {@inheritdoc}
     * @param GoOpportunity $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        return $this->registry->getMetric($entity, CurrentYearValueProvider::NAME) + $entity->getPy();
    }
}
