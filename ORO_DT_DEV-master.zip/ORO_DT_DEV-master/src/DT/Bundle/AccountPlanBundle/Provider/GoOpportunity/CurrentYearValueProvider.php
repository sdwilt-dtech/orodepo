<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class CurrentYearValueProvider extends AbstractOpportunityMetricProvider
{
    public const NAME = 'CurrentYearValue';

    private const DEFAULT_MULTIPLIERS = [
        1  => 0.94,
        2  => 0.881,
        3  => 0.781,
        4  => 0.679,
        5  => 0.577,
        6  => 0.453,
        7  => 0.345,
        8  => 0.258,
        9  => 0.182,
        10 => 0.113,
        11 => 0.056,
        12 => 0.001,
    ];

    private $multipliers = self::DEFAULT_MULTIPLIERS;

    /**
     * Sets custom values for multipliers
     *
     * @param array $multipliers
     * @return self
     */
    public function setMultipliers(array $multipliers): self
    {
        $this->multipliers = $multipliers;
        return $this;
    }

    /**
     * {@inheritdoc}
     * @param GoOpportunity $entity
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        $annualizedValue = $entity->getTargetedOpportunityValue();
        $likehood = $this->registry->getMetric($entity, LikehoodMultiplierProvider::NAME);
        $revenueStartDate = $entity->getRevenueStartDate();
        return (!($annualizedValue * $likehood * $revenueStartDate))
            ? null
            : $this->doCalculateValue($annualizedValue, $likehood, $revenueStartDate);
    }

    /**
     * @param float $annualizedValue
     * @param float $likehood
     * @param int $revenueStartDate
     * @return float
     */
    private function doCalculateValue(float $annualizedValue, float $likehood, int $revenueStartDate): float
    {
        return $annualizedValue * $likehood * $this->getMultiplier($revenueStartDate);
    }

    /**
     * @param int $revenueStartDate
     * @return float
     */
    private function getMultiplier(int $revenueStartDate): float
    {
        return array_key_exists($revenueStartDate, $this->multipliers)
            ? $this->multipliers[$revenueStartDate]
            : 0.0;
    }
}
