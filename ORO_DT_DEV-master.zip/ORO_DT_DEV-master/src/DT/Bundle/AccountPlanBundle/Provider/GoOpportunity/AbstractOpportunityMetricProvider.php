<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Provider\AbstractMetricProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

abstract class AbstractOpportunityMetricProvider extends AbstractMetricProvider
{
    /**
     * {@inheritdoc}
     */
    public function supports(MetricsAwareInterface $entity): bool
    {
        return $entity instanceof GoOpportunity;
    }
}
