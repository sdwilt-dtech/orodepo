<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider;

class PyProvider extends AbstractOrderAwareDataProvider
{
    /**
     * {@inheritdoc}
     */
    public function getData(Criteria $criteria)
    {
        $prevYearCriteria = clone $criteria;
        $prevYearCriteria->setFiscalYear((string)((int)$criteria->getFiscalYear() - 1));

        return parent::getData($prevYearCriteria);
    }

    /**
     * {@inheritdoc}
     */
    public function canProvide(string $datumName): bool
    {
        return $datumName === 'py';
    }
}
