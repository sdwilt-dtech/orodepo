<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

class LikehoodMultiplierProvider extends AbstractOpportunityMetricProvider
{
    public const NAME = 'LikehoodMultiplier';

    private const MULTIPLIER = 0.01;

    /**
     * {@inheritdoc}
     * @param GoOpportunity $entity
     * @return float|null
     */
    public function calculateValue(MetricsAwareInterface $entity)
    {
        if ($likehood = $entity->getLikehood()) {
            return (float)(self::MULTIPLIER * $likehood);
        }

        return null;
    }
}
