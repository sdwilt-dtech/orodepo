<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity;

use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider\Criteria;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;

interface OpportunityProviderInterface
{
    /**
     * Tries to provide opportunity matching certain criteria
     *
     * @param Criteria $criteria
     * @return GoOpportunity|null
     */
    public function getOpportunity(Criteria $criteria): ?GoOpportunity;
}
