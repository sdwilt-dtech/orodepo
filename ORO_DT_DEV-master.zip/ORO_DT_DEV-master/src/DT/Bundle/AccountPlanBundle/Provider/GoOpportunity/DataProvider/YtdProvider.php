<?php

namespace DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider;

class YtdProvider extends AbstractOrderAwareDataProvider
{
    /**
     * {@inheritdoc}
     */
    public function canProvide(string $datumName): bool
    {
        return $datumName === 'ytd';
    }
}
