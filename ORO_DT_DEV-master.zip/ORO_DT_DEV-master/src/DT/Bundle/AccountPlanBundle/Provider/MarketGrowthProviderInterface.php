<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

/**
 * Provides global market growth factors
 *
 * Used in formulas for GoAccountPlan
 */
interface MarketGrowthProviderInterface
{
    /**
     * Provides market growth percentage
     *
     * @return float
     */
    public function getMarketGrowthPercentage(): float;
}
