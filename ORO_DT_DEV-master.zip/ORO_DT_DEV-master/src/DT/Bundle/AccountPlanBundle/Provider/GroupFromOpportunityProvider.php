<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\Repository\GoOpportunityGroupRepository;
use Oro\Bundle\CustomerBundle\Entity\Customer;

class GroupFromOpportunityProvider implements OpportunityGroupProviderInterface
{
    /** @var ManagerRegistry */
    private $doctrine;

    /** @var CustomerHierarchy */
    private $customerHierarchy;

    /** @var OpportunityGroupCreatorInterface */
    private $groupCreator;

    /**
     * @param ManagerRegistry $doctrine
     * @param CustomerHierarchy $customerHierarchy
     * @param OpportunityGroupCreatorInterface $groupCreator
     */
    public function __construct(
        ManagerRegistry $doctrine,
        CustomerHierarchy $customerHierarchy,
        OpportunityGroupCreatorInterface $groupCreator
    ) {
        $this->doctrine = $doctrine;
        $this->customerHierarchy = $customerHierarchy;
        $this->groupCreator = $groupCreator;
    }

    /**
     * {@inheritdoc}
     * @param bool $createIfNotExisting
     */
    public function getOpportunityGroup(
        GoOpportunity $opportunity,
        bool $createIfNotExisting = true
    ): GoOpportunityGroup {
        if ($opportunity->getOpportunityGroup()) {
            return $opportunity->getOpportunityGroup();
        }

        return $this->doGetOpportunityGroup($opportunity, $createIfNotExisting);
    }

    /**
     * @param GoOpportunity $opportunity
     * @param bool $createIfNotExisting
     * @return GoOpportunityGroup
     * @throws \RuntimeException In case group could not be provided
     */
    private function doGetOpportunityGroup(GoOpportunity $opportunity, bool $createIfNotExisting): GoOpportunityGroup
    {
        $customer = $opportunity->getCustomer()
            ? $this->customerHierarchy->getCustomerForLevel($opportunity->getCustomer())
            : null;
        $fiscalYear = $opportunity->getFiscalYear();
        if (null === $customer || null === $fiscalYear) {
            throw new \RuntimeException(sprintf('Customer missing in Opportunity'));
        }
        if ($group = $this->getGroupByCustomer($customer, $fiscalYear)) {
            return $group;
        }

        if ($createIfNotExisting) {
            return $this->groupCreator->createOpportunityGroup($opportunity);
        }

        throw new \RuntimeException('Could not provide opportunity group!');
    }

    /**
     * @param Customer $customer
     * @param string $fiscalYear
     * @return GoOpportunityGroup|null
     */
    private function getGroupByCustomer(Customer $customer, string $fiscalYear): ?GoOpportunityGroup
    {
        /** @var GoOpportunityGroupRepository $repo */
        $results = $this
            ->doctrine
            ->getManagerForClass(GoOpportunityGroup::class)
            ->getRepository(GoOpportunityGroup::class)
            ->getCustomerAwareQueryBuilder($customer, $fiscalYear)
            ->getQuery()
            ->execute();

        return count($results) ? $results[0] : null;
    }
}
