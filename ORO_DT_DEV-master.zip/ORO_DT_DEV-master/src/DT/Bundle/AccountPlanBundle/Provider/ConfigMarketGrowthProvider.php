<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\AccountPlanBundle\DependencyInjection\Configuration;
use Oro\Bundle\ConfigBundle\Config\ConfigManager;

/**
 * Config-based implementation for the percentage value of market growth provider
 */
class ConfigMarketGrowthProvider implements MarketGrowthProviderInterface
{
    /** @var ConfigManager */
    private $configManager;

    /**
     * @param ConfigManager $configManager
     */
    public function __construct(ConfigManager $configManager)
    {
        $this->configManager = $configManager;
    }

    /**
     * {@inheritdoc}
     */
    public function getMarketGrowthPercentage(): float
    {
        return $this
            ->configManager
            ->get(Configuration::getAliasedKey(Configuration::CONFIG_MARKET_GROWTH_PERCENTAGE));
    }
}
