<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\AccountPlanBundle\Exception\EntityNotSetException;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\CustomerBundle\Entity\Customer;

/**
 * Aggregates customer based metrics
 */
interface CustomerPlanDataProviderInterface
{
    /**
     * Sets customer account
     *
     * @param Customer $customer
     *
     * @return self
     */
    public function setCustomerAccount(Customer $customer);

    /**
     * Sets fiscal year for the values to calculate
     *
     * @param string $year
     * @return self
     */
    public function setFiscalYear(string $year);

    /**
     * Returns account goal value
     *
     * @return float|null
     * @throws EntityNotSetException
     */
    public function getAccountGoal(): ?float;

    /**
     * Returns prior year sales value
     *
     * @return float|null
     * @throws EntityNotSetException
     */
    public function getPriorYearSales(): ?float;

    /**
     * Returns actual year-to-date value
     *
     * @return float|null
     * @throws EntityNotSetException
     */
    public function getActualYtd(): ?float;

    /**
     * Returns prior year-to-date value
     *
     * @return float|null
     * @throws EntityNotSetException
     */
    public function getPriorYtd(): ?float;

    /**
     * Returns Keep value
     *
     * @return float|null
     * @throws EntityNotSetException
     */
    public function getCurrentYearValueKeep(): ?float;

    /**
     * Returns Convert value
     *
     * @return float|null
     * @throws EntityNotSetException
     */
    public function getCurrentYearValueConvert(): ?float;

    /**
     * Returns Grow value
     *
     * @return float|null
     * @throws EntityNotSetException
     */
    public function getCurrentYearValueGrow(): ?float;

    /**
     * Returns NPI value
     *
     * @return float|null
     * @throws EntityNotSetException
     */
    public function getCurrentYearValueNpi(): ?float;

    /**
     * Returns Pipeline value
     *
     * @return float|null
     * @throws EntityNotSetException
     */
    public function getCurrentYearValuePipeline(): ?float;

    /**
     * Returns opportunities
     *
     * @return array|GoOpportunity[]
     */
    public function getOpportunities(): array;
}
