<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use Doctrine\Persistence\ManagerRegistry;
use Oro\Bundle\OrganizationBundle\Entity\Organization;
use Oro\Bundle\UserBundle\Entity\User;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class OrganizationRepsAccessProvider implements RepsAccessProviderInterface
{
    /** @var TokenStorageInterface */
    private $tokenStorage;

    /** @var ManagerRegistry */
    private $doctrine;

    /**
     * @param TokenStorageInterface $storage
     * @param ManagerRegistry $doctrine
     */
    public function __construct(TokenStorageInterface $storage, ManagerRegistry $doctrine)
    {
        $this->doctrine = $doctrine;
        $this->tokenStorage = $storage;
    }

    /**
     * @return User|null
     */
    protected function getUser(): ?User
    {
        $token = $this->tokenStorage->getToken();
        if ($token && $user = $token->getUser()) {
            return ($user instanceof User)
                ? $user
                : null;
        }

        return null;
    }

    /**
     * @return Organization
     */
    private function getDefaultOrganization(): Organization
    {
        /** @var Organization $organization */
        $organization = $this
            ->doctrine
            ->getManagerForClass(Organization::class)
            ->getRepository(Organization::class)
            ->findOneBy([]);

        return $organization;
    }

    /**
     * {@inheritdoc}
     */
    public function isInternalUser(): bool
    {
        $user = $this->getUser();
        if ($user->getOrganization()->getId() === $this->getDefaultOrganization()->getId()) {
            return true;
        }

        return false;
    }

    /**
     * {@inheritdoc}
     */
    public function isSalesRep(): bool
    {
        foreach ($this->getUser()->getRoles() as $role) {
            if ($role->getRole() === 'ROLE_SALES_REP') {
                return true;
            }
        }

        return false;
    }
}
