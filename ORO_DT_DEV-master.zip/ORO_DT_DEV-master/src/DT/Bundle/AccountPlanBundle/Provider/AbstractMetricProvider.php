<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

abstract class AbstractMetricProvider implements MetricProviderInterface
{
    public const NAME = '';

    /** @var MetricsProvider */
    protected $registry;

    /**
     * {@inheritdoc}
     */
    public function getName(): string
    {
        return static::NAME;
    }

    /**
     * {@inheritdoc}
     */
    public function setMetricsProvider(MetricsProvider $metricsProvider): void
    {
        $this->registry = $metricsProvider;
    }

    /**
     * Returns float percentage value for given input float value
     *
     * @param float $value
     * @param int $multiplier
     * @return string
     */
    protected function parsePercent(float $value, int $multiplier = 100): string
    {
        return sprintf(
            '%s%%',
            round($value * $multiplier, 2)
        );
    }
}
