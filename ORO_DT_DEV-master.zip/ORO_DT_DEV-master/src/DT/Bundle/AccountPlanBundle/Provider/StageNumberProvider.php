<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;

class StageNumberProvider
{
    protected const REGEXP = '/^(\d)([a-z]+)?\.\s{1}([a-zA-Z1-9\s])+$/';

    /**
     * Returns stage number for given opportunity
     *
     * @param GoOpportunity $opportunity
     * @return int
     */
    public function getOpportunityStageNumber(GoOpportunity $opportunity): int
    {
        if (!($stage = $opportunity->getStage())) {
            return 0;
        }
        return $this->getStageNumber($stage);
    }

    /**
     * Returns stage number for given stage entity
     *
     * @param GoOpportunityStage $stage
     * @return int
     */
    public function getStageNumber(GoOpportunityStage $stage): int
    {
        $matches = [];
        preg_match_all(self::REGEXP, $stage->getName(), $matches);

        return isset($matches[1][0]) ? (int)$matches[1][0] : 0;
    }
}
