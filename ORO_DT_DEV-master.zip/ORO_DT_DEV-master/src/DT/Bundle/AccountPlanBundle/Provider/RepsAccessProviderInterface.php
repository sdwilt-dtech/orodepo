<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

interface RepsAccessProviderInterface
{
    /**
     * Defines if logged in user is an internal user
     * or external/community partner
     *
     * @return bool
     */
    public function isInternalUser(): bool;

    /**
     * @return bool
     */
    public function isSalesRep(): bool;
}
