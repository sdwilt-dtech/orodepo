<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

interface MetricProviderInterface
{
    /**
     * Makes the object aware of all registry
     *
     * @param MetricsProvider $metricsProvider
     */
    public function setMetricsProvider(MetricsProvider $metricsProvider): void;

    /**
     * Calculates value
     *
     * @return mixed
     */
    public function calculateValue(MetricsAwareInterface $entity);

    /**
     * Returns true if provider supports given implementation of
     * MetricsAwareInterface
     *
     * @param MetricsAwareInterface $entity
     * @return bool
     */
    public function supports(MetricsAwareInterface $entity): bool;

    /**
     * Provides metric name
     *
     * @return string
     */
    public function getName(): string;
}
