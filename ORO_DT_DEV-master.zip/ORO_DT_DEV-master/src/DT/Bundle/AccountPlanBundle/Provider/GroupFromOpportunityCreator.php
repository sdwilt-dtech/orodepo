<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\AccountPlanBundle\Api\Processor\Exception\DataErrorException;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityGroupYear;
use DT\Bundle\AccountPlanBundle\Provider\TextId\OpportunityGroupTextIdProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Validator\ConstraintViolationInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Default implementation of DT\Bundle\AccountPlanBundle\Provider\OpportunityGroupCreatorInterface
 */
class GroupFromOpportunityCreator implements OpportunityGroupCreatorInterface
{
    /** @var OpportunityGroupTextIdProvider */
    private $textIdProvider;

    /** @var EnumValueProvider */
    private $enumProvider;

    /** @var ValidatorInterface */
    private $validator;

    /** @var OpportunityRegionRepProviderInterface */
    private $regionRepProvider;

    /** @var TranslatorInterface */
    private $translator;

    /**
     * @param OpportunityGroupTextIdProvider $textIdProvider
     * @param EnumValueProvider $enumValueProvider
     * @param ValidatorInterface $validator
     * @param OpportunityRegionRepProviderInterface $regionRepProvider
     * @param TranslatorInterface $translator
     */
    public function __construct(
        OpportunityGroupTextIdProvider $textIdProvider,
        EnumValueProvider $enumValueProvider,
        ValidatorInterface $validator,
        OpportunityRegionRepProviderInterface $regionRepProvider,
        TranslatorInterface $translator
    ) {
        $this->textIdProvider = $textIdProvider;
        $this->enumProvider = $enumValueProvider;
        $this->validator = $validator;
        $this->regionRepProvider = $regionRepProvider;
        $this->translator = $translator;
    }

    /**
     * {@inheritdoc}
     */
    public function createOpportunityGroup(GoOpportunity $opportunity): GoOpportunityGroup
    {
        try {
            return $this->doCreateGroup($opportunity);
        } catch (\Throwable $exc) {
            if ($exc instanceof \RuntimeException) {
                throw $exc;
            }
            throw new \RuntimeException('Could not create Opportunity Group', null, $exc);
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @return GoOpportunityGroup
     */
    private function doCreateGroup(GoOpportunity $opportunity): GoOpportunityGroup
    {
        $request = $this->prepareRequest($opportunity);
        /** @var GoOpportunityGroup $group */
        $group = (new GoOpportunityGroup())
            ->setTextId($this->textIdProvider->getTextId($request))
            ->setName($this->textIdProvider->getName($request))
            ->setRegion($opportunity->getRegion())
            ->setCustomer($opportunity->getCustomer())
            ->setRepCode($opportunity->getRepCode())
            ->setSalesAgency($opportunity->getSalesAgency())
            ->setFiscalYear($opportunity->getFiscalYear())
            ->setOpportunityYear($this->enumProvider->getEnumValueByCode(
                GoOpportunityGroup::ENUM_OPPORTUNITY_YEAR,
                OpportunityGroupYear::TYPE_CURRENT
            ));
        $region = $opportunity->getRegion();
        if (null !== $region) {
            $manager = $region->getRegionalManager();
            $manager && $group->setRegionalManagerEmail($manager->getEmail());
            $support = $region->getSalesSupport();
            $support && $group->setSalesSupportEmail($support->getEmail());
        }

        $group->setRegionRep($this->regionRepProvider->getOpportunityRegionRep($opportunity));

        return $this->validate($group);
    }

    /**
     * @param GoOpportunityGroup $group
     * @return GoOpportunityGroup
     */
    private function validate(GoOpportunityGroup $group): GoOpportunityGroup
    {
        $errors = $this->validator->validate($group);
        if ($errors->count()) {
            throw new DataErrorException(
                $this->translator->trans('dt.api.goopportunity.opportunity_group.error.message'),
                $this->formatErrors($errors->getIterator())
            );
        }
        $regionRep = $group->getRegionRep();
        if (!$regionRep->getId()) {
            $errors =  $this->validator->validate($regionRep);
            if ($errors->count()) {
                throw new DataErrorException(
                    $this->translator->trans('dt.api.goopportunity.opportunity_group.region_rep.error.message'),
                    $this->formatErrors($errors->getIterator())
                );
            }
        }

        return $group;
    }

    /**
     * @param iterable|ConstraintViolationInterface[] $errors
     * @return string
     */
    private function formatErrors(iterable $errors): string
    {
        $results = [];
        foreach ($errors as $error) {
            $results[] = $error->getMessage();
        }

        return implode('; ', $results);
    }

    /**
     * @param GoOpportunity $opportunity
     * @return null|Request
     */
    private function prepareRequest(GoOpportunity $opportunity): ?Request
    {
        $parts = [];
        if ($region = $opportunity->getRegion()) {
            $parts['region'] = $region->getId();
        }
        if ($customer = $opportunity->getCustomer()) {
            $parts['customer'] = $customer->getId();
        }
        if ($repCode = $opportunity->getRepCode()->getId()) {
            $parts['repCode'] = $repCode;
        }
        if ($fiscalYear = $opportunity->getFiscalYear()) {
            $parts['fiscalYear'] = $fiscalYear;
        }
        if (count($parts) !== 4) {
            return null;
        }

        return new Request([], $parts);
    }
}
