<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\TextId\RegionRepTextIdProvider;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;
use DT\Bundle\CustomerBundle\Provider\CustomerSegmentProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Symfony\Component\HttpFoundation\Request;

class OpportunityRegionRepProvider implements OpportunityRegionRepProviderInterface
{
    /** @var ManagerRegistry */
    private $doctrine;

    /** @var CustomerHierarchy */
    private $customerHierarchy;

    /** @var CustomerSegmentProvider */
    private $customerSegmentProvider;

    /** @var OpportunityRegionRepCreatorInterface */
    private $regionRepCreator;

    /** @var RegionRepTextIdProvider */
    private $textIdProvider;

    /**
     * @param ManagerRegistry $doctrine
     * @param CustomerHierarchy $customerHierarchy
     * @param CustomerSegmentProvider $customerSegmentProvider
     * @param OpportunityRegionRepCreatorInterface $regionRepCreator
     * @param RegionRepTextIdProvider $textIdProvider
     */
    public function __construct(
        ManagerRegistry $doctrine,
        CustomerHierarchy $customerHierarchy,
        CustomerSegmentProvider $customerSegmentProvider,
        OpportunityRegionRepCreatorInterface $regionRepCreator,
        RegionRepTextIdProvider $textIdProvider
    ) {
        $this->doctrine = $doctrine;
        $this->customerHierarchy = $customerHierarchy;
        $this->customerSegmentProvider = $customerSegmentProvider;
        $this->regionRepCreator = $regionRepCreator;
        $this->textIdProvider = $textIdProvider;
    }

    /**
     * {@inheritdoc}
     * @param bool $createIfNotExisting
     */
    public function getOpportunityRegionRep(GoOpportunity $opportunity, bool $createIfNotExisting = true): GoRegionRep
    {
        if ($opportunity->getOpportunityGroup() && $opportunity->getOpportunityGroup()->getRegionRep()) {
            return $opportunity->getOpportunityGroup()->getRegionRep();
        }

        return $this->doGetOpportunityRegionRep($opportunity, $createIfNotExisting);
    }

    /**
     * @param GoOpportunity $opportunity
     * @param bool $createIfNotExisting
     * @return GoRegionRep
     * @throws \RuntimeException
     */
    private function doGetOpportunityRegionRep(GoOpportunity $opportunity, bool $createIfNotExisting): GoRegionRep
    {
        $region = $opportunity->getRegion();
        $customer = $this->customerHierarchy->getCustomerForLevel($opportunity->getCustomer());
        $repCode = $opportunity->getRepCode();
        $fiscalYear = $opportunity->getFiscalYear();
        if (null === $region || null === $customer || null === $fiscalYear || null === $repCode) {
            throw new \RuntimeException('Could not provide Region Rep!');
        }
        if ($regionRep = $this->findRegionRep($region, $repCode, $customer, $fiscalYear)) {
            return $regionRep;
        }

        if ($createIfNotExisting) {
            return $this->regionRepCreator->createRegionRep($opportunity);
        }

        throw new \RuntimeException('Could not provide Region Rep!');
    }

    /**
     * @param Region $region
     * @param RepCode $code
     * @param Customer $customer
     * @param string $fiscalYear
     * @return GoRegionRep|null
     */
    private function findRegionRep(Region $region, RepCode $code, Customer $customer, string $fiscalYear): ?GoRegionRep
    {
        $textId = $this->buildTextId($region, $code, $customer, $fiscalYear);
        return $textId ? $this
            ->doctrine
            ->getManagerForClass(GoRegionRep::class)
            ->getRepository(GoRegionRep::class)
            ->findOneBy([
                'textId' => $this->buildTextId($region, $code, $customer, $fiscalYear)
            ]) : null;
    }

    /**
     * @param Region $region
     * @param RepCode $repCode
     * @param Customer $customer
     * @param string $fiscalYear
     * @return string|null
     */
    private function buildTextId(Region $region, RepCode $repCode, Customer $customer, string $fiscalYear): ?string
    {
        return $this->textIdProvider->getTextId(new Request([], [
            'region' => $region->getId(),
            'repCode' => $repCode->getId(),
            'kcg_customer_segment' => $this->customerSegmentProvider->getCustomerSegment($customer),
            'fiscalYear' => $fiscalYear
        ]));
    }
}
