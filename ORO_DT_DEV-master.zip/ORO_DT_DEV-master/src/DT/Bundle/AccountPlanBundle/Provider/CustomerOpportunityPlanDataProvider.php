<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Exception\EntityNotSetException;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunitySalesType;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\Repository\GoOpportunityRepository;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;

/**
 * Default implementation of CustomerPlanDataProviderInterface. Iterates over customer opportunities
 * and gathers data
 */
class CustomerOpportunityPlanDataProvider implements CustomerPlanDataProviderInterface
{
    /** @var Customer */
    private $customer;

    /** @var string|null */
    private $fiscalYear;

    /** @var EnumValueProvider */
    private $enumValueProvider;

    /** @var array|GoOpportunity[][] */
    private $opportunities = [];

    /** @var ManagerRegistry */
    private $doctrine;

    /** @var GoOpportunityRepository */
    private $opportunityRepo;

    /**
     * Sets Enum Value provider instance
     *
     * @param EnumValueProvider $enumValueProvider
     * @return self
     */
    public function setEnumValueProvider(EnumValueProvider $enumValueProvider): self
    {
        $this->enumValueProvider = $enumValueProvider;
        return $this;
    }

    /**
     * Sets manager registry
     *
     * @param ManagerRegistry $doctrine
     * @return self
     */
    public function setManagerRegistry(ManagerRegistry $doctrine): self
    {
        $this->doctrine = $doctrine;
        return $this;
    }

    /**
     * Setting determining if the plan data must be gathered from the
     * defined Customer or the Customer and it's children customers
     *
     * @var bool
     */
    private $useCustomerTree = true;

    /**
     * Sets on/off setting for customer tree usage on
     * data calculation
     *
     * @param bool $isEnabled
     * @return self
     */
    public function setUseCustomerTree(bool $isEnabled = true): self
    {
        $this->useCustomerTree = $isEnabled;
        return $this;
    }

    /**
     * @return GoOpportunityRepository
     */
    private function getOpportunityRepository(): GoOpportunityRepository
    {
        if (null === $this->opportunityRepo) {
            $this->opportunityRepo = $this
                ->doctrine
                ->getManagerForClass(GoOpportunity::class)
                ->getRepository(GoOpportunity::class);
        }

        return $this->opportunityRepo;
    }

    /**
     * {@inheritdoc}
     */
    public function setCustomerAccount(Customer $customer)
    {
        $this->customer = $customer;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setFiscalYear(?string $year)
    {
        $this->fiscalYear = $year;
        return $this;
    }

    /**
     * Provides customers entities for
     * gathering data
     *
     * @param Customer $customer
     * @return Customer[]|array
     */
    private function getCustomers(Customer $customer): array
    {
        return $this->useCustomerTree
            ? $this->customerTreeToArray($customer)
            : [$customer];
    }

    /**
     * Provides flattened customer tree
     *
     * @param Customer $customer
     * @return Customer[]|array
     */
    private function customerTreeToArray(Customer $customer): array
    {
        $customers = [$customer];
        foreach ($customer->getChildren() as $child) {
            $customers = array_merge($customers, $this->customerTreeToArray($child));
        }

        return $customers;
    }

    /**
     * Validates if customer set. In case not
     * - throws exception \DT\Bundle\AccountPlanBundle\Exception\EntityNotSetException
     */
    private function validateCustomerSet(): void
    {
        if (null === $this->customer) {
            throw new EntityNotSetException(Customer::class);
        }
    }

    /**
     * @param Customer $customer
     * @return array|GoOpportunity[]
     */
    private function getCustomerOpportunities(Customer $customer): array
    {
        if (!array_key_exists($customer->getId(), $this->opportunities)) {
            return $this->opportunities[$customer->getId()] = $this->doGetOpportunities($customer);
        }

        return $this->opportunities[$customer->getId()];
    }

    /**
     * @param Customer $customer
     * @return array
     */
    private function doGetOpportunities(Customer $customer): array
    {
        $opportunities = [];
        foreach ($this->getCustomers($customer) as $treeCustomer) {
            $opportunities = array_merge(
                $opportunities,
                $this->getOpportunitiesResult($treeCustomer)
            );
        }

        return $opportunities;
    }

    /**
     * @param Customer $customer
     * @return array
     */
    private function getOpportunitiesResult(Customer $customer): array
    {
        $queryBuilder = $this->getOpportunityRepository()->getCustomerOpportunitiesQb($customer);
        if (null !== $this->fiscalYear) {
            $queryBuilder->andWhere($queryBuilder->expr()->eq('o.fiscalYear', ':fiscalYear'));
            $queryBuilder->setParameter('fiscalYear', $this->fiscalYear);
        }
        $queryBuilder->andWhere($queryBuilder->expr()->eq('o.opportunity_record_type', ':recordType'));
        $queryBuilder->innerJoin('o.opportunityGroup', 'g');

        $queryBuilder->setParameter('recordType', $this->getRecordType());

        return $queryBuilder->getQuery()->execute();
    }

    /**
     * @return AbstractEnumValue
     */
    private function getRecordType(): AbstractEnumValue
    {
        return $this
            ->enumValueProvider
            ->getEnumValueByCode(
                GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE,
                OpportunityRecordType::TYPE_HVAC_GO_PLAN
            );
    }

    /**
     * {@inheritdoc}
     */
    public function getAccountGoal(): ?float
    {
        $this->validateCustomerSet();
        return $this->sum(function (GoOpportunity $opportunity) {
            return $opportunity->getTargetedOpportunityValue();
        });
    }

    /**
     * @param callable $callback
     * @param null|callable $filter
     * @return float|null
     */
    protected function sum(callable $callback, ?callable $filter = null): ?float
    {
        $results = [];
        foreach ($this->getCustomerOpportunities($this->customer) as $opportunity) {
            if ((null === $filter) || $filter($opportunity)) {
                $results[] = $callback($opportunity);
            }
        }

        return count($results) && ($sum = array_sum($results))
            ? (float)$sum
            : null;
    }

    /**
     * {@inheritdoc}
     */
    public function getPriorYearSales(): ?float
    {
        $this->validateCustomerSet();
        return $this->sum(function (GoOpportunity $opportunity) {
            return $opportunity->getPy();
        });
    }

    /**
     * {@inheritdoc}
     */
    public function getActualYtd(): ?float
    {
        $this->validateCustomerSet();
        return $this->sum(function (GoOpportunity $opportunity) {
            return $opportunity->getYtd();
        });
    }

    /**
     * {@inheritdoc}
     */
    public function getPriorYtd(): ?float
    {
        $this->validateCustomerSet();
        return $this->getPriorYearSales();
    }

    /**
     * {@inheritdoc}
     */
    public function getCurrentYearValueKeep(): ?float
    {
        $this->validateCustomerSet();
        return $this->sum(function (GoOpportunity $opportunity) {
            return $opportunity->getTargetedOpportunityValue();
        }, function (GoOpportunity $opportunity) {
            $type = $opportunity->getSalesOpportunityType();
            return $type && $type->getId() === OpportunitySalesType::TYPE_KEEP;
        });
    }

    /**
     * {@inheritdoc}
     */
    public function getCurrentYearValueConvert(): ?float
    {
        $this->validateCustomerSet();
        return $this->sum(function (GoOpportunity $opportunity) {
            return $opportunity->getTargetedOpportunityValue();
        }, function (GoOpportunity $opportunity) {
            $type = $opportunity->getSalesOpportunityType();
            return $type && $type->getId() === OpportunitySalesType::TYPE_CONVERT;
        });
    }

    /**
     * {@inheritdoc}
     */
    public function getCurrentYearValueGrow(): ?float
    {
        $this->validateCustomerSet();
        return $this->sum(function (GoOpportunity $opportunity) {
            return $opportunity->getTargetedOpportunityValue();
        }, function (GoOpportunity $opportunity) {
            $type = $opportunity->getSalesOpportunityType();
            return $type && $type->getId() === OpportunitySalesType::TYPE_GROW;
        });
    }

    /**
     * {@inheritdoc}
     */
    public function getCurrentYearValueNpi(): ?float
    {
        $this->validateCustomerSet();
        return $this->sum(function (GoOpportunity $opportunity) {
            return $opportunity->getTargetedOpportunityValue();
        }, function (GoOpportunity $opportunity) {
            $type = $opportunity->getSalesOpportunityType();
            return $type && $type->getId() === OpportunitySalesType::TYPE_NPI;
        });
    }

    /**
     * {@inheritdoc}
     */
    public function getCurrentYearValuePipeline(): ?float
    {
        $this->validateCustomerSet();
        return $this->sum(function (GoOpportunity $opportunity) {
            return $opportunity->getTargetedOpportunityValue();
        }, function (GoOpportunity $opportunity) {
            $type = $opportunity->getSalesOpportunityType();
            return $type && $type->getId() === OpportunitySalesType::TYPE_PIPELINE;
        });
    }

    /**
     * {@inheritdoc}
     */
    public function getOpportunities(): array
    {
        $this->validateCustomerSet();
        return $this->getCustomerOpportunities($this->customer);
    }
}
