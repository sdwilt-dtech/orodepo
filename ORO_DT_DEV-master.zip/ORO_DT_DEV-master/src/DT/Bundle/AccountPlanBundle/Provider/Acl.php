<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

class Acl
{
    public const ACL_ASSIGN_STAGE_WITHOUT_VALUES = 'dt_account_plan_assign_stage_without_values';
}
