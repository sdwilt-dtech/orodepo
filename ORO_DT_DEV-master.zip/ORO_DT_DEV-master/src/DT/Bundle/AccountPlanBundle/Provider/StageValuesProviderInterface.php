<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;

interface StageValuesProviderInterface
{
    /**
     * Returns opportunitiy stage values for certain opportunity type
     *
     * @param string $type
     * @return array|GoOpportunityStage[]
     */
    public function getStageValues(string $type): array;

    /**
     * Returns stage by it's name
     *
     * @param string $name
     * @return GoOpportunityStage
     */
    public function getStage(string $name): ?GoOpportunityStage;

    /**
     * Finds stage by ID
     *
     * @param int $stageId
     * @return GoOpportunityStage|null
     */
    public function getStageById(int $stageId): ?GoOpportunityStage;
}
