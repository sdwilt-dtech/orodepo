<?php

namespace DT\Bundle\AccountPlanBundle\Provider;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\Provider\TextId\RegionRepTextIdProvider;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;
use DT\Bundle\CustomerBundle\Provider\CustomerSegmentProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Symfony\Component\HttpFoundation\Request;

class RegionRepFromOpportunityCreator implements OpportunityRegionRepCreatorInterface
{
    /** @var CustomerHierarchy */
    private $customerHierarchy;

    /** @var CustomerSegmentProvider */
    private $customerSegmentProvider;

    /** @var RegionRepTextIdProvider */
    private $textIdProvider;

    /** @var ManagerRegistry */
    private $doctrine;

    /** @var EnumValueProvider */
    private $enumProvider;

    /**
     * @param CustomerHierarchy $customerHierarchy
     * @param CustomerSegmentProvider $customerSegmentProvider
     * @param RegionRepTextIdProvider $textIdProvider
     * @param ManagerRegistry $doctrine
     * @param EnumValueProvider $enumProvider
     */
    public function __construct(
        CustomerHierarchy $customerHierarchy,
        CustomerSegmentProvider $customerSegmentProvider,
        RegionRepTextIdProvider $textIdProvider,
        ManagerRegistry $doctrine,
        EnumValueProvider $enumProvider
    ) {
        $this->customerHierarchy = $customerHierarchy;
        $this->customerSegmentProvider = $customerSegmentProvider;
        $this->textIdProvider = $textIdProvider;
        $this->doctrine = $doctrine;
        $this->enumProvider = $enumProvider;
    }

    /**
     * {@inheritdoc}
     */
    public function createRegionRep(GoOpportunity $opportunity): GoRegionRep
    {
        $region = $opportunity->getRegion();
        $customer = $this->customerHierarchy->getCustomerForLevel($opportunity->getCustomer());
        $repCode = $opportunity->getRepCode();
        $fiscalYear = $opportunity->getFiscalYear();
        $request = new Request([], [
            'region' => $region->getId(),
            'repCode' => $repCode->getId(),
            'kcg_customer_segment' => $this->customerSegmentProvider->getCustomerSegment($customer),
            'fiscalYear' => $fiscalYear
        ]);

        $customerSegment = $this->customerSegmentProvider->getCustomerSegment($customer);
        $textId = $this->textIdProvider->getTextId($request);
        $businessUnit = $this
            ->doctrine
            ->getManagerForClass(BusinessUnit::class)
            ->getRepository(BusinessUnit::class)
            ->findOneBy([
                'dt_agency_rep_code' => $repCode
            ]);
        if (!$textId || !$businessUnit || !$customerSegment) {
            throw new \RuntimeException('Could not create Region Rep from Opportunity!');
        }
        $name = $this->textIdProvider->getName($request);

        /** @var GoRegionRep $regionRep */
        $regionRep = (new GoRegionRep())
            ->setName($name)
            ->setTextId($textId)
            ->setSalesAgency($businessUnit)
            ->setRepCode($repCode)
            ->setRegion($region)
            ->setKcgCustomerSegment($this->enumProvider->getEnumValueByCode(
                GoRegionRep::ENUM_KCG_CUSTOMER_SEGMENT,
                $customerSegment
            ));

        return $regionRep;
    }
}
