<?php

namespace DT\Bundle\AccountPlanBundle\Model;

class GoOpportunity extends AbstractMetricAwareModel
{
    /** @var \DT\Bundle\EntityBundle\Entity\GoOpportunity */
    protected $entity;
}
