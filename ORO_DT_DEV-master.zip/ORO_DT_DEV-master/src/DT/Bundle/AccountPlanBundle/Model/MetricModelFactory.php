<?php

namespace DT\Bundle\AccountPlanBundle\Model;

use DT\Bundle\AccountPlanBundle\Provider\MetricsProvider;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

/**
 * Provides read-only metrics-aware entity wrapper models
 * for given classes
 */
class MetricModelFactory
{
    private const DEFAULT_MAP = [
        \DT\Bundle\EntityBundle\Entity\GoOpportunity::class => GoOpportunity::class,
        \DT\Bundle\EntityBundle\Entity\GoAccountPlan::class => GoAccountPlan::class
    ];

    /** @var MetricsProvider */
    private $registry;

    /** @var array|string */
    private $map;

    /**
     * @param MetricsProvider $registry
     */
    public function __construct(MetricsProvider $registry, array $map = self::DEFAULT_MAP)
    {
        $this->registry = $registry;
        $this->map = $map;
    }

    /**
     * Returns metrics aware model for given entity
     *
     * @param MetricsAwareInterface $entity
     * @return AbstractMetricAwareModel
     */
    public function getModel(MetricsAwareInterface $entity): AbstractMetricAwareModel
    {
        $className = $this->getClassName($entity);
        /** @var AbstractMetricAwareModel $model */
        $model = new $className($this->registry, $entity);

        return $model;
    }

    /**
     * @param MetricsAwareInterface $entity
     * @return string
     */
    private function getClassName(MetricsAwareInterface $entity): string
    {
        $className = get_class($entity);
        if (!array_key_exists($className, $this->map)) {
            throw new \InvalidArgumentException(sprintf(
                'Metrics model does not exist for class %s!',
                $className
            ));
        }

        return $this->map[$className];
    }
}
