<?php

namespace DT\Bundle\AccountPlanBundle\Model;

class Context
{
    /** @var array */
    private $attributes = [];

    /**
     * @param array $attributes
     */
    public function __construct(array $attributes)
    {
        $this->attributes = $attributes;
    }

    /**
     * Returns true if given key exists
     *
     * @param string $key
     * @return bool
     */
    public function has(string $key): bool
    {
        return array_key_exists($key, $this->attributes);
    }

    public function get(string $key, $default = null)
    {
        return $this->has($key) ? $this->attributes[$key] : $default;
    }

    /**
     * Sets the datum into context
     *
     * @param string $key
     * @param mixed $datum
     * @return self
     */
    public function set(string $key, $datum): self
    {
        $this->attributes[$key] = $datum;
        return $this;
    }
}
