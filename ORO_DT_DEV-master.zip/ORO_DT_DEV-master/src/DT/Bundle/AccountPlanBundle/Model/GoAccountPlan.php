<?php

namespace DT\Bundle\AccountPlanBundle\Model;

class GoAccountPlan extends AbstractMetricAwareModel
{
    /** @var \DT\Bundle\EntityBundle\Entity\GoAccountPlan */
    protected $entity;
}
