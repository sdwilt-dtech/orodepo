<?php

namespace DT\Bundle\AccountPlanBundle\Model;

use DT\Bundle\AccountPlanBundle\Provider\MetricsProvider;
use DT\Bundle\EntityBundle\EntityProperty\MetricsAwareInterface;

/**
 * Provides abstraction for all metrics aware objects
 */
abstract class AbstractMetricAwareModel
{
    /** @var MetricsProvider */
    protected $metricsProvider;

    /** @var MetricsAwareInterface */
    protected $entity;

    /**
     * @param MetricsProvider $metricsProvider
     * @param MetricsAwareInterface $entity
     */
    public function __construct(MetricsProvider $metricsProvider, MetricsAwareInterface $entity)
    {
        $this->entity = $entity;
        $this->metricsProvider = $metricsProvider;
    }

    /**
     * Magic getter for entity or metric values
     *
     * @param string $name
     * @param array $arguments
     * @return mixed|null
     */
    public function __call(string $name, array $arguments)
    {
        // Calculated metrics take priority over entity properties
        if (substr($name, 0, 3) === 'get') {
            $metric = substr($name, 3);
            $metricValue = $this->metricsProvider->getMetric($this->entity, $metric);
            if ($metricValue) {
                return $metricValue;
            }
        }

        if (method_exists($this->entity, $name)) {
            return call_user_func_array([$this->entity, $name], $arguments);
        }

        return null;
    }
}
