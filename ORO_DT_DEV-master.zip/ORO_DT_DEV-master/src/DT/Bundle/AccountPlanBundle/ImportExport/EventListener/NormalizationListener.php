<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\EventListener;

use DT\Bundle\AccountPlanBundle\ImportExport\DataPopulator\Headers;
use DT\Bundle\AccountPlanBundle\ImportExport\NormalizationContext;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\ImportExportBundle\Event\NormalizeEntityEvent;

/**
 * Normalization only used for Template sheet generation.
 * That is why the subject of normalization is GoRegionRep,
 * not GoOpportunity
 */
class NormalizationListener
{
    /**
     * Handles normalization
     *
     * @param NormalizeEntityEvent $event
     */
    public function __invoke(NormalizeEntityEvent $event)
    {
        /** @var NormalizationContext $context */
        if (($context = $event->getObject()) instanceof NormalizationContext) {
            $this->populateContext($context);
        }
    }

    /**
     * Populates row data with entity data
     *
     * @param NormalizationContext $context
     */
    private function populateContext(NormalizationContext $context): void
    {
        foreach ($this->getNormalizedData($context->getRegionRep()) as $header => $datum) {
            $context->setDatum($header, $datum);
        }
    }

    /**
     * Returns normalized data array
     *
     * @param GoRegionRep $regionRep
     * @return array
     */
    private function getNormalizedData(GoRegionRep $regionRep): array
    {
        $result = [];
        /** @var GoOpportunityGroup $opportunityGroup */
        $opportunityGroup = $regionRep->getOpportunityGroups()->first();
        /** @var GoOpportunity $opportunity */
        $opportunity = $opportunityGroup->getOpportunities()->first();

        $result[Headers::KEY_CONCAT] = $this->getConcat($regionRep, $opportunityGroup, $opportunity);
        $result[Headers::KEY_REGION] = $regionRep->getRegion()->getJdeId();
        $result[Headers::KEY_REP_JDE_ID] = $regionRep->getRepCode()->getCode();
        $result[Headers::KEY_REP_NAME] = $regionRep->getSalesAgency()->getName();
        $result[Headers::KEY_CUSTOMER_JDE_ID] = $opportunityGroup->getCustomer()->getDtJdeId();
        $result[Headers::KEY_CUSTOMER_NAME] = $opportunityGroup->getCustomer()->getName();
        $result[Headers::KEY_CATEGORY_JDE_ID] = $opportunity->getProductCategoryCode()->getCode();
        $result[Headers::KEY_CATEGORY_NAME] = $opportunity->getProductCategoryCode()->getName();
        $result[Headers::PREFIX_KEY_YTD_YEAR . $opportunity->getFiscalYear()] = $opportunity->getYtd();
        $result[Headers::KEY_LIKEHOOD_PERCENT] = 0;
        $result[Headers::KEY_REVENUE_START_DATE] = 'MAR';
        $result[Headers::KEY_OPPORTUNITY_AMOUNT] = $opportunity->getCalculatedOpportunityValue();
        $result[Headers::KEY_OPPORTUNITY_STAGE] = $opportunity->getStage()->getName();
        $result[Headers::KEY_PY] = $opportunity->getPy();
        $result[Headers::KEY_VERIFIED_TOTAL_CATEGORY_VALUE] = $opportunity->getVerifiedTotalCategoryValue();
        $result[Headers::KEY_TARGETED_OPPORTUNITY_VALUE] = $opportunity->getTargetedOpportunityValue();
        $result[Headers::KEY_CUSTOMER_SEGMENT] = 'Strategic';
        $result[Headers::KEY_YEAR] = $opportunity->getFiscalYear();
        $result[Headers::KEY_ASK_QUARTER] = sprintf('Q%s', $opportunity->getAskQuarter());
        $result[Headers::KEY_GP_CLOSE_DATE] = $opportunity->getGpCloseDate()->format('Y-m-d');
        $result[Headers::KEY_CLOSE_DATE] = $opportunity->getCloseDate()->format('Y-m-d');
        $result[Headers::KEY_BUSINESS_CHALLENGER] = implode(',', array_map(function (AbstractEnumValue $value) {
            return $value->getId();
        }, $opportunity->getBusinessChallenger()->toArray()));
        $result[Headers::KEY_OTHER_BUSINESS_CHALLENGER] = $opportunity->getOtherBusinessChallenger();
        $result[Headers::KEY_SALES_OPPORTUNITY_TYPE] = $opportunity->getSalesOpportunityType()
            ? $opportunity->getSalesOpportunityType()->getId()
            : null;

        return $result;
    }

    /**
     * @param GoRegionRep $regionRep
     * @param GoOpportunityGroup $opportunityGroup
     * @param GoOpportunity $opportunity
     * @return string
     */
    private function getConcat(
        GoRegionRep $regionRep,
        GoOpportunityGroup $opportunityGroup,
        GoOpportunity $opportunity
    ): string {
        return sprintf(
            '%s%s%s%s',
            $regionRep->getRegion()->getJdeId(),
            $regionRep->getRepCode()->getCode(),
            $opportunityGroup->getCustomer()->getDtJdeId(),
            $opportunity->getProductCategoryCode()->getCode()
        );
    }
}
