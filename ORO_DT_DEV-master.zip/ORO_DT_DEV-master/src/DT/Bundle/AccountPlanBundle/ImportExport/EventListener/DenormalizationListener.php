<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\EventListener;

use DT\Bundle\AccountPlanBundle\ImportExport\ImportDataPopulatorInterface;
use DT\Bundle\AccountPlanBundle\ImportExport\NormalizationContext;
use Oro\Bundle\ImportExportBundle\Event\DenormalizeEntityEvent;

class DenormalizationListener
{
    /** @var ImportDataPopulatorInterface[] */
    private $populators;

    /**
     * @param iterable|ImportDataPopulatorInterface[] $populators
     */
    public function __construct(iterable $populators)
    {
        foreach ($populators as $populator) {
            $this->addPopulator($populator);
        }
    }

    /**
     * Registers populator instance
     *
     * @param ImportDataPopulatorInterface $populator
     * @return self
     */
    public function addPopulator(ImportDataPopulatorInterface $populator): self
    {
        $this->populators[] = $populator;
        return $this;
    }

    /**
     * @param DenormalizeEntityEvent $event
     */
    public function __invoke(DenormalizeEntityEvent $event)
    {
        /** @var NormalizationContext $context */
        if (($context = $event->getObject()) instanceof NormalizationContext) {
            $this->populateContext($context);
        }
    }

    /**
     * @param NormalizationContext $context
     */
    private function populateContext(NormalizationContext $context): void
    {
        foreach ($this->getPopulators() as $populator) {
            $populator->populate($context);
        }
    }

    /**
     * Provides ordered populators registered in the service
     *
     * @return array|ImportDataPopulatorInterface[]
     */
    protected function getPopulators(): array
    {
        $populators = $this->populators;
        usort($populators, function (ImportDataPopulatorInterface $pop1, ImportDataPopulatorInterface $pop2) {
            $priority1 = $pop1->getPriority();
            $priority2 = $pop2->getPriority();

            if ($priority1 == $priority2) {
                return 0;
            }

            return $priority1 < $priority2 ? -1 : 1;
        });

        return $populators;
    }
}
