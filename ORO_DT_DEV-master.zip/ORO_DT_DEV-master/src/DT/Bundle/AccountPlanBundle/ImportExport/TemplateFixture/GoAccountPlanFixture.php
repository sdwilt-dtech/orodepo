<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\TemplateFixture;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;

class GoAccountPlanFixture extends AbstractAccountPlanFixture
{
    /**
     * {@inheritdoc}
     */
    public function getEntityClass(): string
    {
        return GoAccountPlan::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getData(): \Iterator
    {
        return $this->getEntityData('example-go-account-plan');
    }

    /**
     * {@inheritdoc}
     */
    public function fillEntityData($key, $entity): void
    {
        /** @var GoAccountPlan $entity */
        $entity->setName('Account Plan');
        $entity->setCustomer($this->getCustomer());
        $entity->setCurrency('USD');
        $entity->setSalesforceId('SFID12');
        $entity->setCreatedAt(new \DateTime('-3 days'));
        $entity->setUpdatedAt(new \DateTime('-1 days'));
        $entity->setOwner($this->getUser());
        $entity->setOrganization($this->getOrganization());
        $entity->addOpportunity($this->getOpportunity());
        $entity->setAccountDollar(1.1);
        $entity->setPriorYtd(1000.50);
        $entity->setTotalPriorYearSales(2000.50);
        $entity->setActualYtd(1500.50);
        $entity->setCurrentYearValueKeep(1500.50);
        $entity->setCurrentYearValueGrow(500.50);
        $entity->setCurrentYearValueConvert(400.50);
        $entity->setCurrentYearValueNpi(400.50);
        $entity->setCurrentYearValuePipeline(400.50);
    }

    /**
     * {@inheritdoc}
     */
    protected function createEntity($key)
    {
        return new GoAccountPlan();
    }
}
