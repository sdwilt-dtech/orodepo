<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\TemplateFixture;

use DT\Bundle\AccountPlanBundle\Provider\Enums\SalesOpportunityType;
use DT\Bundle\CustomerBundle\Provider\CustomerSegmentProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;

class GoRegionRepFixture extends AbstractAccountPlanFixture
{
    /** @var array|string[] */
    private $segments = [
        CustomerSegmentProvider::SEGMENT_CORE,
        CustomerSegmentProvider::SEGMENT_NATIONAL,
        CustomerSegmentProvider::SEGMENT_STRATEGIC
    ];

    /** @var AbstractEnumValue */
    private $segment;

    /**
     * {@inheritdoc}
     */
    protected function createEntity($key)
    {
        return new GoRegionRep();
    }

    /**
     * Fills data
     *
     * @param string $key
     * @param GoRegionRep $regionRep
     */
    public function fillEntityData($key, $regionRep)
    {
        $region = $this->getRegion();
        $agency = $this->getAgency();
        $segment = $this->getSegment();
        $name = sprintf(
            '%s-%s-%s-%d',
            $region->getJdeId(),
            $agency->getName(),
            $segment->getName(),
            $this->getYear()
        );

        $textId = sprintf(
            '%s%s%s%s',
            $region->getJdeId(),
            $segment->getName(),
            $this->getRepCode()->getCode(),
            $this->getYear()
        );

        $regionRep
            ->setTextId($textId)
            ->setName($name)
            ->setOrganization($this->getOrganization())
            ->setSalesAgency($agency)
            ->setRegion($region)
            ->setRepCode($this->getRepCode())
            ->setKcgCustomerSegment($segment);

        $regionRep->addOpportunityGroup($this->getOpportunityGroup());
    }

    /**
     * @return int
     */
    private function getYear(): int
    {
        return (int)date('Y') + 1;
    }

    /**
     * @return GoOpportunityGroup
     */
    protected function getOpportunityGroup(): GoOpportunityGroup
    {
        $name = sprintf(
            '%s-%s-%s-%d',
            $this->getRegion()->getJdeId(),
            $this->getAgency()->getName(),
            $this->getCustomer()->getName(),
            $this->getYear()
        );
        $textId = sprintf(
            '%s%s%s%s',
            $this->getRegion()->getJdeId(),
            $this->getRepCode()->getCode(),
            $this->getCustomer()->getDtJdeId(),
            $this->getYear()
        );

        $group = (new GoOpportunityGroup())
            ->setRepCode($this->getRepCode())
            ->setCustomer($this->getCustomer())
            ->setTextId($textId)
            ->setRegion($this->getRegion())
            ->setSalesAgency($this->getAgency())
            ->setOrganization($this->getOrganization())
            ->setName($name);

        $group->addOpportunity($this->getOpportunity());

        return $group;
    }

    /**
     * @return GoOpportunity
     */
    protected function getOpportunity(): GoOpportunity
    {
        $name = sprintf(
            '%s-%s-%s-%s-%d',
            $this->getRegion()->getJdeId(),
            $this->getRepCode()->getCode(),
            $this->getCustomer()->getName(),
            'Sample Category',
            $this->getYear()
        );
        $textId = sprintf(
            '%s%s%s%s%d',
            $this->getRegion()->getJdeId(),
            $this->getRepCode()->getCode(),
            $this->getCustomer()->getDtJdeId(),
            $this->getCategory()->getCode(),
            $this->getYear()
        );

        $opportunity = new GoOpportunity();
        $opportunity->setTextId($textId)
            ->setName($name)
            ->setFiscalYear($this->getYear())
            ->setFiscalQuarter(4)
            ->setAskQuarter(4)
            ->setLikehood(0)
            ->setGpCloseDate(new \DateTime('+60 days'))
            ->setCloseDate(new \DateTime('+60 days'))
            ->setProductCategoryCode($this->getCategory())
            ->setCustomer($this->getCustomer())
            ->setOrganization($this->getOrganization());
        $opportunity->setAmount(1000.00)
            ->setYtd(500.00)
            ->setPy(5000.00)
            ->setTargetedOpportunityValue(1000.00)
            ->setVerifiedTotalCategoryValue(2000.00)
            ->setStage($this->getStage());

        $businessChallenger = $this
            ->enumValueProvider
            ->getEnumValueByCode(GoOpportunity::ENUM_BUSINESS_CHALLENGER, 'Mars');

        $opportunity->getBusinessChallenger()->add($businessChallenger);

        $salesOpportunityType = $this
            ->enumValueProvider
            ->getEnumValueByCode(GoOpportunity::ENUM_SALES_OPPORTUNITY_TYPE, SalesOpportunityType::TYPE_GROW);

        $opportunity->setSalesOpportunityType($salesOpportunityType);


        return $opportunity;
    }

    /**
     * @return AbstractEnumValue
     */
    private function getSegment(): AbstractEnumValue
    {
        if (null === $this->segment) {
            $this->segment = $this->doGetSegment();
        }

        return $this->segment;
    }

    /**
     * @return AbstractEnumValue
     */
    private function doGetSegment(): AbstractEnumValue
    {
        $key = array_rand($this->segments);
        $segment = $this->segments[$key];
        return $this->enumValueProvider->getEnumValueByCode(GoRegionRep::ENUM_KCG_CUSTOMER_SEGMENT, $segment);
    }

    /**
     * @return GoOpportunityStage
     */
    private function getStage(): GoOpportunityStage
    {
        return $this->stageValuesProvider->getStage('0. Pipeline');
    }

    /**
     * {@inheritdoc}
     */
    public function getEntityClass()
    {
        return GoRegionRep::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getData()
    {
        return $this->getEntityData(1);
    }
}
