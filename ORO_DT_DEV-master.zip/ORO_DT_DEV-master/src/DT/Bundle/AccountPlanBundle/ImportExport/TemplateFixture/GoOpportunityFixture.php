<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\TemplateFixture;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;

class GoOpportunityFixture extends AbstractAccountPlanFixture
{
    /**
     * {@inheritdoc}
     */
    public function getEntityClass(): string
    {
        return GoOpportunity::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getData(): \Iterator
    {
        return $this->getEntityData('example-go-opportunity');
    }

    /**
     * {@inheritdoc}
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function fillEntityData($key, $entity): void
    {
        /** @var GoOpportunity $entity */
        $entity->setName('CR101DESIGN AIR - bE-Lite®2020');
        $entity->setAccount($this->getCustomer());
        $entity->setTextId('CR101209702020');
        $entity->setPy(340.80);
        $entity->setTarget(1000);
        $entity->setAmount(800);
        $entity->setProbability(50);
        $entity->setLikehood(100);
        $entity->setYtd(800);
        $entity->setOtherBusinessChallenger('Other challenger name');
        $entity->setCloseDate(new \DateTime('+60 days'));
        $entity->setGpCloseDate(new \DateTime('+60 days'));
        $entity->setPriorityRating(50);
        $entity->setCalculatedOpportunityValue(900);
        $entity->setFiscalYear((new \DateTime())->format('Y'));
        $entity->setFiscalQuarter(4);
        $entity->setTargetedOpportunityValue(1200);
        $entity->setVerifiedTotalCategoryValue(100);
        $entity->setDollarAmountWon(80);
        $entity->setOtherHvacCompetitor('Other HVAC Competitor name');
        $entity->setNotes('Notes');
        $entity->setExplanationForLoss('Explanation for loss');
        $entity->setRevenueStartDate(12);
        $entity->setAskQuarter(4);
        $entity->setAccountPlan($this->getAccountPlan());
        $entity->setProductCategoryCode($this->getCategory());
        $entity->setRegion($this->getRegion());
        $entity->setBusinessUnit($this->getAgency());
        $entity->setNextStep('Next Step Name');
        $entity->setJobQuote(true);
        $entity->setJobQuoteName('Job Quote Name');
        $entity->setDateSampleSent(new \DateTime('-1 days'));
        $entity->setSituationDescription('Situation description');
        $entity->setNotifyCustomerContact($this->getContact());
        $entity->setNotifySalesRep($this->getUser());
        $entity->setNotifyRsm($this->getUser());
        $entity->setCreatedAt(new \DateTime('-3 days'));
        $entity->setUpdatedAt(new \DateTime('-1 days'));
        $entity->setOwner($this->getUser());
        $entity->setOrganization($this->getOrganization());
        $entity->setOpportunityGroup($this->getOpportunityGroup());
        $entity->setStage($this->stageValuesProvider->getStage('0. Pipeline'));
        $entity->setBusinessChallenger(
            [
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunity::ENUM_BUSINESS_CHALLENGER,
                'AC Guard'
            )]
        );
        $entity->setHvacCompetitor(
            [
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunity::ENUM_BUSINESS_CHALLENGER,
                'AC Guard'
            )]
        );
        $entity->setOpportunityType(
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunity::ENUM_SALES_OPPORTUNITY_TYPE,
                'Convert'
            )
        );
        $entity->setForecastCategory(
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunity::ENUM_FORECAST_CATEGORY,
                'Omitted'
            )
        );
        $entity->setReasonClosedLost(
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunity::ENUM_REASON_FOR_CLOSED_LOST,
                'End of year Go Plan'
            )
        );
        $entity->setOpportunityType(
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunity::ENUM_OPPORTUNITY_TYPE,
                'Job Quote'
            )
        );
        $entity->setOpportunitySource(
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunity::ENUM_OPPORTUNITY_SOURCE,
                'Regional Manager'
            )
        );
        $entity->setOpportunityRecordType(
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE,
                'HVAC Go Plan'
            )
        );
        $entity->setSalesInitiativeType(
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunity::ENUM_SALES_INITIATIVE_TYPE,
                'Product'
            )
        );
    }

    /**
     * {@inheritdoc}
     */
    protected function createEntity($key)
    {
        return new GoOpportunity();
    }
}
