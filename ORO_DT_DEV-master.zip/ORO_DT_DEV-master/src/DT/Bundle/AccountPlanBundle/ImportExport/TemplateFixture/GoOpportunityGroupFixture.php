<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\TemplateFixture;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;

class GoOpportunityGroupFixture extends AbstractAccountPlanFixture
{
    /**
     * {@inheritdoc}
     */
    public function getEntityClass(): string
    {
        return GoOpportunityGroup::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getData(): \Iterator
    {
        return $this->getEntityData('example-go-opportunity-group');
    }

    /**
     * {@inheritdoc}
     */
    public function fillEntityData($key, $entity): void
    {
        /** @var GoOpportunityGroup $entity */
        $entity->setTextId('CR101209702020');
        $entity->setName('CR-A to Z SAL-DESIGN AIR - bill to-2020');
        $entity->setCreatedAt(new \DateTime('-3 days'));
        $entity->setUpdatedAt(new \DateTime('-1 days'));
        $entity->setOwner($this->getUser());
        $entity->setOrganization($this->getOrganization());
        $entity->setCustomer($this->getCustomer());
        $entity->setBusinessUnit($this->getAgency());
        $entity->setCurrency('USD');
        $entity->setSalesforceId('SFID12');
        $entity->setRepCode($this->getRepCode());
        $entity->setRegion($this->getRegion());
        $entity->setRegionRep($this->getRegionRep());
        $entity->setOpportunityYear(
            $this->enumValueProvider->getEnumValueByCode(
                GoOpportunityGroup::ENUM_OPPORTUNITY_YEAR,
                'Current'
            )
        );
        $entity->setRegionalManagerEmail('reg_manager_email@example.com');
        $entity->setSalesSupportEmail('sales_sup_email@example.com');
        $entity->addPlanAgent($this->getPlanAgent());
        $entity->addOpportunity($this->getOpportunity());
        $entity->setState('US');
    }

    /**
     * {@inheritdoc}
     */
    protected function createEntity($key)
    {
        return new GoOpportunityGroup();
    }
}
