<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\TemplateFixture;

use DT\Bundle\AccountPlanBundle\Provider\StageValuesProviderInterface;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoPlanAgent;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\ContactBundle\Entity\Contact;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;
use Oro\Bundle\ImportExportBundle\TemplateFixture\AbstractTemplateRepository;
use Oro\Bundle\ImportExportBundle\TemplateFixture\TemplateFixtureInterface;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Oro\Bundle\OrganizationBundle\Entity\Organization;
use Oro\Bundle\UserBundle\Entity\User;

abstract class AbstractAccountPlanFixture extends AbstractTemplateRepository implements TemplateFixtureInterface
{
    /** @var string[]|array */
    protected $regions = [
        ['CR' => 'North Central Region'],
        ['SER' => 'South East Region']
    ];

    /** @var EnumValueProvider */
    protected $enumValueProvider;

    /** @var Customer */
    protected $customer;

    /** @var BusinessUnit */
    protected $agency;

    /** @var RepCode */
    protected $repCode;

    /** @var Organization */
    protected $organization;

    /** @var ProductCategoryCode */
    protected $category;

    /** @var Region */
    protected $region;

    /** @var StageValuesProviderInterface */
    protected $stageValuesProvider;

    /**
     * @param EnumValueProvider $enumValueProvider
     */
    public function __construct(EnumValueProvider $enumValueProvider, StageValuesProviderInterface $stageValuesProvider)
    {
        $this->stageValuesProvider = $stageValuesProvider;
        $this->enumValueProvider = $enumValueProvider;
    }

    /**
     * @return Customer
     */
    protected function getCustomer(): Customer
    {
        if (null === $this->customer) {
            $parent = $this
                ->templateManager
                ->getEntityFixture(Customer::class)
                ->getEntity(2);
            $parent->setOwner($this->getUser());
            $this->customer = $this
                ->templateManager
                ->getEntityFixture(Customer::class)
                ->getEntity(1);
            $this->customer->setName('Sample Customer');
            $this->customer->setDtJdeId('234');
            $this->customer->setParent($parent);
        }

        return $this->customer;
    }

    /**
     * @return Customer
     */
    protected function getCustomerParent(): Customer
    {
        return $this
                ->templateManager
                ->getEntityFixture(Customer::class)
                ->getEntity(2)
            ->setName('Sample Customer Parent')
            ->setDtJdeId('345');
    }

    /**
     * @return BusinessUnit
     */
    protected function getAgency(): BusinessUnit
    {
        if (null === $this->agency) {
            $this->agency = (new BusinessUnit())
                ->setOrganization($this->getOrganization())
                ->setName('Sample Agency')
                ->setDtAgencyRepCode($this->getRepCode())
                ->setDtIsAgency(true);
        }

        return $this->agency;
    }

    /**
     * @return RepCode
     */
    protected function getRepCode(): RepCode
    {
        if (null === $this->repCode) {
            $this->repCode = (new RepCode())->setCode('123')->setOrganization($this->getOrganization());
        }

        return $this->repCode;
    }

    /**
     * @return Organization
     */
    protected function getOrganization(): Organization
    {
        if (null === $this->organization) {
            $this->organization = (new Organization())->setName('Test Organization')->setEnabled(true);
        }

        return $this->organization;
    }

    /**
     * @return User
     */
    protected function getUser(): User
    {
        $userRepo = $this->templateManager->getEntityRepository(User::class);
        return $userRepo->getEntity('John Doo');
    }

    /**
     * @return GoOpportunityGroup
     */
    protected function getOpportunityGroup(): GoOpportunityGroup
    {
        $opportunityGroupRepo = $this->templateManager->getEntityRepository(GoOpportunityGroup::class);
        return $opportunityGroupRepo->getEntity('example-go-opportunity-group');
    }

    /**
     * @return GoPlanAgent
     */
    protected function getPlanAgent(): GoPlanAgent
    {
        $planAgentRepo = $this->templateManager->getEntityRepository(GoPlanAgent::class);
        return $planAgentRepo->getEntity('example-go-plan-agent');
    }

    /**
     * @return GoOpportunity
     */
    protected function getOpportunity(): GoOpportunity
    {
        $opportunityRepo = $this->templateManager->getEntityRepository(GoOpportunity::class);
        return $opportunityRepo->getEntity('example-go-opportunity');
    }

    /**
     * @return GoAccountPlan
     */
    protected function getAccountPlan(): GoAccountPlan
    {
        $opportunityRepo = $this->templateManager->getEntityRepository(GoAccountPlan::class);
        return $opportunityRepo->getEntity('example-go-account-plan');
    }

    /**
     * @return ProductCategoryCode
     */
    protected function getCategory(): ProductCategoryCode
    {
        if (null === $this->category) {
            $this->category = (new ProductCategoryCode())->setCode('456');
        }

        return $this->category;
    }

    /**
     * @return Contact
     */
    protected function getContact(): Contact
    {
        $contactRepo = $this->templateManager->getEntityRepository(Contact::class);
        return $contactRepo->getEntity('Jerry Coleman');
    }

    /**
     * @return Region
     */
    protected function getRegion(): Region
    {
        if (null === $this->region) {
            $this->region = $this->doGetRegion();
        }

        return $this->region;
    }

    /**
     * @return Region
     */
    protected function doGetRegion(): Region
    {
        $key = array_rand($this->regions);
        $regionDatum = $this->regions[$key];
        $code = key($regionDatum);
        $name = reset($regionDatum);
        return (new Region())
            ->setOrganization($this->getOrganization())
            ->setJdeId($code)
            ->setSalesforceId($code)
            ->setName($name);
    }

    /**
     * @return GoRegionRep
     */
    protected function getRegionRep(): GoRegionRep
    {
        return $this
            ->templateManager
            ->getEntityFixture(GoRegionRep::class)
            ->getEntity(1);
    }
}
