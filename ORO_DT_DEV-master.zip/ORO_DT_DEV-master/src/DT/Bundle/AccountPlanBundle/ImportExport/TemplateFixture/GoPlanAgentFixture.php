<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\TemplateFixture;

use DT\Bundle\EntityBundle\Entity\GoPlanAgent;

class GoPlanAgentFixture extends AbstractAccountPlanFixture
{
    /**
     * {@inheritdoc}
     */
    public function getEntityClass(): string
    {
        return GoPlanAgent::class;
    }

    /**
     * {@inheritdoc}
     */
    public function getData(): \Iterator
    {
        return $this->getEntityData('example-go-plan-agent');
    }

    /**
     * {@inheritdoc}
     */
    public function fillEntityData($key, $entity): void
    {
        /** @var GoPlanAgent $entity */
        $entity->setName('CR-A to Z SALES');
        $entity->setOpportunityPercent(50);
        $entity->setCreatedAt(new \DateTime('-3 days'));
        $entity->setUpdatedAt(new \DateTime('-1 days'));
        $entity->setOrganization($this->getOrganization());
        $entity->setUser($this->getUser());
        $entity->setOpportunityGroup($this->getOpportunityGroup());
        $entity->setRecordType(
            $this->enumValueProvider->getEnumValueByCode(
                GoPlanAgent::ENUM_RECORD_TYPE,
                'GP CY Agents'
            )
        );
    }

    /**
     * {@inheritdoc}
     */
    protected function createEntity($key)
    {
        return new GoPlanAgent();
    }
}
