<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Processor;

use Akeneo\Bundle\BatchBundle\Item\InvalidItemException;
use DT\Bundle\AccountPlanBundle\ImportExport\Exception\NormalizationException;
use DT\Bundle\AccountPlanBundle\ImportExport\Traits\RegionRepsAwareTrait;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\ImportExportBundle\Processor\ImportProcessor;

class GoRepsYearlyMigrationImportProcessor extends ImportProcessor
{
    use RegionRepsAwareTrait;

    /**
     * {@inheritdoc}
     */
    public function process($item)
    {
        try {
            /** @var GoRegionRep $object */
            $entity = parent::process($item);
        } catch (NormalizationException $exc) {
            throw new InvalidItemException($exc->getMessage(), $item);
        }

        if ($entity && !$this->hasRegionRep($entity->getTextId())) {
            $this->addRegionRep($entity);
            return $entity;
        }

        return null;
    }
}
