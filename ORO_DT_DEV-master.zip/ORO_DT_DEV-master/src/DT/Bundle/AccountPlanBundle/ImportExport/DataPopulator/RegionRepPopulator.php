<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\DataPopulator;

use DT\Bundle\AccountPlanBundle\ImportExport\Exception\NormalizationException;
use DT\Bundle\AccountPlanBundle\ImportExport\NormalizationContext;
use DT\Bundle\AccountPlanBundle\ImportExport\Traits\RegionRepsAwareTrait;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\EntityBundle\Entity\Repository\GoRegionRepRepository;
use DT\Bundle\EntityBundle\EntityProperty\TextIdAwareInterface;

/**
 * Populates context with region reps records
 */
class RegionRepPopulator extends AbstractEntityAwarePopulator
{
    use RegionRepsAwareTrait;

    protected const PRIORITY = 10;

    /**
     * {@inheritdoc}
     * @param GoRegionRep $entity
     */
    protected function registerExisting(TextIdAwareInterface $entity): void
    {
        $this->addRegionRep($entity);
    }

    /**
     * {@inheritdoc}
     * @param GoRegionRep $entity
     */
    protected function registerInContext(TextIdAwareInterface $entity, NormalizationContext $context): void
    {
        $context->setRegionRep($entity);
    }

    /**
     * {@inheritdoc}
     */
    protected function createOrFetchEntity(NormalizationContext $context): TextIdAwareInterface
    {
        /** @var GoRegionRepRepository $repository */
        $repository = $this->getRepo(GoRegionRep::class);
        $regionRep = $repository->getOrCreate($this->getTextId($context));
        $this->populateRegionRep($regionRep, $context);

        return $regionRep;
    }

    /**
     * {@inheritdoc}
     */
    protected function hasEntity(string $textId): bool
    {
        return $this->hasRegionRep($textId);
    }

    /**
     * {@inheritdoc}
     */
    protected function getEntity(string $textId): TextIdAwareInterface
    {
        return $this->getRegionRep($textId);
    }

    /**
     * @param GoRegionRep $regionRep
     * @param NormalizationContext $context
     */
    private function populateRegionRep(
        GoRegionRep $regionRep,
        NormalizationContext $context
    ): void {
        $regionId = $context->validateGet(Headers::KEY_REGION);
        $agencyName = $context->validateGet(Headers::KEY_AGENCY_NAME);
        $segment = $context->getFromArray(
            Headers::KEY_CUSTOMER_SEGMENT,
            $this->calculateSegment($context->validateGet(Headers::KEY_CUSTOMER_JDE_ID))
        );
        $agencyId = $context->validateGet(Headers::KEY_REP_JDE_ID);
        $year = $context->validateGet(Headers::KEY_YEAR);
        $regionRep->setName($this->combineStrings([$regionId, $agencyName, $segment, $year]));
        $this->addRepCode($regionRep, $agencyId);
        $this->addRegion($regionRep, $regionId);
        $this->addAgency($regionRep, $agencyId);
        $this->addCustomerSegment($regionRep, $segment);
    }

    /**
     * @param GoRegionRep $regionRep
     * @param string $segment
     * @throws NormalizationException
     */
    private function addCustomerSegment(GoRegionRep $regionRep, string $segment): void
    {
        $enum = $this->getEnumEntity($segment, GoRegionRep::ENUM_KCG_CUSTOMER_SEGMENT);
        if (null === $enum) {
            throw new NormalizationException(sprintf(
                '%s enum value %s does not exist.',
                GoRegionRep::ENUM_KCG_CUSTOMER_SEGMENT,
                $segment
            ));
        }

        $regionRep->setKcgCustomerSegment($enum);
    }

    /**
     * {@inheritdoc}
     */
    public function getTextId(NormalizationContext $context): string
    {
        $regionId = $context->validateGet(Headers::KEY_REGION);
        $segment = $context->getFromArray(
            Headers::KEY_CUSTOMER_SEGMENT,
            $this->calculateSegment($context->validateGet(Headers::KEY_CUSTOMER_JDE_ID))
        );
        $jdeId = $context->validateGet(Headers::KEY_REP_JDE_ID);
        $year = $context->validateGet(Headers::KEY_YEAR);

        return $this->combineStrings([$regionId, $segment, $jdeId, $year], '');
    }
}
