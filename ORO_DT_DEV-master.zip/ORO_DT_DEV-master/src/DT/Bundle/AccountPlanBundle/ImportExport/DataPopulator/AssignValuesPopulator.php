<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\DataPopulator;

use DT\Bundle\AccountPlanBundle\ImportExport\ImportDataPopulatorInterface;
use DT\Bundle\AccountPlanBundle\ImportExport\NormalizationContext;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;

/**
 * Handles context gathered data binding into the
 * Region Rep entity
 */
class AssignValuesPopulator implements ImportDataPopulatorInterface
{
    /**
     * {@inheritdoc}
     */
    public function populate(NormalizationContext $context): void
    {
        $regionRep = $context->getRegionRep();
        if (!$regionRep) {
            throw new \LogicException('Region Rep entity is not present in the import context!');
        }

        $this->doPopulate($regionRep, $context);
    }

    /**
     * @param GoRegionRep $regionRep
     * @param NormalizationContext $context
     */
    protected function doPopulate(GoRegionRep $regionRep, NormalizationContext $context): void
    {
        foreach ($context->getOpportunityGroups() as $group) {
            $this->populateWithOpportunities($group, $context->getOpportunities());
            $regionRep->addOpportunityGroup($group);
        }
    }

    /**
     * @param GoOpportunityGroup $group
     * @param array|GoOpportunity[] $opportunities
     */
    private function populateWithOpportunities(GoOpportunityGroup $group, array $opportunities): void
    {
        foreach ($opportunities as $opportunity) {
            if ($opportunity->getParentTextId() === $group->getTextId()) {
                $this->assignOpportunity($group, $opportunity);
            }
        }
    }

    /**
     * @param GoOpportunityGroup $group
     * @param GoOpportunity $opportunity
     */
    private function assignOpportunity(GoOpportunityGroup $group, GoOpportunity $opportunity): void
    {
        $group->addOpportunity($opportunity);
        $group->getOrganization() && $opportunity->setOrganization($group->getOrganization());
        $group->getCustomer() && $opportunity->setCustomer($group->getCustomer());
    }

    /**
     * {@inheritdoc}
     */
    public function getPriority(): int
    {
        return 40;
    }
}
