<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\DataPopulator;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\ImportExport\ImportDataPopulatorInterface;
use DT\Bundle\AccountPlanBundle\ImportExport\NormalizationContext;
use DT\Bundle\AccountPlanBundle\ImportExport\Traits\OpportunityGroupAwareTrait;
use DT\Bundle\AccountPlanBundle\Model\GoOpportunity;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\Repository\GoOpportunityGroupRepository;
use DT\Bundle\EntityBundle\EntityProperty\RegionAwareInterface;
use DT\Bundle\EntityBundle\EntityProperty\TextIdAwareInterface;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;

/**
 * Populates opportunity groups
 */
class OpportunityGroupPopulator extends AbstractEntityAwarePopulator implements ImportDataPopulatorInterface
{
    use OpportunityGroupAwareTrait;

    protected const PRIORITY = 20;

    /** @var CustomerHierarchy */
    private $customerHierarchy;

    /**
     * @param ManagerRegistry $doctrine
     * @param EnumValueProvider $enumValueProvider
     * @param CustomerHierarchy $customerHierarchy
     */
    public function __construct(
        ManagerRegistry $doctrine,
        EnumValueProvider $enumValueProvider,
        CustomerHierarchy $customerHierarchy
    ) {
        $this->customerHierarchy = $customerHierarchy;
        parent::__construct($doctrine, $enumValueProvider);
    }

    /**
     * {@inheritdoc}
     * @param GoOpportunityGroup $entity
     */
    protected function registerExisting(TextIdAwareInterface $entity): void
    {
        $this->addOpportunityGroup($entity);
    }

    /**
     * {@inheritdoc}
     * @param GoOpportunityGroup $entity
     */
    protected function registerInContext(TextIdAwareInterface $entity, NormalizationContext $context): void
    {
        $context->addOpportunityGroup($entity);
    }

    /**
     * {@inheritdoc}
     */
    protected function createOrFetchEntity(NormalizationContext $context): TextIdAwareInterface
    {
        /** @var GoOpportunityGroupRepository $repository */
        $repository = $this->getRepo(GoOpportunityGroup::class);
        $opportunityGroup = $repository->getOrCreate($this->getTextId($context));
        $this->populateOpportunityGroup($opportunityGroup, $context);

        return $opportunityGroup;
    }

    /**
     * {@inheritdoc}
     */
    protected function hasEntity(string $textId): bool
    {
        return $this->hasOpportunityGroup($textId);
    }

    /**
     * {@inheritdoc}
     */
    protected function getEntity(string $textId): TextIdAwareInterface
    {
        return $this->getOpportunityGroup($textId);
    }

    /**
     * @param GoOpportunityGroup $opportunityGroup
     * @param NormalizationContext $context
     */
    private function populateOpportunityGroup(GoOpportunityGroup $opportunityGroup, NormalizationContext $context): void
    {
        $regionId = $context->validateGet(Headers::KEY_REGION);
        $customerName = $context->validateGet(Headers::KEY_CUSTOMER_NAME);
        $agencyName = $context->validateGet(Headers::KEY_AGENCY_NAME);
        $agencyId = $context->validateGet(Headers::KEY_REP_JDE_ID);
        $customerId = $context->validateGet(Headers::KEY_CUSTOMER_JDE_ID);
        $year = $context->validateGet(Headers::KEY_YEAR);
        $opportunityGroup->setName($this->combineStrings([
            $regionId,
            $agencyName,
            $customerName,
            $year
        ]));
        $opportunityGroup->setFiscalYear($year);
        $this->addRepCode($opportunityGroup, $agencyId);
        $this->addRegion($opportunityGroup, $regionId);
        $this->addAgency($opportunityGroup, $agencyId);
        $this->addCustomer($opportunityGroup, $customerId);
        $opportunityGroup->setOpportunityYear(
            $this->getEnumEntity('Current', GoOpportunityGroup::ENUM_OPPORTUNITY_YEAR)
        );
    }

    /**
     * @param RegionAwareInterface|GoOpportunityGroup|GoOpportunity $entity
     * @param string $regionCode
     */
    protected function addRegion($entity, string $regionCode): void
    {
        parent::addRegion($entity, $regionCode);
        $region = $entity->getRegion();
        if ($salesSupport = $region->getSalesSupport()) {
            $entity->setSalesSupportEmail($salesSupport->getEmail());
        }
        if ($regionalSupport = $region->getRegionalManager()) {
            $entity->setRegionalManagerEmail($regionalSupport->getEmail());
        }
    }

    /**
     * {@inheritdoc}
     */
    protected function getCustomer(string $jdeCode, ?string $type = null): ?Customer
    {
        $customer = parent::getCustomer($jdeCode, $type);
        return $this->customerHierarchy->getCustomerForBillingType($customer) ?: $customer;
    }

    /**
     * {@inheritdoc}
     */
    public function getTextId(NormalizationContext $context): string
    {
        $regionId = $context->validateGet(Headers::KEY_REGION);
        $jdeId = $context->validateGet(Headers::KEY_REP_JDE_ID);
        $year = $context->validateGet(Headers::KEY_YEAR);
        $customerId = $context->validateGet(Headers::KEY_CUSTOMER_JDE_ID);

        return $this->combineStrings([$regionId, $jdeId, $customerId, $year], '');
    }
}
