<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\DataPopulator;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\AccountPlanBundle\ImportExport\Exception\NormalizationException;
use DT\Bundle\AccountPlanBundle\ImportExport\NormalizationContext;
use DT\Bundle\AccountPlanBundle\ImportExport\Traits\OpportunityAwareTrait;
use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use DT\Bundle\AccountPlanBundle\Provider\Enums\SalesOpportunityType;
use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\DataProvider\Criteria;
use DT\Bundle\AccountPlanBundle\Provider\GoOpportunity\OpportunityDataProvider;
use DT\Bundle\AccountPlanBundle\Provider\StageValuesProviderInterface;
use DT\Bundle\CustomerBundle\Provider\CustomerHierarchy;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\ProductCategoryCode;
use DT\Bundle\EntityBundle\Entity\Repository\GoOpportunityRepository;
use DT\Bundle\EntityBundle\EntityProperty\TextIdAwareInterface;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;

class OpportunityPopulator extends AbstractEntityAwarePopulator
{
    use OpportunityAwareTrait;

    protected const PRIORITY = 30;

    /** @var OpportunityGroupPopulator */
    private $opportunityGroupPopulator;

    /** @var StageValuesProviderInterface */
    private $stageProvider;

    /** @var CustomerHierarchy */
    private $customerHierarchy;

    /** @var OpportunityDataProvider */
    private $opportunityDataProvider;

    /** @var bool */
    private $updateFromPrevious = true;

    /**
     * @param ManagerRegistry $doctrine
     * @param EnumValueProvider $enumValueProvider
     * @param OpportunityGroupPopulator $opportunityGroupPopulator
     * @param StageValuesProviderInterface $stageProvider
     * @param CustomerHierarchy $customerHierarchy
     * @param OpportunityDataProvider $opportunityDataProvider
     */
    public function __construct(
        ManagerRegistry $doctrine,
        EnumValueProvider $enumValueProvider,
        OpportunityGroupPopulator $opportunityGroupPopulator,
        StageValuesProviderInterface $stageProvider,
        CustomerHierarchy $customerHierarchy,
        OpportunityDataProvider $opportunityDataProvider
    ) {
        $this->opportunityGroupPopulator = $opportunityGroupPopulator;
        $this->stageProvider = $stageProvider;
        $this->customerHierarchy = $customerHierarchy;
        $this->opportunityDataProvider = $opportunityDataProvider;
        parent::__construct($doctrine, $enumValueProvider);
    }

    /**
     * Defines a way to get previous year opp values if not found
     * in the file. Disabled by default.
     *
     * @param bool $isUpdateFromPrevious
     * @return self
     */
    public function setUpdateFromPrevious(bool $isUpdateFromPrevious): self
    {
        $this->updateFromPrevious = $isUpdateFromPrevious;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    protected function getCustomer(string $jdeCode, ?string $type = null): ?Customer
    {
        $customer = parent::getCustomer($jdeCode, $type);
        return $this->customerHierarchy->getCustomerForBillingType($customer) ?: $customer;
    }

    /**
     * {@inheritdoc}
     * @param GoOpportunity $entity
     */
    protected function registerExisting(TextIdAwareInterface $entity): void
    {
        $this->addOpportunity($entity);
    }

    /**
     * {@inheritdoc}
     * @param GoOpportunity $entity
     */
    protected function registerInContext(TextIdAwareInterface $entity, NormalizationContext $context): void
    {
        $context->addOpportunity($entity);
    }

    /**
     * {@inheritdoc}
     */
    protected function createOrFetchEntity(NormalizationContext $context): TextIdAwareInterface
    {
        /** @var GoOpportunityRepository $repository */
        $repository = $this->getRepo(GoOpportunity::class);
        $opportunity = $repository->getOrCreate($this->getTextId($context));
        $this->populateOpportunity($opportunity, $context);

        return $opportunity;
    }

    /**
     * {@inheritdoc}
     */
    protected function hasEntity(string $textId): bool
    {
        return $this->hasOpportunity($textId);
    }

    /**
     * {@inheritdoc}
     */
    protected function getEntity(string $textId): TextIdAwareInterface
    {
        return $this->getOpportunity($textId);
    }

    /**
     * @param GoOpportunity $opportunity
     * @param NormalizationContext $context
     */
    private function populateOpportunity(GoOpportunity $opportunity, NormalizationContext $context): void
    {
        $regionId = $context->validateGet(Headers::KEY_REGION);
        $jdeId = $context->validateGet(Headers::KEY_REP_JDE_ID);
        $customerName = $context->validateGet(Headers::KEY_CUSTOMER_NAME);
        $year = $context->validateGet(Headers::KEY_YEAR);
        $categoryId = $context->validateGet(Headers::KEY_CATEGORY_JDE_ID);
        $categoryName = $context->validateGet(Headers::KEY_CATEGORY_NAME);

        $opportunity->setParentTextId($this->getParentTextId($context));
        $opportunity->setName($this->combineStrings([
            $regionId,
            $jdeId,
            $customerName,
            $categoryName,
            $year
        ]));
        $opportunity->setFiscalYear($year);
        $this->addCustomer($opportunity, $context->validateGet(Headers::KEY_CUSTOMER_JDE_ID));
        $this->addCategory($opportunity, $categoryId);
        $closeDate = $context->getFromArray(Headers::KEY_CLOSE_DATE, $this->getCloseDate($year));
        $opportunity->setCloseDate($this->parseDate($closeDate));
        if ($gpCloseDate = $context->getFromArray(Headers::KEY_GP_CLOSE_DATE)) {
            $opportunity->setGpCloseDate($this->parseDate($gpCloseDate));
        } else {
            $opportunity->setGpCloseDate($opportunity->getCloseDate());
        }
        $this->addStageName($opportunity, $context);
        $this->addYtd($opportunity, $context);
        $this->addPy($opportunity, $context);
        $this->addBusinessChallenger($opportunity, $context);
        $this->addRegion($opportunity, $regionId);
        $this->addAgency($opportunity, $jdeId);
        $this->addRepCode($opportunity, $jdeId);
        $opportunity->setOpportunityRecordType(
            $this->getEnumEntity(
                OpportunityRecordType::TYPE_HVAC_GO_PLAN,
                GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE
            )
        );
        $opportunity->setLikehood(
            ($likehood = $context->getFromArray(Headers::KEY_LIKEHOOD_PERCENT)) ? (int)$likehood : null
        );
        $opportunity->setRevenueStartDate(
            ($rsd = $context->getFromArray(Headers::KEY_REVENUE_START_DATE))
                ? $this->formatRevenueStartDate($rsd)
                : null
        );
        $opportunity->setAskQuarter(
            ($askQuarter = $context->getFromArray(Headers::KEY_ASK_QUARTER))
                ? (int)$this->formatAskQuarter($askQuarter)
                : null
        );
        $opportunity->setOtherBusinessChallenger($context->getFromArray(Headers::KEY_OTHER_BUSINESS_CHALLENGER));
        $this->addAmounts($opportunity, $context);

        $this->addSalesOpportunityType($opportunity, $context);
    }

    /**
     * @param string $month
     * @return int
     * @throw NormalizationException
     */
    private function formatRevenueStartDate(string $month): int
    {
        $lowerMonth = strtolower(trim($month));
        $time = strtotime(sprintf('1st %s 2020', $lowerMonth));

        if (!$time) {
            throw new NormalizationException(sprintf(
                'Could not parse revenue start date month `%s`!',
                $month
            ));
        }

        return (int)date('m', $time);
    }

    /**
     * @param string $askQuarter
     * @return int
     * @throw NormalizationException
     */
    private function formatAskQuarter(string $askQuarter): int
    {
        $lowerQuarter = strtolower(trim($askQuarter));
        $exploded = str_split($lowerQuarter);
        if ((!count($exploded) === 2) || (!$exploded[0] === 'q') || !ctype_digit($exploded[1])) {
            throw new NormalizationException(sprintf(
                'Could not parse ask quarter `%s`!',
                $askQuarter
            ));
        }

        return (int)$exploded[1];
    }

    /**
     * @param string $dateString
     * @return \DateTime
     */
    private function parseDate(string $dateString): \DateTime
    {
        $dateTime = new \DateTime();
        $dateTime->setTimestamp(strtotime($dateString));

        return $dateTime;
    }

    /**
     * @param GoOpportunity $opportunity
     * @param NormalizationContext $context
     */
    private function addAmounts(GoOpportunity $opportunity, NormalizationContext $context): void
    {
        if ($calculatedOpportunityValue = $context->getFromArray(Headers::KEY_OPPORTUNITY_AMOUNT)) {
            $opportunity->setCalculatedOpportunityValue($calculatedOpportunityValue);
            $opportunity->setAmount($calculatedOpportunityValue);
        }

        if ($verifiedTotalCategoryValue = $context->getFromArray(Headers::KEY_VERIFIED_TOTAL_CATEGORY_VALUE)) {
            $opportunity->setVerifiedTotalCategoryValue($verifiedTotalCategoryValue);
        }

        if ($targetedValue = $context->getFromArray(Headers::KEY_TARGETED_OPPORTUNITY_VALUE)) {
            $opportunity->setTargetedOpportunityValue($targetedValue);
        }

        if (true === $this->updateFromPrevious) {
            $criteria = new Criteria(
                $opportunity->getRegion(),
                $opportunity->getCustomer(),
                $opportunity->getProductCategoryCode(),
                $opportunity->getFiscalYear()
            );
            if (!$opportunity->getPy()) {
                $opportunity->setPy($this->opportunityDataProvider->getData($criteria, 'py'));
            }

            if (!$opportunity->getYtd()) {
                $opportunity->setYtd($this->opportunityDataProvider->getData($criteria, 'ytd'));
            }
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @param NormalizationContext $context
     */
    private function addBusinessChallenger(GoOpportunity $opportunity, NormalizationContext $context): void
    {
        if ($challenger = $context->getFromArray(Headers::KEY_BUSINESS_CHALLENGER)) {
            $normalized = array_map(function (string $challengerSplit) {
                $challengerName = trim($challengerSplit);
                return $challengerName ? $this->enumValueProvider->getEnumValueByCode(
                    GoOpportunity::ENUM_BUSINESS_CHALLENGER,
                    $challengerName
                ) : null;
            }, explode(',', $challenger));

            $existingChallengers = $opportunity->getBusinessChallenger();
            foreach (array_filter($normalized) as $challengerValue) {
                $existingChallengers->add($challengerValue);
            }
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @param NormalizationContext $context
     */
    private function addYtd(GoOpportunity $opportunity, NormalizationContext $context): void
    {
        $year = $context->validateGet(Headers::KEY_YEAR);
        $ytd = $context->getFromArray(sprintf(Headers::PREFIX_KEY_YTD_YEAR . '%s', $year));
        if ($ytd) {
            $opportunity->setYtd($ytd);
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @param NormalizationContext $context
     */
    private function addPy(GoOpportunity $opportunity, NormalizationContext $context): void
    {
        $year = $context->validateGet(Headers::KEY_YEAR);
        $ytd = $context->getFromArray(sprintf(Headers::PREFIX_KEY_FULL_YEAR . '%s', $year));
        if ($ytd) {
            $opportunity->setYtd($ytd);
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @param NormalizationContext $context
     * @throws NormalizationException
     */
    private function addStageName(GoOpportunity $opportunity, NormalizationContext $context): void
    {
        $stageName = $context->getFromArray(Headers::KEY_OPPORTUNITY_STAGE);

        if ($stageName) {
            $stage = $this->stageProvider->getStage($stageName);
            if (null === $stage) {
                throw new NormalizationException(sprintf(
                    'Stage entity for name %s does not exist.',
                    $stageName
                ));
            }

            $opportunity->setStage($stage);
            $probability = $stage->getProbability();
            $opportunity->setProbability($probability);
            $opportunity->setForecastCategory($stage->getForecastCategory());
        } else {
            $opportunity->setProbability(0);
        }
    }

    /**
     * @param string $year
     * @return \DateTime
     */
    private function getCloseDate(string $year): \DateTime
    {
        $dateTime = new \DateTime();
        $dateTime->setTimestamp(strtotime(sprintf('%s-12-31 00:00:00', $year)));

        return $dateTime;
    }

    /**
     * {@inheritdoc}
     */
    public function getTextId(NormalizationContext $context): string
    {
        $regionId = $context->validateGet(Headers::KEY_REGION);
        $jdeId = $context->validateGet(Headers::KEY_REP_JDE_ID);
        $year = $context->validateGet(Headers::KEY_YEAR);
        $customerId = $context->validateGet(Headers::KEY_CUSTOMER_JDE_ID);
        $categoryId = $context->validateGet(Headers::KEY_CATEGORY_JDE_ID);

        return $this->combineStrings([$regionId, $jdeId, $customerId, $categoryId, $year], '');
    }

    /**
     * @param NormalizationContext $context
     * @return string
     */
    public function getParentTextId(NormalizationContext $context): string
    {
        return $this->opportunityGroupPopulator->getTextId($context);
    }

    /**
     * @param GoOpportunity $opportunity
     * @param string $categoryCode
     */
    private function addCategory(GoOpportunity $opportunity, string $categoryCode): void
    {
        $repository = $this->getRepo(ProductCategoryCode::class);
        /** @var ProductCategoryCode $categoryCode */
        $categoryCode = $repository->findOneBy([
            'code' => $categoryCode
        ]);

        if ($categoryCode) {
            $opportunity->setProductCategoryCode($categoryCode);
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @param NormalizationContext $context
     */
    private function addSalesOpportunityType(GoOpportunity $opportunity, NormalizationContext $context): void
    {
        $value = $context->getFromArray(Headers::KEY_SALES_OPPORTUNITY_TYPE, SalesOpportunityType::TYPE_GO_PLAN);
        $opportunity->setSalesOpportunityType(
            $this->getEnumEntity($value, GoOpportunity::ENUM_SALES_OPPORTUNITY_TYPE)
        );
    }
}
