<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\DataPopulator;

use Doctrine\ORM\EntityNotFoundException;
use Doctrine\ORM\EntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Doctrine\Persistence\ObjectRepository;
use DT\Bundle\AccountPlanBundle\ImportExport\Exception\NormalizationException;
use DT\Bundle\AccountPlanBundle\ImportExport\ImportDataPopulatorInterface;
use DT\Bundle\CustomerBundle\Provider\CustomerSegmentProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\Region;
use DT\Bundle\EntityBundle\Entity\RepCode;
use DT\Bundle\EntityBundle\Entity\Repository\RegionRepository;
use DT\Bundle\EntityBundle\EntityProperty\CustomerAccountAwareInterface;
use DT\Bundle\EntityBundle\EntityProperty\RegionAwareInterface;
use DT\Bundle\EntityBundle\EntityProperty\RepCodeAwareInterface;
use DT\Bundle\EntityBundle\EntityProperty\SalesAgencyAwareInterface;
use DT\Bundle\SetupBundle\Entity\ReservedEnumCodes;
use DT\Bundle\SetupBundle\Model\CustomerFields;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Oro\Bundle\OrganizationBundle\Entity\OrganizationAwareInterface;

abstract class AbstractPopulator implements ImportDataPopulatorInterface
{
    protected const NAME_SEPARATOR = '-';

    /* To be overridden in inheriting classes */
    protected const PRIORITY = 0;

    /** @var ManagerRegistry */
    protected $doctrine;

    /** @var EnumValueProvider */
    protected $enumValueProvider;

    /** @var CustomerSegmentProvider */
    protected $customerSegmentProvider;

    /**
     * @param ManagerRegistry $doctrine
     * @param EnumValueProvider $enumValueProvider
     */
    public function __construct(ManagerRegistry $doctrine, EnumValueProvider $enumValueProvider)
    {
        $this->enumValueProvider = $enumValueProvider;
        $this->doctrine = $doctrine;
    }

    /**
     * Sets customer segment name provider
     *
     * @param CustomerSegmentProvider $customerSegmentProvider
     * @return self
     */
    public function setCustomerSegmentProvider(CustomerSegmentProvider $customerSegmentProvider): self
    {
        $this->customerSegmentProvider = $customerSegmentProvider;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getPriority(): int
    {
        return static::PRIORITY;
    }

    /**
     * Returns repository instance for given entity class name
     *
     * @param string $className
     * @return EntityRepository|ObjectRepository
     */
    protected function getRepo(string $className): EntityRepository
    {
        return $this
            ->doctrine
            ->getManagerForClass($className)
            ->getRepository($className);
    }

    /**
     * @param array $parts
     * @param string $separator
     * @return string
     */
    protected function combineStrings(array $parts, string $separator = self::NAME_SEPARATOR): string
    {
        return implode($separator, array_map(function (string $part) {
            return trim($part);
        }, $parts));
    }

    /**
     * Gets region or creates new entity
     *
     * @param string $regionCode
     * @return Region
     */
    protected function getRegion(string $regionCode): Region
    {
        /** @var RegionRepository $repository */
        $repository = $this->getRepo(Region::class);
        $region = $repository->ensureRegionExists($regionCode);
        if (!$region->getId()) {
            $manager = $this->doctrine->getManagerForClass(Region::class);
            $manager->persist($region);
            $manager->flush();
        }

        return $region;
    }

    /**
     * Tries registering an agency, if not avaliable, ommits - data left for validation
     * via entities validators
     *
     * @param SalesAgencyAwareInterface|OrganizationAwareInterface|GoOpportunity $entity
     * @param string $jdeId
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    protected function addAgency($entity, string $jdeId): void
    {
        if (null !== ($agency = $this->getAgency($jdeId))) {
            $entity->setSalesAgency($agency);
            $entity->setOrganization($agency->getOrganization());
        }
    }

    /**
     * Assigns region, ensures region exists in database
     *
     * @param RegionAwareInterface|GoOpportunity $entity
     * @param string $regionCode
     */
    protected function addRegion($entity, string $regionCode): void
    {
        $region = $this->getRegion($regionCode);
        $entity->setRegion($region);
    }

    /**
     * Assigns rep code
     *
     * @param RepCodeAwareInterface $entity
     * @param string $repCode
     */
    protected function addRepCode(RepCodeAwareInterface $entity, string $repCode): void
    {
        $repCode = $this->getRepCode($repCode);
        if (null !== $repCode) {
            $entity->setRepCode($repCode);
        }
    }

    /**
     * Tries assigning customer by ID
     *
     * @param CustomerAccountAwareInterface $entity
     * @param string $jdeId
     */
    protected function addCustomer(CustomerAccountAwareInterface $entity, string $jdeId): void
    {
        $customer = $this->getCustomer($jdeId);
        if (null !== $customer) {
            $entity->setCustomer($customer);
        }
    }

    /**
     * Provides customer with given JDE Code ID if exists
     *
     * @param string $jdeCode
     * @param null|string $type
     * @return Customer|null
     */
    protected function getCustomer(string $jdeCode, ?string $type = null): ?Customer
    {
        $repository = $this->getRepo(Customer::class);
        $enumType = $type
            ? $this
                ->enumValueProvider
                ->getEnumValueByCode(ReservedEnumCodes::DT_CUSTOMER_ENTITY_TYPE, $type)
            : null;
        $criteria = [
            'dt_jde_id' => $jdeCode
        ];
        if (null !== $enumType) {
            $criteria[CustomerFields::DT_ENTITY_TYPE] = $enumType;
        }
        /** @var Customer $customer */
        $customer = $repository->findOneBy($criteria);

        return $customer;
    }

    /**
     * Returns rep code instance for given code string value if one exists
     *
     * @param string $repCode
     * @return RepCode|null
     */
    protected function getRepCode(string $repCode): ?RepCode
    {
        $repository = $this->getRepo(RepCode::class);
        /** @var RepCode $repCodeEntity */
        $repCodeEntity =  $repository->findOneBy([
            'code' => $repCode
        ]);

        return $repCodeEntity;
    }

    /**
     * Returns agency business unit for given JDE code
     *
     * @param string $jdeId
     * @return BusinessUnit|null
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    protected function getAgency(string $jdeId): ?BusinessUnit
    {
        $repository = $this->getRepo(BusinessUnit::class);
        /** @var BusinessUnit $businessUnit */
        $queryBuilder = $repository->createQueryBuilder('bu')
            ->innerJoin('bu.dt_agency_rep_code', 'repCode')
            ->andWhere('repCode.code = :code')
            ->andWhere('bu.dt_is_agency = :isAgency')
            ->setParameter('code', $jdeId)
            ->setParameter('isAgency', true);

        $businessUnit = $queryBuilder->getQuery()->getOneOrNullResult();
        return $businessUnit;
    }

    /**
     * @param string $value
     * @param string $code
     * @return AbstractEnumValue|null
     */
    protected function getEnumEntity(string $value, string $code): ?AbstractEnumValue
    {
        /** @var AbstractEnumValue $entity */
        try {
            $entity = $this->enumValueProvider->getEnumValueByCode($code, trim($value));
            return (null === $entity) || (!$entity->getId()) || (!$entity->getName())
                ? $this->fallbackEnumName($value, $code)
                : $entity;
        } catch (EntityNotFoundException $exc) {
            return $this->fallbackEnumName($value, $code);
        }
    }

    /**
     * @param string $value
     * @param string $code
     * @return AbstractEnumValue|null
     */
    protected function fallbackEnumName(string $value, string $code): ?AbstractEnumValue
    {
        foreach ($this->enumValueProvider->getEnumChoicesByCode($code) as $name => $id) {
            if ($name === $value) {
                $entity = $this->enumValueProvider->getEnumValueByCode($code, $id);
                try {
                    if ($entity && $entity->getId() && $entity->getName()) {
                        return $entity;
                    }
                } catch (EntityNotFoundException $exc) {
                }
            }
        }

        return null;
    }

    /**
     * @param string $jdeCustomerId
     * @return string
     */
    protected function calculateSegment(string $jdeCustomerId): string
    {
        $customer = $this->getCustomer($jdeCustomerId);
        $segment = $customer
            ? $this->customerSegmentProvider->getCustomerSegment($customer)
            : null;

        if (null === $segment) {
            throw new NormalizationException(sprintf(
                'Segment cannot be calculated for given customer with JDE Id %s',
                $jdeCustomerId
            ));
        }

        return $segment;
    }
}
