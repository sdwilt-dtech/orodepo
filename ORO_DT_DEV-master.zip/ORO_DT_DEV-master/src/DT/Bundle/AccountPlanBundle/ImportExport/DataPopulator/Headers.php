<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\DataPopulator;

/**
 * XSLX Financial data import file headers names
 */
class Headers
{
    public const KEY_CONCAT = 'Concat';
    public const KEY_REGION = 'Region Curr';
    public const KEY_YEAR = 'Fiscal Year';
    public const KEY_REP_JDE_ID = 'Rep Curr';
    public const KEY_AGENCY_NAME = 'Rep Curr Name';
    public const KEY_CUSTOMER_JDE_ID = 'Parent';
    public const KEY_CUSTOMER_NAME = 'p Name';
    public const KEY_CATEGORY_NAME = 'Category Invc Name';
    public const KEY_CATEGORY_JDE_ID = 'Category Invc';
    public const KEY_OPPORTUNITY_STAGE = 'Stage';
    public const KEY_OPPORTUNITY_AMOUNT = 'Opportunity Amount';
    public const KEY_VERIFIED_TOTAL_CATEGORY_VALUE = 'Verified Total Category Value';
    public const KEY_TARGETED_OPPORTUNITY_VALUE = 'Targeted Opportunity Value';
    public const KEY_PY = 'PY';
    public const KEY_REP_NAME = 'Rep Curr Name';
    public const KEY_GP_CLOSE_DATE = 'GP Close Date';
    public const KEY_BUSINESS_CHALLENGER = 'Business Challenger';
    public const KEY_OTHER_BUSINESS_CHALLENGER = 'Other Business Challenger';
    public const KEY_SALES_OPPORTUNITY_TYPE = 'Sales Opportunity Type';
    public const KEY_LIKEHOOD_PERCENT = 'Likehood %';
    public const KEY_REVENUE_START_DATE = 'Revenue Start/Lost Date';
    public const KEY_CUSTOMER_SEGMENT = 'Customer Segment';
    public const KEY_CLOSE_DATE = 'Close Date';
    public const KEY_ASK_QUARTER = 'Ask Quarter';

    public const PREFIX_KEY_YTD_YEAR = 'YTD ';
    public const PREFIX_KEY_FULL_YEAR = 'Full Year ';

    public const TAB_NAME = 'All Regions';
}
