<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\DataPopulator;

use DT\Bundle\AccountPlanBundle\ImportExport\NormalizationContext;
use DT\Bundle\EntityBundle\EntityProperty\TextIdAwareInterface;

abstract class AbstractEntityAwarePopulator extends AbstractPopulator
{
    /**
     * {@inheritdoc}
     */
    public function populate(NormalizationContext $context): void
    {
        $entity = $this->buildObject($context);
        $this->registerInContext($entity, $context);
    }

    /**
     * @param NormalizationContext $context
     * @return TextIdAwareInterface
     */
    protected function buildObject(NormalizationContext $context): TextIdAwareInterface
    {
        $textId = $this->getTextId($context);
        if ($this->hasEntity($textId)) {
            return $this->getEntity($textId);
        }

        $entity = $this->createOrFetchEntity($context);
        $this->registerExisting($entity);

        return $entity;
    }

    /**
     * Registers entity for further processing
     *
     * @param TextIdAwareInterface $entity
     */
    abstract protected function registerExisting(TextIdAwareInterface $entity): void;

    /**
     * Registers entity in context object
     *
     * @param TextIdAwareInterface $entity
     * @param NormalizationContext $context
     */
    abstract protected function registerInContext(TextIdAwareInterface $entity, NormalizationContext $context): void;

    /**
     * Creates or fetches the entity
     *
     * @param NormalizationContext $context
     * @return TextIdAwareInterface
     */
    abstract protected function createOrFetchEntity(NormalizationContext $context): TextIdAwareInterface;

    /**
     * Builds text ID from context data
     *
     * @param NormalizationContext $context
     * @return string
     */
    abstract public function getTextId(NormalizationContext $context): string;

    /**
     * Returns true if populator is aware of existing entity for given text ID
     *
     * @param string $textId
     * @return bool
     */
    abstract protected function hasEntity(string $textId): bool;

    /**
     * Returns stored entity by text ID
     *
     * @param string $textId
     * @return TextIdAwareInterface
     */
    abstract protected function getEntity(string $textId): TextIdAwareInterface;
}
