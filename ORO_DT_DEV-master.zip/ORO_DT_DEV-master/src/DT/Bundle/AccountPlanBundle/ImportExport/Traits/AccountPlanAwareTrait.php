<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Traits;

use DT\Bundle\EntityBundle\Entity\GoAccountPlan;

trait AccountPlanAwareTrait
{
    /** @var array|GoAccountPlan[] */
    protected $accountPlans = [];

    /**
     * Returns account plans
     *
     * @return array|GoAccountPlan[]
     */
    public function getAccountPlans(): array
    {
        return $this->accountPlans;
    }

    /**
     * Registers new account plan. Throws exception in case such account plan
     * exists in the context
     *
     * @param GoAccountPlan $accountPlan
     * @return self
     */
    public function addAccountPlan(GoAccountPlan $accountPlan)
    {
        $this->validatePlan($accountPlan);
        $this->accountPlans[$accountPlan->getName()] = $accountPlan;

        return $this;
    }

    /**
     * Returns true if opportunity with same unique identifier exists in the context
     *
     * @param string $name
     * @return bool
     */
    public function hasAccountPlan(string $name): bool
    {
        try {
            $this->validatePlan((new GoAccountPlan())->setName($name));
        } catch (\LogicException $exception) {
            return true;
        }

        return false;
    }

    /**
     * Returns account plan for given text id
     *
     * @param string $name
     * @return GoAccountPlan|null
     */
    public function getAccountPlan(string $name): ?GoAccountPlan
    {
        return $this->accountPlans[$name] ?? null;
    }

    /**
     * @param GoAccountPlan $object
     */
    private function validatePlan(GoAccountPlan $object): void
    {
        if (array_key_exists($object->getName(), $this->accountPlans)) {
            throw new \LogicException(sprintf(
                '%s with name %s already exists in the import context!',
                get_class($object),
                $object->getName()
            ));
        }
    }
}
