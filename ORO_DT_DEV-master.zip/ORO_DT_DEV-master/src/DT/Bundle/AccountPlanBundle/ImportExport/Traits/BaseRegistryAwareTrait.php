<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Traits;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;

trait BaseRegistryAwareTrait
{
    /**
     * @param array $data
     * @param GoOpportunity|GoOpportunityGroup|GoRegionRep $object
     */
    protected function validate(array $data, $object): void
    {
        if (array_key_exists($object->getTextId(), $data)) {
            throw new \LogicException(sprintf(
                '%s with Unique Text ID %s already exists in the import context!',
                get_class($object),
                $object->getTextId()
            ));
        }
    }
}
