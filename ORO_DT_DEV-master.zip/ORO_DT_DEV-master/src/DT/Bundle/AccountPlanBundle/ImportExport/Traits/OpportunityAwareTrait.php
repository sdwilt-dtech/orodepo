<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Traits;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;

trait OpportunityAwareTrait
{
    use BaseRegistryAwareTrait;

    /** @var array|GoOpportunity[] */
    protected $opportunities = [];

    /**
     * Returns opportunities
     *
     * @return array|GoOpportunity[]
     */
    public function getOpportunities(): array
    {
        return $this->opportunities;
    }

    /**
     * Registers new opportunity. Throws exception in case such opportunity
     * exists in the context
     *
     * @param GoOpportunity $opportunity
     * @return self
     */
    public function addOpportunity(GoOpportunity $opportunity)
    {
        $this->validate($this->opportunities, $opportunity);
        $this->opportunities[$opportunity->getTextId()] = $opportunity;

        return $this;
    }

    /**
     * Returns true if opportunity with same unique identifier exists in the context
     *
     * @param string $textId
     * @return bool
     */
    public function hasOpportunity(string $textId): bool
    {
        try {
            $this->validate($this->opportunities, (new GoOpportunity())->setTextId($textId));
        } catch (\LogicException $exception) {
            return true;
        }

        return false;
    }

    /**
     * Returns opportunity for given text id
     *
     * @param string $textId
     * @return GoOpportunity|null
     */
    public function getOpportunity(string $textId): ?GoOpportunity
    {
        return $this->opportunities[$textId] ?? null;
    }
}
