<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Traits;

use DT\Bundle\EntityBundle\Entity\GoRegionRep;

trait RegionRepsAwareTrait
{
    use BaseRegistryAwareTrait;

    /** @var array|GoRegionRep[] */
    protected $regionReps = [];

    /**
     * Returns region reps
     *
     * @return array|GoRegionRep[]
     */
    public function getRegionReps(): array
    {
        return $this->regionReps;
    }

    /**
     * Registers new region rep. Throws exception in case such region rep
     * exists in the context
     *
     * @param GoRegionRep $regionRep
     * @return self
     */
    public function addRegionRep(GoRegionRep $regionRep)
    {
        $this->validate($this->regionReps, $regionRep);
        $this->regionReps[$regionRep->getTextId()] = $regionRep;

        return $this;
    }

    /**
     * Returns true if region rep with same unique identifier exists in the context
     *
     * @param string $textId
     * @return bool
     */
    public function hasRegionRep(string $textId): bool
    {
        try {
            $this->validate($this->regionReps, (new GoRegionRep())->setTextId($textId));
        } catch (\LogicException $exception) {
            return true;
        }

        return false;
    }

    /**
     * Returns region rep
     *
     * @param string $textId
     * @return GoRegionRep|null
     */
    public function getRegionRep(string $textId): ?GoRegionRep
    {
        return $this->regionReps[$textId] ?? null;
    }
}
