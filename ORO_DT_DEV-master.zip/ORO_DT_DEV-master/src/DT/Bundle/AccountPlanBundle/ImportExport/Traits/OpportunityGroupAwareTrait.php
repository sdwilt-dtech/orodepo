<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Traits;

use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;

trait OpportunityGroupAwareTrait
{
    use BaseRegistryAwareTrait;

    /** @var array|GoOpportunityGroup[] */
    protected $opportunityGroups = [];

    /**
     * Returns opportunity groups
     *
     * @return array|GoOpportunityGroup[]
     */
    public function getOpportunityGroups(): array
    {
        return $this->opportunityGroups;
    }

    /**
     * Registers new opportunity group. Throws exception in case such opportunity group
     * exists in the context
     *
     * @param GoOpportunityGroup $opportunityGroup
     * @return self
     */
    public function addOpportunityGroup(GoOpportunityGroup $opportunityGroup)
    {
        $this->validate($this->opportunityGroups, $opportunityGroup);
        $this->opportunityGroups[$opportunityGroup->getTextId()] = $opportunityGroup;

        return $this;
    }

    /**
     * Returns true if opportunity group with same unique identifier exists in the context
     *
     * @param string $textId
     * @return bool
     */
    public function hasOpportunityGroup(string $textId): bool
    {
        try {
            $this->validate($this->opportunityGroups, (new GoOpportunityGroup())->setTextId($textId));
        } catch (\LogicException $exception) {
            return true;
        }

        return false;
    }

    /**
     * Returns opportunity group for given key
     *
     * @param string $textId
     * @return GoOpportunityGroup|null
     */
    public function getOpportunityGroup(string $textId): ?GoOpportunityGroup
    {
        return $this->opportunityGroups[$textId] ?? null;
    }
}
