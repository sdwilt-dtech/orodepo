<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\DataConverter;

use Oro\Bundle\ImportExportBundle\Converter\ConfigurableTableDataConverter;

class XlsxTemplateDataConverter extends ConfigurableTableDataConverter
{
}
