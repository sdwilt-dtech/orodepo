<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport;

interface ImportDataPopulatorInterface
{
    /**
     * Populates import context
     *
     * @param NormalizationContext $context
     */
    public function populate(NormalizationContext $context): void;

    /**
     * Returns priority value for data populator execution
     *
     * @return int
     */
    public function getPriority(): int;
}
