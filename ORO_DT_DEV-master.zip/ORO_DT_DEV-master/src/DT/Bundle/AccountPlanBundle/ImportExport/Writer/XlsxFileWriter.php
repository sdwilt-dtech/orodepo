<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Writer;

use Box\Spout\Common\Type;
use Box\Spout\Writer\WriterFactory;
use Box\Spout\Writer\WriterInterface;
use Oro\Bundle\ImportExportBundle\Writer\XlsxFileWriter as BaseXlsxFileWriter;

/**
 * Overrides default writer to allow
 * multiple files opening/closing to
 * write data to
 */
class XlsxFileWriter extends BaseXlsxFileWriter
{
    /** @var WriterInterface */
    private $writer;

    /** @var int */
    private $currentRow = 0;

    /**
     * @return WriterInterface
     */
    public function getWriter(): WriterInterface
    {
        if (!$this->writer) {
            $this->writer = WriterFactory::create(Type::XLSX);
            $this->writer->openToFile($this->filePath);
        }

        return $this->writer;
    }
    /**
     * {@inheritdoc}
     */
    public function write(array $items): void
    {
        $writeArray = $items;
        // write a header if needed
        if ($this->firstLineIsHeader && $this->currentRow === 0) {
            if (!$this->header && count($items) > 0) {
                $this->header = array_keys($items[0]);
            }

            if ($this->header) {
                array_unshift($writeArray, $this->header);
            }
        }

        $this->getWriter()->addRows($writeArray);

        $this->currentRow += count($writeArray) - 1;
    }

    /**
     * Write to file on close.
     * A little hacky but direct write is not possible because you cannot append data directly
     */
    public function close(): void
    {
        if ($this->writer) {
            $this->writer->close();
            $this->header = null;
            $this->currentRow = 0;
            $this->writer = null;
        }
    }
}
