<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Writer;

use Box\Spout\Writer\WriterInterface;
use Box\Spout\Writer\XLSX\Writer as XlsxWriter;
use DT\Bundle\AccountPlanBundle\ImportExport\DataPopulator\Headers;
use Oro\Bundle\ImportExportBundle\Writer\XlsxFileWriter;

class GoRepsYearlyMigrationXlsxWriter extends XlsxFileWriter
{
    /** @var bool */
    private $isConfigured = false;

    /**
     * {@inheritdoc}
     */
    public function getWriter(): WriterInterface
    {
        /** @var XlsxWriter $writer */
        $writer = parent::getWriter();
        if (!$this->isConfigured) {
            $this->configure($writer);
            $this->isConfigured = true;
        }

        return $writer;
    }

    /**
     * @param XlsxWriter $writer
     */
    private function configure(XlsxWriter $writer): void
    {
        $writer->getCurrentSheet()->setName(Headers::TAB_NAME);
    }
}
