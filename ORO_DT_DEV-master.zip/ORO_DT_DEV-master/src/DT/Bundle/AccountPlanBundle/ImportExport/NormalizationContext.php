<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport;

use DT\Bundle\AccountPlanBundle\ImportExport\Traits\AccountPlanAwareTrait;
use DT\Bundle\AccountPlanBundle\ImportExport\Traits\OpportunityAwareTrait;
use DT\Bundle\AccountPlanBundle\ImportExport\Traits\OpportunityGroupAwareTrait;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\EntityBundle\Entity\Region;

/**
 * Context class for region reps data
 */
class NormalizationContext
{
    use OpportunityAwareTrait;
    use OpportunityGroupAwareTrait;
    use AccountPlanAwareTrait;

    /** @var array */
    protected $originalData;

    /** @var GoRegionRep|null */
    protected $regionRep;

    /** @var array|Region[] */
    protected $regions = [];

    /**
     * @param array $originalData
     */
    public function __construct(array $originalData)
    {
        $this->originalData = $originalData;
    }

    /**
     * Updates datum value
     *
     * @param string $key
     * @param mixed|null $datum
     * @return self
     */
    public function setDatum(string $key, $datum): self
    {
        $this->originalData[$key] = $datum;
        return $this;
    }

    /**
     * Returns original import row data
     *
     * @return array
     */
    public function getOriginalData(): array
    {
        return $this->originalData;
    }

    /**
     * Sets region rep
     *
     * @param GoRegionRep $regionRep
     * @return self
     */
    public function setRegionRep(GoRegionRep $regionRep): self
    {
        $this->regionRep = $regionRep;
        return $this;
    }

    /**
     * Gets region rep
     *
     * @return GoRegionRep|null
     */
    public function getRegionRep(): ?GoRegionRep
    {
        return $this->regionRep;
    }

    /**
     * Ensures key exists in the import row data, throws exception otherwise
     *
     * @param string $key
     * @return mixed
     */
    public function validateGet(string $key)
    {
        $matches = [
            $key, strtoupper($key)
        ];

        foreach ($matches as $matchKey) {
            if (array_key_exists($matchKey, $this->originalData)) {
                return $this->originalData[$matchKey];
            }
        }

        throw new \InvalidArgumentException(sprintf(
            'Key %s does not exist in the import context row data.',
            $key
        ));
    }

    /**
     * Returns datum from array for certain key with default fallback
     *
     * @param string $key
     * @param null $default
     * @return mixed|null
     */
    public function getFromArray(string $key, $default = null)
    {
        try {
            return $this->validateGet($key);
        } catch (\InvalidArgumentException $exc) {
            return $default;
        }
    }
}
