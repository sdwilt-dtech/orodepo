<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport;

class YearlyImportContextRegistry
{
    /** @var NormalizationContext */
    private $context;

    /**
     * @param NormalizationContext $context
     */
    public function registerContext(NormalizationContext $context): void
    {
        $this->context = $context;
    }

    /**
     * @param NormalizationContext $context
     */
    public function unregisterContext(NormalizationContext $context): void
    {
        $this->context = null;
    }

    /**
     * @return NormalizationContext
     */
    public function getRegisteredContext(): NormalizationContext
    {
        if (!$this->context) {
            throw new \LogicException('No context is registered. Check if yearly import operation is running.');
        }

        return $this->context;
    }
}
