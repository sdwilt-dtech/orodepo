<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Step;

use Akeneo\Bundle\BatchBundle\Entity\StepExecution;
use DT\Bundle\AccountPlanBundle\ImportExport\Reader\InitializationForcedXlsxFileReader;
use Oro\Bundle\BatchBundle\Step\ItemStep;

class XlsxImportItemStep extends ItemStep
{
    /**
     * {@inheritdoc}
     */
    public function doExecute(StepExecution $stepExecution)
    {
        if ($this->reader instanceof InitializationForcedXlsxFileReader) {
            $this->reader->reset();
        }
        parent::doExecute($stepExecution);
    }
}
