<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Configuration;

use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\ImportExportBundle\Configuration\ImportExportConfiguration;
use Oro\Bundle\ImportExportBundle\Configuration\ImportExportConfigurationInterface;
use Oro\Bundle\ImportExportBundle\Configuration\ImportExportConfigurationProviderInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

class GoRepsYearlyMigrationConfigurationProvider implements ImportExportConfigurationProviderInterface
{

    /** @var TranslatorInterface */
    private $translator;

    /**
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    /**
     * {@inheritdoc}
     */
    public function get(): ImportExportConfigurationInterface
    {
        return new ImportExportConfiguration([
            ImportExportConfiguration::FIELD_ENTITY_CLASS => GoRegionRep::class,
            ImportExportConfiguration::FIELD_EXPORT_PROCESSOR_ALIAS => null,
            ImportExportConfiguration::FIELD_IMPORT_JOB_NAME => 'yearly_region_reps_import_from_xslx',
            ImportExportConfiguration::FIELD_IMPORT_VALIDATION_JOB_NAME => 'yearly_region_reps_import_validation_from_xslx', // @codingStandardsIgnoreLine
            ImportExportConfiguration::FIELD_EXPORT_TEMPLATE_PROCESSOR_ALIAS => 'region_rep_yearly.template',
            ImportExportConfiguration::FIELD_IMPORT_PROCESSOR_ALIAS => 'region_rep_yearly.add_or_replace',
            ImportExportConfiguration::FIELD_EXPORT_TEMPLATE_JOB_NAME => 'yearly_region_reps_export_template_from_xslx',
            ImportExportConfiguration::FIELD_IMPORT_STRATEGY_TOOLTIP =>
                $this->translator->trans('dt.account_plan.importexport.strategy.description'),
        ]);
    }
}
