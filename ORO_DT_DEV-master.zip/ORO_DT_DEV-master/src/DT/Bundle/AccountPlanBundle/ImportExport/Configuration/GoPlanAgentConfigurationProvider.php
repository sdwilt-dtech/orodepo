<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Configuration;

use DT\Bundle\EntityBundle\Entity\GoPlanAgent;
use Oro\Bundle\ImportExportBundle\Configuration\ImportExportConfiguration;
use Oro\Bundle\ImportExportBundle\Configuration\ImportExportConfigurationInterface;
use Oro\Bundle\ImportExportBundle\Configuration\ImportExportConfigurationProviderInterface;

class GoPlanAgentConfigurationProvider implements ImportExportConfigurationProviderInterface
{
    /**
     * {@inheritdoc}
     *
     * @throws \InvalidArgumentException
     */
    public function get(): ImportExportConfigurationInterface
    {
        return new ImportExportConfiguration([
            ImportExportConfiguration::FIELD_ENTITY_CLASS => GoPlanAgent::class,
            ImportExportConfiguration::FIELD_EXPORT_PROCESSOR_ALIAS => 'dt_go_plan_agent',
            ImportExportConfiguration::FIELD_EXPORT_TEMPLATE_PROCESSOR_ALIAS => 'dt_go_plan_agent',
            ImportExportConfiguration::FIELD_IMPORT_PROCESSOR_ALIAS => 'dt_go_plan_agent'
        ]);
    }
}
