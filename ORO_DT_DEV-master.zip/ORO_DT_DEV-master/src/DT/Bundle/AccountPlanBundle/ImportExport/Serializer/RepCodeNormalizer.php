<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Serializer;

use DT\Bundle\EntityBundle\Entity\RepCode;
use Oro\Bundle\ImportExportBundle\Serializer\Normalizer\ConfigurableEntityNormalizer;

class RepCodeNormalizer extends ConfigurableEntityNormalizer
{
    public function denormalize($data, $class, $format = null, array $context = array())
    {
        //add leading 0 if code is less than 3 characters long
        $data['code'] = sprintf('%03s', $data['code']);

        return parent::denormalize($data, $class, $format, $context);
    }

    public function supportsDenormalization($data, $type, $format = null, array $context = array()): bool
    {
        return is_array($data) && $type === RepCode::class;
    }
}
