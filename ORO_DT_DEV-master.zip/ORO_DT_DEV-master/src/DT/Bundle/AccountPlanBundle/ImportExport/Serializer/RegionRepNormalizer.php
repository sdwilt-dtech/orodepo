<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Serializer;

use DT\Bundle\AccountPlanBundle\ImportExport\NormalizationContext;
use DT\Bundle\AccountPlanBundle\ImportExport\YearlyImportContextRegistry;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\EntityBundle\Helper\FieldHelper;
use Oro\Bundle\ImportExportBundle\Event\Events;
use Oro\Bundle\ImportExportBundle\Serializer\Normalizer\ConfigurableEntityNormalizer;
use Oro\Bundle\ImportExportBundle\Serializer\Normalizer\DenormalizerInterface;

/**
 * Handles denormalization of reps data from XSLX import
 * creating mandatory data on Reps, Opportunity Group and Opportunities.
 * Normalizes data for export template.
 */
class RegionRepNormalizer extends ConfigurableEntityNormalizer implements DenormalizerInterface
{
    private const PROCESSOR_PREFIX = 'region_rep_yearly.';

    /** @var YearlyImportContextRegistry */
    private $registry;

    /**
     * @param FieldHelper $fieldHelper
     * @param YearlyImportContextRegistry $registry
     */
    public function __construct(FieldHelper $fieldHelper, YearlyImportContextRegistry $registry)
    {
        $this->registry = $registry;
        parent::__construct($fieldHelper);
    }

    /**
     * Encapsulates data into context object
     *
     * {@inheritdoc}
     */
    public function denormalize($data, $type, $format = null, array $context = [])
    {
        $normalizationContext = new NormalizationContext($data);
        $this->registry->registerContext($normalizationContext);
        $this->dispatchDenormalizeEvent(
            $data,
            $normalizationContext,
            Events::BEFORE_DENORMALIZE_ENTITY
        );

        return $normalizationContext->getRegionRep();
    }

    /**
     * {@inheritdoc}
     */
    public function supportsDenormalization($data, $type, $format = null, array $context = [])
    {
        return $this->doesSupport($type, $context);
    }

    /**
     * @param string $type
     * @param array $context
     * @return bool
     */
    private function doesSupport(string $type, array $context): bool
    {
        return ($type === GoRegionRep::class)
            && isset($context['processorAlias'])
            && $this->handlesProcesor($context['processorAlias']);
    }

    /**
     * {@inheritdoc}
     */
    public function supportsNormalization($data, $format = null, array $context = [])
    {
        if (is_object($data)) {
            return $this->doesSupport(get_class($data), $context);
        }

        return false;
    }

    /**
     * Checks processor name against supported prefix
     *
     * @param string $processor
     * @return bool
     */
    private function handlesProcesor(string $processor): bool
    {
        return substr($processor, 0, strlen(self::PROCESSOR_PREFIX)) === self::PROCESSOR_PREFIX;
    }

    /**
     * {@inheritdoc}
     * @param GoRegionRep $object
     */
    public function normalize($object, $format = null, array $context = [])
    {
        $normalizationContext = new NormalizationContext([]);
        $this->registry->registerContext($normalizationContext);
        $normalizationContext->setRegionRep($object);
        $this->dispatchNormalize(
            $normalizationContext,
            [],
            $context,
            Events::BEFORE_NORMALIZE_ENTITY
        );

        return $normalizationContext->getOriginalData();
    }
}
