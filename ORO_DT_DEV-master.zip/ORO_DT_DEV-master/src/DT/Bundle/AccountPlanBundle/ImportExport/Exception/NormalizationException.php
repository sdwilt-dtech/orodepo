<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Exception;

class NormalizationException extends \Exception
{
}
