<?php

namespace DT\Bundle\AccountPlanBundle\ImportExport\Reader;

use Oro\Bundle\ImportExportBundle\Context\ContextInterface;
use Oro\Bundle\ImportExportBundle\Reader\XlsxFileReader as BaseXlsxFileReader;

/**
 * Forces initialization of context if no sheet reader is loaded and
 * fixes issue with 2nd row being header datum
 */
class InitializationForcedXlsxFileReader extends BaseXlsxFileReader
{
    /** @var bool */
    private $isInitialized = false;

    /**
     * Resets the initialization step
     */
    public function reset(): void
    {
        $this->isInitialized = false;
    }

    /**
     * {@inheritdoc}
     */
    public function read($context = null): ?array
    {
        if (!$context instanceof ContextInterface) {
            $context = $this->getContext();
        }
        if (!$this->isInitialized) {
            $this->initializeByContext($context);
            $this->isInitialized = true;
        }

        $data = parent::read($context);

        if ($this->isHeader($data)) {
            $data = parent::read($context);
        }

        return is_array($data) ? $this->parse($data) : $data;
    }

    /**
     * @param array $data
     * @return array
     */
    private function parse(array $data): array
    {
        return array_map(function ($datum) {
            if ($datum instanceof \DateTime) {
                return $datum->format('Y-m-d H:i:s');
            }

            return $datum;
        }, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function close()
    {
        $this->reset();
        parent::close();
    }

    /**
     * Detects double header
     *
     * @param array|null $rowData
     * @return bool
     */
    private function isHeader(?array $rowData): bool
    {
        if (null === $rowData) {
            return false;
        }
        foreach ($rowData as $key => $rowDatum) {
            if ($key != $rowDatum) {
                return false;
            }
        }

        return true;
    }
}
