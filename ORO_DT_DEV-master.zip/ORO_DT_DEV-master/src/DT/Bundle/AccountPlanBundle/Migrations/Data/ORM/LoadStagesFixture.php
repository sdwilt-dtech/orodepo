<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Data\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerAwareTrait;
use Symfony\Component\Yaml\Yaml;

class LoadStagesFixture extends AbstractFixture implements ContainerAwareInterface, DependentFixtureInterface
{
    use ContainerAwareTrait;

    /**
     * Provides yml file path for the stages
     */
    public function getDataPath(): string
    {
        return '@DTAccountPlanBundle/Migrations/Data/ORM/data/stages.yml';
    }

    /**
     * {@inheritdoc}
     */
    public function load(ObjectManager $manager)
    {
        $data = $this->getStagesData();
        $enumProvider = $this->container->get('oro_entity_extend.enum_value_provider');
        /** @var array $datum */
        foreach ($data['stages'] as $stageName => $datum) {
            $stage = new GoOpportunityStage();
            $stage->setName($stageName);
            $stage->setProbability($datum['probability']);
            $enumType = $enumProvider
                ->getEnumValueByCode(GoOpportunityStage::ENUM_OPPORTUNITY_STAGE_TYPE, $datum['type']);
            $enumCategory = $enumProvider
                ->getEnumValueByCode(GoOpportunity::ENUM_FORECAST_CATEGORY, $datum['forecastCategory']);

            $stage->setType($enumType);
            $stage->setForecastCategory($enumCategory);

            $manager->persist($stage);
        }

        $manager->flush();
    }

    /**
     * @return array
     */
    private function getStagesData(): array
    {
        $fileName = $this->container
            ->get('kernel')
            ->locateResource($this->getDataPath());
        $fileName = str_replace('/', DIRECTORY_SEPARATOR, $fileName);

        return Yaml::parse(file_get_contents($fileName));
    }

    /**
     * {@inheritdoc}
     */
    public function getDependencies()
    {
        return [
            LoadMissingEnums::class
        ];
    }
}
