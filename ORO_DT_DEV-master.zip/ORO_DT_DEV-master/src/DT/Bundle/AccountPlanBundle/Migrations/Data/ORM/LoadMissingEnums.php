<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Data\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Entity\Repository\EnumValueRepository;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\MigrationBundle\Fixture\VersionedFixtureInterface;

class LoadMissingEnums extends AbstractFixture implements VersionedFixtureInterface
{
    /** @var array */
    private $enumIds = [];

    /**
     * {@inheritdoc}
     */
    public function load(ObjectManager $manager)
    {
        foreach ($this->getValues() as $enumCode => $values) {
            $className = ExtendHelper::buildEnumValueClassName($enumCode);

            /** @var EnumValueRepository $enumRepo */
            $enumRepo = $manager->getRepository($className);
            $priority = $this->getLastPriority($enumRepo);
            $hasChanges = false;
            foreach ($values as $value) {
                if (!$this->exists($value, $enumRepo, $enumCode)) {
                    $enumOption = $enumRepo->createEnumValue($value, ++$priority, false, $value);
                    $manager->persist($enumOption);
                    $hasChanges = true;
                }
            }

            $hasChanges && $manager->flush();
        }
    }

    /**
     * @param EnumValueRepository $enumRepo
     * @return int
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    private function getLastPriority(EnumValueRepository $enumRepo): int
    {
        return (int)$enumRepo->createQueryBuilder('ls')
            ->select('MAX(ls.priority) AS max_priority')
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @param string $id
     * @param EnumValueRepository $enumRepo
     * @param string $enumCode
     * @return bool
     */
    private function exists($id, EnumValueRepository $enumRepo, string $enumCode): bool
    {
        if (!array_key_exists($enumCode, $this->enumIds)) {
            $this->enumIds[$enumCode] = array_map(function (AbstractEnumValue $value) {
                return $value->getId();
            }, $enumRepo->findAll());
        }

        return in_array($id, $this->enumIds[$enumCode]);
    }

    /**
     * @return array
     */
    private function getValues(): array
    {
        return [
            GoOpportunity::ENUM_FORECAST_CATEGORY => [
                'Omitted',
                'Pipeline',
                'Closed',
                'BestCase',
                'Forecast',
                'Commit'
            ],
            GoOpportunity::ENUM_BUSINESS_CHALLENGER => [
                'NewTech',
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function getVersion()
    {
        return '1.1';
    }
}
