<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_9;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Types;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\ParametrizedSqlMigrationQuery;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class ModifyStageNameEnums implements Migration
{
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $enumTable = $schema->getTable('oro_enum_dt_stage_name');
        $queries->addPreQuery('TRUNCATE TABLE ' . $enumTable->getName() . ' CASCADE');
        $sql = sprintf(
            'INSERT INTO %s (id, name, priority, is_default) VALUES (:id, :name, :priority, :is_default)',
            $enumTable->getName()
        );
        $i = 1;
        $params = [
            'id' => Types::STRING,
            'name' => Types::STRING,
            'priority' => Types::STRING,
            'is_default' => Types::BOOLEAN
        ];
        foreach ($this->getValues() as $key => $value) {
            $query = new ParametrizedSqlMigrationQuery();
            $query->addSql(
                $sql,
                [
                    'id' => $value,
                    'name' => $value,
                    'priority' => $i,
                    'is_default' => false
                ],
                $params
            );
            $queries->addQuery($query);
            $i++;
        }
    }

    /**
     * @return array
     */
    private function getValues(): array
    {
        return [
            '0. Pipeline',
            '1. Contact',
            '1. Identified',
            '1. Sample Sent',
            '2. Proposal Made',
            '2. Qualify',
            '2. Qualify Opportunity',
            '3. Info feed/Pricing Shared',
            '3. Quote Sent',
            '3. Quoted',
            '4. Follow-up',
            '4. Verbal Agreement',
            '4a. Closed Won',
            '4b. Closed Lost',
            '5. Closed - Won',
            '5. Part Numbers Loaded',
            '6. Closed Lost',
            '6. Closed Won',
            '7. Closed Lost',
            '8. Closed RSM Declined to Pursue',
            '9. Closed Partially Won'
        ];
    }
}
