<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_10;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Schema\SchemaException;
use Doctrine\DBAL\Types\Types;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;
use Oro\Bundle\EntityBundle\EntityConfig\DatagridScope;
use Oro\Bundle\EntityExtendBundle\EntityConfig\ExtendScope;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtension;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtensionAwareInterface;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\ParametrizedSqlMigrationQuery;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddMissingStageTable implements Migration, ExtendExtensionAwareInterface
{
    /** @var ExtendExtension */
    private $extendExtension;

    /**
     * {@inheritdoc}
     */
    public function setExtendExtension(ExtendExtension $extendExtension)
    {
        $this->extendExtension = $extendExtension;
    }

    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $this->createGoOpportunityStageTable($schema);
        $this->addEnums($schema, $queries);
        $this->addOpportunityRelation($schema);
    }

    /**
     * @param Schema $schema
     * @throws SchemaException
     */
    private function addOpportunityRelation(Schema $schema): void
    {
        $table = $schema->getTable(GoOpportunity::TABLE_NAME);
        if (!$table->hasColumn('stage_id')) {
            $table->addColumn('stage_id', 'integer', ['notnull' => false]);
            $table->addForeignKeyConstraint(
                $schema->getTable(GoOpportunityStage::TABLE_NAME),
                ['stage_id'],
                ['id'],
                ['onDelete' => 'SET NULL', 'onUpdate' => null]
            );
        }
    }

    /**
     * @param Schema $schema
     */
    private function createGoOpportunityStageTable(Schema $schema): void
    {
        if (!$schema->hasTable(GoOpportunityStage::TABLE_NAME)) {
            $table = $schema->createTable(GoOpportunityStage::TABLE_NAME);
            $table->addColumn('id', 'integer', ['autoincrement' => true]);
            $table->addColumn('name', 'string', ['length' => 255, 'notnull' => true]);
            $table->addColumn('probability', 'integer', ['notnull' => true]);
            $table->addColumn('created_at', 'datetime');
            $table->addColumn('updated_at', 'datetime');
            $table->addColumn('organization_id', 'integer', ['notnull' => false]);

            $table->setPrimaryKey(['id']);

            $table->addUniqueIndex(
                ['name'],
                'dt_go_opportunity_stage_name_uidx'
            );
        }
    }

    /**
     * Creates enums with values
     *
     * @param Schema $schema
     * @param QueryBag $queries
     * @throws SchemaException
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    private function addEnums(Schema $schema, QueryBag $queries): void
    {
        foreach ($this->getAvailableEnums() as $tableName => $properties) {
            $table = $schema->getTable($tableName);
            foreach ($properties as $enumCode => $valueData) {
                $properties = $valueData['property'] ?? $enumCode;
                $properties = is_array($properties) ? $properties : [$properties];
                $values = $valueData['values'] ?? [];
                $isMultiple = $valueData['multiple'];
                $indexesAsKeys = $valueData['indexesAsKeys'] ?? false;
                $params = [
                    'id' => Types::STRING,
                    'name' => Types::STRING,
                    'priority' => Types::STRING,
                    'is_default' => Types::BOOLEAN
                ];
                $hasAdded = false;
                foreach ($properties as $property) {
                    if ($table->hasColumn(sprintf('%s_id', $property))) {
                        continue;
                    }
                    $hasAdded = true;
                    $enumTable = $this->extendExtension->addEnumField(
                        $schema,
                        $table,
                        $property,
                        $enumCode,
                        $isMultiple,
                        false,
                        [
                            'extend' => [
                                'is_extend' => true,
                                'owner' => ExtendScope::OWNER_SYSTEM
                            ],
                            'datagrid' => ['is_visible' => DatagridScope::IS_VISIBLE_TRUE],
                            'dataaudit' => ['auditable' => true],
                        ]
                    );
                }

                if ($hasAdded && count($values)) {
                    $sql = sprintf(
                        'INSERT INTO %s (id, name, priority, is_default) VALUES (:id, :name, :priority, :is_default)',
                        $enumTable->getName()
                    );
                    $i = 1;
                    foreach ($values as $key => $value) {
                        $query = new ParametrizedSqlMigrationQuery();
                        $query->addSql(
                            $sql,
                            [
                                'id' => $indexesAsKeys ? $key : $value,
                                'name' => $value,
                                'priority' => $i,
                                'is_default' => false
                            ],
                            $params
                        );
                        $queries->addQuery($query);
                        $i++;
                    }
                }
            }
        }
    }

    /**
     * @return array
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    private function getAvailableEnums(): array
    {
        return [
            GoOpportunityStage::TABLE_NAME => [
                GoOpportunityStage::ENUM_OPPORTUNITY_STAGE_TYPE => [
                    'values' => [
                        'Open',
                        'Closed/Won',
                        'Closed/Lost'
                    ],
                    'property' => 'type',
                    'multiple' => false
                ],
                GoOpportunity::ENUM_FORECAST_CATEGORY => [
                    'property' => 'forecast_category',
                    'multiple' => false
                ]
            ],
        ];
    }
}
