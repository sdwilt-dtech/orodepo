<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_15_1;

use Doctrine\DBAL\Schema\Schema;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddSalesforceIdIndex implements Migration
{
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $table = $schema->getTable('dt_go_opportunity');
        $table->addUniqueIndex(['salesforce_id'], 'dt_go_opportunity_salesforce_id_uidx');
    }
}
