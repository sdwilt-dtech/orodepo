<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_3;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Schema\SchemaException;
use Doctrine\DBAL\Types\Types;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use Oro\Bundle\EntityBundle\EntityConfig\DatagridScope;
use Oro\Bundle\EntityExtendBundle\EntityConfig\ExtendScope;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtension;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtensionAwareInterface;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\ParametrizedSqlMigrationQuery;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddMissingColumnsMigration implements Migration, ExtendExtensionAwareInterface
{
    /** @var ExtendExtension */
    private $extendExtension;

    /**
     * {@inheritdoc}
     */
    public function setExtendExtension(ExtendExtension $extendExtension)
    {
        $this->extendExtension = $extendExtension;
    }

    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $this->addOpportunityGroupTableColumns($schema);
        $this->addEnums($schema, $queries);
    }

    /**
     * @param Schema $schema
     * @throws \Doctrine\DBAL\Schema\SchemaException
     */
    private function addOpportunityGroupTableColumns(Schema $schema): void
    {
        $table = $schema->getTable(GoOpportunityGroup::TABLE_NAME);
        if (!$table->hasColumn('state')) {
            $table->addColumn('state', 'string', ['length' => 2, 'notnull' => false]);
        }
    }

    /**
     * Creates enums with values
     *
     * @param Schema $schema
     * @param QueryBag $queries
     * @throws SchemaException
     */
    private function addEnums(Schema $schema, QueryBag $queries): void
    {
        foreach ($this->getAvailableEnums() as $tableName => $properties) {
            $table = $schema->getTable($tableName);
            foreach ($properties as $enumCode => $valueData) {
                $properties = $valueData['property'] ?? $enumCode;
                $properties = is_array($properties) ? $properties : [$properties];
                $values = $valueData['values'];
                $isMultiple = $valueData['multiple'];
                $indexesAsKeys = $valueData['indexesAsKeys'] ?? false;
                $params = [
                    'id' => Types::STRING,
                    'name' => Types::STRING,
                    'priority' => Types::STRING,
                    'is_default' => Types::BOOLEAN
                ];
                $hasAdded = false;
                foreach ($properties as $property) {
                    if ($table->hasColumn(sprintf('%s_id', $property))) {
                        continue;
                    }
                    $hasAdded = true;
                    $enumTable = $this->extendExtension->addEnumField(
                        $schema,
                        $table,
                        $property,
                        $enumCode,
                        $isMultiple,
                        false,
                        [
                            'extend' => [
                                'is_extend' => true,
                                'owner' => ExtendScope::OWNER_SYSTEM
                            ],
                            'datagrid' => ['is_visible' => DatagridScope::IS_VISIBLE_TRUE],
                            'dataaudit' => ['auditable' => true],
                        ]
                    );
                }

                if ($hasAdded) {
                    $sql = sprintf(
                        'INSERT INTO %s (id, name, priority, is_default) VALUES (:id, :name, :priority, :is_default)',
                        $enumTable->getName()
                    );
                    $i = 1;
                    foreach ($values as $key => $value) {
                        $query = new ParametrizedSqlMigrationQuery();
                        $query->addSql(
                            $sql,
                            [
                                'id' => $indexesAsKeys ? $key : $value,
                                'name' => $value,
                                'priority' => $i,
                                'is_default' => false
                            ],
                            $params
                        );
                        $queries->addQuery($query);
                        $i++;
                    }
                }
            }
        }
    }

    /**
     * @return array
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    private function getAvailableEnums(): array
    {
        return [
            GoOpportunity::TABLE_NAME => [
                GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE => [
                    'values' => [
                        'HVAC',
                        'Sample Request Opp',
                        'HVAC Old GP',
                        'Electrical Sales',
                        'RSM Recovery',
                        'HVAC Go Plan',
                        'Utilities',
                        'Util-LC',
                        'EU Accounts'
                    ],
                    'property' => 'opportunity_record_type',
                    'multiple' => false
                ],
            ],
            GoOpportunityGroup::TABLE_NAME => [
                GoOpportunityGroup::ENUM_OPPORTUNITY_YEAR => [
                    'values' => [
                        'Current',
                        'Previous'
                    ],
                    'property' => 'opportunity_year',
                    'multiple' => false
                ]
            ],
        ];
    }
}
