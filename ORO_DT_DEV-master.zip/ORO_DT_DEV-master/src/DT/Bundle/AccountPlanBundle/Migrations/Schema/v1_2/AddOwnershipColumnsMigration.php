<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_2;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Schema\Table;
use DT\Bundle\EntityBundle\Entity;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddOwnershipColumnsMigration implements Migration
{
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        foreach ($this->getTables($schema) as $table) {
            if (!$table->hasColumn('user_owner_id')) {
                $table->addColumn('user_owner_id', 'integer', ['notnull' => false]);
                $table->addForeignKeyConstraint(
                    $schema->getTable('oro_user'),
                    ['user_owner_id'],
                    ['id'],
                    ['onDelete' => 'SET NULL', 'onUpdate' => null]
                );
            }
        }
    }

    /**
     * Provides all go table instances
     *
     * @param Schema $schema
     * @return array|Table[]
     * @throws \Doctrine\DBAL\Schema\SchemaException
     */
    private function getTables(Schema $schema): array
    {
        return array_map(function (string $tableName) use ($schema) {
            return $schema->getTable($tableName);
        }, [
            Entity\GoOpportunity::TABLE_NAME,
            Entity\GoAccountPlan::TABLE_NAME,
            Entity\GoOpportunityGroup::TABLE_NAME,
            Entity\GoRegionRep::TABLE_NAME,
            Entity\GoPlanAgent::TABLE_NAME
        ]);
    }
}
