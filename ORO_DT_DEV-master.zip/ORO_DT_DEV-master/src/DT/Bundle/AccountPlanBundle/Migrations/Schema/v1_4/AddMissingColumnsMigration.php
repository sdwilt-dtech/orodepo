<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_4;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Schema\SchemaException;
use Doctrine\DBAL\Types\Types;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoPlanAgent;
use Oro\Bundle\EntityBundle\EntityConfig\DatagridScope;
use Oro\Bundle\EntityExtendBundle\EntityConfig\ExtendScope;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtension;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtensionAwareInterface;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\ParametrizedSqlMigrationQuery;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddMissingColumnsMigration implements Migration, ExtendExtensionAwareInterface
{
    /** @var ExtendExtension */
    private $extendExtension;

    /**
     * {@inheritdoc}
     */
    public function setExtendExtension(ExtendExtension $extendExtension)
    {
        $this->extendExtension = $extendExtension;
    }

    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $this->addOpportunityTableColumns($schema);
        $this->addAccountPlanTableColumns($schema);
        $this->addEnums($schema, $queries);
    }

    /**
     * @param Schema $schema
     */
    private function addAccountPlanTableColumns(Schema $schema): void
    {
        $table = $schema->getTable(GoAccountPlan::TABLE_NAME);
        if (!$table->hasColumn('track')) {
            $table->addColumn('track', 'boolean', ['notnull' => true, 'default' => false]);
        }
    }

    /**
     * @param Schema $schema
     * @throws \Doctrine\DBAL\Schema\SchemaException
     *
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    private function addOpportunityTableColumns(Schema $schema): void
    {
        $table = $schema->getTable(GoOpportunity::TABLE_NAME);
        if (!$table->hasColumn('next_step')) {
            $table->addColumn('next_step', 'string', ['length' => 255, 'notnull' => false]);
        }
        if (!$table->hasColumn('job_quote')) {
            $table->addColumn('job_quote', 'boolean', ['notnull' => true, 'default' => false]);
        }
        if (!$table->hasColumn('job_quote_name')) {
            $table->addColumn('job_quote_name', 'string', ['notnull' => false, 'length' => 45]);
        }
        if (!$table->hasColumn('date_sample_sent')) {
            $table->addColumn('date_sample_sent', 'datetime', ['notnull' => false]);
        }
        if (!$table->hasColumn('situation_description')) {
            $table->addColumn('situation_description', 'text', ['notnull' => false]);
        }
        if (!$table->hasColumn('notify_customer_id')) {
            $table->addColumn('notify_customer_id', 'integer', ['notnull' => false]);
            $table->addForeignKeyConstraint(
                $schema->getTable('oro_customer'),
                ['notify_customer_id'],
                ['id'],
                ['onDelete' => 'SET NULL', 'onUpdate' => null]
            );
        }
        if (!$table->hasColumn('notify_sales_rep_id')) {
            $table->addColumn('notify_sales_rep_id', 'integer', ['notnull' => false]);
            $table->addForeignKeyConstraint(
                $schema->getTable('oro_user'),
                ['notify_sales_rep_id'],
                ['id'],
                ['onDelete' => 'SET NULL', 'onUpdate' => null]
            );
        }
        if (!$table->hasColumn('notify_rsm_id')) {
            $table->addColumn('notify_rsm_id', 'integer', ['notnull' => false]);
            $table->addForeignKeyConstraint(
                $schema->getTable('oro_user'),
                ['notify_rsm_id'],
                ['id'],
                ['onDelete' => 'SET NULL', 'onUpdate' => null]
            );
        }
    }

    /**
     * Creates enums with values
     *
     * @param Schema $schema
     * @param QueryBag $queries
     * @throws SchemaException
     */
    private function addEnums(Schema $schema, QueryBag $queries): void
    {
        foreach ($this->getAvailableEnums() as $tableName => $properties) {
            $table = $schema->getTable($tableName);
            foreach ($properties as $enumCode => $valueData) {
                $properties = $valueData['property'] ?? $enumCode;
                $properties = is_array($properties) ? $properties : [$properties];
                $values = $valueData['values'];
                $isMultiple = $valueData['multiple'];
                $indexesAsKeys = $valueData['indexesAsKeys'] ?? false;
                $params = [
                    'id' => Types::STRING,
                    'name' => Types::STRING,
                    'priority' => Types::STRING,
                    'is_default' => Types::BOOLEAN
                ];
                $hasAdded = false;
                foreach ($properties as $property) {
                    if ($table->hasColumn(sprintf('%s_id', $property))) {
                        continue;
                    }
                    $hasAdded = true;
                    $enumTable = $this->extendExtension->addEnumField(
                        $schema,
                        $table,
                        $property,
                        $enumCode,
                        $isMultiple,
                        false,
                        [
                            'extend' => [
                                'is_extend' => true,
                                'owner' => ExtendScope::OWNER_SYSTEM
                            ],
                            'datagrid' => ['is_visible' => DatagridScope::IS_VISIBLE_TRUE],
                            'dataaudit' => ['auditable' => true],
                        ]
                    );
                }

                if ($hasAdded) {
                    $sql = sprintf(
                        'INSERT INTO %s (id, name, priority, is_default) VALUES (:id, :name, :priority, :is_default)',
                        $enumTable->getName()
                    );
                    $i = 1;
                    foreach ($values as $key => $value) {
                        $query = new ParametrizedSqlMigrationQuery();
                        $query->addSql(
                            $sql,
                            [
                                'id' => $indexesAsKeys ? $key : $value,
                                'name' => $value,
                                'priority' => $i,
                                'is_default' => false
                            ],
                            $params
                        );
                        $queries->addQuery($query);
                        $i++;
                    }
                }
            }
        }
    }

    /**
     * @return array
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    private function getAvailableEnums(): array
    {
        return [
            GoPlanAgent::TABLE_NAME => [
                GoPlanAgent::ENUM_RECORD_TYPE => [
                    'values' => [
                        'GP CY Agents',
                        'GP Old Agents',
                    ],
                    'property' => 'record_type',
                    'multiple' => false,
                ],
            ],
        ];
    }
}
