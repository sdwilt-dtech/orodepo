<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_13;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Types;
use DT\Bundle\SetupBundle\Model\CustomerAddressFields;
use DT\Bundle\SetupBundle\Model\CustomerFields;
use Oro\Bundle\CustomerBundle\Migrations\Schema\OroCustomerBundleInstaller;
use Oro\Bundle\EntityBundle\EntityConfig\DatagridScope;
use Oro\Bundle\EntityExtendBundle\EntityConfig\ExtendScope;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtension;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtensionAwareInterface;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddCustomerFields implements Migration, ExtendExtensionAwareInterface
{
    /** @var ExtendExtension */
    protected $extendExtension;

    /**
     * @param ExtendExtension $extendExtension
     */
    public function setExtendExtension(ExtendExtension $extendExtension)
    {
        $this->extendExtension = $extendExtension;
    }

    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $this->addCustomerFields($schema);
    }

    /**
     * Adds customer fields
     *
     * @param Schema $schema
     * @throws \Doctrine\DBAL\Schema\SchemaException
     */
    private function addCustomerFields(Schema $schema): void
    {
        $table = $schema->getTable(OroCustomerBundleInstaller::ORO_CUSTOMER_TABLE_NAME);
        !$table->hasColumn(CustomerFields::DT_ALTERNATE_PHONE) && $table->addColumn(
            CustomerFields::DT_ALTERNATE_PHONE,
            Types::STRING,
            [
                'notnull' => false,
                'length' => 27,
                'oro_options' => [
                    'extend' => [
                        'is_extend' => true,
                        'owner' => ExtendScope::OWNER_CUSTOM,
                    ],
                    'datagrid' => ['is_visible' => DatagridScope::IS_VISIBLE_HIDDEN, 'show_filter' => false],
                    'form' => ['is_enabled' => true],
                    'view' => ['is_displayable' => true],
                    'merge' => ['display' => false],
                    'dataaudit' => ['auditable' => false]
                ]
            ]
        );

        !$table->hasColumn(CustomerFields::LAST_JDE_SYNC_DATE) && $table->addColumn(
            CustomerFields::LAST_JDE_SYNC_DATE,
            'datetime',
            [
                'notnull'     => false,
                'oro_options' => [
                    'extend'    => [
                        'is_extend' => true,
                        'owner'     => ExtendScope::OWNER_CUSTOM,
                    ],
                    'datagrid'     => ['is_visible' => DatagridScope::IS_VISIBLE_FALSE, 'show_filter' => false],
                    'form'         => ['is_enabled' => false],
                    'view'         => ['is_displayable' => false],
                    'merge'        => ['display' => false],
                    'dataaudit'    => ['auditable' => false],
                    'importexport' => ['excluded' => false]
                ]
            ]
        );

        !$table->hasColumn(CustomerFields::LAST_JDE_SYNC_STATUS) && $table->addColumn(
            CustomerFields::LAST_JDE_SYNC_STATUS,
            Types::STRING,
            [
                'notnull'     => false,
                'oro_options' => [
                    'extend'    => [
                        'is_extend' => true,
                        'owner'     => ExtendScope::OWNER_CUSTOM,
                    ],
                    'datagrid'     => ['is_visible' => DatagridScope::IS_VISIBLE_FALSE, 'show_filter' => false],
                    'form'         => ['is_enabled' => false],
                    'view'         => ['is_displayable' => false],
                    'merge'        => ['display' => false],
                    'dataaudit'    => ['auditable' => false],
                    'importexport' => ['excluded' => false]
                ]
            ]
        );

        $addressTable = $schema->getTable('oro_customer_address');
        !$addressTable->hasColumn(CustomerAddressFields::DT_EFFECTIVE_DATE) && $addressTable->addColumn(
            CustomerAddressFields::DT_EFFECTIVE_DATE,
            'datetime',
            [
                'notnull'     => false,
                'oro_options' => [
                    'extend'    => [
                        'is_extend' => true,
                        'owner'     => ExtendScope::OWNER_CUSTOM,
                    ],
                    'datagrid'     => ['is_visible' => DatagridScope::IS_VISIBLE_FALSE, 'show_filter' => false],
                    'form'         => ['is_enabled' => false],
                    'view'         => ['is_displayable' => false],
                    'merge'        => ['display' => false],
                    'dataaudit'    => ['auditable' => false],
                    'importexport' => ['excluded' => false]
                ]
            ]
        );
    }
}
