<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_14;

use Doctrine\DBAL\Schema\Schema;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddFiscalYear implements Migration
{
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $table = $schema->getTable(GoAccountPlan::TABLE_NAME);
        if (!$table->hasColumn('fiscal_year')) {
            $table->addColumn('fiscal_year', 'integer', ['notnull' => false]);
        }
        $tableGroups = $schema->getTable(GoOpportunityGroup::TABLE_NAME);
        if (!$tableGroups->hasColumn('fiscal_year')) {
            $tableGroups->addColumn('fiscal_year', 'integer', ['notnull' => false]);
        }
    }
}
