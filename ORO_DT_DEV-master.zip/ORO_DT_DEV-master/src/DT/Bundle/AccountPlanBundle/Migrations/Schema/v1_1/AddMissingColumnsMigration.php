<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_1;

use Doctrine\DBAL\Schema\Schema;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoPlanAgent;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddMissingColumnsMigration implements Migration
{
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $this->addAgentTableColumns($schema);
        $this->addOpportunityTableColumns($schema);
        $this->addAccountPlanTableColumns($schema);
    }

    /**
     * @param Schema $schema
     * @throws \Doctrine\DBAL\Schema\SchemaException
     */
    private function addAccountPlanTableColumns(Schema $schema): void
    {
        $table = $schema->getTable(GoAccountPlan::TABLE_NAME);
        if (!$table->hasColumn('is_active')) {
            $table->addColumn('is_active', 'boolean', ['notnull' => true]);
        }
    }

    /**
     * @param Schema $schema
     */
    private function addOpportunityTableColumns(Schema $schema): void
    {
        $table = $schema->getTable(GoOpportunity::TABLE_NAME);
        if (!$table->hasColumn('gp_close_date')) {
            $table->addColumn('gp_close_date', 'datetime', ['notnull' => false]);
        }
        if (!$table->hasColumn('amount')) {
            $table->addColumn('amount', 'money', [
                'precision' => 19,
                'scale' => 4,
                'comment' => '(DC2Type:money)',
                'notnull' => false
            ]);
        }
        if (!$table->hasColumn('dollar_amount_won')) {
            $table->addColumn('dollar_amount_won', 'money', [
                'precision' => 19,
                'scale' => 4,
                'comment' => '(DC2Type:money)',
                'notnull' => false
            ]);
        }
        if (!$table->hasColumn('fiscal_year')) {
            $table->addColumn('fiscal_year', 'integer', ['notnull' => false]);
        }
        if (!$table->hasColumn('region_id')) {
            $table->addColumn('region_id', 'integer', ['notnull' => false]);
            $table->addForeignKeyConstraint(
                $schema->getTable('dt_region'),
                ['region_id'],
                ['id'],
                ['onDelete' => 'SET NULL', 'onUpdate' => null]
            );
        }
        if (!$table->hasColumn('rep_code_id')) {
            $table->addColumn('rep_code_id', 'integer', ['notnull' => false]);
            $table->addForeignKeyConstraint(
                $schema->getTable('dt_rep_code'),
                ['rep_code_id'],
                ['id'],
                ['onDelete' => 'SET NULL', 'onUpdate' => null]
            );
        }
        if (!$table->hasColumn('business_unit_id')) {
            $table->addColumn('business_unit_id', 'integer', ['notnull' => false]);
            $table->addForeignKeyConstraint(
                $schema->getTable('oro_business_unit'),
                ['business_unit_id'],
                ['id'],
                ['onDelete' => 'SET NULL', 'onUpdate' => null]
            );
        }
    }

    /**
     * @param Schema $schema
     * @throws \Doctrine\DBAL\Schema\SchemaException
     */
    private function addAgentTableColumns(Schema $schema): void
    {
        $table = $schema->getTable(GoPlanAgent::TABLE_NAME);
        if (!$table->hasColumn('opportunity_percent')) {
            $table->addColumn('opportunity_percent', 'integer', ['notnull' => false]);
        }
    }
}
