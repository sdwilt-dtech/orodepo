<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Schema\SchemaException;
use Doctrine\DBAL\Types\Types;
use DT\Bundle\EntityBundle\Entity;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\SetupBundle\Model\CustomerFields;
use Oro\Bundle\ActivityBundle\Migration\Extension\ActivityExtension;
use Oro\Bundle\ActivityBundle\Migration\Extension\ActivityExtensionAwareInterface;
use Oro\Bundle\AttachmentBundle\Migration\Extension\AttachmentExtension;
use Oro\Bundle\AttachmentBundle\Migration\Extension\AttachmentExtensionAwareInterface;
use Oro\Bundle\CustomerBundle\Migrations\Schema\OroCustomerBundleInstaller;
use Oro\Bundle\EntityBundle\EntityConfig\DatagridScope;
use Oro\Bundle\EntityExtendBundle\EntityConfig\ExtendScope;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtension;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtensionAwareInterface;
use Oro\Bundle\MigrationBundle\Migration\Installation;
use Oro\Bundle\MigrationBundle\Migration\ParametrizedSqlMigrationQuery;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

/**
 * @SuppressWarnings(PHPMD.TooManyMethods)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 * @SuppressWarnings(PHPMD.ExcessiveClassLength)
 */
class DTAccountPlanBundleInstaller implements
    Installation,
    ExtendExtensionAwareInterface,
    AttachmentExtensionAwareInterface,
    ActivityExtensionAwareInterface
{
    private const VERSION = 'v1_15_1';

    /** @var ExtendExtension */
    protected $extendExtension;

    /** @var AttachmentExtension */
    protected $attachmentExtension;

    private ActivityExtension $activityExtension;

    /**
     * {@inheritdoc}
     */
    public function setExtendExtension(ExtendExtension $extendExtension)
    {
        $this->extendExtension = $extendExtension;
    }

    /**
     * @param AttachmentExtension $attachmentExtension
     */
    public function setAttachmentExtension(AttachmentExtension $attachmentExtension)
    {
        $this->attachmentExtension = $attachmentExtension;
    }

    /**
     * {@inheritdoc}
     */
    public function getMigrationVersion()
    {
        return self::VERSION;
    }

    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $this->createRegionRepTable($schema);
        $this->createOpportunityGroupTable($schema);
        $this->createAccountPlanTable($schema);
        $this->createGoOpportunityStageTable($schema);
        $this->createOpportunityTable($schema, $queries);
        $this->createGoPlanAgentTable($schema);
        $this->addEnums($schema, $queries);
        $this->addAttachmentAssociations($schema);
        $this->addCustomerFields($schema, $queries);
        $this->enableActivities($schema);
    }

    /**
     * @param Schema $schema
     */
    private function createGoOpportunityStageTable(Schema $schema): void
    {
        $table = $schema->createTable(Entity\GoOpportunityStage::TABLE_NAME);
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('name', 'string', ['length' => 255, 'notnull' => true]);
        $table->addColumn('probability', 'integer', ['notnull' => true]);
        $table->addColumn('created_at', 'datetime');
        $table->addColumn('updated_at', 'datetime');
        $table->addColumn('organization_id', 'integer', ['notnull' => false]);

        $table->setPrimaryKey(['id']);

        $table->addUniqueIndex(
            ['name'],
            'dt_go_opportunity_stage_name_uidx'
        );
    }

    /**
     * @param Schema $schema
     *
     * @throws SchemaException
     */
    private function createRegionRepTable(Schema $schema): void
    {
        $table = $schema->createTable(Entity\GoRegionRep::TABLE_NAME);
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('name', 'string', ['length' => 255]);
        $table->addColumn('organization_id', 'integer', ['notnull' => false]);
        $table->addColumn('business_unit_id', 'integer', ['notnull' => true]);
        $table->addColumn('region_id', 'integer', ['notnull' => true]);
        $table->addColumn('rep_code_id', 'integer', ['notnull' => false]);
        $table->addColumn('text_id', 'string', ['length' => 255, 'notnull' => true]);
        $table->addColumn('created_at', 'datetime');
        $table->addColumn('updated_at', 'datetime');
        $table->addColumn('agency_tier_level', 'integer', ['notnull' => false]);
        $table->addColumn('salesforce_id', 'string', ['length' => 18, 'notnull' => false]);
        $table->addColumn('user_owner_id', 'integer', ['notnull' => false]);
        $table->addColumn('agency_target', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('regional_target', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('national_direct_target', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('currency_iso_code', 'string', ['length' => 3, 'notnull' => false]);

        $table->setPrimaryKey(['id']);

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_organization'),
            ['organization_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_business_unit'),
            ['business_unit_id'],
            ['id'],
            ['onDelete' => 'CASCADE', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('dt_rep_code'),
            ['rep_code_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('dt_region'),
            ['region_id'],
            ['id'],
            ['onDelete' => 'RESTRICT', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_user'),
            ['user_owner_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addUniqueIndex(
            ['text_id'],
            'dt_go_region_rep_text_id_uidx'
        );
    }

    /**
     * @param Schema $schema
     *
     * @throws SchemaException
     */
    private function createOpportunityGroupTable(Schema $schema): void
    {
        $table = $schema->createTable(Entity\GoOpportunityGroup::TABLE_NAME);
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('organization_id', 'integer', ['notnull' => false]);
        $table->addColumn('business_unit_id', 'integer', ['notnull' => true]);
        $table->addColumn('region_rep_id', 'integer', ['notnull' => false]);
        $table->addColumn('region_id', 'integer', ['notnull' => true]);
        $table->addColumn('rep_code_id', 'integer', ['notnull' => false]);
        $table->addColumn('customer_id', 'integer', ['notnull' => true]);
        $table->addColumn('created_at', 'datetime');
        $table->addColumn('updated_at', 'datetime');
        $table->addColumn('name', 'string', ['length' => 255]);
        $table->addColumn('text_id', 'string', ['length' => 255, 'notnull' => true]);
        $table->addColumn('regional_manager_email', 'string', ['length' => 255, 'notnull' => false]);
        $table->addColumn('sales_support_email', 'string', ['length' => 255, 'notnull' => false]);
        $table->addColumn('salesforce_id', 'string', ['length' => 18, 'notnull' => false]);
        $table->addColumn('currency_iso_code', 'string', ['length' => 3, 'notnull' => false]);
        $table->addColumn('user_owner_id', 'integer', ['notnull' => false]);
        $table->addColumn('state', 'string', ['length' => 2, 'notnull' => false]);
        $table->addColumn('fiscal_year', 'integer', ['notnull' => false]);

        $table->setPrimaryKey(['id']);

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_organization'),
            ['organization_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_business_unit'),
            ['business_unit_id'],
            ['id'],
            ['onDelete' => 'CASCADE', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable(Entity\GoRegionRep::TABLE_NAME),
            ['region_rep_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('dt_region'),
            ['region_id'],
            ['id'],
            ['onDelete' => 'RESTRICT', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('dt_rep_code'),
            ['rep_code_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_customer'),
            ['customer_id'],
            ['id'],
            ['onDelete' => 'CASCADE', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_user'),
            ['user_owner_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addUniqueIndex(
            ['text_id'],
            'dt_go_opportunity_group_text_id_uidx'
        );
    }

    /**
     * @param Schema $schema
     * @param QueryBag $queries
     *
     * @throws SchemaException
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    private function createOpportunityTable(Schema $schema, QueryBag $queries): void
    {
        $table = $schema->createTable(Entity\GoOpportunity::TABLE_NAME);
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('organization_id', 'integer', ['notnull' => false]);
        $table->addColumn('account_plan_id', 'integer', ['notnull' => false]);
        $table->addColumn('opportunity_group_id', 'integer', ['notnull' => false]);
        $table->addColumn('name', 'string', ['length' => 255]);
        $table->addColumn('customer_id', 'integer', ['notnull' => true]);
        $table->addColumn('created_at', 'datetime');
        $table->addColumn('updated_at', 'datetime');
        $table->addColumn('close_date', 'datetime', ['notnull' => false]);
        $table->addColumn('text_id', 'string', ['length' => 255, 'notnull' => false]);
        $table->addColumn('category_code_id', 'integer', ['notnull' => false]);
        $table->addColumn('revenue_start_date', 'integer', ['notnull' => false]);
        $table->addColumn('ask_quarter', 'integer', ['notnull' => false]);
        $table->addColumn('salesforce_id', 'string', ['length' => 18, 'notnull' => false]);
        $table->addColumn('region_id', 'integer', ['notnull' => false]);
        $table->addColumn('rep_code_id', 'integer', ['notnull' => false]);
        $table->addColumn('business_unit_id', 'integer', ['notnull' => false]);
        $table->addColumn('user_owner_id', 'integer', ['notnull' => false]);
        $table->addColumn('stage_id', 'integer', ['notnull' => false]);
        $table->addColumn('py', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('target', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('ytd', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('probability', 'integer', ['notnull' => true]);
        $table->addColumn('calc_opp_value', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('verified_cat_value', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('targeted_opp_value', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('likehood', 'integer', ['notnull' => false]);
        $table->addColumn(
            'other_business_challenger',
            'string',
            ['length' => 255, 'notnull' => false]
        );
        $table->addColumn('other_hvac_competitor', 'string', ['length' => 255, 'notnull' => false]);
        $table->addColumn('priority_rating', 'integer', ['notnull' => false]);
        $table->addColumn('fiscal_year', 'integer', ['notnull' => false]);
        $table->addColumn('notes', 'text', ['notnull' => false]);
        $table->addColumn('explanation_for_loss', 'text', ['notnull' => false]);
        $table->addColumn('currency_iso_code', 'string', ['length' => 3, 'notnull' => false]);
        $table->addColumn('gp_close_date', 'datetime', ['notnull' => false]);
        $table->addColumn('fiscal_quarter', 'integer', ['notnull' => false]);
        $table->addColumn('amount', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('dollar_amount_won', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);

        $table->addColumn('next_step', 'string', ['length' => 255, 'notnull' => false]);
        $table->addColumn('job_quote', 'boolean', ['notnull' => true, 'default' => false]);
        $table->addColumn('job_quote_name', 'string', ['notnull' => false, 'length' => 45]);
        $table->addColumn('date_sample_sent', 'datetime', ['notnull' => false]);
        $table->addColumn('situation_description', 'text', ['notnull' => false]);
        $table->addColumn('notify_cust_contact_id', 'integer', ['notnull' => false]);
        $table->addColumn('notify_sales_rep_id', 'integer', ['notnull' => false]);
        $table->addColumn('notify_rsm_id', 'integer', ['notnull' => false]);

        $table->setPrimaryKey(['id']);

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_organization'),
            ['organization_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable(Entity\GoAccountPlan::TABLE_NAME),
            ['account_plan_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable(Entity\GoOpportunityGroup::TABLE_NAME),
            ['opportunity_group_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_customer'),
            ['customer_id'],
            ['id'],
            ['onDelete' => 'CASCADE', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('orocrm_contact'),
            ['notify_cust_contact_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_user'),
            ['notify_sales_rep_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_user'),
            ['notify_rsm_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('dt_product_category_code'),
            ['category_code_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('dt_region'),
            ['region_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('dt_rep_code'),
            ['rep_code_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );
        $table->addForeignKeyConstraint(
            $schema->getTable('oro_business_unit'),
            ['business_unit_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );
        $table->addForeignKeyConstraint(
            $schema->getTable('oro_user'),
            ['user_owner_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );
        $table->addForeignKeyConstraint(
            $schema->getTable(Entity\GoOpportunityStage::TABLE_NAME),
            ['stage_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addUniqueIndex(
            ['text_id'],
            'dt_go_opportunity_text_id_uidx'
        );

        $table->addUniqueIndex(
            ['salesforce_id'],
            'dt_go_opportunity_salesforce_id_uidx'
        );
    }

    /**
     * @param Schema $schema
     *
     * @throws SchemaException
     */
    private function createGoPlanAgentTable(Schema $schema): void
    {
        $table = $schema->createTable(Entity\GoPlanAgent::TABLE_NAME);
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('organization_id', 'integer', ['notnull' => false]);
        $table->addColumn('user_id', 'integer', ['notnull' => false]);
        $table->addColumn('opportunity_group_id', 'integer', ['notnull' => true]);
        $table->addColumn('name', 'string', ['length' => 255]);
        $table->addColumn('created_at', 'datetime');
        $table->addColumn('updated_at', 'datetime');
        $table->addColumn('currency_iso_code', 'string', ['length' => 3, 'notnull' => false]);
        $table->addColumn('salesforce_id', 'string', ['length' => 18, 'notnull' => false]);
        $table->addColumn('opportunity_percent', 'integer', ['notnull' => false]);

        $table->setPrimaryKey(['id']);

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_organization'),
            ['organization_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_user'),
            ['user_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable(Entity\GoOpportunityGroup::TABLE_NAME),
            ['opportunity_group_id'],
            ['id'],
            ['onDelete' => 'CASCADE', 'onUpdate' => null]
        );
    }

    /**
     * @param Schema $schema
     *
     * @throws SchemaException
     */
    public function createAccountPlanTable(Schema $schema): void
    {
        $table = $schema->createTable(Entity\GoAccountPlan::TABLE_NAME);
        $table->addColumn('id', 'integer', ['autoincrement' => true]);
        $table->addColumn('organization_id', 'integer', ['notnull' => false]);
        $table->addColumn('name', 'string', ['length' => 255]);
        $table->addColumn('customer_id', 'integer', ['notnull' => true]);
        $table->addColumn('created_at', 'datetime');
        $table->addColumn('updated_at', 'datetime');
        $table->addColumn('is_active', 'boolean', ['notnull' => true]);
        $table->addColumn('user_owner_id', 'integer', ['notnull' => false]);
        $table->addColumn('track', 'boolean', ['notnull' => true, 'default' => false]);
        $table->addColumn('fiscal_year', 'integer', ['notnull' => false]);
        $table->addColumn('account_dollar', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('total_prior_year_sales', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('actual_ytd', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('prior_ytd', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('current_year_value_keep', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('current_year_value_grow', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('current_year_value_convert', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('current_year_value_npi', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('current_year_value_pipeline', 'money', [
            'precision' => 19,
            'scale' => 4,
            'comment' => '(DC2Type:money)',
            'notnull' => false,
        ]);
        $table->addColumn('currency_iso_code', 'string', ['length' => 3, 'notnull' => false]);
        $table->addColumn('salesforce_id', 'string', ['length' => 18, 'notnull' => false]);

        $table->setPrimaryKey(['id']);

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_organization'),
            ['organization_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_user'),
            ['user_owner_id'],
            ['id'],
            ['onDelete' => 'SET NULL', 'onUpdate' => null]
        );

        $table->addForeignKeyConstraint(
            $schema->getTable('oro_customer'),
            ['customer_id'],
            ['id'],
            ['onDelete' => 'CASCADE', 'onUpdate' => null]
        );
    }

    /**
     * Creates enums with values
     *
     * @param Schema $schema
     * @param QueryBag $queries
     *
     * @throws SchemaException
     */
    private function addEnums(Schema $schema, QueryBag $queries): void
    {
        foreach ($this->getAvailableEnums() as $tableName => $properties) {
            $table = $schema->getTable($tableName);
            foreach ($properties as $enumCode => $valueData) {
                $properties = $valueData['property'] ?? $enumCode;
                $properties = is_array($properties) ? $properties : [$properties];
                $values = $valueData['values'] ?? [];
                $isMultiple = $valueData['multiple'];
                $indexesAsKeys = $valueData['indexesAsKeys'] ?? false;
                $params = [
                    'id' => Types::STRING,
                    'name' => Types::STRING,
                    'priority' => Types::STRING,
                    'is_default' => Types::BOOLEAN,
                ];
                foreach ($properties as $property) {
                    $enumTable = $this->extendExtension->addEnumField(
                        $schema,
                        $table,
                        $property,
                        $enumCode,
                        $isMultiple,
                        false,
                        [
                            'extend' => [
                                'is_extend' => true,
                                'owner' => ExtendScope::OWNER_SYSTEM,
                            ],
                            'datagrid' => ['is_visible' => DatagridScope::IS_VISIBLE_TRUE],
                            'dataaudit' => ['auditable' => true],
                        ]
                    );
                }

                if (count($values)) {
                    $sql = sprintf(
                        'INSERT INTO %s (id, name, priority, is_default) VALUES (:id, :name, :priority, :is_default)',
                        $enumTable->getName()
                    );
                    $i = 1;
                    foreach ($values as $key => $value) {
                        $query = new ParametrizedSqlMigrationQuery();
                        $query->addSql(
                            $sql,
                            [
                                'id' => $indexesAsKeys ? $key : $value,
                                'name' => $value,
                                'priority' => $i,
                                'is_default' => false,
                            ],
                            $params
                        );
                        $queries->addQuery($query);
                        $i++;
                    }
                }
            }
        }
    }

    /**
     * @return array
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    private function getAvailableEnums(): array
    {
        return [
            Entity\GoOpportunityGroup::TABLE_NAME => [
                Entity\GoOpportunityGroup::ENUM_OPPORTUNITY_YEAR => [
                    'values' => [
                        'Current',
                        'Previous',
                    ],
                    'property' => 'opportunity_year',
                    'multiple' => false,
                ],
            ],
            Entity\GoPlanAgent::TABLE_NAME => [
                Entity\GoPlanAgent::ENUM_RECORD_TYPE => [
                    'values' => [
                        'GP CY Agents',
                        'GP Old Agents',
                    ],
                    'property' => 'record_type',
                    'multiple' => false,
                ],
            ],
            Entity\GoOpportunity::TABLE_NAME => [
                Entity\GoOpportunity::ENUM_SALES_OPPORTUNITY_TYPE => [
                    'values' => [
                        'Convert',
                        'Grow',
                        'Keep',
                        'NPI',
                        'Pipeline',
                        'Go Plan',
                    ],
                    'property' => 'sales_opportunity_type',
                    'multiple' => false,
                ],
                Entity\GoOpportunity::ENUM_FORECAST_CATEGORY => [
                    'values' => [
                        'Omitted',
                        'Pipeline',
                        'Closed',
                        'BestCase',
                        'Forecast',
                        'Commit',
                    ],
                    'property' => 'forecast_category',
                    'multiple' => false,
                ],
                Entity\GoOpportunity::ENUM_REASON_FOR_CLOSED_LOST => [
                    'values' => [
                        'End of year Go Plan',
                        'No product purchased within 90 days of sample.',
                        'Brand Loyalty/Program',
                        'Pricing',
                        'Competitor won',
                        'Specs/Product compatibility',
                        'Lead time/Product Availability',
                        'Specs/ product compatibility',
                        'Project/job canceled; postponed',
                        'Exclusivity on brand',
                        'Product availability',
                        'Other--Explanation Required',
                    ],
                    'indexesAsKeys' => true,
                    'property' => 'reason_closed_lost',
                    'multiple' => false,
                ],
                Entity\GoOpportunity::ENUM_OPPORTUNITY_TYPE => [
                    'values' => [
                        'Job Quote',
                        'Standard Quote',
                        'Sample Request',
                        'Private Label',
                        'New Channel',
                        'New Category',
                        'Defend Business',
                        'New Customer',
                        'Shift Share',
                        'New Product',
                        'New Products',
                        'Replace Competitor',
                        'Quick Quote',
                        'Regain Lost Business',
                    ],
                    'property' => 'opportunity_type',
                    'multiple' => false,
                ],
                Entity\GoOpportunity::ENUM_OPPORTUNITY_SOURCE => [
                    'values' => [
                        'Regional Manager',
                        'Rep Generated',
                        'Sales Initiative',
                        'Tradeshow',
                        'Web',
                        'CSR Generated',
                    ],
                    'property' => 'opportunity_source',
                    'multiple' => false,
                ],
                Entity\GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE => [
                    'values' => [
                        'HVAC',
                        'Sample Request Opp',
                        'HVAC Old GP',
                        'Electrical Sales',
                        'RSM Recovery',
                        'HVAC Go Plan',
                        'Utilities',
                        'Util-LC',
                        'EU Accounts',
                    ],
                    'property' => 'opportunity_record_type',
                    'multiple' => false,
                ],
                Entity\GoOpportunity::ENUM_SALES_INITIATIVE_TYPE => [
                    'values' => [
                        'Product',
                        'Rgional',
                        'National',
                        'Company',
                    ],
                    'property' => 'sales_initiative_type',
                    'multiple' => false,
                ],
                Entity\GoOpportunity::ENUM_BUSINESS_CHALLENGER => [
                    'property' => ['business_challenger', 'hvac_competitor'],
                    'multiple' => true,
                    'values' => [
                        '.',
                        'AC Guard',
                        'Ace',
                        'ACT',
                        'Advanced',
                        'Anaconda',
                        'AO Smith',
                        'Arlington',
                        'Aspen',
                        'Beckett',
                        'Bramec',
                        'Broad Ocean',
                        'Buffalo',
                        'Cambridge',
                        'Carlon',
                        'Carly',
                        'Carrier',
                        'Carson',
                        'Cooper B-Line',
                        'CPS',
                        'Cutler Hammer',
                        'Danfoss',
                        'Dormont',
                        'Dottie',
                        'Dow',
                        'DuroDyne',
                        'Emerson',
                        'Everwell',
                        'Evolve',
                        'Fortress',
                        'Galpa',
                        'GE',
                        'Global',
                        'Hydrobalance',
                        'ICM',
                        'JB',
                        'JMF',
                        'Kaf-Tech',
                        'Klein',
                        'KMP',
                        'LineHide',
                        'Little Giant',
                        'Littlefuse',
                        'Local',
                        'Lyft Safety',
                        'MA Line',
                        'Madison',
                        'Malco',
                        'Mars',
                        'Miami-Tech',
                        'Midwest',
                        'Milbank',
                        'Mitsubishi',
                        'Mueller',
                        'NewTech',
                        'Nidec',
                        'Nu Calgon',
                        'OEM',
                        'Other',
                        'Packard',
                        'Peco',
                        'Priority Wire',
                        'Private Label',
                        'Pro-Stock',
                        'Quality',
                        'Qwik',
                        'Rectorseal',
                        'Ritchie',
                        'Ritchie/Yellow Jacket',
                        'Sauermann',
                        'SES',
                        'ShuBee',
                        'Siccom',
                        'Siemens',
                        'Smart Electric',
                        'Southwire',
                        'SQD',
                        'Supco',
                        'Superior Stands',
                        'SurTape',
                        'Thomas & Betts',
                        'Topaz',
                        'Unknown',
                        'US Motors',
                        'Vapco',
                        'Venti',
                        'Xantus',
                        'York',
                    ],
                ],
            ],
            Entity\GoRegionRep::TABLE_NAME => [
                Entity\GoRegionRep::ENUM_AGENCY_TIER => [
                    'values' => [
                        'Big 5',
                        'Core Market',
                        'Growth Market',
                    ],
                    'property' => 'agency_tier',
                    'multiple' => false,
                ],
                Entity\GoRegionRep::ENUM_KCG_CUSTOMER_SEGMENT => [
                    'values' => [
                        'Core',
                        'Strategic',
                        'National',
                    ],
                    'property' => 'kcg_customer_segment',
                    'multiple' => false,
                ],
            ],
            Entity\GoOpportunityStage::TABLE_NAME => [
                Entity\GoOpportunityStage::ENUM_OPPORTUNITY_STAGE_TYPE => [
                    'values' => [
                        'Open',
                        'Closed/Won',
                        'Closed/Lost',
                    ],
                    'property' => 'type',
                    'multiple' => false,
                ],
                Entity\GoOpportunity::ENUM_FORECAST_CATEGORY => [
                    'property' => 'forecast_category',
                    'multiple' => false,
                ],
            ],
        ];
    }

    /**
     * @param Schema $schema
     */
    private function addAttachmentAssociations(Schema $schema)
    {
        $this->attachmentExtension->addAttachmentAssociation($schema, GoOpportunity::TABLE_NAME);
    }

    /**
     * Adds customer fields
     *
     * @param Schema $schema
     * @param QueryBag $queries
     *
     * @throws \Doctrine\DBAL\Schema\SchemaException
     */
    private function addCustomerFields(Schema $schema, QueryBag $queries): void
    {
        $table = $schema->getTable(OroCustomerBundleInstaller::ORO_CUSTOMER_TABLE_NAME);
        $this->extendExtension->addEnumField(
            $schema,
            $table,
            CustomerFields::DT_KCG_CUSTOMER_SEGMENT,
            GoRegionRep::ENUM_KCG_CUSTOMER_SEGMENT,
            false,
            false,
            [
                'extend' => [
                    'is_extend' => true,
                    'owner' => ExtendScope::OWNER_CUSTOM,
                    'nullable' => true,
                ],
                'datagrid' => ['is_visible' => DatagridScope::IS_VISIBLE_HIDDEN, 'show_filter' => false],
                'form' => ['is_enabled' => true],
                'view' => ['is_displayable' => true],
                'merge' => ['display' => false],
                'dataaudit' => ['auditable' => true],
            ]
        );
    }

    /**
     * {@inheritdoc}
     */
    public function enableActivities(Schema $schema)
    {
        $activitiesMapping = [
            'oro_email' => [
                'dt_go_opportunity',
                'dt_go_opportunity_group',
                'dt_go_account_plan',
                'dt_go_region_rep',
                'dt_go_plan_agent',
            ],
            'orocrm_call' => [
                'dt_go_opportunity',
                'dt_go_opportunity_group',
                'dt_go_account_plan',
                'dt_go_region_rep',
                'dt_go_plan_agent',
            ],
            'orocrm_task' => [
                'dt_go_opportunity',
                'dt_go_opportunity_group',
                'dt_go_account_plan',
                'dt_go_region_rep',
                'dt_go_plan_agent',
            ],
            'oro_note' => [
                'dt_go_opportunity',
                'dt_go_opportunity_group',
                'dt_go_account_plan',
                'dt_go_region_rep',
                'dt_go_plan_agent',
            ],
        ];

        foreach ($activitiesMapping as $activityTable => $targetEntityTables) {
            foreach ($targetEntityTables as $targetEntityTable) {
                $associationTableName = $this->activityExtension->getAssociationTableName(
                    $activityTable,
                    $targetEntityTable
                );
                if (!$schema->hasTable($associationTableName)) {
                    $this->activityExtension->addActivityAssociation(
                        $schema,
                        $activityTable,
                        $targetEntityTable,
                        false
                    );
                }
            }
        }
    }

    /**
     * {@inheritdoc}
     */
    public function setActivityExtension(ActivityExtension $activityExtension)
    {
        $this->activityExtension = $activityExtension;
    }
}
