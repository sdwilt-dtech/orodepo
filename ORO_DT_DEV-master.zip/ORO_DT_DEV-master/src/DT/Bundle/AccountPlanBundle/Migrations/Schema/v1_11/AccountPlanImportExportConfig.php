<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_11;

use Doctrine\DBAL\Schema\Schema;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\GoPlanAgent;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\EntityConfigBundle\Migration\UpdateEntityConfigFieldValueQuery;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AccountPlanImportExportConfig implements Migration
{
    private static $configs = [
        GoPlanAgent::class => [
            'owner' => ['order' => 50, 'short' => true, 'full' => false],
            'salesforceId' => ['order' => 15],
            'updatedAt' => ['excluded' => true],
            'createdAt' => ['excluded' => true]
        ],
        GoOpportunityGroup::class => [
            'owner' => ['order' => 80, 'short' => true, 'full' => false],
            'organization' =>  ['order' => 70, 'short' => true, 'full' => false],
            'salesforceId' => ['order' => 15],
            'updatedAt' => ['excluded' => true],
            'createdAt' => ['excluded' => true]
        ],
        GoOpportunity::class => [
            'businessUnit' =>  ['order' => 260, 'short' => true, 'full' => false],
            'owner' => ['order' => 380, 'short' => true, 'full' => false],
            'organization' =>  ['order' => 390, 'short' => true, 'full' => false],
            'business_challenger' =>  ['order' => 400, 'short' => true, 'full' => false],
            'hvac_competitor' =>  ['order' => 410, 'short' => true, 'full' => false],
            'updatedAt' => ['excluded' => true],
            'createdAt' => ['excluded' => true]
        ],
        GoAccountPlan::class => [
            'owner' => ['order' => 140, 'short' => true, 'full' => false],
            'organization' =>  ['order' => 150, 'short' => true, 'full' => false],
            'updatedAt' => ['excluded' => true],
            'createdAt' => ['excluded' => true]
        ],
        GoRegionRep::class => [
            'owner' => ['order' => 60, 'short' => true, 'full' => false],
            'updatedAt' => ['excluded' => true],
            'createdAt' => ['excluded' => true]
        ],
    ];
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        foreach (self::$configs as $class => $fields) {
            foreach ($fields as $field => $values) {
                foreach ($values as $code => $value) {
                    $queries->addQuery(
                        new UpdateEntityConfigFieldValueQuery(
                            $class,
                            $field,
                            'importexport',
                            $code,
                            $value
                        )
                    );
                }
            }
        }
    }
}
