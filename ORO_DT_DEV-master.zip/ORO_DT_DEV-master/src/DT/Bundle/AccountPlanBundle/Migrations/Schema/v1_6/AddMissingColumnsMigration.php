<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_6;

use Doctrine\DBAL\Schema\Schema;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddMissingColumnsMigration implements Migration
{
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $this->addOpportunityTableColumns($schema);
    }

    /**
     * @param Schema $schema
     * @throws \Doctrine\DBAL\Schema\SchemaException
     */
    private function addOpportunityTableColumns(Schema $schema): void
    {
        $table = $schema->getTable(GoOpportunity::TABLE_NAME);
        if (!$table->hasColumn('fiscal_quarter')) {
            $table->addColumn('fiscal_quarter', 'integer', ['notnull' => false]);
        }
    }
}
