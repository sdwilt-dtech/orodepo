<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_7;

use Doctrine\DBAL\Schema\Schema;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class DropNotifyCustomerRelation implements Migration
{
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $table = $schema->getTable(GoOpportunity::TABLE_NAME);
        foreach ($table->getForeignKeys() as $key) {
            if ($key->getForeignTableName() === 'oro_customer') {
                if (in_array('notify_customer_id', $key->getColumns())) {
                    $table->removeForeignKey($key->getName());
                }
            }
        }
        if ($table->hasColumn('notify_customer_id')) {
            $table->dropColumn('notify_customer_id');
        }

        if (!$table->hasColumn('notify_cust_contact_id')) {
            $table->addColumn('notify_cust_contact_id', 'integer', ['notnull' => false]);
        }
    }
}
