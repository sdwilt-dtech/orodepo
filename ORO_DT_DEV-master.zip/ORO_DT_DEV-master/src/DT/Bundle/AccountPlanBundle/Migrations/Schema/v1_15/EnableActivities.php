<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_15;

use Doctrine\DBAL\Schema\Schema;
use Oro\Bundle\ActivityBundle\Migration\Extension\ActivityExtension;
use Oro\Bundle\ActivityBundle\Migration\Extension\ActivityExtensionAwareInterface;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

/**
 * Enables activities for Go entities
 */
class EnableActivities implements Migration, ActivityExtensionAwareInterface
{
    protected ActivityExtension $activityExtension;

    /**
     * {@inheritdoc}
     */
    public function setActivityExtension(ActivityExtension $activityExtension)
    {
        $this->activityExtension = $activityExtension;
    }

    public function up(Schema $schema, QueryBag $queries)
    {
        $activitiesMapping = [
            'oro_email' => [
                'dt_go_opportunity',
                'dt_go_opportunity_group',
                'dt_go_account_plan',
                'dt_go_region_rep',
                'dt_go_plan_agent',
            ],
            'orocrm_call' => [
                'dt_go_opportunity',
                'dt_go_opportunity_group',
                'dt_go_account_plan',
                'dt_go_region_rep',
                'dt_go_plan_agent',
            ],
            'orocrm_task' => [
                'dt_go_opportunity',
                'dt_go_opportunity_group',
                'dt_go_account_plan',
                'dt_go_region_rep',
                'dt_go_plan_agent',
            ],
            'oro_note' => [
                'dt_go_opportunity',
                'dt_go_opportunity_group',
                'dt_go_account_plan',
                'dt_go_region_rep',
                'dt_go_plan_agent',
            ],
        ];

        foreach ($activitiesMapping as $activityTable => $targetEntityTables) {
            foreach ($targetEntityTables as $targetEntityTable) {
                $associationTableName = $this->activityExtension->getAssociationTableName(
                    $activityTable,
                    $targetEntityTable
                );
                if (!$schema->hasTable($associationTableName)) {
                    $this->activityExtension->addActivityAssociation(
                        $schema,
                        $activityTable,
                        $targetEntityTable,
                        false
                    );
                }
            }
        }
    }
}
