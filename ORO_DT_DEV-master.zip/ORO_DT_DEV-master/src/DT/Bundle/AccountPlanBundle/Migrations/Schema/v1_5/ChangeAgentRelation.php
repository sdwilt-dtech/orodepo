<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_5;

use Doctrine\DBAL\Schema\Schema;
use DT\Bundle\EntityBundle\Entity\GoPlanAgent;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class ChangeAgentRelation implements Migration
{
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $table = $schema->getTable(GoPlanAgent::TABLE_NAME);
        foreach ($table->getForeignKeys() as $key) {
            if ($key->getForeignTableName() === 'orocrm_contact') {
                $table->removeForeignKey($key->getName());
            }
        }
        if ($table->hasColumn('contact_id')) {
            $table->dropColumn('contact_id');
        }
        if (!$table->hasColumn('user_id')) {
            $table->addColumn('user_id', 'integer', ['notnull' => false]);
            $table->addForeignKeyConstraint(
                $schema->getTable('oro_user'),
                ['user_id'],
                ['id'],
                ['onDelete' => 'SET NULL', 'onUpdate' => null]
            );
        }
    }
}
