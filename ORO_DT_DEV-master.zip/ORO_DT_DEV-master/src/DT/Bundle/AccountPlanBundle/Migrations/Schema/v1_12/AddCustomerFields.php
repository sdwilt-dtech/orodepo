<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_12;

use Doctrine\DBAL\Schema\Schema;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use DT\Bundle\SetupBundle\Model\CustomerFields;
use Oro\Bundle\CustomerBundle\Migrations\Schema\OroCustomerBundleInstaller;
use Oro\Bundle\EntityBundle\EntityConfig\DatagridScope;
use Oro\Bundle\EntityExtendBundle\EntityConfig\ExtendScope;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtension;
use Oro\Bundle\EntityExtendBundle\Migration\Extension\ExtendExtensionAwareInterface;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class AddCustomerFields implements Migration, ExtendExtensionAwareInterface
{
    /** @var ExtendExtension */
    protected $extendExtension;

    /**
     * @param ExtendExtension $extendExtension
     */
    public function setExtendExtension(ExtendExtension $extendExtension)
    {
        $this->extendExtension = $extendExtension;
    }

    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $this->addCustomerFields($schema, $queries);
    }

    /**
     * Adds customer fields
     *
     * @param Schema $schema
     * @param QueryBag $queries
     * @throws \Doctrine\DBAL\Schema\SchemaException
     */
    private function addCustomerFields(Schema $schema, QueryBag $queries): void
    {
        $table = $schema->getTable(OroCustomerBundleInstaller::ORO_CUSTOMER_TABLE_NAME);
        $this->extendExtension->addEnumField(
            $schema,
            $table,
            CustomerFields::DT_KCG_CUSTOMER_SEGMENT,
            GoRegionRep::ENUM_KCG_CUSTOMER_SEGMENT,
            false,
            false,
            [
                'extend'    => [
                    'is_extend' => true,
                    'owner'     => ExtendScope::OWNER_CUSTOM,
                    'nullable'  => true
                ],
                'datagrid'  => ['is_visible' => DatagridScope::IS_VISIBLE_HIDDEN, 'show_filter' => false],
                'form'      => ['is_enabled' => true],
                'view'      => ['is_displayable' => true],
                'merge'     => ['display' => false],
                'dataaudit' => ['auditable' => true]
            ]
        );
    }
}
