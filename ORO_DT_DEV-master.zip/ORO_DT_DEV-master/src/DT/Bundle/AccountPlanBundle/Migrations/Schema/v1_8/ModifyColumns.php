<?php

namespace DT\Bundle\AccountPlanBundle\Migrations\Schema\v1_8;

use Doctrine\DBAL\Schema\Schema;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;

class ModifyColumns implements Migration
{
    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $table = $schema->getTable(GoOpportunity::TABLE_NAME);
        $table->changeColumn('text_id', [
            'notnull' => false
        ]);
    }
}
