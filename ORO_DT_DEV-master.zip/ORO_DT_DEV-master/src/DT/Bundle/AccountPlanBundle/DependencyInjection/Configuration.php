<?php

namespace DT\Bundle\AccountPlanBundle\DependencyInjection;

use Oro\Bundle\ConfigBundle\DependencyInjection\SettingsBuilder;
use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

class Configuration implements ConfigurationInterface
{
    public const ALIAS = 'dt_account_plan';
    public const CONFIG_MARKET_GROWTH_PERCENTAGE = 'market_growth_percentage';

    /**
     * {@inheritdoc}
     */
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder(self::ALIAS);
        $rootNode = $treeBuilder->getRootNode();

        SettingsBuilder::append($rootNode, [
            self::CONFIG_MARKET_GROWTH_PERCENTAGE => [
                'value' => 4.0,
                'type' => 'float',
            ]
        ]);

        return $treeBuilder;
    }

    /**
     * Returns aliased key
     *
     * @param string $config
     * @return string
     */
    public static function getAliasedKey(string $config): string
    {
        return sprintf('%s.%s', self::ALIAS, $config);
    }
}
