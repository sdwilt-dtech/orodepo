<?php

namespace DT\Bundle\AccountPlanBundle\DependencyInjection;

use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Loader;
use Symfony\Component\HttpKernel\DependencyInjection\Extension;

class DTAccountPlanExtension extends Extension
{
    /**
     * {@inheritdoc}
     */
    public function load(array $configs, ContainerBuilder $container)
    {
        $config = $this->processConfiguration(new Configuration(), $configs);
        $loader = new Loader\YamlFileLoader($container, new FileLocator(__DIR__.'/../Resources/config'));
        foreach ($this->getServicesFiles() as $file) {
            $loader->load($file);
        }
        $container->prependExtensionConfig($this->getAlias(), array_intersect_key($config, array_flip(['settings'])));
    }

    /**
     * @return array|string[]
     */
    protected function getServicesFiles(): array
    {
        return [
            'services.yml',
            'import_export.yml',
            'oroimportexport.yml',
            'controllers.yml',
            'forms.yml',
            'api.yml'
        ];
    }
}
