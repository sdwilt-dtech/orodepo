<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Form\Type\GoAccountPlanType;
use DT\Bundle\AccountPlanBundle\Model\MetricModelFactory;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class AccountPlanController extends AbstractController
{
    /**
     * @Route("/index", name="dt_go_plan_account_plan_index")
     * @Template("DTAccountPlanBundle:AccountPlan:index.html.twig")
     * @Acl(
     *      id="dt_go_plan_account_plan_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DT\Bundle\EntityBundle\Entity\GoAccountPlan"
     * )
     * @return array
     */
    public function indexAction(): array
    {
        return [
            'entity_class' => GoAccountPlan::class,
            'theme_name' => 'list-view',
            'grid_config' => [
                'go-plan-account-plan-grid',
            ],
        ];
    }

    /**
     * @Route("/create", name="dt_go_plan_account_plan_create")
     * @Acl(
     *      id="dt_go_plan_account_plan_create",
     *      type="entity",
     *      permission="CREATE",
     *      class="DT\Bundle\EntityBundle\Entity\GoAccountPlan"
     * )
     * @Template("DTAccountPlanBundle:AccountPlan:update.html.twig")
     */
    public function createAction()
    {
        return $this->update(new GoAccountPlan());
    }

    /**
     * @Route("/update/{id}", name="dt_go_plan_account_plan_update", requirements={"id"="\d+"})
     * @Acl(
     *      id="dt_go_plan_account_plan_update",
     *      type="entity",
     *      permission="EDIT",
     *      class="DT\Bundle\EntityBundle\Entity\GoAccountPlan"
     * )
     * @Template("DTAccountPlanBundle:AccountPlan:update.html.twig")
     *
     * @param GoAccountPlan $entity
     */
    public function updateAction(GoAccountPlan $entity)
    {
        return $this->update($entity);
    }

    /**
     * @param GoAccountPlan $entity
     * @return array|RedirectResponse
     */
    protected function update(GoAccountPlan $entity)
    {
        return $this->get('oro_form.update_handler')->update(
            $entity,
            $this->get('form.factory')->createNamed('dt_go_plan_account_plan', GoAccountPlanType::class),
            $this->get(TranslatorInterface::class)->trans('dt.account_plan.account_plan.form.saved.message')
        );
    }

    /**
     * @Route("/view/{id}", name="dt_go_plan_account_plan_view", requirements={"id"="\d+"})
     * @AclAncestor("dt_go_plan_account_plan_view")
     * @Template("DTAccountPlanBundle:AccountPlan:view.html.twig")
     *
     * @param GoAccountPlan $entity
     */
    public function viewAction(GoAccountPlan $entity)
    {
        return [
            'entity' => $entity,
            'model' => $this->get(MetricModelFactory::class)->getModel($entity)
        ];
    }
}
