<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Form\Type\GoRegionRepType;
use DT\Bundle\EntityBundle\Entity\GoRegionRep;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class RegionRepController extends AbstractTextIdAwareController
{
    /**
     * @Route("/index", name="dt_go_plan_region_rep_index")
     * @Acl(
     *      id="dt_go_plan_region_rep_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DT\Bundle\EntityBundle\Entity\GoRegionRep"
     * )
     * @Template("DTAccountPlanBundle:RegionRep:index.html.twig")
     *
     * @return array
     */
    public function indexAction(): array
    {
        return [
            'entity_class' => GoRegionRep::class,
            'theme_name' => 'list-view',
            'grid_config' => [
                'go-plan-region-rep-grid',
            ],
        ];
    }

    /**
     * @Route("/create", name="dt_go_plan_region_rep_create")
     * @Acl(
     *      id="dt_go_plan_region_rep_create",
     *      type="entity",
     *      permission="CREATE",
     *      class="DT\Bundle\EntityBundle\Entity\GoRegionRep"
     * )
     * @Template("DTAccountPlanBundle:RegionRep:update.html.twig")
     */
    public function createAction()
    {
        return $this->update(new GoRegionRep());
    }

    /**
     * @Route("/update/{id}", name="dt_go_plan_region_rep_update", requirements={"id"="\d+"})
     * @Acl(
     *      id="dt_go_plan_region_rep_update",
     *      type="entity",
     *      permission="EDIT",
     *      class="DT\Bundle\EntityBundle\Entity\GoRegionRep"
     * )
     * @Template("DTAccountPlanBundle:RegionRep:update.html.twig")
     *
     * @param GoRegionRep $entity
     */
    public function updateAction(GoRegionRep $entity)
    {
        return $this->update($entity);
    }

    /**
     * @param GoRegionRep $entity
     * @return array|RedirectResponse
     */
    protected function update(GoRegionRep $entity)
    {
        return $this->get('oro_form.update_handler')->update(
            $entity,
            $this->get('form.factory')->createNamed('dt_go_plan_region_rep', GoRegionRepType::class),
            $this->get(TranslatorInterface::class)->trans('dt.entity.goregionrep.form.saved.message')
        );
    }

    /**
     * @Route("/view/{id}", name="dt_go_plan_region_rep_view", requirements={"id"="\d+"})
     * @AclAncestor("dt_go_plan_region_rep_view")
     * @Template("DTAccountPlanBundle:RegionRep:view.html.twig")
     */
    public function viewAction(GoRegionRep $entity)
    {
        return ['entity' => $entity];
    }

    /**
     * @Route("generate-text-id/", name="dt_go_plan_region_rep_generate_text_id", options={"expose"=true})
     */
    public function textIdAction(): JsonResponse
    {
        return parent::textIdAction();
    }

    /**
     * {@inheritdoc}
     */
    protected function getHandledClass(): string
    {
        return GoRegionRep::class;
    }
}
