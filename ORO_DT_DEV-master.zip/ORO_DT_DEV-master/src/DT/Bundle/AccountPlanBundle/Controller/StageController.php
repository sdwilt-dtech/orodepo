<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Form\Type\GoOpportunityStageType;
use DT\Bundle\EntityBundle\Entity\GoOpportunityStage;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class StageController extends AbstractController
{
    /**
     * @Route("/index", name="dt_go_plan_opportunity_stage_index")
     * @AclAncestor("dt_go_plan_opportunity_stage_view")
     * @Template("DTAccountPlanBundle:Stage:index.html.twig")
     *
     * @return array
     */
    public function indexAction(): array
    {
        return [
            'entity_class' => GoOpportunityStage::class,
            'theme_name' => 'list-view',
            'grid_config' => [
                'go-plan-opportunity-stage-type-grid',
            ],
        ];
    }

    /**
     * @Route("/create", name="dt_go_plan_opportunity_stage_create")
     * @Acl(
     *      id="dt_go_plan_opportunity_stage_create",
     *      type="entity",
     *      permission="CREATE",
     *      class="DT\Bundle\EntityBundle\Entity\GoOpportunityStage"
     * )
     * @Template("DTAccountPlanBundle:Stage:update.html.twig")
     */
    public function createAction()
    {
        return $this->update(new GoOpportunityStage());
    }

    /**
     * @Route("/update/{id}", name="dt_go_plan_opportunity_stage_update", requirements={"id"="\d+"})
     * @Acl(
     *      id="dt_go_plan_opportunity_stage_update",
     *      type="entity",
     *      permission="EDIT",
     *      class="DT\Bundle\EntityBundle\Entity\GoOpportunityStage"
     * )
     * @Template("DTAccountPlanBundle:Stage:update.html.twig")
     *
     * @param GoOpportunityStage $entity
     */
    public function updateAction(GoOpportunityStage $entity)
    {
        return $this->update($entity);
    }

    /**
     * @param GoOpportunityStage $entity
     * @return array|RedirectResponse
     */
    protected function update(GoOpportunityStage $entity)
    {
        return $this->get('oro_form.update_handler')->update(
            $entity,
            $this->get('form.factory')
                ->createNamed('dt_go_plan_opportunity_stage', GoOpportunityStageType::class),
            $this->get(TranslatorInterface::class)->trans('dt.entity.goopportunitystage.form.saved.message')
        );
    }

    /**
     * @Route("/view/{id}", name="dt_go_plan_opportunity_stage_view", requirements={"id"="\d+"})
     * @Acl(
     *      id="dt_go_plan_opportunity_stage_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DT\Bundle\EntityBundle\Entity\GoOpportunityStage"
     * )
     * @Template("DTAccountPlanBundle:Stage:view.html.twig")
     */
    public function viewAction(GoOpportunityStage $entity)
    {
        return ['entity' => $entity];
    }
}
