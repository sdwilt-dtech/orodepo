<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Form\Type\GoPlanAgentType;
use DT\Bundle\EntityBundle\Entity\GoPlanAgent;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class PlanAgentController extends AbstractController
{
    /**
     * @Route("/index", name="dt_go_plan_plan_agent_index")
     * @Template("DTAccountPlanBundle:PlanAgent:index.html.twig")
     * @Acl(
     *      id="dt_go_plan_plan_agent_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DT\Bundle\EntityBundle\Entity\GoPlanAgent"
     * )
     * @return array
     */
    public function indexAction(): array
    {
        return [
            'entity_class' => GoPlanAgent::class,
            'theme_name' => 'list-view',
            'grid_config' => [
                'go-plan-agent-grid',
            ],
        ];
    }

    /**
     * @Route("/create", name="dt_go_plan_plan_agent_create")
     * @Acl(
     *      id="dt_go_plan_plan_agent_create",
     *      type="entity",
     *      permission="CREATE",
     *      class="DT\Bundle\EntityBundle\Entity\GoPlanAgent"
     * )
     * @Template("DTAccountPlanBundle:PlanAgent:update.html.twig")
     */
    public function createAction()
    {
        return $this->update(new GoPlanAgent());
    }

    /**
     * @Route("/update/{id}", name="dt_go_plan_plan_agent_update", requirements={"id"="\d+"})
     * @Acl(
     *      id="dt_go_plan_plan_agent_update",
     *      type="entity",
     *      permission="EDIT",
     *      class="DT\Bundle\EntityBundle\Entity\GoPlanAgent"
     * )
     * @Template("DTAccountPlanBundle:PlanAgent:update.html.twig")
     *
     * @param GoPlanAgent $entity
     */
    public function updateAction(GoPlanAgent $entity)
    {
        return $this->update($entity);
    }

    /**
     * @param GoPlanAgent $entity
     * @return array|RedirectResponse
     */
    protected function update(GoPlanAgent $entity)
    {
        return $this->get('oro_form.update_handler')->update(
            $entity,
            $this->get('form.factory')->createNamed('dt_go_plan_plan_agent', GoPlanAgentType::class),
            $this->get(TranslatorInterface::class)->trans('dt.account_plan.plan_agent.form.saved.message')
        );
    }

    /**
     * @Route("/view/{id}", name="dt_go_plan_plan_agent_view", requirements={"id"="\d+"})
     * @AclAncestor("dt_go_plan_plan_agent_view")
     * @Template("DTAccountPlanBundle:PlanAgent:view.html.twig")
     *
     * @param GoPlanAgent $entity
     */
    public function viewAction(GoPlanAgent $entity)
    {
        return ['entity' => $entity];
    }
}
