<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Provider\TextId\NameAwareTextIdProviderInterface;
use DT\Bundle\AccountPlanBundle\Provider\TextId\TextIdProviderRegistry;
use Symfony\Component\HttpFoundation\JsonResponse;

abstract class AbstractTextIdAwareController extends AbstractController
{
    /**
     * Handles form data to generate textID
     *
     * @return JsonResponse
     */
    public function textIdAction(): JsonResponse
    {
        $request = $this->get('request_stack')->getMasterRequest();
        $textIdProvider = $this
            ->get(TextIdProviderRegistry::class)
            ->getProvider($this->getHandledClass());

        $data = [
            'textId' => $textIdProvider->getTextId($request)
        ];

        if ($textIdProvider instanceof NameAwareTextIdProviderInterface) {
            $data['name'] = $textIdProvider->getName($request);
        }

        return new JsonResponse($data);
    }

    /**
     * Returns class name for the controller
     *
     * @return string
     */
    abstract protected function getHandledClass(): string;

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return array_merge(parent::getSubscribedServices(), [
            TextIdProviderRegistry::class
        ]);
    }
}
