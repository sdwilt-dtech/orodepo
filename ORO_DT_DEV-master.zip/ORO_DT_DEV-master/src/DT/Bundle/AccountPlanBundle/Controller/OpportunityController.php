<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Form\Type\GoOpportunityType;
use DT\Bundle\AccountPlanBundle\Form\Type\Subscriber\ModifiersRegistry;
use DT\Bundle\AccountPlanBundle\Model\MetricModelFactory;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use Oro\Bundle\EntityExtendBundle\Provider\EnumValueProvider;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class OpportunityController extends AbstractTextIdAwareController
{
    /**
     * @Route("/index", name="dt_go_plan_opportunity_index")
     * @Template("DTAccountPlanBundle:Opportunity:index.html.twig")
     * @Acl(
     *      id="dt_go_plan_opportunity_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DT\Bundle\EntityBundle\Entity\GoOpportunity"
     * )
     * @return array
     */
    public function indexAction(): array
    {
        return [
            'entity_class' => GoOpportunity::class,
            'theme_name' => 'list-view',
            'grid_config' => [
                'go-plan-opportunity-grid',
            ],
        ];
    }
    /**
     * @Route("/create", name="dt_go_plan_opportunity_create")
     * @Acl(
     *      id="dt_go_plan_opportunity_create",
     *      type="entity",
     *      permission="CREATE",
     *      class="DT\Bundle\EntityBundle\Entity\GoOpportunity"
     * )
     */
    public function createAction()
    {
        $opportunity = new GoOpportunity();
        if (($type = $this->getOpportunityRecordType($opportunity))) {
            $typeEntity = $this->get(EnumValueProvider::class)->getEnumValueByCode(
                GoOpportunity::ENUM_OPPORTUNITY_RECORD_TYPE,
                $type
            );
            $typeEntity && $opportunity->setOpportunityRecordType($typeEntity);
        }

        if (($group = $this->getOpportunityGroup())) {
            $opportunity->setOpportunityGroup($group);
            $opportunity->setCustomer($group->getCustomer());
            $opportunity->setRegion($group->getRegion());
            $opportunity->setSalesAgency($group->getSalesAgency());
            $opportunity->setRepCode($group->getRepCode());
        }

        return $this->update($opportunity);
    }

    /**
     * @param GoOpportunity $opportunity
     * @return string|null
     */
    private function getOpportunityRecordType(GoOpportunity $opportunity): ?string
    {
        if ($opportunity->getOpportunityRecordType()) {
            return $opportunity->getOpportunityRecordType()->getId();
        }
        $request = $this->get('request_stack')->getCurrentRequest();
        $data = $request->get(GoOpportunityType::NAME, []);
        if (($type = $data['opportunity_record_type'] ?? null)) {
            return $type;
        }

        return null;
    }

    /**
     * @return GoOpportunityGroup|null
     */
    private function getOpportunityGroup(): ?GoOpportunityGroup
    {
        $request = $this->get('request_stack')->getCurrentRequest();
        $groupId = $request->get('opportunity_group_id', 0);
        if ($groupId) {
            return $this->getDoctrine()
                ->getRepository(GoOpportunityGroup::class)
                ->find($groupId);
        }

        return null;
    }

    /**
     * @Route("/update/{id}", name="dt_go_plan_opportunity_update", requirements={"id"="\d+"})
     * @Acl(
     *      id="dt_go_plan_opportunity_update",
     *      type="entity",
     *      permission="EDIT",
     *      class="DT\Bundle\EntityBundle\Entity\GoOpportunity"
     * )
     *
     * @param GoOpportunity $entity
     */
    public function updateAction(GoOpportunity $entity)
    {
        return $this->update($entity);
    }

    /**
     * @param GoOpportunity $entity
     * @return Response
     */
    protected function update(GoOpportunity $entity)
    {
        $updateData = $this->get('oro_form.update_handler')->update(
            $entity,
            $this->get('form.factory')->createNamed(GoOpportunityType::NAME, GoOpportunityType::class),
            $this->get(TranslatorInterface::class)->trans('dt.entity.goopportunity.form.saved.message')
        );
        if ($updateData instanceof RedirectResponse) {
            return $updateData;
        }

        $modifier = $this
            ->get(ModifiersRegistry::class)
            ->getModifier($this->getOpportunityRecordType($entity));
        $template = $modifier->getFormTemplate();
        $response = $this->get('twig')->render($template, $updateData);

        return new Response($response);
    }

    /**
     * @Route("/view/{id}", name="dt_go_plan_opportunity_view", requirements={"id"="\d+"})
     * @AclAncestor("dt_go_plan_opportunity_view")
     */
    public function viewAction(GoOpportunity $entity)
    {
        $modifier = $this
            ->get(ModifiersRegistry::class)
            ->getModifier(
                $entity->getOpportunityRecordType() ? $entity->getOpportunityRecordType()->getId() : null
            );
        $template = $modifier->getViewTemplate();
        $response = $this->get('twig')->render($template, [
            'entity' => $entity,
            'model' => $this->get(MetricModelFactory::class)->getModel($entity)
        ]);

        return new Response($response);
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return array_merge(parent::getSubscribedServices(), [
            ModifiersRegistry::class,
            EnumValueProvider::class
        ]);
    }

    /**
     * @Route("generate-text-id/", name="dt_go_plan_opportunity_generate_text_id", options={"expose"=true})
     */
    public function textIdAction(): JsonResponse
    {
        return parent::textIdAction();
    }

    /**
     * {@inheritdoc}
     */
    protected function getHandledClass(): string
    {
        return GoOpportunity::class;
    }
}
