<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Form\Model\ImportXlsxData;
use Oro\Bundle\ImportExportBundle\Controller\ImportExportController as BaseImportExportController;
use Oro\Bundle\ImportExportBundle\Form\Type\ImportType;
use Oro\Bundle\ImportExportBundle\Job\JobExecutor;
use Oro\Bundle\ImportExportBundle\Processor\ProcessorRegistry;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ImportExportController extends BaseImportExportController
{
    /**
     * @Route("/import_validate_export", name="dt_account_plan_import_validate_template_form", options={"expose"=true})
     * @AclAncestor("oro_importexport_import_validate_export_template_form")
     * @Template("DTAccountPlanBundle:ImportExport:widget/importValidateTemplate.html.twig")
     *
     * @param Request $request
     *
     * @return array|Response
     */
    public function importValidateExportTemplateFormAction(Request $request)
    {
        return parent::importValidateExportTemplateFormAction($request);
    }

    /**
     * {@inheritdoc}
     */
    protected function getImportForm($entityName)
    {
        return $this->createForm(ImportType::class, null, [
            'entityName' => $entityName,
            'data_class' => ImportXlsxData::class
        ]);
    }

    /**
     * @Route("/export/template/{processorAlias}", name="dt_account_plan_export_template", options={"expose"=true})
     * @AclAncestor("oro_importexport_export_template")
     *
     * @param string $processorAlias
     * @param Request $request
     *
     * @return Response
     */
    public function templateExportAction($processorAlias, Request $request)
    {
        $jobName = $request->get('exportTemplateJob', JobExecutor::JOB_EXPORT_TEMPLATE_TO_CSV);
        $result  = $this->getExportHandler()->getExportResult(
            $jobName,
            $processorAlias,
            ProcessorRegistry::TYPE_EXPORT_TEMPLATE,
            'xlsx',
            null,
            $this->getOptionsFromRequest($request)
        );

        return $this->getExportHandler()->handleDownloadExportResult($result['file']);
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return parent::getSubscribedServices();
    }
}
