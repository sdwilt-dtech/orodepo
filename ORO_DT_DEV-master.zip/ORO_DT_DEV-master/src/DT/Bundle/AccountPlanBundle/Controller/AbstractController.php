<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Model\MetricModelFactory;
use Oro\Bundle\FormBundle\Model\UpdateHandlerFacade;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController as BaseController;
use Symfony\Component\Form\FormFactoryInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

abstract class AbstractController extends BaseController
{
    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return array_merge(parent::getSubscribedServices(), [
            MetricModelFactory::class,
            TranslatorInterface::class,
            'oro_form.update_handler' => UpdateHandlerFacade::class,
            'form.factory' => FormFactoryInterface::class
        ]);
    }
}
