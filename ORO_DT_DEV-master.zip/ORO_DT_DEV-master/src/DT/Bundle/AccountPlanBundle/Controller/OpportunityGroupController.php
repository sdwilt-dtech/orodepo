<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Form\Type\GoOpportunityGroupType;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class OpportunityGroupController extends AbstractTextIdAwareController
{
    /**
     * @Route("/index", name="dt_go_plan_opportunity_group_index")
     * @Template("DTAccountPlanBundle:OpportunityGroup:index.html.twig")
     * @Acl(
     *      id="dt_go_plan_opportunity_group_view",
     *      type="entity",
     *      permission="VIEW",
     *      class="DT\Bundle\EntityBundle\Entity\GoOpportunityGroup"
     * )
     *
     * @return array
     */
    public function indexAction(): array
    {
        return [
            'entity_class' => GoOpportunityGroup::class,
            'theme_name' => 'list-view',
            'grid_config' => [
                'go-plan-opportunity-group-grid',
            ],
        ];
    }

    /**
     * @Route("/create", name="dt_go_plan_opportunity_group_create")
     * @Template("DTAccountPlanBundle:OpportunityGroup:update.html.twig")
     * @Acl(
     *      id="dt_go_plan_opportunity_group_create",
     *      type="entity",
     *      permission="CREATE",
     *      class="DT\Bundle\EntityBundle\Entity\GoOpportunityGroup"
     * )
     */
    public function createAction()
    {
        return $this->update(new GoOpportunityGroup());
    }

    /**
     * @Route("/update/{id}", name="dt_go_plan_opportunity_group_update", requirements={"id"="\d+"})
     * @Template("DTAccountPlanBundle:OpportunityGroup:update.html.twig")
     * @Acl(
     *      id="dt_go_plan_opportunity_group_update",
     *      type="entity",
     *      permission="EDIT",
     *      class="DT\Bundle\EntityBundle\Entity\GoOpportunityGroup"
     * )
     *
     * @param GoOpportunityGroup $entity
     * @return array|RedirectResponse
     */
    public function updateAction(GoOpportunityGroup $entity)
    {
        return $this->update($entity);
    }

    /**
     * @param GoOpportunityGroup $entity
     * @return array|RedirectResponse
     */
    protected function update(GoOpportunityGroup $entity)
    {
        return $this->get('oro_form.update_handler')->update(
            $entity,
            $this->get('form.factory')
                ->createNamed('dt_go_plan_opportunity_group', GoOpportunityGroupType::class),
            $this->get(TranslatorInterface::class)->trans('dt.entity.goopportunitygroup.form.saved.message')
        );
    }

    /**
     * @Route("/view/{id}", name="dt_go_plan_opportunity_group_view", requirements={"id"="\d+"})
     * @Template
     * @AclAncestor("dt_go_plan_opportunity_group_view")
     *
     * @param GoOpportunityGroup $opportunityGroup
     * @return array
     */
    public function viewAction(GoOpportunityGroup $opportunityGroup): array
    {
        return [
            'entity' => $opportunityGroup
        ];
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedServices()
    {
        return array_merge(parent::getSubscribedServices(), []);
    }

    /**
     * @Route("generate-text-id/", name="dt_go_plan_opportunity_group_generate_text_id", options={"expose"=true})
     */
    public function textIdAction(): JsonResponse
    {
        return parent::textIdAction();
    }

    /**
     * {@inheritdoc}
     */
    protected function getHandledClass(): string
    {
        return GoOpportunityGroup::class;
    }
}
