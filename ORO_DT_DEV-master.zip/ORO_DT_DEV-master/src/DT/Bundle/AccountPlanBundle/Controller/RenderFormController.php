<?php

namespace DT\Bundle\AccountPlanBundle\Controller;

use DT\Bundle\AccountPlanBundle\Form\Type\GoOpportunityType;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

class RenderFormController extends AbstractController
{
    private const REQUEST_KEY_FORM_TYPE = 'form_type';
    private const REQUEST_KEY_FORM_NAME = 'form_name';
    private const REQUEST_KEY_FIELD = 'field';
    private const TEMPLATE = "DTAccountPlanBundle:Form:render_form.html.twig";

    /**
     * @Route("/render", name="dt_go_plan_render_form", options={"expose"=true})
     * @return JsonResponse
     */
    public function renderForm()
    {
        $request = $this->get('request_stack')->getCurrentRequest();
        $formType = $request->get(self::REQUEST_KEY_FORM_TYPE, GoOpportunityType::class);
        $formName = $request->get(self::REQUEST_KEY_FORM_NAME, GoOpportunityType::NAME);
        $field = $request->get(self::REQUEST_KEY_FIELD);

        $form = $this->get('form.factory')->createNamed($formName, $formType);
        return new JsonResponse([
            'form_field' => $this->get('twig')->render(self::TEMPLATE, [
                'form' => $form->createView(),
                'field' => $field
            ])
        ]);
    }
}
