<?php

namespace DT\Bundle\AccountPlanBundle\Exception;

use Throwable;

/**
 * Exception for data providers aware of context entity, which
 * was not set for the execution
 */
class EntityNotSetException extends \LogicException
{
    /**
     * @param string $className
     * @param int $code
     * @param Throwable|null $previous
     */
    public function __construct(string $className = "", $code = 0, Throwable $previous = null)
    {
        parent::__construct(sprintf('%s entity is not set!', $className), $code, $previous);
    }
}
