<?php

namespace DT\Bundle\AccountPlanBundle\Command;

use Doctrine\ORM\EntityRepository;
use DT\Bundle\AccountPlanBundle\Async\Topics;
use DT\Bundle\EntityBundle\Entity\GoAccountPlan;
use DT\Bundle\EntityBundle\Entity\Repository\GoAccountPlanRepository;
use Oro\Bundle\ActionBundle\Model\ActionData;
use Oro\Bundle\ActionBundle\Model\ActionGroup;
use Oro\Bundle\ActionBundle\Model\ActionGroupRegistry;
use Oro\Bundle\CronBundle\Command\CronCommandInterface;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Oro\Component\MessageQueue\Client\MessageProducerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class RecalculateAccountPlansCommand extends Command implements CronCommandInterface
{
    public const COMMAND_NAME = 'oro:cron:account-plan-recalculate';
    public const OPTION_ACCOUNT_PLANS = 'ids';
    public const RECALCULATE_ACTION_GROUP_NAME = 'recalculate_account_plan';
    public const OPTION_SYNC = 'sync';

    /** @var DoctrineHelper */
    private $doctrineHelper;

    /** @var ActionGroupRegistry */
    private $actionGroupRegistry;

    /** @var MessageProducerInterface */
    private $messageProducer;

    /** @var ProgressBar */
    private $progressBar;

    /** @var ActionGroup */
    private $actionGroup;

    /** @var boolean */
    private $isSync;

    /**
     * @param DoctrineHelper $doctrineHelper
     * @param ActionGroupRegistry $actionGroupRegistry
     * @param MessageProducerInterface $messageProducer
     */
    public function __construct(
        DoctrineHelper $doctrineHelper,
        ActionGroupRegistry $actionGroupRegistry,
        MessageProducerInterface $messageProducer
    ) {
        $this->doctrineHelper = $doctrineHelper;
        $this->actionGroupRegistry = $actionGroupRegistry;
        $this->messageProducer = $messageProducer;
        parent::__construct(null);
    }

    /**
     * @return string
     */
    public function getDefaultDefinition(): string
    {
        return '0 1 * * *';
    }

    /**
     * @return bool
     */
    public function isActive(): bool
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure(): void
    {
        $this
            ->setName(self::COMMAND_NAME)
            ->setDescription('Recalculates Accounts Plans')
            ->addOption(
                self::OPTION_ACCOUNT_PLANS,
                null,
                InputOption::VALUE_OPTIONAL,
                'List of Account Plans id to recalculate, coma separated, by default it will recalculate all active plans', // @codingStandardsIgnoreLine
                ''
            )
            ->addOption(
                self::OPTION_SYNC,
                null,
                InputOption::VALUE_NONE,
                'Forces synchronous processing'
            )
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|void
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln('Starting execution. Fetching plans to recalculate');
        $accountPlans = $this->getAccountPlansToRecalculate($input->getOption(self::OPTION_ACCOUNT_PLANS));
        $this->isSync = $input->getOption(self::OPTION_SYNC);
        $this->actionGroup = $this->actionGroupRegistry->get(self::RECALCULATE_ACTION_GROUP_NAME);

        if ($this->isSync && $input->isInteractive()) {
            $this->startProcess($output, count($accountPlans));
        }

        if (empty($accountPlans)) {
            $output->writeln('There is no AccountPlans to recalculate.');
        }
        foreach ($accountPlans as $accountPlan) {
            if ($this->isSync) {
                $this->processSync($accountPlan, $output, $input);
            } else {
                $this->processAsync($accountPlan, $output);
            }
        }

        if ($this->isSync && $input->isInteractive()) {
            $this->progressBar->finish();
        }
        $output->writeln('Command execution finished');
    }

    /**
     * Asynchronous processing of the recalculation of single AccountPlan
     * @param GoAccountPlan $accountPlan
     * @param OutputInterface $output
     */
    private function processAsync(GoAccountPlan $accountPlan, OutputInterface $output): void
    {
        $this->messageProducer->send(
            Topics::RECALCULATE_ACCOUNT_PLAN,
            ['account_plan_id' => $accountPlan->getId()]
        );
        $output->writeln(
            sprintf(
                'Scheduled Recalculation for Account Plan: [%d] %s',
                $accountPlan->getId(),
                $accountPlan->getName()
            )
        );
    }

    /**
     * Synchronous processing of the recalculation of single AccountPlan
     * @param GoAccountPlan $accountPlan
     * @param OutputInterface $output
     */
    private function processSync(
        GoAccountPlan $accountPlan,
        OutputInterface $output,
        InputInterface $input
    ): void {
        $actionData = (new ActionData())
            ->set('account_plan', $accountPlan);

        if ($this->actionGroup->isAllowed($actionData)) {
            $this->actionGroup->execute($actionData);
            $output->writeln(
                sprintf(
                    'Recalculated Account Plan: [%d]%s',
                    $accountPlan->getId(),
                    $accountPlan->getName()
                )
            );
        } else {
            $output->writeln(
                sprintf(
                    'Cannot Recalculate Account Plan: [%d]%s',
                    $accountPlan->getId(),
                    $accountPlan->getName()
                )
            );
        }
        if ($input->isInteractive()) {
            $this->progressBar->advance(1);
            $output->writeln('');
        }
    }

    /**
     * Return specific AccountPlans if id's were provided, otherwise return all active Account Plans
     * @param string $accountPlanIds
     * @return array|GoAccountPlan[]
     */
    private function getAccountPlansToRecalculate(string $accountPlanIds): array
    {
        $ids = $accountPlanIds ?
            explode(',', trim($accountPlanIds)) :
            [];
        return empty($ids) ?
            $this->getAccountPlanRepository()->findBy(['isActive' => true]) :
            $this->getAccountPlanRepository()->findBy(['id' => $ids])
        ;
    }

    /**
     * Starts the progress output.
     *
     * @param OutputInterface $output
     * @param int|null $max Maximum steps
     */
    protected function startProcess(OutputInterface $output, $max): void
    {
        $this->progressBar = new ProgressBar($output);
        $this->progressBar->start($max);
        $this->progressBar->setFormat(' [%bar%] %percent%%');
        $this->progressBar->display();
        $output->writeln('');
    }

    /**
     * @return GoAccountPlanRepository|EntityRepository
     */
    private function getAccountPlanRepository(): GoAccountPlanRepository
    {
        return $this->doctrineHelper->getEntityRepositoryForClass(GoAccountPlan::class);
    }
}
