<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * Ensures account plan is assigned to Go Plan opportunity
 */
class GoPlanOpportunityMustHavePlan extends Constraint
{
    /** @var string */
    public $message = 'This HVAC Go Plan Opportunity does not have an associated Account Plan. Please reach out to your RSM to create an Account Plan before creating the opportunity'; // @codingStandardsIgnoreLine

    /**
     * {@inheritdoc}
     */
    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
