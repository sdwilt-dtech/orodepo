<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraints\NotBlank as BaseNotBlank;

/**
 * Checks for blank values on Go Opp level only
 */
class NotBlank extends BaseNotBlank
{
}
