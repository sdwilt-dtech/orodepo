<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * Ensures newly created opportunity is assigned
 * to current year opportunity group
 */
class AttachPlanOpportunityToCurrentYearGroup extends Constraint
{
    /** @var string */
    public $message = 'You cannot attach a new opportunity to a prior year\'s Go Plan Opportunity Group. If you don\'t see a current year opportunity group for this account, please contact your ISSR for assistance'; // @codingStandardsIgnoreLine

    /**
     * {@inheritdoc}
     */
    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
