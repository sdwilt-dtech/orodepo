<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * Ensures GP Close date is set on Go Plan Opportunity
 */
class GoPlanOpportunityGpCloseDate extends Constraint
{
    /** @var string */
    public $message = 'You must enter the GP Close Date. This should be the last day of the Quarter the Opportunity will close.	'; // @codingStandardsIgnoreLine
}
