<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Validator\Constraint;

class CompetitorValueValidator extends HigherStageValueValidator
{
    public const ALIAS = 'competitor_filled_higher_stage_validator';

    /**
     * {@inheritdoc}
     */
    protected function doValidateStageValues(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        if (!$opportunity->getOtherBusinessChallenger()) {
            parent::doValidateStageValues($opportunity, $constraint, $originalValue);
        }
    }
}
