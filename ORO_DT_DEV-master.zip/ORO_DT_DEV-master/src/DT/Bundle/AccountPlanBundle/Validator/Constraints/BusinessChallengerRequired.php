<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * Ensures business challenger is set if challenger is set to 'Other'.
 * If competitor/business challenger to whom opp was lost is not in the drop-down, name must be entered in the text box.
 */
class BusinessChallengerRequired extends Constraint
{
    /** @var string */
    public $message = 'Please name the \'Other\' Business Challenger';
}
