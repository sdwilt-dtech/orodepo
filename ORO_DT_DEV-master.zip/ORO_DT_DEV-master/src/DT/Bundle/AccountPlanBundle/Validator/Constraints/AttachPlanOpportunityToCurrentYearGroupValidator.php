<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Validator\Constraint;

class AttachPlanOpportunityToCurrentYearGroupValidator extends AbstractGoPlanOpportunityValidator
{
    private const GROUP_YEAR_INVALID = 'Previous';

    /**
     * {@inheritdoc}
     */
    protected function doValidate(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        $group = $opportunity->getOpportunityGroup();
        $year = $group ? $group->getOpportunityYear() : null;
        if (!$opportunity->getId() && $group && ($year && $year->getId() === self::GROUP_YEAR_INVALID)) {
            $this->context->addViolation($constraint->message);
        }
    }
}
