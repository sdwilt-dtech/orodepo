<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * Ensures annualized value is less or equal 0
 * for Keep opportunity
 */
class KeepValueLessGreaterThanZero extends Constraint
{
    /** @var string */
    public $message = 'Keep Opportunities cannot have Targeted Opportunity Value Greater than Zero';
}
