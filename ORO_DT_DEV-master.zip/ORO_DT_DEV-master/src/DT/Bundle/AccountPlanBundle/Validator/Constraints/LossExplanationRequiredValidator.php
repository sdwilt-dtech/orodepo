<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Validator\Constraint;

class LossExplanationRequiredValidator extends AbstractGoPlanOpportunityValidator
{
    private const EXPLANATION_REASON = 'Other--Explanation Required';

    /**
     * {@inheritdoc}
     */
    protected function doValidate(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        $reasonClosed = $opportunity->getReasonClosedLost();
        if ($reasonClosed && ($reasonClosed->getId() === self::EXPLANATION_REASON)
            && !$opportunity->getExplanationForLoss()) {
            $this->context->addViolation($constraint->message);
        }
    }
}
