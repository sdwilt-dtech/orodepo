<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * Traverses customer hierarchy tree to check if there are no nested Go plans
 */
class GoOpportunityGroupNotNested extends Constraint
{
    public $message = 'Go Opportunity Group cannot be assigned if hierarchy tree contains other group plans on different levels.'; // @codingStandardsIgnoreLine

    /**
     * If this option is set, the validator will check
     * if customer type assigned to the Opportunity group
     * is 'group' indeed.
     *
     * @var bool
     */
    public $strictGroupValidation = false;

    /**
     * If this option is set, the validator will force validation
     * on already saved/existing entity, if not - will
     * ignore validation against the constraint.
     *
     * @var bool
     */
    public $validateExisting = false;

    /**
     * {@inheritdoc}
     */
    public function getTargets()
    {
        return self::CLASS_CONSTRAINT;
    }
}
