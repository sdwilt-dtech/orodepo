<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Validator\Constraint;

class GoPlanOpportunityGpCloseDateValidator extends AbstractGoPlanOpportunityValidator
{
    /**
     * {@inheritdoc}
     */
    protected function doValidate(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        if (!$opportunity->getGpCloseDate()) {
            $this->context->addViolation($constraint->message);
        }
    }
}
