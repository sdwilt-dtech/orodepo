<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

class StageAccessAwareConstraint extends Constraint
{
    /**
     * This option provides information if admin user having ability to assign stages
     * without additional checks should be allowed to ommit the check. False by default,
     * the check will always be made. If true - the check will not be made and the validator
     * call will be ignored/omitted.
     *
     * @var bool
     */
    public $allowAdmin = false;
}
