<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\AccountPlanBundle\Provider\Enums\OpportunityRecordType;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

abstract class AbstractGoPlanOpportunityValidator extends ConstraintValidator
{
    protected const HVAC_GO_PLAN_VAL = OpportunityRecordType::TYPE_HVAC_GO_PLAN;

    /**
     * {@inheritdoc}
     * @param mixed $value
     */
    public function validate($value, Constraint $constraint)
    {
        /** @var GoOpportunity $opportunity */
        $opportunity = $this->resolveEntity($this->context->getRoot());
        if ($opportunity instanceof GoOpportunity) {
            $opportunityType = $opportunity->getOpportunityRecordType();
            if ($opportunityType && ($opportunityType->getId() === self::HVAC_GO_PLAN_VAL)) {
                $this->doValidate($opportunity, $constraint, $value);
            }
        }
    }

    /**
     * @param mixed $subject
     * @return GoOpportunity|mixed|null
     */
    protected function resolveEntity($subject)
    {
        switch (true) {
            case $subject instanceof FormInterface:
                return $subject->getData();
            case $subject instanceof GoOpportunity:
                return $subject;
            default:
                return null;
        }
    }

    /**
     * Performs validation
     *
     * @param GoOpportunity $opportunity
     * @param Constraint $constraint
     * @param mixed $originalValue
     */
    abstract protected function doValidate(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void;
}
