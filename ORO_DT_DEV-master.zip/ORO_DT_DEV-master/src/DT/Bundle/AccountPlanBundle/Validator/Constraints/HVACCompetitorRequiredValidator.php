<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Symfony\Component\Validator\Constraint;

class HVACCompetitorRequiredValidator extends AbstractGoPlanOpportunityValidator
{
    private const ENUM_HVAC_COMPETITOR_OTHER = 'Other';

    /**
     * {@inheritdoc}
     */
    protected function doValidate(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        $challengers = $opportunity->getHvacCompetitor();
        $otherCollection = $challengers->filter(function (AbstractEnumValue $value) {
            return $value->getId() === self::ENUM_HVAC_COMPETITOR_OTHER;
        });
        if ($otherCollection->count() && !$opportunity->getOtherHvacCompetitor()) {
            $this->context->addViolation($constraint->message);
        }
    }
}
