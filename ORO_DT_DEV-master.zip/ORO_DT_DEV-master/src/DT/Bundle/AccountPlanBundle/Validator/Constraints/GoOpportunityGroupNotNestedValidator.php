<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Doctrine\Persistence\ManagerRegistry;
use DT\Bundle\EntityBundle\Entity\GoOpportunityGroup;
use DT\Bundle\EntityBundle\Entity\Repository\GoOpportunityGroupRepository;
use DT\Bundle\SetupBundle\Model\EnumValues;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

class GoOpportunityGroupNotNestedValidator extends ConstraintValidator
{
    public const ALIAS = 'go_groups_not_nested_validator';

    /** @var ManagerRegistry */
    private $doctrine;

    /**
     * @param ManagerRegistry $doctrine
     */
    public function __construct(ManagerRegistry $doctrine)
    {
        $this->doctrine = $doctrine;
    }

    /**
     * {@inheritdoc}
     */
    public function validate($value, Constraint $constraint)
    {
        if (!$constraint instanceof GoOpportunityGroupNotNested) {
            throw new \LogicException(sprintf(
                'Validator %s operates only on constraints of class %s',
                __CLASS__,
                GoOpportunityGroupNotNested::class
            ));
        }
        if (!$value instanceof GoOpportunityGroup) {
            throw new \LogicException(sprintf(
                'Constraint %s may only be attached to entity of class %s',
                GoOpportunityGroupNotNested::class,
                GoOpportunityGroup::class
            ));
        }

        $this->doValidate($value, $constraint);
    }

    /**
     * @param GoOpportunityGroup $opportunityGroup
     * @param GoOpportunityGroupNotNested $constraint
     */
    private function doValidate(GoOpportunityGroup $opportunityGroup, GoOpportunityGroupNotNested $constraint): void
    {
        $isExisting = (bool)$opportunityGroup->getId();
        $customer = $opportunityGroup->getCustomer();
        if (!$isExisting || $constraint->validateExisting && $customer) {
            $hierarchy = $this->getHierarchy($customer);
            if (count($hierarchy) && $this->hasGoPlans($hierarchy)) {
                $this->context->addViolation($constraint->message);
            }
            $isGroup = $customer->getDtEntityType()
                && ($customer->getDtEntityType()->getId() === EnumValues::DT_CUSTOMER_ENTITY_TYPE_GROUP);
            if ($constraint->strictGroupValidation && !$isGroup) {
                $this->context->addViolation($constraint->message);
            }
        }
    }

    /**
     * @param Customer $customer
     * @return array
     */
    private function getHierarchy(Customer $customer): array
    {
        $hierarchy = [$customer];
        $parent = $customer->getParent();
        while ($parent) {
            $hierarchy[] = $parent;
            $parent = $parent->getParent();
        }
        return array_merge($hierarchy, $this->getChildrenArray($customer));
    }

    /**
     * Provides flattened customer tree
     *
     * @param Customer $customer
     * @param bool $add
     * @return Customer[]|array
     */
    private function getChildrenArray(Customer $customer, bool $add = false): array
    {
        $customers = [];
        if ($add) {
            $customers[] = $customer;
        }
        foreach ($customer->getChildren() as $child) {
            $customers = array_merge($customers, $this->getChildrenArray($child, true));
        }

        return $customers;
    }

    /**
     * @param array|Customer[] $customers
     * @return bool
     */
    private function hasGoPlans(array $customers): bool
    {
        /** @var GoOpportunityGroupRepository $repo */
        $repo = $this
            ->doctrine
            ->getManagerForClass(GoOpportunityGroup::class)
            ->getRepository(GoOpportunityGroup::class);

        $queryBuilder = $repo->createQueryBuilder('g');
        $queryBuilder
            ->resetDQLPart('select')
            ->select('count(g.id)')
            ->innerJoin('g.customer', 'c')
            ->andWhere($queryBuilder->expr()->in('c.id', ':customerIds'))
            ->setParameter('customerIds', array_map(function (Customer $customer) {
                return $customer->getId();
            }, $customers));

        return (bool)$queryBuilder->getQuery()->getSingleScalarResult();
    }
}
