<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

/**
 * If Opportunity Stage progresses from Stage 1,
 * then Competitor Value need to be filled in.
 */
class CompetitorValue extends HigherStageValue
{
    /** @var string */
    public $message = 'Please Enter the {{ name }} to the Opportunity';

    /** @var string */
    public $name = 'Business Challenger';

    /**
     * Defines the stage number from which the field will be mandatory
     *
     * @var int
     */
    public $stage = 2;

    /**
     * {@inheritdoc}
     */
    public function getRequiredOptions()
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function validatedBy()
    {
        return CompetitorValueValidator::ALIAS;
    }
}
