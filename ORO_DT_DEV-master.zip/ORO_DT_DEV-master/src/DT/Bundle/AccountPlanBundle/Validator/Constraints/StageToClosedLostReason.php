<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

/**
 * When stage is set to closed/lost, a reason must be selected.
 */
class StageToClosedLostReason extends StageAccessAwareConstraint
{
    /** @var string */
    public $message = 'Please select the reason why the opportunity is closed/lost.';

    /**
     * {@inheritdoc}
     */
    public function validatedBy()
    {
        return StageToClosedLostReasonValidator::ALIAS;
    }
}
