<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Validator\Constraint;

class GoPlanOpportunityMustHavePlanValidator extends AbstractGoPlanOpportunityValidator
{
    /**
     * {@inheritdoc}
     */
    protected function doValidate(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        if (!$opportunity->getAccountPlan()) {
            $this->context->addViolation($constraint->message);
        }
    }
}
