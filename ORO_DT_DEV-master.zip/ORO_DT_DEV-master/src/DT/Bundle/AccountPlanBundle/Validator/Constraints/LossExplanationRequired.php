<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * Ensures loss explanation is set if reason is 'Other--Explanation Required'
 */
class LossExplanationRequired extends Constraint
{
    /** @var string */
    public $message = 'An explanation is required if opportunity is closed/lost for "Other" reason';
}
