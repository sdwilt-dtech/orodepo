<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\AccountPlanBundle\Provider\Acl;
use DT\Bundle\AccountPlanBundle\Provider\StageNumberProvider;
use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;
use Symfony\Component\Validator\Constraint;

abstract class AbstractStageValuesAwareValidator extends AbstractGoPlanOpportunityValidator
{
    /** @var AuthorizationCheckerInterface */
    private $authorizationChecker;

    /** @var StageNumberProvider */
    private $stageNumberProvider;

    /**
     * @param AuthorizationCheckerInterface $authorizationChecker
     * @param StageNumberProvider $stageNumberProvider
     */
    public function __construct(
        AuthorizationCheckerInterface $authorizationChecker,
        StageNumberProvider $stageNumberProvider
    ) {
        $this->authorizationChecker = $authorizationChecker;
        $this->stageNumberProvider = $stageNumberProvider;
    }

    /**
     * {@inheritdoc}
     * @param StageAccessAwareConstraint $constraint
     */
    protected function doValidate(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        if (!$constraint->allowAdmin
            || !$this->authorizationChecker->isGranted(Acl::ACL_ASSIGN_STAGE_WITHOUT_VALUES)) {
            $this->doValidateStageValues($opportunity, $constraint, $originalValue);
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @param Constraint $constraint
     * @param mixed $originalValue
     */
    abstract protected function doValidateStageValues(
        GoOpportunity $opportunity,
        Constraint $constraint,
        $originalValue
    ): void;

    /**
     * @param GoOpportunity $opportunity
     * @return int
     */
    protected function getStageNumber(GoOpportunity $opportunity): int
    {
        return $this->stageNumberProvider->getOpportunityStageNumber($opportunity);
    }
}
