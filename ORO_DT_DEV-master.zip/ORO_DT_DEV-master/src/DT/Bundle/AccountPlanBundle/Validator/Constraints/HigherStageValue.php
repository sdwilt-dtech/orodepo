<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

/**
 * If Opportunity Stage progresses from Stage 1,
 * then some values need to be filled in.
 */
class HigherStageValue extends StageAccessAwareConstraint
{
    /** @var string */
    public $message = 'Please Enter the {{ name }} to the Opportunity';

    /** @var string */
    public $name = null;

    public const DEFAULT_STAGE = 2;

    /**
     * Defines the stage number from which the field will be mandatory
     *
     * @var int
     */
    public $stage = null;

    public function __construct($options = null)
    {
        parent::__construct($options);
        $this->stage = $this->stage ?: self::DEFAULT_STAGE;
    }

    /**
     * {@inheritdoc}
     */
    public function getRequiredOptions()
    {
        return ['name'];
    }

    /**
     * {@inheritdoc}
     */
    public function validatedBy()
    {
        return HigherStageValueValidator::ALIAS;
    }
}
