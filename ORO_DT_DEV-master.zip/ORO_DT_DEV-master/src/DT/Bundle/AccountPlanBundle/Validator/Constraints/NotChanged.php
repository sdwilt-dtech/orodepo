<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

class NotChanged extends Constraint
{
    /** @var string */
    public $message = 'The field {{ field }} cannot be changed once set.';

    /** @var string */
    public $field;

    /** @var mixed */
    public $value;

    /** @var string */
    public $className;

    /**
     * {@inheritdoc}
     */
    public function getRequiredOptions()
    {
        return [
            'field',
            'value',
            'className'
        ];
    }

    public function validatedBy()
    {
        return NotChangedValidator::ALIAS;
    }
}
