<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Validator\Constraint;

class StageToClosedLostReasonValidator extends AbstractStageValuesAwareValidator
{
    public const ALIAS = 'stage_closed_reason_validator';

    protected const STAGE_LOST = '4b. Closed Lost';

    /**
     * {@inheritdoc}
     */
    protected function doValidateStageValues(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        if ($opportunity->getStage() && ($opportunity->getStage()->getName() === self::STAGE_LOST)) {
            if (!$opportunity->getReasonClosedLost()) {
                $this->context->addViolation($constraint->message);
            }
        }
    }
}
