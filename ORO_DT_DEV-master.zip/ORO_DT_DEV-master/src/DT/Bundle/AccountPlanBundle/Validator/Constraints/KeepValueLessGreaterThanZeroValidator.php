<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Validator\Constraint;

class KeepValueLessGreaterThanZeroValidator extends AbstractGoPlanOpportunityValidator
{
    protected const TYPE_CHECK_VALUE = 'Keep';

    /**
     * {@inheritdoc}
     */
    protected function doValidate(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        $type = $opportunity->getSalesOpportunityType();
        if ($type && ($type->getId() === static::TYPE_CHECK_VALUE)
            && !$this->isValid($opportunity)) {
            $this->context->addViolation($constraint->message);
        }
    }

    /**
     * @param GoOpportunity $opportunity
     * @return bool
     */
    protected function isValid(GoOpportunity $opportunity): bool
    {
        return $opportunity->getTargetedOpportunityValue() <= 0;
    }
}
