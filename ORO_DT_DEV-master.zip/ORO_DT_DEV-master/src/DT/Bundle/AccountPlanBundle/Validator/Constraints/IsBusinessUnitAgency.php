<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

class IsBusinessUnitAgency extends Constraint
{
    public $message = 'Given business unit does not represent Sales Agency!';
}
