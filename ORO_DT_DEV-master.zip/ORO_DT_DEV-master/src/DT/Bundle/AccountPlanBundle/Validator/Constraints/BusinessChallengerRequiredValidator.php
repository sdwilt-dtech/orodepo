<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Symfony\Component\Validator\Constraint;

class BusinessChallengerRequiredValidator extends AbstractGoPlanOpportunityValidator
{
    private const ENUM_BUSINESS_CHALLENGER_OTHER = 'Other';

    /**
     * {@inheritdoc}
     */
    protected function doValidate(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        $challengers = $opportunity->getBusinessChallenger();
        $otherCollection = $challengers->filter(function (AbstractEnumValue $value) {
            return $value->getId() === self::ENUM_BUSINESS_CHALLENGER_OTHER;
        });
        if ($otherCollection->count() && !$opportunity->getOtherBusinessChallenger()) {
            $this->context->addViolation($constraint->message);
        }
    }
}
