<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\EntityBundle\Entity\GoOpportunity;
use Symfony\Component\Validator\Constraint;

class HigherStageValueValidator extends AbstractStageValuesAwareValidator
{
    public const ALIAS = 'fields_filled_higher_stage_validator';

    /**
     * @param GoOpportunity $opportunity
     * @param Constraint|HigherStageValue $constraint
     * @param mixed $originalValue
     */
    protected function doValidateStageValues(GoOpportunity $opportunity, Constraint $constraint, $originalValue): void
    {
        if ($this->getStageNumber($opportunity) >= $constraint->stage) {
            $isFilled = is_countable($originalValue)
                ? (bool)count($originalValue)
                : (bool)$originalValue;
            if (!$isFilled) {
                $this->context->addViolation($constraint->message, [
                    '{{ name }}' => $constraint->name
                ]);
            }
        }
    }
}
