<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use DT\Bundle\AccountPlanBundle\Model\GoOpportunity;
use Oro\Bundle\EntityConfigBundle\Provider\ConfigProvider;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Contracts\Translation\TranslatorInterface;

class NotChangedValidator extends ConstraintValidator
{
    public const ALIAS = 'not_changed_value_validator';

    /** @var ConfigProvider */
    private $entityConfigProvider;

    /** @var TranslatorInterface */
    private $translator;

    /**
     * @param ConfigProvider $entityConfigProvider
     */
    public function __construct(ConfigProvider $entityConfigProvider, TranslatorInterface $translator)
    {
        $this->entityConfigProvider = $entityConfigProvider;
        $this->translator = $translator;
    }

    /**
     * @param mixed $value
     * @param Constraint $constraint
     */
    public function validate($value, Constraint $constraint)
    {
        if (!$constraint instanceof NotChanged) {
            throw new \LogicException(sprintf('This validator operates only on %s constraint!', NotChanged::class));
        }

        $previousValue = $constraint->value;
        // TODO: Temporary fix - remove after changing to Date type
        if ($previousValue instanceof \DateTime && $value instanceof \DateTime) {
            $value = $value->format('Y-m-d');
            $previousValue = $previousValue->format('Y-m-d');
        }
        if ((null !== $previousValue) && ($previousValue != $value)) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{{ field }}', $this->formatField($constraint->field, $constraint->className))
                ->addViolation();
        }
    }

    /**
     *
     * @param string $field
     * @param string $className
     * @return string
     */
    private function formatField(string $field, string $className): string
    {
        $fieldLabel = $this->entityConfigProvider->hasConfig(GoOpportunity::class, $field)
            ? $this->doFormatField($field, $className)
            : null;

        return $fieldLabel ?: '';
    }

    /**
     * @param string $field
     * @param string $className
     * @return string
     */
    private function doFormatField(string $field, string $className): string
    {
        return $this->translator->trans(
            $this->entityConfigProvider->getConfig($className, $field)->get('label')
        );
    }
}
