<?php

namespace DT\Bundle\AccountPlanBundle\Validator\Constraints;

use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;
use Symfony\Component\Validator\Exception\UnexpectedValueException;

class IsBusinessUnitAgencyValidator extends ConstraintValidator
{
    public function validate($value, Constraint $constraint)
    {
        if (!$constraint instanceof IsBusinessUnitAgency) {
            throw new UnexpectedTypeException($constraint, IsBusinessUnitAgency::class);
        }

        if (null === $value || '' === $value) {
            return;
        }

        if (!$value instanceof BusinessUnit) {
            throw new UnexpectedValueException($value, BusinessUnit::class);
        }

        if (!$value->getDtIsAgency()) {
            $this->context->buildViolation($constraint->message)
                ->addViolation();
        }
    }
}
