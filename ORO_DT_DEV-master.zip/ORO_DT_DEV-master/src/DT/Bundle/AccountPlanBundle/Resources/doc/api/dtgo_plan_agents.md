# DT\Bundle\EntityBundle\Entity\GoPlanAgent

## ACTIONS

### get

Retrieve a specific Go Plan Agent Record.

{@inheritdoc}

### get_list

Retrieve a collection of Go Plan Agent records.

{@inheritdoc}

### create

Create a new Go Plan Agent record.

The created record is returned in the response.

{@inheritdoc}

{@request:json_api}

Example:

```JSON
{
  "data": {
    "type": "dtgo_plan_agents",
    "attributes": {
      "opportunityPercent": 40,
      "name": "Test agent name 2",
      "currencyIsoCode": "USD"
    },
    "relationships": {
      "opportunityGroup": {
        "data": {
          "type": "dtgo_opportunity_groups",
          "id": "66"
        }
      },
      "user": {
        "data": {
          "type": "users",
          "id": "1"
        }
      },
      "organization": {
        "data": {
          "type": "organizations",
          "id": "1"
        }
      },
      "record_type": {
        "data": {
          "type": "dtagentrecordtypes",
          "id": "GP CY Agents"
        }
      }
    }
  }
}
```

{@/request}

## FIELDS

### name

#### create

{@inheritdoc}

**A required field.** 
