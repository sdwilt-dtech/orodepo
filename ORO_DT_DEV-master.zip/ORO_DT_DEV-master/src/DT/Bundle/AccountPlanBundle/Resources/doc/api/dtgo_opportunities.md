# DT\Bundle\EntityBundle\Entity\GoOpportunity

## ACTIONS

### get

Retrieve a specific Go Opportunity Record.

{@inheritdoc}

### get_list

Retrieve a collection of Go Opportunity records.

{@inheritdoc}

### create

Create a new Go Opportunity record.

The created record is returned in the response.

{@inheritdoc}

{@request:json_api}

There is a possibility to create Go Opportunity record along with related records with
one shot to the API endpoint. `included` resource is used. Please keep in mind that include
resources that already exist must be matched with *exisitng integer ID/key* indicating the 
resource and non-existing IDs must match the resources within data body/Go Opportunity relations
definition and `included` section and must be unique and explicit.

Automatic assignments:
- Customer may be passed via *id*

```JSON
"customer": {
  "data": {
    "type": "customers",
    "id": "1"
  }
}
```

or via *jdeId*

```JSON 
"customer": {
  "data": {
    "type": "customers",
    "jdeId": "55121"
  }
},
```

- Customer may determine `opportunityGroup` - Go Opportunity group is checked against customer and 
`fiscalYear` attribute. If such group exists, it will be automatically assigned to the Go Opportunity

Example:

```JSON
{
  "data": {
    "type": "dtgo_opportunities",
    "attributes": {
      "name": "Test API opportunity",
      "opportunity_record_type": "HVAC Go Plan",
      "textId": "CR10155121312",
      "closeDate": "2020-12-30T00:00:00Z",
      "gpCloseDate": "2020-12-30T00:00:00Z",
      "fiscalYear": "2021",
      "fiscalQuarter": "4",
      "py": "3000.00",
      "likehood": null,
      "ytd": null,
      "otherBusinessChallenger": null,
      "priorityRating": null,
      "calculatedOpportunityValue": "2000.00",
      "targetedOpportunityValue": "1,200.00",
      "verifiedTotalCategoryValue": "3000.00",
      "otherHvacCompetitor": null,
      "notes": "Lorem Ipsum dolor sit amet",
      "revenueStartDate": 2,
      "askQuarter": 4
    },
    "relationships": {
      "opportunity_record_type": {
        "data": {
          "type": "dtgo_opportunity_record_types",
          "id": "HVAC Go Plan"
        }
      },
      "sales_opportunity_type": {
        "data": {
          "type": "dtgo_opportunity_sales_types",
          "id": "Pipeline"
        }
      },
      "repCode": {
        "data": {
          "type": "dt_rep_codes",
          "code": "101"
        }
      },
      "region": {
        "data": {
          "type": "dt_regions",
          "code": "CR"
        }
      },
      "stage": {
        "data": {
          "type": "dtgo_opportunity_stages",
          "id": "0. Pipeline"
        }
      },
      "customer": {
        "data": {
          "type": "customers",
          "jdeId": "55121"
        }
      },
      "productCategoryCode": {
        "data": {
          "type": "dt_product_category_codes",
          "code": "312"
        }
      }
    }
  }
}
```

In case opportunity group **does not exist**, one can be created for the opportunity, if **other 
relations/attributes are properly filled** and the request contains/API can figure out:
`Customer (Customer JDE Id)`, `Region (Region Code)`, `Business Unit/Sales Agency (Rep Code)` and
`Product Category Code`

In case Region rep record does not exist too, it will also be created.

Example:

```JSON
{
  "data": {
    "type": "dtgo_opportunities",
    "id": "140",
    "attributes": {
      "py": null,
      "probability": 0,
      "likehood": 0,
      "ytd": null,
      "otherBusinessChallenger": null,
      "closeDate": "2020-12-31T00:00:00Z",
      "gpCloseDate": "2020-12-31T00:00:00Z",
      "calculatedOpportunityValue": null,
      "fiscalYear": 2020,
      "fiscalQuarter": 1,
      "targetedOpportunityValue": null,
      "verifiedTotalCategoryValue": null,
      "otherHvacCompetitor": null,
      "notes": null,
      "explanationForLoss": null,
      "revenueStartDate": null,
      "askQuarter": 1,
      "opportunity_record_type": "HVAC Go Plan"
    },
    "relationships": {
      "productCategoryCode": {
        "data": {
          "type": "dt_product_category_codes",
          "code": "320"
        }
      },
      "region": {
        "data": {
          "type": "dt_regions",
          "code": "SER"
        }
      },
      "stage": {
        "data": {
          "type": "dtgo_opportunity_stages",
          "id": "0. Pipeline"
        }
      },
      "repCode": {
        "data": {
          "type": "dt_rep_codes",
          "code": "101"
        }
      },
      "customer": {
        "data": {
          "type": "customers",
          "id": "4"
        }
      },
      "sales_opportunity_type": {
        "data": {
          "type": "dtgo_opportunity_sales_types",
          "id": "Grow"
        }
      }
    }
  }
}
```

{@/request}

### update

Edit a specific Go Opportunity record.

The updated record is returned in the response.

{@inheritdoc}

{@request:json_api}
Example:

```JSON
{
  "data": {
    "type": "dtgo_opportunities",
    "id": "109",
    "attributes": {
      "textId": "CR101713482302020",
      "py": "3000.00",
      "probability": 0,
      "likehood": 0,
      "ytd": "4000.00",
      "otherBusinessChallenger": null,
      "closeDate": "2021-12-30T00:00:00Z",
      "gpCloseDate": "2020-11-18T00:00:00Z",
      "calculatedOpportunityValue": null,
      "fiscalYear": 2020,
      "fiscalQuarter": 1,
      "targetedOpportunityValue": "1,500.00",
      "verifiedTotalCategoryValue": null,
      "otherHvacCompetitor": null,
      "notes": null,
      "explanationForLoss": null,
      "revenueStartDate": null,
      "askQuarter": 1,
      "name": "CR-101-44 Supply, LLC-SpeediChannel™-2020",
      "opportunity_record_type": "HVAC Go Plan"
    },
    "relationships": {
      "opportunityGroup": {
        "data": {
          "type": "dtgo_opportunity_groups",
          "id": "63"
        }
      },
      "accountPlan": {
        "data": null
      },
      "productCategoryCode": {
        "data": {
          "type": "dt_product_category_codes",
          "id": "2"
        }
      },
      "repCode": {
        "data": {
          "type": "dt_rep_codes",
          "code": "101"
        }
      },
      "region": {
        "data": {
          "type": "dt_regions",
          "id": "23"
        }
      },
      "stage": {
        "data": {
          "type": "dtgo_opportunity_stages",
          "id": "38"
        }
      },
      "businessUnit": {
        "data": {
          "type": "businessunits",
          "id": "3"
        }
      },
      "owner": {
        "data": null
      },
      "customer": {
        "data": {
          "type": "customers",
          "id": "12"
        }
      },
      "sales_opportunity_type": {
        "data": {
          "type": "dtgo_opportunity_sales_types",
          "id": "Go Plan"
        }
      },
      "reason_closed_lost": {
        "data": null
      },
      "opportunity_type": {
        "data": null
      },
      "opportunity_record_type": {
        "data": {
          "type": "dtgo_opportunity_record_types",
          "id": "HVAC Go Plan"
        }
      },
      "business_challenger": {
        "data": []
      },
      "hvac_competitor": {
        "data": []
      }
    }
  }
}
```
{@/request}

### delete

Delete a specific Go Opportunity record.

{@inheritdoc}

### delete_list

Delete a collection of Go Opportunity records.

{@inheritdoc}

## FIELDS

### name

#### create

{@inheritdoc}

**A required field.**

Ideally consists of:
- Region Code
- Rep Name (Agency name)
- Customer Name
- Category Code/Name
- Current/Import/Creation YEAR

**If not present in the attributes, the value will be generated from the above relations - if all relations are present**


#### update

{@inheritdoc}

**Please note:**

*This field is **required** and must remain defined.*

### amount

#### create, update

{@inheritdoc}

Ignored, if **targetedOpportunityValue** is present. Please use **targetedOpportunityValue**

### opportunity_record_type

#### create, update

{@inheritdoc}

Relationship/attribute. **Required attribute** string data to determine type of Go Opportunity Record.
Must be same as the relationship. If no relationship provided, the value will be taken from attribute.

### closeDate

#### create, update

{@inheritdoc}

Last day of the plan year

### askQuarter

#### create, update

{@inheritdoc}

Suggested Quarter you should ask for the business

Integer value [1..4]

### revenueStartDate

#### create, update

{@inheritdoc}

Number of month.

Integer value [1..12]

### fiscalYear

#### create

{@inheritdoc}

**Required** for **HVAC Go Plan** Opportunity Record Type

### fiscalQuarter

#### create

{@inheritdoc}

**Required** for **HVAC Go Plan** Opportunity Record Type, [1..4]

### askQuarter

#### create

{@inheritdoc}

**Required** for **HVAC Go Plan** Opportunity Record Type [1..4]

### textId

#### create

{@inheritdoc}

Unique and **required** for **HVAC Go Plan** Opportunity Record Type

Ideally consists of:
- Region Code
- JDE Rep Code
- Customer Account JDE ID
- Category Code
- Current/Import Year

**If not present in the attributes, the value will be generated from the above relations - if all relations are present**

### sales_opportunity_type

#### create, update

{@inheritdoc}

Relationship. **Required** for **HVAC Go Plan** Opportunity Record Type
Values: `Convert`, `Grow`, `Keep`, `NPI`, `Pipeline`, `Go Plan`

## SUBRESOURCES

### opportunityGroup

#### get_subresource

Retrieve a record of Go Opportunity Group assigned to a specific Go Opportunity record.

#### get_relationship

Retrieve ID of Go Opportunity Group record assigned to a specific Go Opportunity record.

#### update_relationship

Replace the Go Opportunity Group assigned to a specific Go Opportunity record.

{@request:json_api}
Example:

```JSON
{
  "data": {
    "type": "dtgo_opportunity_groups",
    "id": "1"
  }
}
```
{@/request}

### stage

#### get_subresource

Retrieve a record of Go Opportunity Stage assigned to a specific Go Opportunity record.

#### get_relationship

Retrieve ID of Go Opportunity Stage record assigned to a specific Go Opportunity record.

#### update_relationship

Replace the Go Opportunity Stage assigned to a specific Go Opportunity record.

{@request:json_api}
Example:

```JSON
{
  "data": {
    "type": "dtgo_opportunity_stages",
    "id": "1"
  }
}
```
{@/request}

### customer

#### get_subresource

Retrieve the customer records a specific Go Opportunity record is assigned to.

#### get_relationship

Retrieve the IDs of the customer records which a specific Go Opportunity record is assigned to.

#### update_relationship

Replace customer a specific Go Opportunity record is assigned to.

{@request:json_api}
Example:

```JSON
{
  "data": {
    "type": "customers",
    "id": "1"
  }
}
```
{@/request}

### organization

#### get_subresource

Retrieve the record of the organization a specific Go Opportunity record belongs to.

#### get_relationship

Retrieve the ID of the organization record which a specific Go Opportunity record will belong to.

#### update_relationship

Replace the organization a specific Go Opportunity record belongs to.

{@request:json_api}
Example:

```JSON
{
  "data": {
    "type": "organizations",
    "id": "1"
  }
}
```
{@/request}

### owner

#### get_subresource

Retrieve the record of the user who is an owner of a specific Go Opportunity record.

#### get_relationship

Retrieve the ID of the user who is an owner of a specific Go Opportunity record.

#### update_relationship

Replace the owner of a specific Go Opportunity record.

{@request:json_api}
Example:

```JSON
{
  "data": {
    "type": "users",
    "id": "1"
  }
}
```
{@/request}

# Extend\Entity\EV_Dt_Business_Challenge

## ACTIONS

### get

Retrieve a specific Business Challenger/Competitor record.

### get_list

Retrieve a collection of Business Challenger/Competitor records.


# Extend\Entity\EV_Dt_Sales_Opp_Type

## ACTIONS

### get

Retrieve a specific Go Opportunity Sales Opportunity Type record.

### get_list

Retrieve a collection of Go Opportunity Sales Opportunity Type records.

# Extend\Entity\EV_Dt_Forecast_Category

## ACTIONS

### get

Retrieve a specific Go Opportunity Forecast Category record.

### get_list

Retrieve a collection of Go Opportunity Forecast Category records.

# Extend\Entity\EV_Dt_Reason_Closed_Lost

## ACTIONS

### get

Retrieve a specific Go Opportunity Closed/Lost Reason record.

### get_list

Retrieve a collection of Go Opportunity Closed/Lost Reason records.


# Extend\Entity\EV_Dt_Opportunity_Type

## ACTIONS

### get

Retrieve a specific Go Opportunity Type record.

### get_list

Retrieve a collection of Go Opportunity Type records.


# Extend\Entity\EV_Dt_Opportunity_Source

## ACTIONS

### get

Retrieve a specific Go Opportunity Source record.

### get_list

Retrieve a collection of Go Opportunity Source records.


# Extend\Entity\EV_Dt_Opp_Rec_Type

## ACTIONS

### get

Retrieve a specific Go Opportunity Record Type record.

### get_list

Retrieve a collection of Go Opportunity Record Type records.

# Extend\Entity\EV_Dt_Sales_Initiat_Type

## ACTIONS

### get

Retrieve a specific Go Opportunity Sales Initiative Type record.

### get_list

Retrieve a collection of Go Opportunity Sales Initiative Type records.


