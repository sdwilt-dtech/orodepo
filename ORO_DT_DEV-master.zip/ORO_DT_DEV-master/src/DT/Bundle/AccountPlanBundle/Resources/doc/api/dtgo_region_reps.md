# DT\Bundle\EntityBundle\Entity\GoRegionRep

## ACTIONS

### get

Retrieve a specific Go Region Rep Record.

{@inheritdoc}

### get_list

Retrieve a collection of Go Region Rep records.

{@inheritdoc}

### create

Create a new Go Region Rep record.

The created record is returned in the response.

{@inheritdoc}

{@request:json_api}

Example:

```JSON
{
  "data": {
    "type": "dtgo_region_reps",
    "attributes": {
      "agencyTierLevel": null,
      "agencyTarget": null,
      "regionalTarget": null,
      "nationalDirectTarget": null,
      "currencyIsoCode": "USD",
      "fiscalYear": "2020"
    },
    "relationships": {
      "region": {
        "data": {
          "type": "dt_regions",
          "code": "NER"
        }
      },
      "repCode": {
        "data": {
          "type": "dt_rep_codes",
          "code": "101"
        }
      },
      "organization": {
        "data": {
          "type": "organizations",
          "id": "1"
        }
      },
      "kcg_customer_segment": {
        "data": {
          "type": "dtkcgcustsegments",
          "id": "Strategic"
        }
      }
    }
  }
}
```

{@/request}

## FIELDS

### fiscalYear

#### create

{@inheritdoc}

**Ignored field.** This field is used to generate Text ID and Name **Only**.

### name

#### create

{@inheritdoc}

**A required field.**

Ideally consists of:
- Region Code
- Customer Segment Code
- Rep Name (Agency name)
- Current/Import/Creation YEAR

**If not present in the attributes, the value will be generated from the above relations - if all relations are present**


### textId

#### create

{@inheritdoc}

Ideally consists of:
- Region Code
- Customer Segment Code
- JDE Rep Code
- Current/Import Year
    
**If not present in the attributes, the value will be generated from the above relations - if all relations are present**

Unique and **required**.
