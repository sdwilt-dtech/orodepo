# DT\Bundle\EntityBundle\Entity\GoPlanAgent

## ACTIONS

### get

Retrieve a specific Go Plan Agent Record.

{@inheritdoc}

### get_list

Retrieve a collection of Go Plan Agent records.

{@inheritdoc}

### create

Create a new Go Plan Agent record.

The created record is returned in the response.

{@inheritdoc}

{@request:json_api}

Example:

```JSON
{
  "data": {
    "type": "dtgo_account_plans",
    "id": "3",
    "attributes": {
      "accountDollar": "46500.0000",
      "totalPriorYearSales": "268.0000",
      "actualYtd": "199.0000",
      "priorYtd": "268.0000",
      "currentYearValueKeep": null,
      "currentYearValueGrow": null,
      "currentYearValueConvert": null,
      "currentYearValueNpi": null,
      "currentYearValuePipeline": null,
      "isActive": true,
      "track": false,
      "fiscalYear": "2020",
      "name": "TEST Account Plan 2020"
    },
    "relationships": {
      "customer": {
        "data": {
          "type": "customers",
          "id": "1"
        }
      },
      "organization": {
        "data": {
          "type": "organizations",
          "id": "1"
        }
      }
    }
  }
}
```

{@/request}

## FIELDS

### name

#### create

{@inheritdoc}

**A required field.** 
