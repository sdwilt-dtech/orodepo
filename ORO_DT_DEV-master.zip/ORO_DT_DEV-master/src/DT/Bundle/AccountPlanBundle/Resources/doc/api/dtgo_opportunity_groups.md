# DT\Bundle\EntityBundle\Entity\GoOpportunityGroup

## ACTIONS

### get

Retrieve a specific Go Opportunity Group Record.

{@inheritdoc}

### get_list

Retrieve a collection of Go Opportunity Group records.

{@inheritdoc}

### create

Create a new Go Opportunity Group record.

The created record is returned in the response.

{@inheritdoc}

{@request:json_api}

Example:

```JSON
{
  "data": {
    "type": "dtgo_opportunity_groups",
    "attributes": {
      "textId": "CR1011713482020",
      "regionalManagerEmail": null,
      "salesSupportEmail": null,
      "state": null,
      "fiscalYear": 2021,
      "createdAt": "2020-11-19T12:17:54Z",
      "updatedAt": "2020-11-19T12:17:54Z",
      "name": "CR-A to Z SALES, INC.-44 Supply, LLC-2020",
      "currencyIsoCode": "USD",
      "salesforceId": null
    },
    "relationships": {
      "regionRep": {
        "data": {
          "type": "dtgo_region_reps",
          "id": "63"
        }
      },
      "businessUnit": {
        "data": {
          "type": "businessunits",
          "id": "3"
        }
      },
      "repCode": {
        "data": {
         "type": "dt_rep_codes",
         "code": "101"
        }
      },
      "region": {
        "data": {
          "type": "dt_regions",
          "id": "23"
        }
      },
      "customer": {
        "data": {
          "type": "customers",
          "id": "12"
        }
      },
      "owner": {
        "data": null
      },
      "organization": {
        "data": {
          "type": "organizations",
          "id": "1"
        }
      },
      "opportunity_year": {
        "data": {
          "type": "dtopportunityyears",
          "id": "Current"
        }
      }
    }
  }
}
```

{@/request}

### update

Create existing Go Opportunity Group record.

The updated record is returned in the response.

{@inheritdoc}

{@request:json_api}

Example:

```JSON
{
  "data": {
    "type": "dtgo_opportunity_groups",
    "id": "63",
    "attributes": {
      "name": "CR-A to Z SALES, INC.-44 Supply, LLC-2020 Sample Update"
    },
    "relationships": {
      "regionRep": {
        "data": {
          "type": "dtgo_region_reps",
          "id": "63"
        }
      },
      "businessUnit": {
        "data": {
          "type": "businessunits",
          "id": "3"
        }
      },
      "region": {
        "data": {
          "type": "dt_regions",
          "id": "23"
        }
      },
      "repCode": {
        "data": {
          "type": "dt_rep_codes",
          "id": "6"
        }
      },
      "customer": {
        "data": {
          "type": "customers",
          "id": "12"
        }
      },
      "organization": {
        "data": {
          "type": "organizations",
          "id": "1"
        }
      },
      "opportunity_year": {
        "data": {
          "type": "dtopportunityyears",
          "id": "Current"
        }
      }
    }
  }
}
```

{@/request}

## FIELDS

### name

#### create

{@inheritdoc}

**A required field.**

Ideally consists of:
- Region Code
- Rep Name (Agency name)
- Customer Name
- Current/Import/Creation YEAR

**If not present in the attributes, the value will be generated from the above relations - if all relations are present**

### textId

#### create

{@inheritdoc}

Ideally consists of:
- Region Code
- JDE Rep Code ID
- Customer Account JDE ID
- Current/Import/Creation YEAR

**If not present in the attributes, the value will be generated from the above relations - if all relations are present**

Unique and **required**.

### opportunity_year

#### create, update

{@inheritdoc}

Relationship. **Required** Available values: `Current`, `Previous`
