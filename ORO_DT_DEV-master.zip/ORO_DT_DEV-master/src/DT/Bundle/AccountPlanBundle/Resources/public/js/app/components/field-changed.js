define(function (require) {
    'use strict';

    const $ = require('jquery');
    const BaseComponent = require('oroui/js/app/components/base/component');
    const mediator = require('oroui/js/mediator');
    const FieldChanged = BaseComponent.extend({

        /** @property {Object} */
        $context: null,

        /** @property {String} */
        target: null,

        /** @property {String} */
        eventName: 'dt:content:changed',

        /** @property {String} */
        key: 'content',

        /** @property {String} */
        formType: null,

        /** @property {String} */
        formName: null,

        /** @property {String} */
        currentValue: null,

        /**
         * @inheritDoc
         */
        constructor: function FieldChanged(options) {
            FieldChanged.__super__.constructor.call(this, options);
        },

        /**
         * {@inheritdoc}
         */
        initialize: function (options) {
            this.$context = options._sourceElement;
            this.target = options.target;
            this.key = options.key || this.key;
            this.eventName = options.eventName || this.eventName;
            this.formType = options.formType || this.formType;
            this.formName = options.formName || this.formName;

            this.currentValue = this.$context.find(this.target).val();
            this.$context.on('change.' + this.cid, this.target, this.getChangeCallback());
            mediator.on('dt:form:field-rendered', this.fieldReRendered, this);
        },

        /**
         * Handles re-render of the field, maybe with new data value, therefore
         * the change event must be triggered
         *
         * @param {Object} data
         */
        fieldReRendered: function (data) {
            if (this.$context.find(this.target).is(':input[name*="\[' + data.field + '\]"]')) {
                this.getChangeCallback()();
            }
        },

        /**
         * Returns callback for change event (binding)
         * on the target field in context of this component's
         * main element. Single change callback is considered every
         * 400ms.
         *
         * @return {function(): void}
         */
        getChangeCallback: function () {
            const self = this;
            let timeout;
            return function () {
                if (null !== timeout) {
                    clearTimeout(timeout);
                }
                timeout = setTimeout(function () {
                    const targetValue = self.$context.find(self.target).val();
                    if (targetValue != self.currentValue) {
                        self.currentValue = targetValue;
                        self.triggerChange(self.$context.find(self.target).val());
                    }
                }.bind(this), 400);
            };
        },

        /**
         *
         * @param {String} value
         */
        triggerChange: function (value) {
            const data = {};
            data[this.key] = value;
            if (this.formType) {
                data.form_type = this.formType;
            }
            if (this.formName) {
                data.form_name = this.formName;
            }
            mediator.trigger(this.eventName, data);
        },

        /**
         * {@inheritdoc}
         */
        dispose: function () {
            this.$context.off('change.' + this.cid);
            mediator.off('dt:form:field-rendered', this.fieldReRendered, this);
        }
    });

    return FieldChanged;
});
