define(function (require) {
    'use strict';

    const _ = require('underscore');
    const $ = require('jquery');
    const BaseComponent = require('oroui/js/app/components/base/component');
    const mediator = require('oroui/js/mediator');
    const RenderFormView = require('dtaccountplan/js/app/views/render-form');
    const routing = require('routing');
    const RenderFormFieldComponent = BaseComponent.extend({

        ViewType: RenderFormView,

        /** @property {Object} */
        $context: null,

        /** @property {String} */
        route: 'dt_go_plan_render_form',

        /** @property {String} */
        field: null,

        /** @property {Object} */
        view: null,

        /** @property {String} */
        eventName: 'dt:content:changed',

        /** @property {Number} */
        fiscalYear: null,

        /** @property {Object} */
        currentData: null,

        /** @property {Boolean} */
        ignoreEmpty: false,

        /**
         * @inheritDoc
         */
        constructor: function RenderFormFieldComponent(options) {
            RenderFormFieldComponent.__super__.constructor.call(this, options);
        },

        /**
         * {@inheritdoc}
         */
        initialize: function (options) {
            this.$context = options._sourceElement;
            this.route = options.route || this.route;
            this.field = options.field || this.field;
            this.fiscalYear = options.fiscalYear || this.fiscalYear;
            this.ignoreEmpty = options.ignoreEmpty || false;
            this.eventName = options.eventName || this.eventName;
            const viewOptions = {
                el: this.$context.find(options.target)
            };
            this.view = new this.ViewType(viewOptions);

            _.each(this.eventName.split(','), function (eventName) {
                mediator.on(eventName, this.updateForm, this);
            }.bind(this));

            mediator.on('dt:fiscalYear:changed', this.updateFiscalYear, this);
        },

        /**
         * Updates fiscalYear property from event data
         *
         * @param {Object} data
         */
        updateFiscalYear: function (data) {
            this.fiscalYear = data.fiscalYear;
            if (null !== this.currentData) {
                this.updateForm(this.currentData);
            }
        },

        /**
         * Updates form field
         *
         * @param {Object} data
         */
        updateForm: function (data) {
            if (this.ignoreEmpty && this.isEmpty(data)) {
                return;
            }
            this.currentData = data;
            data.field = this.field;
            if (null !== this.fiscalYear) {
                data.fiscalYear = this.fiscalYear;
            }
            this.handleUpdate(data);
        },

        /**
         * Checks if ID of te trigger property is empty
         *
         * @param {Object} data
         * @return {Boolean}
         */
        isEmpty: function (data) {
            const trigger = this.getTrigger(data);
            if (null !== trigger) {
                const value = data[trigger];
                return !value || String(value) === '';
            }

            return false;
        },

        /**
         * @param {Object} data
         * @return {String|null}
         */
        getTrigger: function (data) {
            const properties = [];
            const ignore = ['field', 'form_name', 'form_type'];
            _.each(data, function (val, key) {
                if (!_.contains(ignore, key)) {
                    properties.push(key);
                }
            });

            if (properties.length === 1) {
                return properties[0];
            }

            return null;
        },

        /**
         * Handles update of the form with given input data
         *
         * @param {Object} data
         */
        handleUpdate: function (data) {
            $.ajax({
                url: routing.generate(this.route),
                data: data,
                method: 'POST'
            }).done(function (response) {
                if (!!response.form_field) {
                    this.view.setHtml(response.form_field);
                    const renderPromise = this.view.render();
                    if (null !== renderPromise) {
                        renderPromise.done(function () {
                            mediator.trigger('dt:form:field-rendered', {
                                field: this.field
                            });
                        }.bind(this));
                    }
                }
            }.bind(this));
        },

        /**
         * {@inheritdoc}
         */
        dispose: function () {
            if (this.disposed || !this.$context) {
                return;
            }

            _.each(this.eventName.split(','), function (eventName) {
                mediator.off(eventName, this.updateForm, this);
            }.bind(this));
            mediator.off('dt:fiscalYear:changed', this.updateFiscalYear, this);
        }
    });

    return RenderFormFieldComponent;
});
