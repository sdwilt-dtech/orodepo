define(function(require) {
    'use strict';

    const _ = require('underscore');
    const Select2Component = require('oro/select2-component');

    const Select2CustomerContactComponent = Select2Component.extend({

        customerId: null,

        /**
         * @inheritDoc
         */
        constructor: function Select2CustomerContactComponent(options) {
            Select2CustomerContactComponent.__super__.constructor.call(this, options);
        },

        /**
         * @inheritDoc
         */
        initialize: function(options) {
            this.customerId = _.result(options, 'customer_id') || this.customerId;
            Select2CustomerContactComponent.__super__.initialize.call(this, options);
        },

        preConfig: function(config) {
            const that = this;
            Select2CustomerContactComponent.__super__.preConfig.call(this, config);
            const dataCallback = config.ajax.data;
            config.ajax.data = function (query, page) {
                const result = dataCallback(query, page);
                result.customerId = that.customerId;

                return result;
            };

            return config;
        }
    });
    return Select2CustomerContactComponent;
});
