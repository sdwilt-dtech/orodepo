define(function (require) {
    "use strict";

    const $ = require("jquery");
    const BaseComponent = require("oroui/js/app/components/base/component");
    const defaultOptions = {
            actionSelector: '[data-generate-date]',
            valueSelector: '[data-value-target]',
            linkContainerSelector: '[data-date-container]'
        };
    const DefaultDateComponent = BaseComponent.extend((function () {

        /**
         * Click listener to toggle visibility of format example
         *
         * @param {Object} ev
         */
        function targetClickListener(ev) {
            ev.preventDefault();
            ev.target.blur();

            const date = new Date($(ev.target).closest(this.actionSelector).data('value'));

            $(this.valueSelector, this.$context).datepicker('setDate', date).trigger('change');
        }

        return {
            /**
             * @property {Object}
             */
            $context: null,

            /**
             * @property {String}
             */
            actionSelector: defaultOptions.actionSelector,

            /**
             * @property {Object}
             */
            valueSelector: defaultOptions.valueSelector,

            /**
             * @inheritDoc
             */
            constructor: function DefaultDateComponent(options) {
                DefaultDateComponent.__super__.constructor.call(this, options);
            },

            /**
             * {@inheritdoc}
             */
            initialize: function (options) {
                this.$context = options._sourceElement;
                if (!this.$context) {
                    return;
                }

                this.actionSelector = options.actionSelector || defaultOptions.actionSelector;
                this.valueSelector = options.valueSelector || defaultOptions.valueSelector;

                this.$context.on("click." + this.cid, this.actionSelector, targetClickListener.bind(this));
            },

            /**
             * {@inheritdoc}
             */
            dispose: function () {
                if (this.disposed || !this.$context) {
                    return;
                }
                this.$context.off("." + this.cid);
            }
        };
    })());

    return DefaultDateComponent;
});
