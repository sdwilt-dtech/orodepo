define(function(require) {
    'use strict';

    const _ = require('underscore');
    const BaseView = require('oroui/js/app/views/base/view');

    const RenderFormView = BaseView.extend({

        /**
         * @inheritDoc
         */
        constructor: function RenderFormView(options) {
            RenderFormView.__super__.constructor.call(this, options);
        },

        /**
         * If new HTML available, will return render promise
         *
         * @return {null|Promise}
         */
        render: function() {
            if (this.html && this.html.length > 0) {
                // Notify related layout components to interact with manager
                // about self-removal
                this.$el.find('[data-bound-component]').trigger('content:remove')
                this.$el.html(this.html);
                return this.initLayout().done(_.bind(this._resolveDeferredRender, this));
            }

            return null;
        },

        /**
         * Forces separate layout initialization
         *
         * @inheritDoc
         */
        hasOwnLayout: function () {
            return true;
        },

        /**
         * Set html template
         * @param {string} html
         */
        setHtml: function(html) {
            this.html = html;
        }
    });

    return RenderFormView;
});
