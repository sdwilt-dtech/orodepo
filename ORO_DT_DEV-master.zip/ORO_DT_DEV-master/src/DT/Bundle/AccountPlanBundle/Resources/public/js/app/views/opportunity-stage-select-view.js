define(function(require) {
    'use strict';

    const _ = require('underscore');
    const BaseView = require('oroui/js/app/views/base/view');

    const OpportunityStageSelectView = BaseView.extend({

        /**
         * @inheritDoc
         */
        constructor: function OpportunityStageSelectView(options) {
            OpportunityStageSelectView.__super__.constructor.call(this, options);
        },

        /**
         * @inheritDoc
         */
        initialize: function(options) {
            OpportunityStageSelectView.__super__.initialize.call(this, options);

            this.options = _.defaults(options || {}, this.options);

            this.render();
        },

        render: function() {
            this.initLayout().then(_.bind(this.afterLayoutInit, this));
        },

        /**
         * Handles initiation of change events and show/
         * hide mandatory fields
         */
        afterLayoutInit: function() {
            this.initProbability();
            this.initMandatoryFields();
        },

        initProbability: function () {
            const $stage = this.$('select[data-name="field__stage"]');
            const $probability = this.$('input[data-name="field__probability"]');
            const stages = this.options.stages;
            let shouldChangeProbability = false;

            if (stages.hasOwnProperty($stage.val())) {
                const probabilityVal = parseFloat($probability.val());
                if (!probabilityVal || (probabilityVal === parseFloat(stages[$stage.val()].probability))) {
                    shouldChangeProbability = true;
                }
            }

            $probability.on('change', function(e) {
                shouldChangeProbability = false;
            });

            $stage.on('change', function(e) {
                const val = $stage.val();

                if (!shouldChangeProbability) {
                    return;
                }

                if (stages.hasOwnProperty(val)) {
                    $probability.val(stages[val].probability);
                }
            });
        },

        initMandatoryFields: function () {
            const $stage = this.$('select[data-name="field__stage"]');
            $stage.on('change', _.bind(this.showHideFields, this));
            this.showHideFields();
        },

        showHideFields: function () {
            const value = this.$('select[data-name="field__stage"]').find('option:selected').text();
            const stageNumber = this.getStageNumber(value);
            if (stageNumber > 1) {
                this.showFields();
            } else {
                this.hideFields();
            }
        },

        getStageNumber: function (value) {
            const matches = value.match(/^(\d)([a-z]+)?\.\s{1}([a-zA-Z1-9\s])+$/);
            return matches && matches[1] ? parseInt(matches[1]) : 0;
        },

        showFields: function () {
            this.$('[data-mandatory-stage-fields]').show(0, function () {
                this.$('[data-mandatory-stage-fields] [data-validation]').each(function () {
                    const $field = $(this);
                    $field.prop('disabled', false);
                });
            }.bind(this));
        },

        hideFields: function () {
            this.$('[data-mandatory-stage-fields]').hide(0, function () {
                this.$('[data-mandatory-stage-fields] [data-validation]').each(function () {
                    const $field = $(this);
                    $field.prop('disabled', true);
                });
            }.bind(this));
        }
    });

    return OpportunityStageSelectView;
});
