define(function (require) {
    'use strict';

    const $ = require('jquery');
    const _ = require('underscore');
    const BaseComponent = require('oroui/js/app/components/base/component');
    const routing = require('routing');
    const mediator = require('oroui/js/mediator')
    const TextIdGenerateComponent = BaseComponent.extend({

        /** @property {jQuery} */
        $context: null,

        /** @property {String[]} */
        fields: [],

        /** @property {String} */
        route: null,

        /** @property {jQuery} */
        $target: null,

        /** @property {jQuery} */
        $name: null,

        /**
         * @inheritDoc
         */
        constructor: function TextIdGenerateComponent(options) {
            TextIdGenerateComponent.__super__.constructor.call(this, options);
        },

        /**
         * {@inheritdoc}
         */
        initialize: function (options) {
            this.$context = options._sourceElement;
            this.fields = options.fields;
            this.route = options.route;
            this.$target = this.$context.find(options.target || '[name^="dt_go_plan_"][name$="\[textId\]"]');
            this.$name = this.$context.find(options.target || '[name^="dt_go_plan_"][name$="\[name\]"]');

            this.$context.on('change.' + this.cid, this.getFieldsSelector(), _.bind(this.onFieldChange, this));
            mediator.on('dt:form:field-rendered', this.onFieldChange, this);
        },

        /**
         *  Handles change of one of defined fields
         */
        onFieldChange: function () {
            if (this.hasAllFields()) {
                $.ajax({
                    url: routing.generate(this.route),
                    data: this.getData(),
                    method: 'POST'
                }).done(function (response) {
                    if (!!response.textId) {
                        this.$target.val(response.textId);
                    }
                    if (!!response.name) {
                        this.$name.val(response.name);
                    }
                }.bind(this));
            }
        },

        /**
         * {@inheritdoc}
         */
        dispose: function () {
            if (this.disposed || !this.$context) {
                return;
            }
            this.$context.off('change.' + this.cid);
            mediator.off('dt:form:field-rendered', this.onFieldChange, this);
        },

        /**
         * Returns data from gathered fields
         *
         * @return {Object}
         */
        getData: function () {
            const data = {};
            _.each(this.fields, function (selector) {
                const $field = this.$context.find(selector);
                const name = $field.prop('name');
                const matches = name.match(/\[([_a-zA-Z0-9]+)\]/);
                if (matches && !!matches[1]) {
                    data[matches[1]] = $field.val();
                }
            }.bind(this));

            return data;
        },

        /**
         * Creates single selector
         *
         * @return {String}
         */
        getFieldsSelector: function () {
            return this.fields.join(', ');
        },

        /**
         * Returns true if all fields from the options
         * contain values
         *
         * @return {Boolean}
         */
        hasAllFields: function () {
            let hasAll = true;
            _.each(this.fields, function (selector) {
                const $field = this.$context.find(selector);
                if (!$field.length || !String($field.val()).length) {
                    hasAll = false;
                }
            }.bind(this));

            return hasAll;
        }
    });

    return TextIdGenerateComponent;
});
