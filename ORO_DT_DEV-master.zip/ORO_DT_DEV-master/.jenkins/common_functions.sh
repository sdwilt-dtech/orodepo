#!/bin/bash

EXECUTOR_NUMBER_S1="$((EXECUTOR_NUMBER))"
PORT_S1=$((9515 + EXECUTOR_NUMBER))

export JENKINS_URL="https://10.142.0.3/userFiles"
USER_RUNTIME=nginx

# dbname=${DB_NAME:-oro_$EXECUTOR_NUMBER}
# [ $PG_VER ] && source scl_source enable rh-postgresql96
# [ $MYSQL_VER ] && source scl_source enable rh-mysql57
# [ $REDIS_VER ] && source scl_source enable oro-redis$REDIS_VER
# [ $ES_VER ] && source scl_source enable oro-elasticsearch$ES_VER
# [ $RMQ_VER ] && source scl_source enable oro-rabbitmq-server$RMQ_VER
[ $PHP_VER ] && source scl_source enable php$PHP_VER
[ $NODEJS_VER ] && source scl_source enable oro-nodejs$NODEJS_VER

REDIS_CONNECTION_TYPE="${ORO_REDIS_CONN-SOCKET}"
REDIS_CONNECTION="/run/redis_docker/redis.sock"
MONGO_INITDB_ROOT_USERNAME='dba'
MONGO_INITDB_ROOT_PASSWORD='nRfbge'
MONGO_USER_PASSWORD='6y1JyY'
REDIS_PASSWORD='qj16wCLxZxxHMaA7RlFUFfUD9y5vn8SALJX54kMDpJHPfy4x'

export LANG="en_US.UTF-8"
export LC_CTYPE="en_US.UTF-8"
export INSTALLER_LOCALE=" --language=en --formatting-code=en_US "

SET_COMPOSER_HOME=$HOME/.composer

# shellcheck disable=SC2034
DEMO_URL_CRM="https://github.com/laboro/crm-demo.git"
# shellcheck disable=SC2034
DEMO_URL_COMMERCE="https://github.com/laboro/commerce-demo.git"
# shellcheck disable=SC2034
DEMO_COMPOSER_CRM="${DEMO_COMPOSER_CRM-oro/crm-demo$CRM_DEMO}"
# shellcheck disable=SC2034
CRM_PRO_DEMO_DATA_BUNDLE=${CRM_PRO_DEMO_DATA_BUNDLE-$CRM_DEMO}
# shellcheck disable=SC2034
DEMO_COMPOSER_COMMERCE="${DEMO_COMPOSER_COMMERCE-oro/commerce-demo$COMMERCE_DEMO}"

if [ ! "x$(id -u)" = "x0" ]; then
  SUDO_BIN="sudo"
fi

export SUDO_RUNTIME="sudo -u $USER_RUNTIME -E -- "

sudo_scl() {
  SUDO_USER=${2-$USER_RUNTIME}
  local sudo_options="-u $SUDO_USER -E"
  local scls=$X_SCLS
  local RETVAL
  #available_scls="`scl --list | tr '\n' ' ' | sed 's/ $//'`"

  if [ "x$scls" = "x" ]; then
    echo "Unable to identify activated SCL collection(s). Please activate them in shell profile via"
    echo 'source /opt/rh/$collection_name/enable'
    echo 'export X_SCLS="`scl enable $collection_name '"'"'echo \$X_SCLS'"'"'`"'
    exit 1
  fi

  /usr/bin/sudo $sudo_options LD_LIBRARY_PATH="$LD_LIBRARY_PATH" PATH="$PATH" -- scl enable $scls "$1"
  RETVAL=$?
  return $RETVAL
}

function fatal() {
  export GREP_COLOR='00;38;5;157'
  export GREP_COLOR='1;32'
  export GREP_COLOR=''
  echo "[ERROR] $*" | grep --color -w '\[ERROR\]'
  exit 1
}

cleanup_system() {
  local NUM=${1-$EXECUTOR_NUMBER}
  if [[ "X$SKIP_CACHE_PREPARE" == "Xno" || "X$SKIP_CACHE_PREPARE" == "X" ]]; then
    echo "Stop nginx service"
    $SUDO_BIN systemctl stop "nginx.service"
    echo "Stop oro-* rh-* service"
    for service in $(systemctl --no-legend list-unit-files php* oro-* rh-* mysql55* | grep -v @ | cut -d' ' -f1); do
      echo "systemctl stop \"$service\""
      $SUDO_BIN systemctl stop "$service"
    done
    # $SUDO_BIN systemctl stop "phantomjs_$NUM"
    echo "Stop browser_$EXECUTOR_NUMBER_S1 service"
    $SUDO_BIN systemctl stop "browser_$EXECUTOR_NUMBER_S1"
    $SUDO_BIN systemctl disable "browser_$EXECUTOR_NUMBER_S1"
    echo "Kill processes with browser_$EXECUTOR_NUMBER_S1"
    pgrep -f "session_$EXECUTOR_NUMBER_S1" | xargs -r -I {} kill -9 {} # 2>/dev/null
    $SUDO_BIN rm -rf /run/systemd/system/browser_*

    echo "docker stop"
    docker ps
    docker ps -q | xargs -r -I {} docker stop {} #2>/dev/null
    echo "docker rm"
    docker ps -aq | xargs -r -I {} docker rm {} #2>/dev/null
    echo "docker volume rm"
    docker volume ls -q | xargs -r -I {} docker volume rm {} #2>/dev/null
    echo "docker network rm"
    docker network ls -q | xargs -r -I {} docker network rm {} #2>/dev/null
    sleep 2
    $SUDO_BIN systemctl restart docker
    $SUDO_BIN systemctl daemon-reload
    $SUDO_BIN systemctl reset-failed

    #NB! Doesn't work on multiworker nodes. It will intersect with other sessions
    echo "Cleaunup /tmp"
    $SUDO_BIN rm -rf /tmp/.org.chromium*
    $SUDO_BIN rm -rf /tmp/.com.google*
    $SUDO_BIN rm -rf /tmp/behat*
    $SUDO_BIN rm -rf /tmp/oro*
    $SUDO_BIN rm -rf /tmp/phpstan*
    $SUDO_BIN rm -f /tmp/{*.gif,*.jpg,*.png,*.doc,*.ods,*.csv*,*.svg,tmp.*,*.xlsx}
    $SUDO_BIN find /tmp -group $USER_RUNTIME -delete

    echo "Kill chrome processes"
    $SUDO_BIN pgrep -f "chrome" | xargs -r -I {} $SUDO_BIN kill -9 {} 2>/dev/null
    echo "Kill processes epmd"
    $SUDO_BIN systemctl stop epmd@0.0.0.0.socket
    $SUDO_BIN pgrep -f "epmd" | xargs -r -I {} $SUDO_BIN kill -9 {} 2>/dev/null

    echo "Cleaunup $HOME"
    $SUDO_BIN rm -rf "$HOME/phantomjs/"*
    $SUDO_BIN rm -rf "$HOME/chrome/"*
    $SUDO_BIN rm -rf "$HOME/.pdepend/"
  fi

  $SUDO_BIN sync
  sleep 0.5
  #Unmount all OVFS
  for dev in $(mount | grep "/var/www/ovfs-mnt_${EXECUTOR_NUMBER}" | cut -d' ' -f3); do
    if grep -q "$dev" /proc/mounts; then
      echo "Umounting try $dev"
      $SUDO_BIN fuser -v -M $dev || :
      fuser -k -M $dev || :
      sleep 1
      $SUDO_BIN umount -l "$dev" || :
    fi
  done
  echo "Remove /var/www/ovfs-{mnt,wrk,stash}_$NUM*"
  $SUDO_BIN rm -rf /var/www/ovfs-{mnt,wrk,stash}_"$NUM"*
  [ "$2" ] && $SUDO_BIN rm -rf /var/www/ovfs-tmp_"$NUM"*
  df -h
  df -h -i
  $SUDO_BIN netstat -ltpun
}

setup_system() {
  $SUDO_BIN setenforce 0
  $SUDO_BIN systemctl stop firewalld
  # $SUDO_BIN npm config set cache /mnt/jenkins/npm --global
  # npm config set cache /mnt/jenkins/npm
}

collect_logs() {
  local LOGPATH=${1-app/logs}
  echo "Show used disk space"
  df -h
  df -h -i
  $SUDO_BIN du -sh /var/www/*
  echo "Collect logs to $LOGPATH"
  $SUDO_BIN chmod 755 /var/opt/remi/php"$PHP_VER"/log/php-fpm || :
  $SUDO_BIN chmod 644 /var/opt/remi/php"$PHP_VER"/log/php-fpm/* || :
  $SUDO_BIN cp -rfv /var/opt/remi/php"$PHP_VER"/log/php-fpm "${LOGPATH}"/ || :
  $SUDO_BIN chown -R "$USER":"$USER_RUNTIME" "$LOGPATH"/*
}

install_packages() {
  local TMP_FILE
  $SUDO_BIN yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm yum-utils scl-utils centos-release-scl centos-release-scl-rh
  #Enable repositories
  $SUDO_BIN yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
  $SUDO_BIN yum-config-manager --add-repo http://koji.oro.cloud/rpms/oro-el7.repo

  if [[ ! -e /etc/yum.repos.d/google-chrome.repo ]]; then
    TMP_FILE=$(mktemp)
    cat >"$TMP_FILE" <<__EOF__
[google-chrome]
name=google-chrome
baseurl=http://dl.google.com/linux/chrome/rpm/stable/x86_64
enabled=1
gpgcheck=1
gpgkey=https://dl.google.com/linux/linux_signing_key.pub
__EOF__
    $SUDO_BIN cp -f "$TMP_FILE" "/etc/yum.repos.d/google-chrome.repo"
  fi

  PKG+="php70-runtime php70-php-cli php70-php-fpm php70-php-opcache php70-php-mbstring php70-php-mcrypt php70-php-mysqlnd php70-php-pgsql php70-php-process php70-php-ldap php70-php-gd php70-php-intl php70-php-bcmath php70-php-xml php70-php-soap php70-php-tidy php70-php-zip php70-php-pecl-mongodb "
  PKG+="php71-runtime php71-php-cli php71-php-fpm php71-php-opcache php71-php-mbstring php71-php-mcrypt php71-php-mysqlnd php71-php-pgsql php71-php-process php71-php-ldap php71-php-gd php71-php-intl php71-php-bcmath php71-php-xml php71-php-soap php71-php-tidy php71-php-zip php71-php-pecl-mongodb "
  PKG+="php72-runtime php72-php-cli php72-php-fpm php72-php-opcache php72-php-mbstring  php72-php-mysqlnd php72-php-pgsql php72-php-process php72-php-ldap php72-php-gd php72-php-intl php72-php-bcmath php72-php-xml php72-php-soap php72-php-tidy php72-php-zip php72-php-pecl-mongodb "
  PKG+="php73-runtime php73-php-cli php73-php-fpm php73-php-opcache php73-php-mbstring  php73-php-mysqlnd php73-php-pgsql php73-php-process php73-php-ldap php73-php-gd php73-php-intl php73-php-bcmath php73-php-xml php73-php-soap php73-php-tidy php73-php-zip php73-php-pecl-mongodb "
  PKG+="php74-runtime php74-php-cli php74-php-fpm php74-php-opcache php74-php-mbstring  php74-php-mysqlnd php74-php-pgsql php74-php-process php74-php-ldap php74-php-gd php74-php-intl php74-php-bcmath php74-php-xml php74-php-soap php74-php-tidy php74-php-zip php74-php-pecl-mongodb "
  # workaround until fix BAP-20075
  PKG+="rh-postgresql96 rh-postgresql96-postgresql rh-postgresql96-postgresql-syspaths "
  PKG+="rh-mysql57 rh-mysql57-mysql "
  # PKG+="rh-postgresql10-postgresql rh-postgresql10 rh-postgresql10-postgresql-libs rh-postgresql10-postgresql-contrib rh-postgresql10-postgresql-server rh-postgresql10-runtime rh-postgresql10-postgis rh-postgresql10-postgis-utils rh-postgresql11 rh-postgresql11-postgresql-libs rh-postgresql11-postgresql-contrib rh-postgresql11-postgresql-server rh-postgresql11-runtime rh-postgresql11-postgis rh-postgresql11-postgis-utils mysql55 mysql55-mysql mysql55-mysql-server rh-mysql56-mysql-server rh-mysql56 rh-mysql56-mysql "
  # " oro-elasticsearch24 oro-elasticsearch24-runtime oro-elasticsearch24-elasticsearch oro-elasticsearch62 oro-elasticsearch62-runtime oro-elasticsearch62-elasticsearch oro-elasticsearch6 oro-elasticsearch6-runtime oro-elasticsearch6-elasticsearch oro-redis4 oro-redis4-runtime oro-redis4-redis oro-redis5 oro-redis5-runtime oro-redis5-redis oro-rabbitmq-server35 oro-rabbitmq-server35-runtime oro-rabbitmq-server35-rabbitmq-server oro-rabbitmq-server36 oro-rabbitmq-server36-runtime oro-rabbitmq-server36-rabbitmq-server oro-rabbitmq-server37 oro-rabbitmq-server37-runtime oro-rabbitmq-server37-rabbitmq-server "
  PKG+="nginx nodejs npm oro-nodejs12 postfix git device-mapper-persistent-data lvm2 mc atop unzip bzip2 bc docker-ce google-chrome-stable chromedriver-last parallel "

  if ! uname -r | grep -q ^4; then
    echo "Install new kernel"
    #Enable new kernel for support overlayfs2
    $SUDO_BIN rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
    $SUDO_BIN rpm -Uvh http://www.elrepo.org/elrepo-release-7.0-2.el7.elrepo.noarch.rpm
    $SUDO_BIN yum -y --enablerepo=elrepo-kernel install kernel-ml
    $SUDO_BIN grub2-set-default 0
    fatal "Please reboot node and run test again"
  fi

  # shellcheck disable=SC2086
  $SUDO_BIN yum -y --nogpgcheck install $PKG || return 1

  setup_docker
  parallel --record-env
}

setup_docker() {
  local TMP_FILE

  if [[ ! -e /etc/docker/daemon.json ]]; then
    $SUDO_BIN mkdir -p /etc/docker
    TMP_FILE=$(mktemp)
    cat >"$TMP_FILE" <<__EOF__
{
  "storage-driver": "overlay2"
}
__EOF__
    $SUDO_BIN cp -f "$TMP_FILE" "/etc/docker/daemon.json"
  fi

  $SUDO_BIN systemctl restart "docker.service" 2>/dev/null || :
  $SUDO_BIN systemctl enable "docker.service" 2>/dev/null || :

}

set_permission() {
  echo "Set security permission for $1"
  $SUDO_BIN setfacl -b -R "$1"
  # $SUDO_BIN find "$1" -type d -name ".jenkins" -prune -o -type f -exec chmod 0644 {} \;
  # $SUDO_BIN find "$1" -type d -exec chmod 0755 {} \;
  $SUDO_BIN chown -R "$USER":"$USER_RUNTIME" "$1"
  $SUDO_BIN chown -R "$USER_RUNTIME":"$USER_RUNTIME" "$1"/var/{attachment,cache,import_export,logs,sessions} 2>/dev/null || :
  $SUDO_BIN chown -R "$USER_RUNTIME":"$USER_RUNTIME" "$1"/public/{media,uploads,js} 2>/dev/null || :
}

unset_permission() {
  echo "Disable security permission for $1"
  $SUDO_BIN chown -R "$USER":"$USER_RUNTIME" "$1" 2>/dev/null || :
}

enable_permission_installer() {
  echo "Set security permission for installer $1"
  $SUDO_BIN chown "$USER_RUNTIME":"$USER_RUNTIME" "$1"/config/parameters.yml 2>/dev/null || :
  $SUDO_BIN chown "$USER_RUNTIME":"$USER_RUNTIME" "$1"/config/parameters_test.yml 2>/dev/null || :
  $SUDO_BIN chown "$USER_RUNTIME":"$USER_RUNTIME" "$1"/public 2>/dev/null || :
  $SUDO_BIN chown "$USER_RUNTIME":"$USER_RUNTIME" "$1"/var 2>/dev/null || :
  $SUDO_BIN chown "$USER_RUNTIME":"$USER_RUNTIME" "$1"/vendor/oro/platform/build 2>/dev/null || :
  $SUDO_BIN chown -R "$USER_RUNTIME":"$USER_RUNTIME" "$1"/public/bundles 2>/dev/null || :
}

disable_permission_installer() {
  echo "Disable security permission for installer $1"
  $SUDO_BIN chown "$USER":"$USER_RUNTIME" "$1"/config/parameters.yml 2>/dev/null || :
  $SUDO_BIN chown "$USER":"$USER_RUNTIME" "$1"/config/parameters_test.yml 2>/dev/null || :
  $SUDO_BIN chown "$USER":"$USER_RUNTIME" "$1"/public 2>/dev/null || :
  $SUDO_BIN chown "$USER":"$USER_RUNTIME" "$1"/var 2>/dev/null || :
  $SUDO_BIN chown "$USER":"$USER_RUNTIME" "$1"/vendor/oro/platform/build 2>/dev/null || :
  $SUDO_BIN chown -R "$USER":"$USER_RUNTIME" "$1"/public/bundles 2>/dev/null || :
}

enable_exception_for_php_warning_and_notice() {
  #enable throwing exceptions if any PHP warning or notice is occured
  echo "sed -i -e '/^framework:/a \    php_errors:\n        throw: true' \"$1/config/config_$2.yml\""
  sed -i -e '/^framework:/a \    php_errors:\n        throw: true' "$1/config/config_$2.yml"
}

prepare_instance() {
  SRC=${1-$DIRNAME}
  NUM=${2-$EXECUTOR_NUMBER}
  TMP_FOLDER="/var/www/ovfs-tmp_$NUM"
  MNT_FOLDER="/var/www/ovfs-mnt_$NUM"
  WRK_FOLDER="/var/www/ovfs-wrk_$NUM"
  [[ -d /var/www ]] || {
    echo "Not exist /var/www. Create /var/www and mount as tmpfs 5G"
    $SUDO_BIN mkdir -p /var/www
    $SUDO_BIN mount -t tmpfs -o size=5G,noatime tmpfs /var/www || fatal "Can't mount /var/www as tmpfs"
  }
  mkdir -p "$TMP_FOLDER"
  mkdir -p "$MNT_FOLDER"
  mkdir -p "$WRK_FOLDER"

  echo "mount -t overlay -o redirect_dir=on,index=on,noatime,lowerdir=\"$SRC\",upperdir=\"$TMP_FOLDER\",workdir=\"$WRK_FOLDER\" none \"$MNT_FOLDER\""
  $SUDO_BIN mount -t overlay -o redirect_dir=on,index=on,noatime,lowerdir="$SRC",upperdir="$TMP_FOLDER",workdir="$WRK_FOLDER" none "$MNT_FOLDER" || fatal "Can't mount"
}

prepare_instance_bind() {
  SRC=${1-$DIRNAME}
  NUM=${2-$EXECUTOR_NUMBER}
  MNT_FOLDER="/var/www/ovfs-mnt_$NUM"
  [[ -d /var/www ]] || {
    echo "Not exist /var/www. Create /var/www and mount as tmpfs 5G"
    $SUDO_BIN mkdir -p /var/www
    $SUDO_BIN mount -t tmpfs -o size=5G,noatime tmpfs /var/www || fatal "Can't mount /var/www as tmpfs"
  }
  mkdir -p "$MNT_FOLDER"
  echo "$SUDO_BIN mount -o bind \"$SRC\" \"$MNT_FOLDER\""
  $SUDO_BIN mount -o bind "$SRC" "$MNT_FOLDER"
}

dump_db() {
  local DB_FILE=${1-db.sql}
  local DB_NAME=${2-$dbname}
  echo "Dump DB type $DB $DB_NAME to $DB_FILE"
  case ${DB} in
  MYSQL)
    docker exec -t mysql mysqldump -u root -h 127.0.0.1 "$DB_NAME" >"$DB_FILE" || fatal "Can't create DB dump to $DB_FILE"
    ;;
  PG)
    docker exec -t pgsql pg_dump -U postgres -c --if-exists "$DB_NAME" >"$DB_FILE" || fatal "Can't create DB dump to $DB_FILE"
    ;;
  esac
}

load_db() {
  local DB_FILE=${1-db.sql}
  local DB_NAME=${2-$dbname}
  local TEMP_DIR
  echo "Load DB type $DB $DB_FILE to $DB_NAME"
  case ${DB} in
  MYSQL)
    TEMP_DIR="$(mktemp -d)"
    zcat -f <"$DB_FILE" >"$TEMP_DIR/dump.sql"
    docker exec -t mysql mysql -e "CREATE DATABASE IF NOT EXISTS $DB_NAME;"
    docker cp "$TEMP_DIR/dump.sql" mysql:/tmp/ || fatal "Can't copy dump in container mysql"
    docker exec mysql bash -c "cat /tmp/dump.sql | mysql -u root -h 127.0.0.1 -D $DB_NAME" || fatal "Can't restore dump"
    rm -rf "$TEMP_DIR" || :
    ;;
  PG)
    if [ -e "$DB_FILE" ]; then
      TEMP_DIR="$(mktemp -d)"
      zcat -f <"$DB_FILE" >"$TEMP_DIR/dump.sql"
      docker exec -t pgsql psql -q -U postgres -c "SELECT 1 FROM pg_database WHERE datname = '$DB_NAME'" | grep -q 1 || docker exec -t pgsql psql -q -U postgres -c "CREATE DATABASE $DB_NAME WITH lc_collate = 'C' template = template0;" || fatal "Can't create DB"
      docker cp "$TEMP_DIR/dump.sql" pgsql:/tmp/ || fatal "Can't copy dump in container pgsql"
      docker exec pgsql bash -c "cat /tmp/dump.sql | psql -U postgres -d $DB_NAME >/dev/null" || fatal "Can't restore dump"
      docker exec -i pgsql psql -U postgres -c 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp";' -d "$DB_NAME"
      rm -rf "$TEMP_DIR" || :
    else
      docker exec -i pgsql psql -U postgres -c "CREATE DATABASE $DB_NAME WITH TEMPLATE '${dbname}_1';" || fatal "Can't create DB $DB_NAME from template ${dbname}_1"
    fi
    ;;
  esac
}

drop_db() {
  local DB_NAME=${1-$dbname}
  echo "Drop DB type $DB"
  case ${DB} in
  MYSQL)
    echo "Drop all DBs like $DB_NAME"
    DBASES="$(docker exec -t mysql mysql -sNe "SHOW DATABASES LIKE \"${DB_NAME}%\";" || fatal "Can't get DB list")"
    echo "Remove DBASES=$DBASES"
    for d in $DBASES; do
      docker exec -t mysql mysql -e "DROP DATABASE $d;"
    done
    ;;
  PG)
    echo "Drop all DBs like $DB_NAME"
    docker exec -t pgsql psql -q -U postgres -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$DB_NAME';"
    sleep 1
    docker exec -t pgsql bash -c "psql -U postgres -t -c \"select 'drop database '||datname||';' from pg_database where datistemplate=false\" | grep -w '$DB_NAME' | xargs -I {} psql -U postgres -c \"{}\"" || fatal "Can't drop DB"
    ;;
  esac
}

setup_db_mysql() {
  local DB_NAME="${2-$dbname}"
  local DOCKER_RUN
  DOCKER_RUN="$(docker ps -a | grep -q pgsql && docker inspect -f "{{.State.Running}}" mysql)"
  [[ "X$DOCKER_RUN" == "Xtrue" ]] && return 0

  rm -rf /tmp/mysql && mkdir -p /tmp/mysql/conf.d
  {
    echo '[mysqld]'
    echo 'wait_timeout = 28800'
    echo 'innodb_file_per_table = 0'
    echo 'optimizer_search_depth = 0'
  } >>/tmp/mysql/conf.d/oro.cnf
  [[ "$MYSQL_VER" =~ ^8*$ ]] && MYSQL_DOCKER_OPTION="--default-authentication-plugin=mysql_native_password"
  local w_timeout=0
  echo "docker run -d --name mysql -v /tmp/mysql/conf.d:/etc/mysql/conf.d --mount type=tmpfs,destination=/var/lib/mysql -p 127.0.0.1:3306:3306 -p 127.0.0.1:33060:33060 -e MYSQL_ALLOW_EMPTY_PASSWORD=yes mysql:$MYSQL_VER $MYSQL_DOCKER_OPTION"
  docker run -d --name mysql -v /tmp/mysql/conf.d:/etc/mysql/conf.d --mount type=tmpfs,destination=/var/lib/mysql -p 127.0.0.1:3306:3306 -p 127.0.0.1:33060:33060 -e MYSQL_ALLOW_EMPTY_PASSWORD=yes mysql:"$MYSQL_VER" $MYSQL_DOCKER_OPTION
  echo "Waiting for mysql-$MYSQL_VER "
  while [[ "$w_timeout" -lt 60 ]]; do
    docker exec -t mysql mysqladmin ping -u root -h 127.0.0.1 >/dev/null 2>&1 && break
    echo -n "."
    sleep 1
    ((w_timeout++))
  done
  echo " mysql UP"
  sleep 10

  docker exec -t mysql mysql -e "SET GLOBAL wait_timeout = 36000;"
  docker exec -t mysql mysql -e "SET GLOBAL max_allowed_packet = 33554432;"
  echo "Create DB=$DB_NAME"
  docker exec -t mysql mysql -e "CREATE DATABASE $DB_NAME; FLUSH PRIVILEGES;" || fatal "Can't grant privileges"
}

set_parameters_db_mysql() {
  [ "$#" -ge 1 ] || fatal "No path to application in function set_parameters_db_mysql"
  local DB_NAME="${2-$dbname}"
  find "$1"/config -type f -name 'parameters.yml' -print0 | xargs -0 sed -i "/database_driver:/s/:[[:space:]].*$/: pdo_mysql/g; /database_name/s/:[[:space:]].*$/: $DB_NAME/g; /database_user/s/:[[:space:]].*$/: root/g; /database_password/s/:[[:space:]].*$/: ''/g; /mailer_transport/s/:[[:space:]].*$/: null/g"
}

init_db_mysql() {
  setup_db_mysql "$@"
  set_parameters_db_mysql "$@"
}

setup_db_pgsql() {
  [ "$#" -ge 1 ] || fatal "No path to application in function setup_db_pgsql"
  local DOCKER_RUN
  DOCKER_RUN="$(docker ps -a | grep -q pgsql && docker inspect -f "{{.State.Running}}" pgsql)"
  [[ "X$DOCKER_RUN" == "Xtrue" ]] && return 0
  local DB_NAME="$dbname"
  rm -rf /tmp/pgsql && mkdir -p /tmp/pgsql/docker-entrypoint-initdb.d
  cat >>"/tmp/pgsql/docker-entrypoint-initdb.d/init.sh" <<__EOF__
  #!/bin/bash
  set -e -x

  export PGDATA=/var/lib/postgresql/data
  sed -i '/^local/s/peer/trust/g; /127\.0\.0\.1/s/ident/trust/g' "\$PGDATA"/pg_hba.conf
  # tune vacuum and other settings
  sed -i '/#autovacuum[[:space:]]=[[:space:]]on/s/#autovacuum[[:space:]]=/autovacuum =/g' "\$PGDATA"/postgresql.conf
  sed -i '/#log_autovacuum_min_duration =/s/#log_autovacuum_min_duration[[:space:]]=[[:space:]][-0-9]*[[:space:]]\(.*\)/log_autovacuum_min_duration = 0 \1/g' "\$PGDATA"/postgresql.conf
  sed -i '/#autovacuum_max_workers[[:space:]]=/s/#autovacuum_max_workers[[:space:]]=[[:space:]][0-9]*[[:space:]]\(.*\)/autovacuum_max_workers = 3 \1/g' "\$PGDATA"/postgresql.conf
  sed -i '/#autovacuum_naptime[[:space:]]=/s/#autovacuum_naptime[[:space:]]=[[:space:]][[:alnum:]]*[[:space:]]\(.*\)/autovacuum_naptime = 720 \1/g' "\$PGDATA"/postgresql.conf
  sed -i '/^max_connections[[:space:]]=/s/max_connections[[:space:]]=[[:space:]][0-9]*[[:space:]]\(.*\)/max_connections = 2000 \1/g' "\$PGDATA"/postgresql.conf
  sed -i '/^shared_buffers[[:space:]]=/s/shared_buffers[[:space:]]=[[:space:]][0-9]*\(.*\)/shared_buffers = 120\1/g' "\$PGDATA"/postgresql.conf
  sed -i '/#effective_cache_size[[:space:]]=/s/#effective_cache_size[[:space:]].*/effective_cache_size = 1GB/g' "\$PGDATA"/postgresql.conf
  # enable logging
  # $SUDO_BIN sed -i "s/^#log_statement = 'none'/log_statement = 'all'/g" "\$PGDATA"/postgresql.conf
  # enable unix socket
  sed -i "/#unix_socket_directories[[:space:]]=/s/#unix_socket_directories[[:space:]].*/unix_socket_directories = '\/run\/postgresql'/g" "\$PGDATA"/postgresql.conf

  psql -v ON_ERROR_STOP=1 -U "\$POSTGRES_USER" -c "CREATE DATABASE $DB_NAME WITH lc_collate = 'C' template = template0;"
  psql -v ON_ERROR_STOP=1 -U "\$POSTGRES_USER" -c 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp";' -d "$DB_NAME"

__EOF__

  chmod a+x /tmp/pgsql/docker-entrypoint-initdb.d/init.sh
  echo "docker run -d --name pgsql -v /tmp/pgsql/docker-entrypoint-initdb.d:/docker-entrypoint-initdb.d -v /run/postgresql_docker:/run/postgresql --mount type=tmpfs,destination=/var/lib/postgresql -p 127.0.0.1:5432:5432 -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD=postgres -e DB_NAME=\"$DB_NAME\" postgres:$PG_VER-alpine"
  docker run -d --name pgsql -v /tmp/pgsql/docker-entrypoint-initdb.d:/docker-entrypoint-initdb.d -v /run/postgresql_docker:/run/postgresql --mount type=tmpfs,destination=/var/lib/postgresql -p 127.0.0.1:5432:5432 -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD=postgres -e DB_NAME="$DB_NAME" postgres:"$PG_VER"-alpine

  echo "Waiting for PosgreSQL-$PG_VER"
  local w_timeout=0
  while [[ "$w_timeout" -lt 60 ]]; do
    docker exec -t pgsql pg_isready -h '/run/postgresql' >/dev/null 2>&1 && break
    echo -n "."
    sleep 1
    ((w_timeout++))
  done
  echo " pgsql UP"
  sleep 5
}

set_parameters_db_pgsql() {
  [ "$#" -ge 1 ] || fatal "No path to application"
  local DB_NAME="$dbname"
  find "$1"/config -type f -name 'parameters.yml' -print0 | xargs -0 sed -i "/database_driver:/s/:[[:space:]].*$/: pdo_pgsql/g; /database_host:/s/:[[:space:]].*$/: '\/run\/postgresql_docker'/g; /database_name/s/:[[:space:]].*$/: $DB_NAME/g; /database_user/s/:[[:space:]].*$/: postgres/g; /database_password/s/:[[:space:]].*$/: 'postgres'/g; /mailer_transport/s/:[[:space:]].*$/: null/g"
  if [ -n "$SHARD_PRICES" ]; then
    echo "Enable price sharding"
    sed -i 's/enable_price_sharding:.*/enable_price_sharding: true/g' "$1/config/parameters.yml"
  fi
}

init_db_pgsql() {
  setup_db_pgsql "$@"
  set_parameters_db_pgsql "$@"
}

clean_se_orm() {
  echo "Cleaning SE orm"
}

init_se_orm() {
  [ "$#" -ge 1 ] || fatal "No path to application in function init_se_orm"
  [ "$#" -eq 1 ] && clean_se_orm
}

status_se_elastic() {
  echo "Check elasticsearch health and status"
  curl -s -XGET -k http://localhost:9200/_cluster/health | jq
  [[ ${PIPESTATUS[0]} -eq 0 ]] || fatal "The health elasticsearch is bad"
  echo "Elasticsearch index list:"
  curl -s -XGET http://localhost:9200/_cat/indices/*?v
}

reindex_se() {
  [ "$#" -ge 1 ] || fatal "No path to application in function setup_se"
  local NUM=${2-$EXECUTOR_NUMBER}
  local _ENV=${3}
  local ENV=${4-test}
  echo "Reindex search engine $NUM"
  echo "php \"$1/bin/console\" oro:search:reindex --env=$ENV"
  php "$1/bin/console" oro:search:reindex --env="$ENV" || fatal "Can't reindex search"
  if grep -q "website_search_engine_index_prefix" "$1/config/parameters.yml"; then
    echo "php \"$1/bin/console\" oro:website-search:reindex --env=$ENV"
    php "$1/bin/console" oro:website-search:reindex --env="$ENV" || fatal "Can't reindex search"
    # echo "Delete elasticsearch index oro_website_search_test_es_index_0_$NUM"
    # curl -XDELETE "localhost:9200/oro_website_search_test_es_index_0_$NUM"
  fi
  if [[ "X$SE" == 'XES' ]]; then
    status_se_elastic
  fi
}

setup_se_elastic() {
  local DOCKER_RUN
  DOCKER_RUN="$(docker ps -a | grep -q -w elasticsearch && docker inspect -f "{{.State.Running}}" elasticsearch)"
  [[ "X$DOCKER_RUN" == "Xtrue" ]] && return 0
  rm -rf /tmp/elasticsearch && mkdir -p /tmp/elasticsearch
  cat >>"/tmp/elasticsearch/elasticsearch.yml" <<__EOF__
cluster.name: "docker-cluster"
network.host: 0.0.0.0
path.repo: /tmp
__EOF__

  echo "docker run -d --name elasticsearch --mount type=tmpfs,destination=/usr/share/elasticsearch/data -v /tmp/elasticsearch/elasticsearch.yml:/usr/share/elasticsearch/config/elasticsearch.yml -p 127.0.0.1:9200:9200 -p 127.0.0.1:9300:9300 -e ES_JAVA_OPTS=\"-Xms2g -Xmx2g\" -e \"discovery.type=single-node\" docker.elastic.co/elasticsearch/elasticsearch:$ES_VER"
  docker run -d --name elasticsearch --mount type=tmpfs,destination=/usr/share/elasticsearch/data -v /tmp/elasticsearch/elasticsearch.yml:/usr/share/elasticsearch/config/elasticsearch.yml -p 127.0.0.1:9200:9200 -p 127.0.0.1:9300:9300 -e ES_JAVA_OPTS="-Xms2g -Xmx2g" -e "discovery.type=single-node" docker.elastic.co/elasticsearch/elasticsearch:"$ES_VER"

  echo "Waiting for elasticsearch-$ES_VER"
  while [[ "$w_timeout" -lt 60 ]]; do
    curl -s -I -XGET -k http://localhost:9200/_cluster/health >/dev/null 2>&1 && {
      echo " Elasticsearch UP"
      curl -s -I -XGET -k http://localhost:9200/_cluster/health
    } && break
    echo -n "."
    sleep 1
    ((w_timeout++))
  done
  sleep 5
  curl -s -X PUT "localhost:9200/_cluster/settings?pretty" -H 'Content-Type: application/json' -d'{"persistent" : { "cluster" : { "max_shards_per_node": "5000" } } }' -O /dev/null
}

set_parameters_se_elastic() {
  [ "$#" -ge 1 ] || fatal "No path to application in function setup_se_elastic"
  local NUM=${index_name-$2}
  if [[ "X$NUM" == "X" ]]; then
    NUM=$EXECUTOR_NUMBER
  fi
  local _ENV=${3}
  echo "Setup elasticsearch $NUM"
  sed -i "s/search_engine_name:.*/search_engine_name: elastic_search/g; s/search_engine_port:.*/search_engine_port: 9200/g" "$1/config/parameters${_ENV}.yml"
  sed -i "s/search_engine_index_prefix:.*/search_engine_index_prefix: oro_search_test_es_index_$NUM/g" "$1/config/parameters${_ENV}.yml"
  # sed -i "s/oro_search_test_es_index/oro_search_test_es_index_$EXECUTOR_NUMBER/g" "$1/var/cache/test/srcTestProjectContainer.php"
  if grep -q "website_search_engine_index_prefix" "$1/config/parameters${_ENV}.yml"; then
    sed -i "s/website_search_engine_index_prefix:.*/website_search_engine_index_prefix: oro_website_search_test_es_index_$NUM/g" "$1/config/parameters${_ENV}.yml"
    # sed -i "s/oro_website_search_test_es_index/oro_website_search_test_es_index_$EXECUTOR_NUMBER/g" "$1/var/cache/test/srcTestProjectContainer.php"
  fi
}

init_se_elastic() {
  setup_se_elastic
  set_parameters_se_elastic "$@"
}

clean_ce_dbal() {
  echo "Cleaning CE dbal"
}

init_ce_dbal() {
  [ "$#" -ge 1 ] || fatal "No path to application in function init_ce_dbal"
  [ "$#" -eq 1 ] && clean_ce_dbal
  sed -i 's/message_queue_transport:.*/message_queue_transport: dbal/g' "$1"/config/parameters.yml
}

setup_ce_rmq() {
  local DOCKER_RUN
  DOCKER_RUN="$(docker ps -a | grep -q -w rabbitmq && docker inspect -f "{{.State.Running}}" rabbitmq)"
  [[ "X$DOCKER_RUN" == "Xtrue" ]] && return 0
  echo "docker run -d --hostname rabbitmq --name rabbitmq --mount type=tmpfs,destination=/var/lib/rabbitmq -p 127.0.0.1:4369:4369 -p 127.0.0.1:5671:5671 -p 127.0.0.1:5672:5672 -p 127.0.0.1:15671:15671 -p 127.0.0.1:15672:15672 -p 127.0.0.1:25672:25672 oroinc/rabbitmq:$RMQ_VER-alpine"
  docker run -d --hostname rabbitmq --name rabbitmq --user rabbitmq --mount type=tmpfs,destination=/var/lib/rabbitmq -p 127.0.0.1:4369:4369 -p 127.0.0.1:5671:5671 -p 127.0.0.1:5672:5672 -p 127.0.0.1:15671:15671 -p 127.0.0.1:15672:15672 -p 127.0.0.1:25672:25672 oroinc/rabbitmq:"$RMQ_VER"-alpine || fatal "Can't run rabbitmq container"

  echo "Waiting for RMQ-$RMQ_VER"
  while :; do
    docker exec -t --user rabbitmq rabbitmq rabbitmqctl node_health_check >/dev/null 2>&1 && break
    echo -n "."
    sleep 1
    ((w_timeout++))
    [[ "$w_timeout" -lt 60 ]] || fatal "Can't run rabbitmq-$RMQ_VER"
  done
  echo " RMQ UP"
  sleep 1
}

set_parameters_ce_rmq() {
  sed -i "s/message_queue_transport:.*/message_queue_transport: amqp/g; s/message_queue_transport_config:.*/message_queue_transport_config: { host: 127.0.0.1, port: 5672, user: guest, password: guest, vhost: \\/$2 }/g;" "$1"/config/parameters.yml

  docker exec -t --user rabbitmq rabbitmq rabbitmqctl add_vhost "/$2" || fatal "Can't add_vhost /$2"
  docker exec -t --user rabbitmq rabbitmq rabbitmqctl set_permissions -p "/$2" guest ".*" ".*" ".*" || fatal "Can't set_permissions /$2"
}

init_ce_rmq() {
  [ "$#" -ge 1 ] || fatal "No path to application in function init_ce_rmq"
  setup_ce_rmq "$1" "$2"
  set_parameters_ce_rmq "$1" "$2"
}

setup_cache_redis() {
  local DOCKER_RUN
  DOCKER_RUN="$(docker ps -a | grep -q -w redis && docker inspect -f "{{.State.Running}}" redis)"
  [[ "X$DOCKER_RUN" == "Xtrue" ]] && return 0
  echo "docker run -d -h redis --name redis -v /run/redis_docker:/data/redis -p 127.0.0.1:6379:6379 docker.io/redis:$REDIS_VER-alpine --unixsocket /data/redis/redis.sock --unixsocketperm 666"
  docker run -d -h redis --name redis -v /run/redis_docker:/data/redis -p 127.0.0.1:6379:6379 docker.io/redis:"$REDIS_VER"-alpine --unixsocket /data/redis/redis.sock --unixsocketperm 666
}

set_parameters_cache_redis() {
  [ "$#" -ge 1 ] || fatal "No path to application in function init_cache_redis"
  if ! grep -q "snc_redis.session.handler" "$1/config/parameters.yml"; then
    sed -i -e 's/session_handler: .*$/session_handler: snc_redis.session.handler/g' "$1/config/parameters.yml"
    if [[ "X$REDIS_CONNECTION_TYPE" == "X$TCP" ]]; then
      REDIS_CONNECTION='127.0.0.1:6379'
    fi
    cat >>"$1/config/parameters.yml" <<__EOF__
    redis_dsn_cache: "redis://$REDIS_CONNECTION/0"
    redis_dsn_session: "redis://$REDIS_CONNECTION/1"
    redis_dsn_doctrine: "redis://$REDIS_CONNECTION/2"
__EOF__
  fi
}

init_cache_redis() {
  setup_cache_redis
  set_parameters_cache_redis "$@"
}

setup_cache_redis_cluster() {
  [[ "X$(docker ps -f "name=docker-hoster" --format '{{.Names}}')" == "Xdocker-hoster" ]] || { docker run -d --name docker-hoster -v /var/run/docker.sock:/tmp/docker.sock -v /etc/hosts:/tmp/hosts dvdarias/docker-hoster; }
  # prepare redis cluster for cache
  docker run -d -h redis_cache1 --name redis_cache1 -v /etc/hosts:/etc/hosts --restart always docker.io/redis:"$REDIS_VER"-alpine --requirepass $REDIS_PASSWORD --masterauth $REDIS_PASSWORD
  docker run -d -h redis_cache2 --name redis_cache2 -v /etc/hosts:/etc/hosts --restart always docker.io/redis:"$REDIS_VER"-alpine --replicaof redis_cache1 6379 --requirepass $REDIS_PASSWORD --masterauth $REDIS_PASSWORD
  # prepare redis cluster for session
  docker run -d -h redis_session1 --name redis_session1 -v /etc/hosts:/etc/hosts --restart always docker.io/redis:"$REDIS_VER"-alpine --requirepass $REDIS_PASSWORD --masterauth $REDIS_PASSWORD
  docker run -d -h redis_session2 --name redis_session2 -v /etc/hosts:/etc/hosts --restart always docker.io/redis:"$REDIS_VER"-alpine --replicaof redis_session1 6379 --requirepass $REDIS_PASSWORD --masterauth $REDIS_PASSWORD

  rm -rf /tmp/tmp.*.redis
  # prepare sentinel for session
  for f in {1..3}; do
    TMP_FILE=$(mktemp --suffix=.redis)
    cat >"$TMP_FILE" <<__EOF__
sentinel monitor session_master redis_session1 6379 2
sentinel auth-pass session_master $REDIS_PASSWORD
__EOF__
    docker run -d -h redis_session_sentinel$f --name redis_session_sentinel$f -v /etc/hosts:/etc/hosts -v "$TMP_FILE":/data/sentinel.conf --restart always docker.io/redis:"$REDIS_VER"-alpine /data/sentinel.conf --sentinel
  done
  # prepare sentinel for cache
  for f in {1..3}; do
    TMP_FILE=$(mktemp)
    cat >"$TMP_FILE" <<__EOF__
sentinel monitor cache_master redis_cache1 6379 2
sentinel auth-pass cache_master $REDIS_PASSWORD
__EOF__
    docker run -d -h redis_cache_sentinel$f --name redis_cache_sentinel$f -v /etc/hosts:/etc/hosts -v "$TMP_FILE":/data/sentinel.conf --restart always docker.io/redis:"$REDIS_VER"-alpine /data/sentinel.conf --sentinel
  done
  sleep 5
  # show configuration
  echo "Configuration sentinel for cache:"
  docker exec -t redis_cache_sentinel1 redis-cli -p 26379 info sentinel
  echo "Configuration sentinel for session:"
  docker exec -t redis_session_sentinel1 redis-cli -p 26379 info sentinel
}

set_parameters_cache_redis_cluster() {
  [ "$#" -ge 1 ] || fatal "No path to application in function set_parameters_cache_redis_cluster"

  grep -q -w 'session_handler: snc_redis.session.handler' "$1/config/parameters.yml" || {
    sed -i -e 's/session_handler: .*$/session_handler: snc_redis.session.handler/g' "$1/config/parameters.yml"
    cat >>"$1/config/parameters.yml" <<__EOF__
    redis_dsn_cache:
        - 'redis://$REDIS_PASSWORD@redis_cache_sentinel1:26379/0'
        - 'redis://$REDIS_PASSWORD@redis_cache_sentinel2:26379/0'
        - 'redis://$REDIS_PASSWORD@redis_cache_sentinel3:26379/0'
    redis_dsn_cache_type: 'sentinel'
    redis_cache_sentinel_master_name: 'cache_master'
    redis_dsn_doctrine:
        - 'redis://$REDIS_PASSWORD@redis_cache_sentinel1:26379/1'
        - 'redis://$REDIS_PASSWORD@redis_cache_sentinel2:26379/1'
        - 'redis://$REDIS_PASSWORD@redis_cache_sentinel3:26379/1'
    redis_dsn_doctrine_type: 'sentinel'
    redis_doctrine_sentinel_master_name: 'cache_master'
    redis_dsn_session:
        - 'redis://$REDIS_PASSWORD@redis_session_sentinel1:26379/0'
        - 'redis://$REDIS_PASSWORD@redis_session_sentinel2:26379/0'
        - 'redis://$REDIS_PASSWORD@redis_session_sentinel3:26379/0'
    redis_dsn_session_type: 'sentinel'
    redis_session_sentinel_master_name: 'session_master'
__EOF__
  }
}

init_cache_redis_cluster() {
  setup_cache_redis_cluster
  set_parameters_cache_redis_cluster "$@"
}

# backup_cache_redis() {
#   echo "Backup CACHE redis"
#   $SUDO_BIN rm -rf /var/lib/redis_backup
#   $SUDO_BIN redis-cli save
#   sleep 1
#   $SUDO_BIN cp -rfv /var/opt/oro/oro-redis$REDIS_VER/lib/redis /var/lib/redis_backup || fatal "Can't backup redis"
# }

# restore_backup_cache_redis() {
#   echo "Restore backup CACHE redis"
#   clean_cache_redis
#   $SUDO_BIN su - -c 'cp -rfv /var/lib/redis_backup/* /var/lib/redis/' || fatal "Can't restore backup redis"
#   $SUDO_BIN chown -R redis:redis /var/opt/oro/oro-redis$REDIS_VER/lib/redis
#   $SUDO_BIN systemctl enable "oro-redis$REDIS_VER-redis.service"
#   $SUDO_BIN systemctl restart "oro-redis$REDIS_VER-redis.service" || fatal "Can't run oro-redis$REDIS_VER-redis.service"
# }

setup_db_mongo_cluster() {
  local KEY_FILE
  KEY_FILE=$(mktemp --suffix=_mongokey)
  openssl rand -base64 24 >"$KEY_FILE"
  chown 1001 "$KEY_FILE"
  chmod 600 "$KEY_FILE"

  [[ "X$(docker ps -f "name=docker-hoster" --format '{{.Names}}')" == "Xdocker-hoster" ]] || { docker run -d --name docker-hoster -v /var/run/docker.sock:/tmp/docker.sock -v /etc/hosts:/tmp/hosts dvdarias/docker-hoster || fatal "Can't run docker-hoster docker container"; }

  MONGO_CONTAINERS=$(docker ps -f "name=mongo" --format '{{.Names}}' | wc -l)
  if [[ $MONGO_CONTAINERS -ne 3 ]]; then
    for n in {1..3}; do
      docker run -d -h mongo$n --name mongo$n -v /etc/hosts:/etc/hosts -v "$KEY_FILE":/data/keyfile -e MONGO_INITDB_ROOT_USERNAME="$MONGO_INITDB_ROOT_USERNAME" -e MONGO_INITDB_ROOT_PASSWORD="$MONGO_INITDB_ROOT_PASSWORD" --restart always percona/percona-server-mongodb:"$MONGO_VER" --replSet "rs0" --keyFile /data/keyfile || fatal "Can't run mongo$n docker container"
    done
    sleep 10
    docker exec -t mongo1 mongo -u "$MONGO_INITDB_ROOT_USERNAME" -p "$MONGO_INITDB_ROOT_PASSWORD" --eval "rs.initiate({_id:'rs0', members:[{_id: 0, host: 'mongo1:27017' }, {_id: 1, host: 'mongo2:27017' }, {_id: 2, host: 'mongo3:27017', arbiterOnly: true}]})" || fatal "Can't create replica cluster"
    sleep 2
    docker exec -t mongo1 mongo "mongodb://mongo1:27017,mongo2:27017,mongo3:27017/?replicaSet=rs0" -u $MONGO_INITDB_ROOT_USERNAME -p $MONGO_INITDB_ROOT_PASSWORD --eval "db=db.getSiblingDB('attachment'); db.createUser({user: 'mongouser', pwd: '$MONGO_USER_PASSWORD', roles: [{role: 'dbOwner', db: 'attachment'}]}); db=db.getSiblingDB('cache'); db.createUser({user: 'mongouser', pwd: '$MONGO_USER_PASSWORD', roles: [{role: 'dbOwner', db: 'cache'}]}); db=db.getSiblingDB('protected_mediacache'); db.createUser({user: 'mongouser', pwd: '$MONGO_USER_PASSWORD', roles: [{role: 'dbOwner', db: 'protected_mediacache'}]})" || fatal "Can't create users in mongo cluster"
  fi
  docker exec -t mongo1 mongo "mongodb://mongo1:27017,mongo2:27017,mongo3:27017/?replicaSet=rs0" -u $MONGO_INITDB_ROOT_USERNAME -p $MONGO_INITDB_ROOT_PASSWORD --eval "rs.status()" || fatal "Error in replication status of mongo cluster"
}

set_parameters_db_mongo_cluster() {
  [ "$#" -ge 1 ] || fatal "No path to application in function set_parameters_db_mongo_cluster"
  grep -q -w 'mongodb_dsn_attachment:' "$1/config/parameters.yml" ||
    cat >>"$1/config/parameters.yml" <<__EOF__
    mongodb_dsn_attachment: "mongodb://mongouser:$MONGO_USER_PASSWORD@mongo1:27017,mongo2:27017/attachment"
    mongodb_dsn_attachment_cache: "mongodb://mongouser:$MONGO_USER_PASSWORD@mongo1:27017,mongo2:27017/cache"
    mongodb_dsn_protected_mediacache: "mongodb://mongouser:$MONGO_USER_PASSWORD@mongo1:27017,mongo2:27017/protected_mediacache"
__EOF__
}

init_db_mongo_cluster() {
  setup_db_mongo_cluster
  set_parameters_db_mongo_cluster "$@"
}

init_php() {
  echo "Setup php $PHP_VER"
  # Build the php config files.
  $SUDO_BIN rm -f "/etc/opt/remi/php$PHP_VER/php-fpm.d"/*
  local TMP_FILE
  TMP_FILE=$(mktemp)
  cat >"$TMP_FILE" <<__EOF__
[oro]
listen = /run/php$PHP_VER-fpm.sock
listen.owner = $USER_RUNTIME
listen.group = $USER_RUNTIME
listen.mode = 0660
user = $USER_RUNTIME
request_slowlog_timeout = 5s
slowlog = /var/opt/remi/php$PHP_VER/log/php-fpm/slow.log
pm = dynamic
pm.max_children = 15
pm.start_servers = 3
pm.min_spare_servers = 2
pm.max_spare_servers = 4
pm.max_requests = 200
listen.backlog = -1
pm.status_path = /status
request_terminate_timeout = 200s
rlimit_files = 131072
rlimit_core = unlimited
catch_workers_output = yes
env[HOSTNAME] = $HOSTNAME
env[TMP] = /tmp
env[TMPDIR] = /tmp
env[TEMP] = /tmp
php_admin_value[memory_limit] = 2048M
__EOF__
  $SUDO_BIN mv -f "$TMP_FILE" "/etc/opt/remi/php$PHP_VER/php-fpm.d/oro.conf"

  cat >"$TMP_FILE" <<__EOF__
error_reporting = E_ALL
display_errors = On
memory_limit=6096M

opcache.enable=1
opcache.enable_cli=0
opcache.memory_consumption=512
opcache.max_accelerated_files=32531
opcache.interned_strings_buffer=32

; http://symfony.com/doc/current/performance.html
realpath_cache_size=4096K
realpath_cache_ttl=600
date.timezone=UTC
__EOF__

  $SUDO_BIN cp -f "$TMP_FILE" "/etc/opt/remi/php$PHP_VER/php.d/oro.ini"

  $SUDO_BIN su - -c "rm -fr /var/opt/remi/php$PHP_VER/log/php-fpm/*"

  #Stop all php-fpm versions
  for service in $(systemctl --no-legend list-unit-files php* | cut -d' ' -f1); do
    $SUDO_BIN systemctl stop "$service"
    $SUDO_BIN systemctl disable "$service"
  done
  # Start php-fpm
  $SUDO_BIN systemctl enable "php$PHP_VER-php-fpm.service"
  $SUDO_BIN systemctl restart "php$PHP_VER-php-fpm.service" || fatal "Can't run php-fpm"
}

init_nginx() {

  init_php "$@" || fatal "Can't setup php"
  local TMP_FILE
  TMP_FILE=$(mktemp)

  # Build the default nginx config files.
  cat >"$TMP_FILE" <<__EOF__
upstream php {
  server unix:/run/php$PHP_VER-fpm.sock;
}
__EOF__
  $SUDO_BIN mv -f "$TMP_FILE" /etc/nginx/conf.d/upstream.conf

  grep -q fastcgi_split_path_info /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_split_path_info             ^(.+\.php)(.*)$;' >>/etc/nginx/fastcgi_params"
  grep -q 'fastcgi_param  PATH_INFO' /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_param  PATH_INFO            \$fastcgi_path_info;' >>/etc/nginx/fastcgi_params"
  grep -q fastcgi_ignore_client_abort /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_ignore_client_abort         off;' >>/etc/nginx/fastcgi_params"
  grep -q fastcgi_connect_timeout /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_connect_timeout             60;' >>/etc/nginx/fastcgi_params"
  grep -q fastcgi_send_timeout /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_send_timeout                1800;' >>/etc/nginx/fastcgi_params"
  grep -q fastcgi_read_timeout /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_read_timeout                1800;' >>/etc/nginx/fastcgi_params"
  grep -q fastcgi_buffer_size /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_buffer_size                 128k;' >>/etc/nginx/fastcgi_params"
  grep -q fastcgi_buffers /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_buffers                     4 256k;' >>/etc/nginx/fastcgi_params"
  grep -q fastcgi_busy_buffers_size /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_busy_buffers_size           256k;' >>/etc/nginx/fastcgi_params"
  grep -q fastcgi_temp_file_write_size /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_temp_file_write_size        256k;' >>/etc/nginx/fastcgi_params"
  grep -q fastcgi_keep_conn /etc/nginx/fastcgi_params || $SUDO_BIN bash -c "echo 'fastcgi_keep_conn                   on;' >>/etc/nginx/fastcgi_params"

  $SUDO_BIN su - -c "rm -f /etc/nginx/conf.d/site*"
  $SUDO_BIN su - -c "rm -f /var/log/nginx/*site${EXECUTOR_NUMBER}*"

  # Start nginx.
  $SUDO_BIN systemctl enable "nginx.service"
  $SUDO_BIN systemctl restart "nginx.service" || fatal "Can't run nginx.service"

}

create_ssl_certificate() {
  local CERT_FOLDER=${1-/etc/pki/nginx}
  local CERT_NAME=${2-localhost}
  local KEY_NAME=${3-localhost}
  $SUDO_BIN mkdir -p "$CERT_FOLDER"
  if [[ -e "$CERT_FOLDER/$KEY_NAME.key" && -e "$CERT_FOLDER/$CERT_NAME.cert" ]]; then
    echo "Certificate and key exist"
  else
    echo "Generate self signet certificate and key"
    $SUDO_BIN openssl req -new -newkey rsa:4096 -days 365 -nodes -x509 -subj "/C=US/ST=CA/L=Los Angeles/O=ORO Inc/OU=Org/CN=localhost" -keyout "$CERT_FOLDER/$KEY_NAME.key" -out "$CERT_FOLDER/$CERT_NAME.cert"
  fi
}

install_ssl_certificate() {
  local CERT_FOLDER=${1-/etc/pki/nginx}
  local CERT_NAME=${2-dev.oroinc.com}
  local KEY_NAME=${3-dev.oroinc.com}
  $SUDO_BIN mkdir -p "$CERT_FOLDER"
  [ -e "$CERT_FOLDER/$KEY_NAME.key" ] || $SUDO_BIN cp "$DIRNAME/.jenkins/ssl/dev.oroinc.com.key" "$CERT_FOLDER/$KEY_NAME.key"
  [ -e "$CERT_FOLDER/$KEY_NAME.crt" ] || $SUDO_BIN cp "$DIRNAME/.jenkins/ssl/dev.oroinc.com.crt" "$CERT_FOLDER/$KEY_NAME.crt"
}

make_host() {
  HOST_NUMBER=${1-0}
  ROOT=${2-$DIRNAME/${APPLICATION}${HOST_NUMBER}}
  HOST_ADDRES=${3-127.0.0.1}
  install_ssl_certificate "/etc/pki/nginx" "dev.oroinc.com" "dev.oroinc.com"
  local PORT=$((8000 + HOST_NUMBER))
  local TMP_FILE
  TMP_FILE=$(mktemp)
  cat >"$TMP_FILE" <<__EOF__
server {
    listen $HOST_ADDRES:$PORT default_server ssl http2;
    server_name _;
    root ${ROOT}/public;
    ssl on;
    ssl_certificate /etc/pki/nginx/dev.oroinc.com.crt;
    ssl_certificate_key /etc/pki/nginx/dev.oroinc.com.key;
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDH+AESGCM:ECDH+AES256:ECDH+AES128:DH+3DES:!ADH:!AECDH:!MD5;
    # Optimize session cache
    ssl_session_cache   shared:SSL:40m;
    ssl_session_timeout 4h;
    # Enable session tickets
    ssl_session_tickets on;

    access_log /var/log/nginx/access_site${HOST_NUMBER}.log;
    error_log /var/log/nginx/error_site${HOST_NUMBER}.log;
    types_hash_max_size 2048;
    client_max_body_size 512m;
    client_body_buffer_size 1m;
    fastcgi_connect_timeout       900s;
    fastcgi_read_timeout          900s;
    fastcgi_send_timeout          900s;
    send_timeout                900s;
    gzip_proxied any;
    gzip_types text/plain text/xml text/css application/javascript application/json;
    gzip_vary on;
    index index.php;
    try_files \$uri \$uri/ @rewrite;
    location @rewrite {
        rewrite ^/(.*)\$ /index.php/\$1;
    }
    location ~ /\.ht {
        deny all;
    }
    location ~* ^[^(\.php)]+\.(jpg|jpeg|gif|png|ico|css|pdf|ppt|txt|bmp|rtf|js)$ {
        # access_log off;
    }
    location ~ [^/]\.php(/|\$) {
        fastcgi_split_path_info ^(.+?\.php)(/.*)\$;
        if (!-f \$document_root\$fastcgi_script_name) {
            return 404;
        }
        include                         fastcgi_params;
        fastcgi_pass                    php;
        fastcgi_index                   index.php;
        fastcgi_intercept_errors        on;
        fastcgi_param  SCRIPT_FILENAME  \$document_root\$fastcgi_script_name;
        fastcgi_param  PATH_INFO        \$fastcgi_path_info;
    }
}
__EOF__

  $SUDO_BIN mv -f "$TMP_FILE" "/etc/nginx/conf.d/site${HOST_NUMBER}.conf"
  $SUDO_BIN rm -f "/etc/nginx/conf.d/default" || :
  $SUDO_BIN rm -f "/var/log/nginx/"*"site$EXECUTOR_NUMBER.log"*
  $SUDO_BIN gpasswd -a nginx docker
  $SUDO_BIN systemctl restart "nginx.service" || fatal "Can't restart nginx.service"
  $SUDO_BIN bash -c ": > /var/log/nginx/access_site${HOST_NUMBER}.log"
  $SUDO_BIN bash -c ": > /var/log/nginx/error_site${HOST_NUMBER}.log"

}

install_composer() {
  if [ ! -x "/usr/local/bin/composer" ]; then
    echo "install composer"

    EXPECTED_SIGNATURE="$(wget -q -O - https://composer.github.io/installer.sig)"
    php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
    ACTUAL_SIGNATURE="$(php -r "echo hash_file('SHA384', 'composer-setup.php');")"

    if [ "$EXPECTED_SIGNATURE" != "$ACTUAL_SIGNATURE" ]; then
      echo >&2 'ERROR: Invalid installer signature'
      rm composer-setup.php
      exit 1
    fi
    php composer-setup.php --quiet
    RESULT=$?
    rm composer-setup.php
    ln -fs composer.phar composer
    $SUDO_BIN bash -c "cp -rf composer.phar composer /usr/local/bin/"
    return $RESULT
  fi
}

init_composer() {
  install_composer
  [[ $TOKEN ]] && COMPOSER_HOME=$SET_COMPOSER_HOME composer config -g github-oauth.github.com "$TOKEN"
  [[ $TOKEN_GITLAB ]] && COMPOSER_HOME=$SET_COMPOSER_HOME composer config -g gitlab-oauth.git.oroinc.com "$TOKEN_GITLAB"
  local COMPOSER=${2-composer.json}
  [[ $3 ]] && export COMPOSER_ROOT_VERSION="${3}"
  #install parallel plugin
  echo "time COMPOSER_HOME=$SET_COMPOSER_HOME composer global require hirak/prestissimo symfony/flex"
  time COMPOSER_HOME=$SET_COMPOSER_HOME composer global require hirak/prestissimo symfony/flex || fatal "Can't install hirak/prestissimo symfony/flex"

  echo "time COMPOSER_HOME=$SET_COMPOSER_HOME COMPOSER=$COMPOSER COMPOSER_MIRROR_PATH_REPOS=1 composer install --prefer-dist --no-suggest --optimize-autoloader --no-interaction --working-dir=\"$1\""
  time COMPOSER_HOME=$SET_COMPOSER_HOME COMPOSER=$COMPOSER COMPOSER_MIRROR_PATH_REPOS=1 composer install --prefer-dist --no-suggest --optimize-autoloader --no-interaction --working-dir="$1" || fatal "Can't install $1/$COMPOSER"
}

validate_composer() {
  install_composer
  [[ $TOKEN ]] && COMPOSER_HOME=$SET_COMPOSER_HOME composer config -g github-oauth.github.com "$TOKEN"
  [[ $TOKEN_GITLAB ]] && COMPOSER_HOME=$SET_COMPOSER_HOME composer config -g gitlab-oauth.git.oroinc.com "$TOKEN_GITLAB"
  echo "time COMPOSER_HOME=$SET_COMPOSER_HOME composer -v validate \"$1/dev.json\" --no-check-all --no-check-publish --working-dir=\"$1\""
  time COMPOSER_HOME=$SET_COMPOSER_HOME composer -v validate "$1/dev.json" --no-check-all --no-check-publish --working-dir="$1" || fatal "Can't validate $1/dev.json"
  echo "time COMPOSER_HOME=$SET_COMPOSER_HOME composer -v validate \"$1/composer.json\" --no-check-lock --no-check-all --no-check-publish --working-dir=\"$1\""
  time COMPOSER_HOME=$SET_COMPOSER_HOME composer -v validate "$1/composer.json" --no-check-lock --no-check-all --no-check-publish --working-dir="$1" || fatal "Can't validate $1/composer.json"
}

update_composer() {
  install_composer
  [[ $TOKEN ]] && COMPOSER_HOME=$SET_COMPOSER_HOME composer config -g github-oauth.github.com "$TOKEN"
  [[ $TOKEN_GITLAB ]] && COMPOSER_HOME=$SET_COMPOSER_HOME composer config -g gitlab-oauth.git.oroinc.com "$TOKEN_GITLAB"
  echo "composer -v update --prefer-dist --no-dev --optimize-autoloader --no-interaction --working-dir=\"$1\""
  COMPOSER_HOME=$SET_COMPOSER_HOME composer -v update --prefer-dist --no-dev --optimize-autoloader --no-interaction --working-dir="$1"
}

#legacy not used
install_chromedriver() {
  echo "Install chromedriver"
  CHROME_DRIVER_VERSION=$(curl -sS chromedriver.storage.googleapis.com/LATEST_RELEASE)
  CURRENT_CHROME_DRIVER_VERSION=$(chromedriver --version)
  CURRENT_CHROME_DRIVER_VERSION=${CURRENT_CHROME_DRIVER_VERSION:12:5}
  if [ "X${CURRENT_CHROME_DRIVER_VERSION}" != "X${CHROME_DRIVER_VERSION}" ]; then
    mkdir -p "$HOME/chrome" || true
    wget "http://chromedriver.storage.googleapis.com/${CHROME_DRIVER_VERSION}/chromedriver_linux64.zip" \
      -O "$HOME/chrome/chromedriver_linux64_${CHROME_DRIVER_VERSION}.zip"
    unzip "$HOME/chrome/chromedriver_linux64_${CHROME_DRIVER_VERSION}.zip" -d "$HOME/chrome"
    $SUDO_BIN mv -f "$HOME/chrome/chromedriver" /usr/local/bin/chromedriver
    $SUDO_BIN chown root:root /usr/local/bin/chromedriver
    $SUDO_BIN chmod 0755 /usr/local/bin/chromedriver
  fi

  chromedriver --version | grep "${CHROME_DRIVER_VERSION}"
}

init_chromedriver() {
  local CHROMEDRIVER=/usr/bin/chromedriver
  [ -e /usr/local/bin/chromedriver ] && CHROMEDRIVER=/usr/local/bin/chromedriver
  # LOG_DIR="/var/www/ovfs-mnt_0/application/commerce-crm-ee/var/logs/cromdriver"
  # $SUDO_BIN rm -rf "$LOG_DIR"
  # $SUDO_BIN mkdir -p "$LOG_DIR"
  # $SUDO_BIN chown -R $USER_RUNTIME:$USER_RUNTIME "$LOG_DIR"

  echo "Run browser"
  $SUDO_BIN systemctl -q is-active "browser_$EXECUTOR_NUMBER_S1".service ||
    $SUDO_BIN systemd-run --unit="browser_$EXECUTOR_NUMBER_S1" -p User="$USER_RUNTIME" \
      --setenv="DBUS_SESSION_BUS_ADDRESS='unix:path=/var/run/dbus/system_bus_socket'" \
      $CHROMEDRIVER --port=$PORT_S1
  # --verbose
  # --log-path="$LOG_DIR/session_${EXECUTOR_NUMBER_S1}_driver_$EXECUTOR_NUMBER.log"
  # --env="CHROME_LOG_FILE=/var/log/cromdriver/session_${EXECUTOR_NUMBER_S1}_browser_$EXECUTOR_NUMBER.log" -- \
}

get_env_spec() {
  echo "Environment specifications:"
  echo "========================="
  uname -a
  ulimit -a
  [ -x /usr/local/bin/composer ] && /usr/local/bin/composer --version
  [ -x /usr/local/bin/chromedriver ] && /usr/local/bin/chromedriver --version
  echo "RPMs:"
  rpm -qa | grep "nginx\|php$PHP_VER\|google-chrome\|parallel\|docker\|nodejs" | sort
  echo "========================="
  echo "Services version:"
  [[ "X$DB" == 'XPG' ]] && echo "PostgreSQL: $PG_VER"
  [[ "X$DB" == 'XMYSQL' ]] && echo "MySQL: $MYSQL_VER"
  [[ "X$SE" == 'XES' ]] && echo "Elasticsearch: $ES_VER"
  [[ "X$CACHE" == 'XREDIS' || "X$CACHE" == 'XREDIS_CLUSTER' ]] && echo "Redis: $REDIS_VER"
  [[ "X$CE" == 'XRMQ' ]] && echo "RMQ: $RMQ_VER"
  [[ "X$STORAGE" == 'XMONGO_CLUSTER' ]] && echo "Percoma mongo: $MONGO_VER"
  echo "========================="
}

get_env_spec_docker() {
  echo "========================="
  echo "Services in docker:"
  [[ "X$DB" == 'XPG' ]] && docker exec -t pgsql psql --version
  [[ "X$DB" == 'XMYSQL' ]] && docker exec -t mysql mysql --version
  [[ "X$SE" == 'XES' ]] && echo -n "Elasticsearch " && docker exec -t elasticsearch elasticsearch --version
  [[ "X$CACHE" == 'XREDIS' || "X$CACHE" == 'XREDIS_CLUSTER' ]] && docker exec -t redis redis-cli --version
  [[ "X$CE" == 'XRMQ' ]] && echo -n "RMQ version: " && docker exec -t rabbitmq rabbitmqctl version
  [[ "X$STORAGE" == 'XMONGO_CLUSTER' ]] && docker exec -t mongo1 mongo --version | head -n 1
  echo "========================="
}

usage() {
  [ -z "$*" ] || echo "$*"
  echo "Try \`$PROGNAME --help' for more information." >&2
  exit 1
}

get_env_id() {
  DIVIDER=${1-_}
  ENV_ID="$ORO_TEST_SUITE"
  if [[ "X$APPLICATION" != "X" ]]; then
    # shellcheck disable=SC2001
    ENV_ID="$ENV_ID${DIVIDER}$(echo "$APPLICATION" | sed 's|^.*/||g')"
  fi
  if [[ "X$CS" != "X" ]]; then
    ENV_ID="$ENV_ID${DIVIDER}CS-$CS"
  fi
  if [[ "X$PHP_VER" != "X" ]]; then
    ENV_ID="$ENV_ID${DIVIDER}PHP-$PHP_VER"
  fi
  if [[ "X$NODEJS_VER" != "X" ]]; then
    ENV_ID="$ENV_ID${DIVIDER}NODEJS-$NODEJS_VER"
  fi
  if [[ "X$DB" != "X" ]]; then
    case ${DB} in
    MYSQL)
      ENV_ID="$ENV_ID${DIVIDER}MySQL"
      if [[ "X$MYSQL_VER" != "X" ]]; then
        ENV_ID="$ENV_ID-$MYSQL_VER"
      fi
      ;;
    PG)
      ENV_ID="$ENV_ID${DIVIDER}PgSQL"
      if [[ "X$PG_VER" != "X" ]]; then
        ENV_ID="$ENV_ID-$PG_VER"
      fi
      ;;
    esac
  fi
  if [[ "X$SE" != "X" ]]; then
    ENV_ID="$ENV_ID${DIVIDER}$SE"
    case ${SE} in
    ES)
      if [[ "X$ES_VER" != "X" ]]; then
        ENV_ID="$ENV_ID-$ES_VER"
      fi
      ;;
    esac
  fi
  if [[ "X$CE" != "X" ]]; then
    ENV_ID="$ENV_ID${DIVIDER}$CE"
    case ${CE} in
    RMQ)
      if [[ "X$RMQ_VER" != "X" ]]; then
        ENV_ID="$ENV_ID-$RMQ_VER"
      fi
      ;;
    esac
  fi
  if [[ "X$CACHE" != "X" ]]; then
    ENV_ID="$ENV_ID${DIVIDER}$CACHE"
    case ${CACHE} in
    REDIS)
      if [[ "X$REDIS_VER" != "X" ]]; then
        ENV_ID="$ENV_ID-$REDIS_VER"
      fi
      ;;
    esac
  fi
  if [[ "X$ORO_STORAGE" != "X" ]]; then
    ENV_ID="$ENV_ID${DIVIDER}$ORO_STORAGE"
  fi

  if [[ "X$ORO_INSTALLED" != "X" ]]; then
    ENV_ID="$ENV_ID${DIVIDER}UPG-$(echo "$ORO_INSTALLED" | cut -d'_' -f2)"
  fi
  if [[ "X$TEST_RUNNER_OPTIONS" != "X" ]]; then
    ENV_ID="$ENV_ID${DIVIDER}$(echo "$TEST_RUNNER_OPTIONS" | cut -d'=' -f2)"
  fi
  if [[ "X$XSS_TEST" == "Xyes" ]]; then
    if [[ "X$XSS_PAYLOAD_TYPE" != "X" ]]; then
      ENV_ID="$ENV_ID${DIVIDER}XSS-$XSS_PAYLOAD_TYPE"
    fi
  fi
  # if [[ "X$BEHAT_TAGS" != "X" ]]; then
  #   ENV_ID="$ENV_ID${DIVIDER}BEHAT_TAGS-$BEHAT_TAGS"
  # fi

  # ENV_ID=${ENV_ID//./$DIVIDER}
  echo "$ENV_ID"
}

add_root_node() {
  ENV_ID=$(get_env_id '_')
  echo "Add $ENV_ID root node to junit report"
  $SUDO_BIN find -L "$1" -name "$2" -exec sed -i -e "s/<testsuite name=\"/<testsuite name=\"${ENV_ID}./g" "{}" \;
}

add_exclude_group() {
  local PHPUNIT_XML GROUP G
  PHPUNIT_XML=${2-phpunit.xml.dist}
  GROUP=$1
  for G in $(echo $GROUP | sed 's/,/ /g'); do
    sed -n '/<groups>/, /<\/exclude>/p' "$PHPUNIT_XML" | grep -q "$G" && {
      echo "Found exclude group $G. Skip it"
      continue
    }
    echo "Add $G to exclude group"
    sed -i '/<groups>/{N
    /\n.*<exclude>/a \
	    <group>'"$G"'</group>
    }' "$PHPUNIT_XML" || fatal "Can't add excluded groiups to $PHPUNIT_XML"
  done
}

install_demo_bandles() {
  local APP_DIR=$1
  local APP_FIXTURES=$2
  local COMPOSER=${3-composer.json}
  local DEMO DEMO_VER
  echo "APP_FIXTURES=$APP_FIXTURES"
  set -x
  if [[ "X$APP_FIXTURES" == "X" ]]; then
    echo "No app fixtures. Skip demo bandles installation"
    return 0
  elif [[ "X$APP_FIXTURES" == "Xdemo" ]]; then
    DEMO=COMMERCE
    DEMO_VER=$COMMERCE_DEMO
  elif [[ "X$APP_FIXTURES" != "Xdemo" ]]; then
    DEMO=CRM
    export DEMO_VER=$CRM_DEMO
  fi

  local DEMO_COMPOSER="DEMO_COMPOSER_$DEMO"
  time COMPOSER=$COMPOSER COMPOSER_MIRROR_PATH_REPOS=1 php -dmemory_limit=-1 /usr/local/bin/composer require "${!DEMO_COMPOSER}" --no-suggest --optimize-autoloader --no-interaction --working-dir="$APP_DIR" -v || return 1

  if [[ "X$DEMO" == "XCRM" ]]; then
    # composer config repositories.crm-pro-demo-data-bundle vcs "https://github.com/oroinc/OroCRMProDemoDataBundle" --working-dir="$APP_DIR" || return 1
    time COMPOSER=$COMPOSER COMPOSER_MIRROR_PATH_REPOS=1 php -dmemory_limit=-1 /usr/local/bin/composer require oro/crm-magento1-connector "oro/crm-pro-demo-data-bundle$CRM_PRO_DEMO_DATA_BUNDLE" --no-suggest --optimize-autoloader --no-interaction --working-dir="$APP_DIR" -v || return 1
  fi
  set +x
}

demo_data_load() {
  local APP_DIR=$1
  local APP_FIXTURES=$2
  echo "APP_FIXTURES=$APP_FIXTURES"
  set -x
  if [[ "X$APP_FIXTURES" == "X" ]]; then
    echo "No app fixtures. Skip demo data load"
    return 0
  elif [[ "X$APP_FIXTURES" == "Xdemo" ]]; then
    time php "$APP_DIR/bin/console" oro:migration:data:load --fixtures-type=demo --env=prod -vvv || return 1
    # reindex is needed to run manually after loading fixture
    time php "$APP_DIR/bin/console" oro:website-search:reindex --env=prod || return 1
  elif [[ "X$APP_FIXTURES" != "Xdemo" ]]; then
    time php "$APP_DIR/bin/console" oro:migration:live:demo:data:load --fixtures-type="$APP_FIXTURES" --env=prod --force -vvv || return 1
  fi
  # reindex is needed to run manually after loading fixture
  time php "$APP_DIR/bin/console" oro:search:reindex --env=prod || return 1
  set +x
}

demo_data_clean() {
  local APP_DIR=$1
  local APP_FIXTURES=$2
  echo "APP_FIXTURES=$APP_FIXTURES"
  set -x
  if [[ "X$APP_FIXTURES" == "X" ]]; then
    echo "No app fixtures. Skip demo data load"
    return 0
  elif [[ "X$APP_FIXTURES" == "Xdemo" ]]; then
    time php "$APP_DIR/bin/console" oro:migration:data:load --env=prod --clean -vvv || return 1
    # reindex is needed to run manually after loading fixture
    time php "$APP_DIR/bin/console" oro:website-search:reindex --env=prod || return 1
    # elif [[ "X$APP_FIXTURES" != "Xdemo" ]]; then
    #   time php "$APP_DIR/bin/console" oro:migration:live:demo:data:load --env=prod --clean -vvv || return 1
  fi
  # reindex is needed to run manually after loading fixture
  time php "$APP_DIR/bin/console" oro:search:reindex --env=prod || return 1
  set +x
}
