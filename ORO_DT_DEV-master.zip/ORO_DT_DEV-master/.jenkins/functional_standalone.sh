#!/bin/bash

PROGNAME="${0##*/}"
DIRNAME=$(realpath "$(dirname "$0")")
DEBUG="${DEBUG-}"

TITLE='Copyright 2017 by ORO, Inc.'
USER=$(whoami)

EXECUTOR_NUMBER=${EXECUTOR_NUMBER-0}
[[ $EXECUTOR_NUMBER =~ ^[0-9]{1}$ ]] || fatal 'Not correct EXECUTOR_NUMBER'
PARALLEL_PROCESSES=${PARALLEL_PROCESSES-2}
RUN_INSTALL=yes
RUN_TEST=yes
export SYMFONY_ENV=test
export SYMFONY_DEBUG=0

ORO_APP_TAG="${ORO_APP_TAG-'master'}"
TESTS_LIST=$TESTS_LIST
EXCLUDE_GROUP=$EXCLUDE_GROUP
# shellcheck disable=SC2034
PHP_VER="${ORO_PHP-74}"
PG_VER="${ORO_PG-9.6.20}"
MYSQL_VER="${ORO_MYSQL-5.7.32}"
ES_VER="${ORO_ES-7.9.3}"
REDIS_VER="${ORO_REDIS-5.0.10}"
RMQ_VER="${ORO_RMQ-3.8.9}"
MONGO_VER="${ORO_MONGO-4.4.2}"
NODEJS_VER="${ORO_NODEJS-14}"

# shellcheck disable=SC2034
DB="${ORO_DB-PG}"
SE="${ORO_SE-ES}"
# shellcheck disable=SC2034
CE="${ORO_CE-DBAL}"
# shellcheck disable=SC2034
CACHE="${ORO_CACHE-}"
HTTP_HOST="${HTTP_HOST-http://localhost/}"
dbname=${DB_NAME:-oro_$EXECUTOR_NUMBER}

# shellcheck disable=SC1091
# shellcheck source=.jenkins/common_functions.sh
. "$DIRNAME/common_functions.sh"

run() {
  local RETVAL
  get_env_spec
  echo "Run $TESTENV"
  # ulimit -n 20480
  if [[ "X$RUN_INSTALL" == 'Xyes' && "$BUILD_ID" ]]; then
    prepare_instance_bind "$(realpath "$DIRNAME/..")" "${EXECUTOR_NUMBER}_1"
  else
    prepare_instance "$(realpath "$DIRNAME/..")" "${EXECUTOR_NUMBER}_1"
  fi

  APP_ROOT="/var/www/ovfs-mnt_${EXECUTOR_NUMBER}_1"
  echo "APP_ROOT=$APP_ROOT"
  trap 'collect_logs "$APP_ROOT/var/logs"' EXIT INT TERM

  init_php || return 1
  if [[ "X$RUN_INSTALL" == 'Xyes' ]]; then
    init_composer "$APP_ROOT"
    cp -f "$APP_ROOT/config/parameters_test.yml.dist" "$APP_ROOT/config/parameters.yml"
  fi
  PHP_VER="$PHP_VER" PG_VER="$PG_VER" MYSQL_VER="$MYSQL_VER" MYSQL_DOCKER_VER="$MYSQL_DOCKER_VER" ES_VER="$ES_VER" REDIS_VER="$REDIS_VER" RMQ_VER="$RMQ_VER" DB="$DB" SE="$SE" CE="$CE" CACHE="$CACHE" \
    APP_DIR="$APP_ROOT" dbname=${dbname}_1 SHARD_PRICES=$SHARD_PRICES EXECUTOR_NUMBER=$EXECUTOR_NUMBER \
    LANG="$LANG" LC_CTYPE="$LC_CTYPE" index_name="${EXECUTOR_NUMBER}_1" \
    time parallel --tagstring {} --no-notice --gnu -k --lb -j 4 --env _ "$DIRNAME/run_services.sh -t" ::: DB SE CE CACHE
  RETVAL=$?
  [ $RETVAL -eq 0 ] || fatal "ERROR to run services"

  if [[ "X$RUN_INSTALL" == 'Xyes' ]]; then
    if [ -n "$ORO_INSTALLED" ]; then
      echo "Restore DB ${ORO_INSTALLED}..."
      case ${DB} in
      MYSQL)
        load_db "/var/www/ovfs-mnt_${EXECUTOR_NUMBER}_1/environment/mysql/dumps/${ORO_INSTALLED}.mysql.sql.gz" "${dbname}_1"
        ;;
      PG)
        load_db "/var/www/ovfs-mnt_${EXECUTOR_NUMBER}_1/environment/pgsql/dumps/${ORO_INSTALLED}.pgsql.sql.gz" "${dbname}_1"
        ;;
      esac
      INSTALLED_DATE=$(date --rfc-3339=seconds)
      sed -i "s/installed:.*/installed: '${INSTALLED_DATE}'/g" "$APP_ROOT/config/parameters.yml"
    fi

    cp -f "$APP_ROOT/config/parameters.yml" "$APP_ROOT/config/parameters_test.yml"

    set_permission "$APP_ROOT"
    enable_permission_installer "$APP_ROOT"

    if [ -n "$ORO_INSTALLED" ]; then
      echo "Exist ${ORO_INSTALLED}..."
      if [ -n "$UPGRADE" ]; then
        echo "sudo_scl time php \"$APP_ROOT/bin/console\" oro:platform:upgrade20 --env=test --force --no-interaction --skip-assets --timeout=600 --skip-translations"
        sudo_scl "time php \"$APP_ROOT/bin/console\" oro:platform:upgrade20 --env=test --force --no-interaction --skip-assets --timeout=600 --skip-translations" || fatal "ERROR to run console oro:platform:upgrade20"
      else
        echo "sudo_scl time php \"$APP_ROOT/bin/console\" oro:platform:update --env=test --force --no-interaction --skip-assets --timeout=600 --skip-translations"
        sudo_scl "time php \"$APP_ROOT/bin/console\" oro:platform:update --env=test --force --no-interaction --skip-assets --timeout=600 --skip-translations" || fatal "ERROR to run console oro:platform:update"
      fi
      echo "sudo_scl time php \"$APP_ROOT/bin/console\" oro:config:update --env=test oro_ui.application_url \"${HTTP_HOST}\""
      sudo_scl "time php \"$APP_ROOT/bin/console\" oro:config:update --env=test oro_ui.application_url \"${HTTP_HOST}\"" || fatal "ERROR to run console oro:config:update"
      echo "sudo_scl time  php \"$APP_ROOT/bin/console\" oro:config:update --env=test oro_website.url \"${HTTP_HOST}\""
      sudo_scl "time php \"$APP_ROOT/bin/console\" oro:config:update --env=test oro_website.url \"${HTTP_HOST}\"" || fatal "ERROR to run console oro:config:update"
      echo "sudo_scl time php \"$APP_ROOT/bin/console\" oro:config:update --env=test oro_website.secure_url \"${HTTP_HOST}\""
      sudo_scl "time php \"$APP_ROOT/bin/console\" oro:config:update --env=test oro_website.secure_url \"${HTTP_HOST}\"" || fatal "ERROR to run console oro:config:update"
    else
      #console installer
      echo "sudo_scl time php \"$APP_ROOT/bin/console\" oro:install --env=test --skip-translations --user-name=admin --user-email=admin@example.com --user-firstname=John --user-lastname=Doe --user-password=admin --sample-data=n --organization-name=Oro --no-interaction --application-url=\"${HTTP_HOST}\" --skip-assets --timeout 600 $INSTALLER_LOCALE"
      sudo_scl "time php \"$APP_ROOT/bin/console\" oro:install --env=test --skip-translations --user-name=admin --user-email=admin@example.com --user-firstname=John --user-lastname=Doe --user-password=admin --sample-data=n --organization-name=Oro --no-interaction --application-url=\"${HTTP_HOST}\" --skip-assets --timeout 600 $INSTALLER_LOCALE" || fatal "ERROR to run console installation"
    fi

    pushd "$APP_ROOT"
    disable_permission_installer "$APP_ROOT"
    echo "sudo_scl time php \"$APP_ROOT/bin/phpunit\" -c \"$APP_ROOT\" --testsuite=dt-functional --group=schema --colors=always --log-junit=\"$APP_ROOT/var/logs/junit/functional.schema.xml\""
    sudo_scl "time php \"$APP_ROOT/bin/phpunit\" -c \"$APP_ROOT\" --testsuite=dt-functional --group=schema --colors=always --log-junit=\"$APP_ROOT/var/logs/junit/functional.schema.xml\""
    RETVAL=$?
    add_root_node "$APP_ROOT/var/logs/junit/" "functional.schema.xml"
    [ $RETVAL -eq 0 ] || fatal "ERROR to run phpunit"
    popd

    dump_db "$APP_ROOT/db.sql" "${dbname}_1"
    unset_permission "$APP_ROOT"

  fi

  if [[ "X$RUN_TEST" == 'Xyes' ]]; then
    load_db "$APP_ROOT/db.sql" "${dbname}_1"
    reindex_se "$APP_ROOT" "${EXECUTOR_NUMBER}_1" "_test"

    echo "TEST_RUNNER_OPTIONS=$TEST_RUNNER_OPTIONS"
    if [[ ! "$TEST_RUNNER_OPTIONS" =~ --group.*dist ]]; then

      echo "List of tests :"
      if [[ "X$TESTS_LIST" != "X" ]]; then
        : >"$APP_ROOT/var/logs/tests_list.log"
        for l in $TESTS_LIST; do
          echo "$l"
          echo "$l" | sed "s/^'//g; s/'$//g" >>"$APP_ROOT/var/logs/tests_list.log"
        done
      else
        pushd "$APP_ROOT"
        find -L src -type d -ipath "**tests/functional" | uniq | sort | tee -a "$APP_ROOT/var/logs/tests_list.log"
        popd
      fi

      local NUM_TESTS
      NUM_TESTS=$(wc -l <"$APP_ROOT/var/logs/tests_list.log")

      if [ "$NUM_TESTS" -lt "$PARALLEL_PROCESSES" ]; then
        echo "Reduce PARALLEL_PROCESSES to $NUM_TESTS"
        PARALLEL_PROCESSES=$NUM_TESTS
      fi

      if [ "X$EXCLUDE_GROUP" != "X" ]; then
        add_exclude_group "$EXCLUDE_GROUP" "$APP_ROOT/phpunit.xml.dist"
      fi

      echo "Cloning environment in $PARALLEL_PROCESSES ..."
      local DIR_TMP DIR_MNT
      for i in $(seq 2 "$PARALLEL_PROCESSES"); do
        DIR_TMP="/var/www/ovfs-tmp_${EXECUTOR_NUMBER}_$i"
        DIR_MNT="/var/www/ovfs-mnt_${EXECUTOR_NUMBER}_$i"
        echo "Copy to $DIR_TMP"
        cp -r "/var/www/ovfs-tmp_${EXECUTOR_NUMBER}_1" "$DIR_TMP"
        prepare_instance "$(realpath "$DIRNAME/..")" "${EXECUTOR_NUMBER}_$i"
      done

      for i in $(seq 2 "$PARALLEL_PROCESSES"); do
        DIR_MNT="/var/www/ovfs-mnt_${EXECUTOR_NUMBER}_$i"
        echo "Change ath, DB name (${dbname}_${i}) in cache $DIR_MNT"
        find "$DIR_MNT/var/cache" -type f -print0 | xargs -0 sed -i "s/ovfs-mnt_${EXECUTOR_NUMBER}_1/ovfs-mnt_${EXECUTOR_NUMBER}_$i/g; s/${dbname}_1/${dbname}_$i/g"
        sed -i "s/database_name:.*/database_name: ${dbname}_$i/g" "$DIR_MNT/config/parameters_test.yml"
        load_db "$APP_ROOT/db.sql" "${dbname}_${i}"
        if [[ "X$CE" == 'XRMQ' ]]; then
          setup_ce_rmq "$DIR_MNT" "${dbname}_$i"
        fi
        if [[ "X$SE" == 'XES' ]]; then
          FILES_TO_UPDATE="$DIR_MNT/var/cache/test/Container*/srcAppKernelTestContainer.php $DIR_MNT/var/cache/test/Container*/getOroElasticsearch_Client_FactoryService.php"
          for file in $FILES_TO_UPDATE; do
            sed -i "s/oro_search_test_es_index_${EXECUTOR_NUMBER}_1/oro_search_test_es_index_${EXECUTOR_NUMBER}_$i/g; s/oro_website_search_test_es_index_${EXECUTOR_NUMBER}_1/oro_website_search_test_es_index_${EXECUTOR_NUMBER}_$i/g" $file
          done
          setup_se_elastic "$DIR_MNT" "${EXECUTOR_NUMBER}_$i" "_test"
        fi
        sleep 4
        reindex_se "$DIR_MNT" "${EXECUTOR_NUMBER}_$i" "_test"
        set_permission "$DIR_MNT"
      done

      #    echo "time php \"$APP_ROOT/bin/phpunit\" -c \"$APP_ROOT\" --testsuite=dt-functional --colors=always"
      #    time php "$APP_ROOT/bin/phpunit" -c "$APP_ROOT" --testsuite=dt-functional --colors=always || fatal "ERROR to run phpunit"

      mkdir -p "$APP_ROOT/var/logs/junit"
      set_permission "$APP_ROOT"

      pushd "$APP_ROOT"
      # shellcheck disable=SC2097,2098,2016
      APP_ROOT=$APP_ROOT EXECUTOR_NUMBER=$EXECUTOR_NUMBER TEST_RUNNER_OPTIONS=$TEST_RUNNER_OPTIONS \
        sudo_scl "mkdir -p ~/.parallel && parallel --record-env && time parallel --no-notice --gnu -k --lb --env _ --joblog \"$APP_ROOT/var/logs/parallel.log\" -j \"${PARALLEL_PROCESSES}\" -a \"$APP_ROOT/var/logs/tests_list.log\" \
        'cd /var/www/ovfs-mnt_${EXECUTOR_NUMBER}_{%}; php bin/phpunit --testsuite=dt-functional {} --colors=always $TEST_RUNNER_OPTIONS --log-junit=/var/www/ovfs-mnt_${EXECUTOR_NUMBER}_1/var/logs/junit/functional_{= s/\//_/g =}_{#}.xml'"
      RETVAL=$?
      add_root_node "/var/www/ovfs-mnt_${EXECUTOR_NUMBER}_1/var/logs/junit" "*.xml"
      [ $RETVAL -eq 0 ] || fatal "ERROR to run phpunit"
      popd

      #Collect logs
      for i in $(seq 2 "$PARALLEL_PROCESSES"); do
        DIR_MNT="/var/www/ovfs-mnt_${EXECUTOR_NUMBER}_$i"
        sudo_scl "cp -f \"$DIR_MNT/var/logs/test.log\" \"$APP_ROOT/var/logs/test${i}.log\" ||:"
      done

      unset_permission "$APP_ROOT"

      echo "Generate statistics to $APP_ROOT/var/logs/stats.txt"
      : >"$APP_ROOT/var/logs/stats.txt"
      grep 'bin/phpunit' "$APP_ROOT/var/logs/parallel.log" | expand | tr -s ' ' |
        while read -r line; do
          L=$(echo "$line" | sed -n 's/.*=functional \(.*\) --color.*/\1/p')
          T=$(echo "$line" | cut -d' ' -f4)
          T=$(echo "($T + 0.5)/1" | bc)
          echo "'$L'==$T; " >>"$APP_ROOT/var/logs/stats.txt"
        done
      # paste -d' ' -s "$APP_ROOT/var/logs/stats.txt" >"$APP_ROOT/var/logs/stats2.txt"
      # mv -f "$APP_ROOT/var/logs/stats2.txt" "$APP_ROOT/var/logs/stats.txt"

    else
      echo "time php \"$APP_ROOT/bin/phpunit\" -c \"$APP_ROOT\" --testsuite=dt-functional ${TEST_RUNNER_OPTIONS} --colors=always --log-junit=\"$APP_ROOT/var/logs/junit/functional.xml\""
      #shellcheck disable=SC2086
      time php "$APP_ROOT/bin/phpunit" -c "$APP_ROOT" --testsuite=dt-functional $TEST_RUNNER_OPTIONS --colors=always --log-junit="$APP_ROOT/var/logs/junit/functional.xml"
      RETVAL=$?
      add_root_node "$APP_ROOT/var/logs/junit/" "*.xml"
      [ $RETVAL -eq 0 ] || fatal "ERROR to run phpunit"
    fi
  fi
  # cleanup_system "$EXECUTOR_NUMBER"
}

install_system() {
  :
  # install_packages || return 1
  # clean_db_pgsql
  # clean_db_mysql
  # init_nginx || return 1
  # install_composer || return 1
}

help() {
  OPTIONS_SPEC="\
$TITLE

$PROGNAME [options]

options:

-i            | --install           run install part
-t            | --test              run tests part
-h            | --help              this help

Example: $PROGNAME --test
"
  echo "$OPTIONS_SPEC"

}

OPTIONS=$(getopt -q -n "$PROGNAME" -o hit -l help,install,test -- "$@")

eval set -- "$OPTIONS"

while :; do
  case "$1" in
  -h | --help)
    help
    exit 0
    ;;
  -i | --install)
    RUN_TEST=no
    ;;
  -t | --test)
    RUN_INSTALL=no
    ;;
  --)
    shift
    break
    ;;
  *)
    fatal "ERROR: unrecognized option: $1"
    ;;
  esac
  shift
done

cleanup_system "$EXECUTOR_NUMBER"
setup_system
counter=0
while [ -e /tmp/installing ]; do #waiting until other process finish installation but no more then 120 sec
  sleep 5
  echo "waiting installation $counter"
  counter=$((counter + 5))
  [ $counter -gt 120 ] && {
    rm -f /tmp/installing
    fatal "Exit because timer was expired for wait installation"
  }
done
if [ ! -e /tmp/installed ]; then #new installation. Run installation
  touch /tmp/installing
  echo "Run installation"
  install_system || {
    rm -f /tmp/installing
    fatal "Installation was finished with error!"
  }
  touch /tmp/installed
  rm -f /tmp/installing
fi

run
