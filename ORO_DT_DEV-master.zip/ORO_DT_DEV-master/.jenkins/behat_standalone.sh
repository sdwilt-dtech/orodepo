#!/bin/bash

# set -o xtrace

PROGNAME="${0##*/}"
DIRNAME=$(dirname "$(realpath "$(dirname "$0")")")
DEBUG="${DEBUG-}"

TITLE='Copyright 2017 by ORO, Inc.'
USER=$(whoami)

PHP_VER="${ORO_PHP-74}"
PG_VER="${ORO_PG-9.6.20}"
MYSQL_VER="${ORO_MYSQL-5.7.32}"
ES_VER="${ORO_ES-7.9.3}"
REDIS_VER="${ORO_REDIS-5.0.10}"
RMQ_VER="${ORO_RMQ-3.8.9}"
MONGO_VER="${ORO_MONGO-4.4.2}"
NODEJS_VER="${ORO_NODEJS-14}"

DB="${ORO_DB-PG}"
SE="${ORO_SE-ES}"
CE="${ORO_CE-DBAL}"
CACHE="${CACHE-}"

# shellcheck disable=SC1091
# shellcheck source=.jenkins/common_functions.sh
. "$DIRNAME/.jenkins/common_functions.sh"

SUITE_SET_MAX_EXECUTION_TIME=${SUITE_SET_MAX_EXECUTION_TIME-450}
BEHAT_SUIT_INSTALL="OroInstallerBundle"
CONSOLE_INSTALL='console_install'
EXECUTOR_NUMBER=${EXECUTOR_NUMBER-0}
[[ $EXECUTOR_NUMBER =~ ^[0-9]{1}$ ]] || fatal 'Not correct EXECUTOR_NUMBER'
EXECUTOR_NUMBER="$((EXECUTOR_NUMBER))"

XSS_TEST=${XSS_TEST-no}
XSS_PAYLOAD_TYPE="${XSS_PAYLOAD_TYPE-script}"
testsuite=${BEHAT_SUIT-$BEHAT_SUIT_INSTALL}
BEHAT_TAGS=${BEHAT_TAGS-'~@skip&&@diversitech'}
if [[ "X$XSS_TEST" == "Xyes" ]]; then
  BEHAT_TAGS=@xss
fi
SKIP_CACHE_PREPARE=no

dbname=${DB_NAME:-oro_crm_$EXECUTOR_NUMBER}

get_list_suits() {
  APP_ROOT="/var/www/ovfs-mnt_$EXECUTOR_NUMBER"
  set_permission "$APP_ROOT" >/dev/null 2>&1

  pushd "$APP_ROOT" >/dev/null 2>&1

  LIST_SUITES="$(
    sudo_scl "php \"$APP_ROOT/bin/behat\" \
      --tags=\"$BEHAT_TAGS\" \
      --available-suites \
      -c \"$APP_ROOT/behat.yml\"" 2>/dev/null
  )"

  STATUS_CODE=$?
  [ $STATUS_CODE -eq 0 ] || fatal "Can't get behat lists suites"

  # shellcheck disable=SC2001
  echo "$LIST_SUITES" | sed "s/[^ ]\+/'&'/g"

  popd >/dev/null 2>&1
  unset_permission "$APP_ROOT" >/dev/null 2>&1

}

dump_list_suites() {
  sudo_scl "php \"$APP_ROOT/bin/behat\" \
    --tags=\"$BEHAT_TAGS\" \
    --available-suites \
    -c \"$APP_ROOT/behat.yml\" \
    -vvv"
}

run_behat() {
  local RETVAL
  get_env_spec
  echo "Run behat $testsuite"
  # ulimit -n 20480
  #Run installer in one process for bootstrap (create DB)
  if [[ ("X$BEHAT_SUIT_INSTALL" == "X$testsuite" || "X$CONSOLE_INSTALL" == "X$testsuite") && "$BUILD_ID" ]]; then
    prepare_instance_bind
  else
    prepare_instance
  fi
  APP_ROOT="/var/www/ovfs-mnt_$EXECUTOR_NUMBER"
  echo "APP_ROOT=$APP_ROOT"
  trap 'collect_logs "$APP_ROOT/var/logs"' EXIT INT TERM

  pushd "$APP_ROOT"
  if [[ "X$BEHAT_SUIT_INSTALL" == "X$testsuite" || "X$CONSOLE_INSTALL" == "X$testsuite" ]]; then
    init_composer "$APP_ROOT"
    if [[ "X$XSS_TEST" == "Xyes" ]]; then
      [[ $TOKEN ]] && composer config -g github-oauth.github.com "$TOKEN"
      echo "Setup requirements for XSS test"
      echo "time COMPOSER=\"dev.json\" composer -v require \"oro/test-security\" --no-interaction --working-dir=\"$APP_ROOT\""
      time COMPOSER="dev.json" composer -v require "oro/test-security" --no-interaction --working-dir="$APP_ROOT" || fatal "Can't install oro/test-security package"
    fi
  fi

  init_nginx || return 1
  make_host "$EXECUTOR_NUMBER" "$APP_ROOT"
  if [[ "X$CONSOLE_INSTALL" != "X$testsuite" ]]; then
    init_chromedriver
  fi
  if [[ "X$SKIP_CACHE_PREPARE" == "Xno" ]]; then
    PHP_VER="$PHP_VER" PG_VER="$PG_VER" MYSQL_VER="$MYSQL_VER" MYSQL_DOCKER_VER="$MYSQL_DOCKER_VER" ES_VER="$ES_VER" REDIS_VER="$REDIS_VER" RMQ_VER="$RMQ_VER" \
      DB="$DB" SE="$SE" CE="$CE" CACHE="$CACHE" \
      APP_DIR="$APP_ROOT" dbname=$dbname \
      time parallel --tagstring {} --no-notice --gnu -k --lb -j 4 --env _ "$DIRNAME/.jenkins/run_services.sh -t" ::: DB SE CE CACHE
    RETVAL=$?
    [ $RETVAL -eq 0 ] || fatal "ERROR to run services"

    # cp "$DIRNAME/behat.yml" "$APP_ROOT/behat.yml"
    local TMP_FILE
    TMP_FILE=$(mktemp)
    cat >"$TMP_FILE" <<__EOF__
imports:
- ./behat.yml.dist

default: &default
  extensions: &default_extensions
    Oro\Bundle\TestFrameworkBundle\Behat\ServiceContainer\OroTestFrameworkExtension:
      artifacts:
        handlers:
          local:
            directory: "%paths.base%/public/uploads/behat"
            base_url: "${BUILD_URL}artifact/${ARTIFACT_DIR}"
            auto_clear: false
    Behat\MinkExtension:
      browser_name: chrome
      sessions:
        second_session:
            oroSelenium2:
                wd_host: 'http://127.0.0.1:${PORT_S1}'
                capabilities:
                    extra_capabilities:
                        chromeOptions:
                            args:
                                - "--no-proxy-server"
                                - "--no-sandbox"
                                - "--dns-prefetch-disable"
                                - "--no-first-run"
                                - "--headless"
                                - "--disable-gpu"
                                - "--window-size=1920,1080"
                                - "--start-maximized"
                                - "--no-pings"
                                - "--disable-renderer-backgrounding"
        first_session:
            oroSelenium2:
                wd_host: 'http://127.0.0.1:${PORT_S1}'
                capabilities:
                    extra_capabilities:
                        chromeOptions:
                            args:
                                - "--no-proxy-server"
                                - "--no-sandbox"
                                - "--dns-prefetch-disable"
                                - "--no-first-run"
                                - "--headless"
                                - "--disable-gpu"
                                - "--window-size=1920,1080"
                                - "--start-maximized"
                                - "--no-pings"
                                - "--disable-renderer-backgrounding"
        system_session:
            oroSelenium2:
                wd_host: 'http://127.0.0.1:${PORT_S1}'
                capabilities:
                    extra_capabilities:
                        chromeOptions:
                            args:
                                - "--no-proxy-server"
                                - "--no-sandbox"
                                - "--dns-prefetch-disable"
                                - "--no-first-run"
                                - "--headless"
                                - "--disable-gpu"
                                - "--window-size=1920,1080"
                                - "--start-maximized"
                                - "--no-pings"
                                - "--disable-renderer-backgrounding"
        320_session:
            oroSelenium2:
                wd_host: 'http://127.0.0.1:${PORT_S1}'
                capabilities:
                    extra_capabilities:
                        chromeOptions:
                            args:
                                - "--no-proxy-server"
                                - "--no-sandbox"
                                - "--dns-prefetch-disable"
                                - "--no-first-run"
                                - "--headless"
                                - "--disable-gpu"
                                - "--window-size=320,640"
                                - "--start-maximized"
                                - "--no-pings"
                                - "--disable-renderer-backgrounding"
        640_session:
            oroSelenium2:
                wd_host: 'http://127.0.0.1:${PORT_S1}'
                capabilities:
                    extra_capabilities:
                        chromeOptions:
                            args:
                                - "--no-proxy-server"
                                - "--no-sandbox"
                                - "--dns-prefetch-disable"
                                - "--no-first-run"
                                - "--headless"
                                - "--disable-gpu"
                                - "--window-size=640,1100"
                                - "--start-maximized"
                                - "--no-pings"
                                - "--disable-renderer-backgrounding"
__EOF__
    # extra_capabilities:
    # chromeOptions:
    # args:
    # - "--no-sandbox"
    # capabilities: { "browserName": "chrome", "browser": "chrome", 'chrome': {'switches':['--no-sandbox']}}
    mv -f "$TMP_FILE" "$APP_ROOT/behat.yml"
    $SUDO_BIN chmod 0644 "$APP_ROOT/behat.yml"

    local PORT=$((8000 + EXECUTOR_NUMBER))
    sed -i "s/^            base_url:.*$/            base_url: 'https:\/\/localhost\.dev\.oroinc\.com:$PORT\/'/g" "$APP_ROOT/behat.yml.dist"

    pushd "$APP_ROOT"
    {
      echo 'oro_form: {settings: { wysiwyg_enabled: { value: false } }}'
      echo 'imports:'
    } >>config/parameters.yml
    find -L vendor/oro/platform/src/Oro/Bundle/MessageQueueBundle -type f -name "parameters.yml" -path "**Tests/Behat**" -exec echo "  - { resource: ./../{} }" \; >>config/parameters.yml
    find -L src -type f -name "parameters.yml" -path "**Tests/Behat**" -exec echo "  - { resource: ./../{} }" \; >>config/parameters.yml
    popd
    echo "Enable requirejs build logger"
    sed -i "s/build_logger: false/build_logger: true/g" "$APP_ROOT/config/config_prod.yml"
    mkdir -p "$APP_ROOT/var/logs/junit"
  fi

  if [[ "X$BEHAT_SUIT_INSTALL" != "X$testsuite" && "X$CONSOLE_INSTALL" != "X$testsuite" ]]; then
    if [[ "X$SKIP_CACHE_PREPARE" == "Xno" ]]; then
      local dbname_org
      dbname_org=$(find "$APP_ROOT" -maxdepth 1 -name '*.sql' -print0 | xargs -0 basename | cut -d'.' -f1)
      load_db "$APP_ROOT/${dbname_org}.sql" "${dbname}"

      # echo "Change application url in DB"
      # psql -q -U postgres -o /dev/null -c "UPDATE oro_config_value SET text_value = 'https://localhost.dev.oroinc.com:${PORT}' WHERE name = 'url'" -d "${dbname}"
      # psql -q -U postgres -o /dev/null -c "UPDATE oro_config_value SET text_value = 'https://localhost.dev.oroinc.com:${PORT}' WHERE name = 'secure_url'" -d "${dbname}"
      # psql -q -U postgres -o /dev/null -c "UPDATE oro_config_value SET text_value = 'https://localhost.dev.oroinc.com:${PORT}' WHERE name = 'application_url'" -d "${dbname}"

      # echo "Change path, url and DB name in cache"
      # find "/var/www/ovfs-tmp_$EXECUTOR_NUMBER" -type f -print0 | xargs -0 sed -i -r "s/ovfs-mnt_[0-9]+/ovfs-mnt_$EXECUTOR_NUMBER/g; s/localhost\\.dev\\.oroinc\\.com:800[0-9]+/localhost\\.dev\\.oroinc\\.com:800$EXECUTOR_NUMBER/g; s/'800[0-9]+'/'800$EXECUTOR_NUMBER'/g; s/${dbname_org}/${dbname}/g"
      reindex_se "$APP_ROOT" "${EXECUTOR_NUMBER}" "" "prod"
    fi
    if [[ "X$testsuite" != "X" ]]; then
      SUITE_SET="--suite=$testsuite"
    fi
    # time php "$APP_ROOT/bin/console" cache:clear --env=prod || fatal "ERROR run $APP_ROOT/bin/console cache:clear"
    df -h
    $SUDO_BIN du -sh /var/www/*
    echo "Run behat with parameters BEHAT_TAGS: '$BEHAT_TAGS'"
    echo "XSS_PAYLOAD_TYPE: '$XSS_PAYLOAD_TYPE'"
    set_permission "$APP_ROOT"
    df -h
    df -h -i
    $SUDO_BIN du -sh /var/www/*
    time sudo_scl "php \"$APP_ROOT/bin/behat\" \
      -vvv \
      --tags=\"$BEHAT_TAGS\" \
      $SUITE_SET --strict -c \"$APP_ROOT/behat.yml\" \
      --colors -f pretty -o std -f junit -o \"$APP_ROOT/var/logs/junit\""
    RETVAL=$?
    unset_permission "$APP_ROOT"
    add_root_node "$APP_ROOT/var/logs/junit/" "*.xml"
    [ $RETVAL -eq 0 ] || fatal "ERROR run behat $APP_ROOT/behat.yml"
    # OPI-132: enable missed RequireJS config check
    echo "Check for missed RequireJS config"
    grep -r 'not found in built JS file' "$APP_ROOT/var/logs"
    RETVAL=$?
    [ $RETVAL -eq 1 ] || fatal "Found not minified js files"
  fi

  if [[ "X$BEHAT_SUIT_INSTALL" == "X$testsuite"* || "X$CONSOLE_INSTALL" == "X$testsuite" ]]; then

    set_permission "$APP_ROOT"
    enable_permission_installer "$APP_ROOT"
    if [ -n "$ORO_INSTALLED" ]; then
      echo "Restore DB ${ORO_INSTALLED}..."
      case ${DB} in
      MYSQL)
        fatal "MYSQL doesn't support"
        ;;
      PG)
        load_db "/var/www/ovfs-mnt_${EXECUTOR_NUMBER}/environment/behat/base.sql.gz" "${dbname}"
        ;;
      esac
      INSTALLED_DATE=$(date --rfc-3339=seconds)
      sed -i "s/installed:.*/installed: '${INSTALLED_DATE}'/g" "$APP_ROOT/config/parameters.yml"

      echo "Exist ${ORO_INSTALLED}..."
      echo "sudo_scl time php \"$APP_ROOT/bin/console\" oro:platform:update --env=prod --force --no-interaction --timeout=600 -vvv"
      sudo_scl "time php \"$APP_ROOT/bin/console\" oro:platform:update --env=prod --force --no-interaction --timeout=600 -vvv" || fatal "ERROR to run console oro:platform:update"

      echo "sudo_scl time php \"$APP_ROOT/bin/console\" bn:behat:prepare --env=prod --application-url \"https://localhost.dev.oroinc.com:${PORT}\""
      sudo_scl "time php \"$APP_ROOT/bin/console\" bn:behat:prepare --env=prod --application-url \"https://localhost.dev.oroinc.com:${PORT}\"" || fatal "ERROR to run console bn:behat:prepare"
    else
      if [[ "X$BEHAT_SUIT_INSTALL" == "X$testsuite" ]]; then
        echo "time sudo_scl php \"$APP_ROOT/bin/behat\" -s \"$testsuite\" -c \"$APP_ROOT/behat.yml\" \
        --colors -f pretty -o std -f junit -o \"$APP_ROOT/var/logs/junit\""
        time sudo_scl "php \"$APP_ROOT/bin/behat\" -s \"$testsuite\" -c \"$APP_ROOT/behat.yml\" \
        --colors -f pretty -o std -f junit -o \"$APP_ROOT/var/logs/junit\""
        RETVAL=$?
        add_root_node "$APP_ROOT/var/logs/junit/" "*.xml"
        [ $RETVAL -eq 0 ] || fatal "ERROR run behat $APP_ROOT/behat.yml"
        #find "$APP_ROOT"/config -type f -name 'parameters.yml' -print0 | xargs -0 sed -i "/mailer_transport/s/:[[:space:]].*$/: null/g"
        #time php "$APP_ROOT/bin/console" cache:clear --env=prod || fatal "ERROR run $APP_ROOT/bin/console cache:clear"
      elif [[ "X$CONSOLE_INSTALL" == "X$testsuite" ]]; then
        echo "time sudo_scl php \"$APP_ROOT/bin/console\" oro:install --env=prod --user-name=admin --user-email=admin@example.com --user-firstname=John --user-lastname=Doe --user-password=admin --sample-data=n --organization-name=ORO --no-interaction --application-url=\"https://localhost.dev.oroinc.com:${PORT}\" --timeout=600"
        time sudo_scl "php \"$APP_ROOT/bin/console\" oro:install --env=prod --user-name=admin --user-email=admin@example.com --user-firstname=John --user-lastname=Doe --user-password=admin --sample-data=n --organization-name=ORO --no-interaction --application-url=\"https://localhost.dev.oroinc.com:${PORT}\" --timeout=600" || fatal "ERROR to run console installation"
        sudo rm -rf "/var/www/ovfs-mnt_$EXECUTOR_NUMBER/var/cache/prod/oro_data/oro_behat_mesage_queue_mock_lifecycle_message" || :
      fi
    fi
    #statements

    echo "LIST_SUITES:"
    dump_list_suites

    dump_db "$APP_ROOT/${dbname}.sql" "$dbname"
    disable_permission_installer "$APP_ROOT"
    unset_permission "$APP_ROOT"

  fi

  popd

}

install_system() {
  :
  # install_packages || return 1
}

usage() {
  [ -z "$*" ] || echo "$*"
  echo "Try \`$PROGNAME --help' for more information." >&2
  exit 1
}

help() {
  OPTIONS_SPEC="\
$TITLE

$PROGNAME [options]

options:

-t[testname]  | --test[=testname]   Run specific test. Default is $BEHAT_SUIT_INSTALL (web installation)
-i            | --install           Run console installation
-l            | --list              Show available list of test
-s            | --skip              Skip cache preparation
-h            | --help              this help

Example: $PROGNAME --list
"
  echo "$OPTIONS_SPEC"

}

OPTIONS=$(getopt -q -n "$PROGNAME" -o t::ilsh -l test::,install,list,skip,help -- "$@")

eval set -- "$OPTIONS"

while :; do
  case "$1" in
  -t | --test)
    shift
    [[ "X$1" != "X" ]] && testsuite="$1"
    ;;
  -i | --install)
    testsuite="$CONSOLE_INSTALL"
    ;;
  -l | --list)
    get_list_suits
    exit 0
    ;;
  -s | --skip)
    SKIP_CACHE_PREPARE=yes
    ;;
  -h | --help)
    help
    exit 0
    ;;
  --)
    shift
    break
    ;;
  *)
    fatal "ERROR: unrecognized option: $1"
    ;;
  esac
  shift
done

cleanup_system
setup_system
sleep "$EXECUTOR_NUMBER" #sleep for worker 0 was started first
counter=0
while [ -e /tmp/installing ]; do #waiting until other process finish installation but no more then 120 sec
  sleep 5
  echo "waiting installation $counter"
  counter=$((counter + 5))
  [ $counter -gt 120 ] && {
    rm -f /tmp/installing
    fatal "Exit because timer was expired for wait installation"
  }
done
if [ ! -e /tmp/installed ]; then #new installation. Run installation
  touch /tmp/installing
  echo "Run installation"
  install_system || {
    rm -f /tmp/installing
    fatal "Installation was finished with error!"
  }
  touch /tmp/installed
  rm -f /tmp/installing
fi
run_behat
