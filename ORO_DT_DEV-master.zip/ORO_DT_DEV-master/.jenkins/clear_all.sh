#!/bin/bash

PROGNAME="${0##*/}"
DIRNAME=$(realpath "$(dirname "$0")")
DEBUG="${DEBUG-}"

# shellcheck disable=SC1091
# shellcheck source=.jenkins/common_functions.sh
. "$DIRNAME/common_functions.sh"

cleanup_system
sudo rm -rf /var/www/ovfs*
