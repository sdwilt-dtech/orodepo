#!/bin/bash

PROGNAME="${0##*/}"
DIRNAME=$(realpath "$(dirname "$0")")
DEBUG="${DEBUG-}"

TITLE='Copyright 2018 by ORO, Inc.'
USER=$(whoami)

EXECUTOR_NUMBER=${EXECUTOR_NUMBER-0}
[[ $EXECUTOR_NUMBER =~ ^[0-9]{1}$ ]] || fatal 'Not correct EXECUTOR_NUMBER'

PHP_VER="${ORO_PHP-74}"
PG_VER="${ORO_PG-9.6.20}"
MYSQL_VER="${ORO_MYSQL-5.7.32}"
ES_VER="${ORO_ES-7.9.3}"
REDIS_VER="${ORO_REDIS-5.0.10}"
RMQ_VER="${ORO_RMQ-3.8.9}"
MONGO_VER="${ORO_MONGO-4.4.2}"
NODEJS_VER="${ORO_NODEJS-14}"

# shellcheck disable=SC2034
DB="${ORO_DB-PG}"
# shellcheck disable=SC2034
SE="${ORO_SE-ORM}"
# shellcheck disable=SC2034
CE="${ORO_CE-DBAL}"
# shellcheck disable=SC2034
CACHE="${ORO_CACHE-}"
HTTP_HOST="${HTTP_HOST-http://localhost/}"
DIR_DIFF="${DIR_DIFF-$WORKSPACE/stats}"
FILE_DIFF="${FILE_DIFF-diff.log}"
RED='\033[1;31m' # Red color
NC='\033[0m'     # No Color

# shellcheck disable=SC1091
# shellcheck source=.jenkins/common_functions.sh
. "$DIRNAME/common_functions.sh"

run() {
  local RETVAL=0
  get_env_spec
  echo "Run $ORO_TEST_SUITE"
  # ulimit -n 20480
  prepare_instance "$(realpath "$DIRNAME/..")" "${EXECUTOR_NUMBER}"
  APP_ROOT="/var/www/ovfs-mnt_${EXECUTOR_NUMBER}"
  echo "APP_ROOT=$APP_ROOT"

  init_php || return 1
  init_composer "$APP_ROOT"

  pushd "$APP_ROOT"
  echo "find -L \"$APP_ROOT/src\" -type f -iname '*.php' | uniq | sort > \"$APP_ROOT/var/logs/diff_php.log\""
  find -L "$APP_ROOT/src" -type f -iname '*.php' | uniq | sort >"$APP_ROOT/var/logs/diff_php.log"

  echo "php \"$APP_ROOT/bin/php-cs-fixer\" fix {} --verbose --dry-run --config=\"$APP_ROOT/vendor/oro/platform/build/.php_cs\" --path-mode=intersection"
  # shellcheck disable=SC2016,SC2097,SC2098
  APP_ROOT=$APP_ROOT \
    time parallel --no-notice --gnu -k --lb --env _ --xargs --joblog "$APP_ROOT/var/logs/parallel.csfixer.log" -a "$APP_ROOT/var/logs/diff_php.log" \
    'php "$APP_ROOT/bin/php-cs-fixer" fix {} --verbose --dry-run --config="$APP_ROOT/vendor/oro/platform/build/.php_cs" --path-mode=intersection' || {
    RETVAL=+1
    echo -e "${RED}ERROR to run php-cs-fixer${NC}"
  }

  echo "php \"$APP_ROOT/bin/phpmd\" \${files// /,} text \"$APP_ROOT/vendor/oro/commerce/build_config/phpmd.xml\" --suffixes php"
  # shellcheck disable=SC2016,SC2097,SC2098
  APPLICATION=${APPLICATION} APP_ROOT=$APP_ROOT \
    time parallel --no-notice --gnu -k --lb --env _ --xargs --joblog "$APP_ROOT/var/logs/parallel.md2.log" -a "$APP_ROOT/var/logs/diff_php.log" \
    'files="{}"; php "$APP_ROOT/bin/phpmd" ${files// /,} text "$APP_ROOT/vendor/oro/commerce/build_config/phpmd.xml" --suffixes php' || { RETVAL=+1;  echo -e "${RED}ERROR to run phpmd${NC}"; }

  echo "php \"$APP_ROOT/bin/phpcs\" {} -p --encoding=utf-8 --extensions=php --standard=PSR2"
  # shellcheck disable=SC2016,SC2097,SC2098
  APPLICATION=${APPLICATION} APP_ROOT=$APP_ROOT \
    time parallel --no-notice --gnu -k --lb --env _ --xargs --joblog "$APP_ROOT/var/logs/parallel.cs.log" -a "$APP_ROOT/var/logs/diff_php.log" \
    'php "$APP_ROOT/bin/phpcs" {} -p --encoding=utf-8 --extensions=php --standard=PSR2' || {
    RETVAL=+1
    echo -e "${RED}ERROR to run phpcs${NC}"
  }

  [[ $RETVAL -eq 0 ]] || fatal "ERROR in tests. Look to output"

  # cleanup_system "$EXECUTOR_NUMBER"
  popd
}

install_system() {
  :
  # install_packages || return 1
  # init_nginx || return 1
  # install_composer || return 1
}

help() {
  OPTIONS_SPEC="\
$TITLE

$PROGNAME [options]

options:

-h            | --help              this help

Example: $PROGNAME --list
"
  echo "$OPTIONS_SPEC"

}

OPTIONS=$(getopt -q -n "$PROGNAME" -o h -l help -- "$@")

eval set -- "$OPTIONS"

while :; do
  case "$1" in
  -h | --help)
    help
    exit 0
    ;;
  --)
    shift
    break
    ;;
  *)
    fatal "ERROR: unrecognized option: $1"
    ;;
  esac
  shift
done

cleanup_system "$EXECUTOR_NUMBER" "ALL"
setup_system
counter=0
while [ -e /tmp/installing ]; do #waiting until other process finish installation but no more then 120 sec
  sleep 5
  echo "waiting installation $counter"
  counter=$((counter + 5))
  [ $counter -gt 120 ] && {
    rm -f /tmp/installing
    fatal "Exit because timer was expired for wait installation"
  }
done
if [ ! -e /tmp/installed ]; then #new installation. Run installation
  touch /tmp/installing
  echo "Run installation"
  install_system || {
    rm -f /tmp/installing
    fatal "Installation was finished with error!"
  }
  touch /tmp/installed
  rm -f /tmp/installing
fi

run
