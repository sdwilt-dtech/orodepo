#!/bin/bash

PROGNAME="${0##*/}"
DIRNAME=$(realpath "$(dirname "$0")")
DEBUG="${DEBUG-}"

TITLE='Copyright 2017 by ORO, Inc.'
USER=$(whoami)

EXECUTOR_NUMBER=${EXECUTOR_NUMBER-0}
[[ $EXECUTOR_NUMBER =~ ^[0-9]{1}$ ]] || fatal 'Not correct EXECUTOR_NUMBER'
PARALLEL_PROCESSES=${PARALLEL_PROCESSES-4}

ORO_APP_TAG="${ORO_APP_TAG-'master'}"
PHP_VER="${ORO_PHP-74}"
PG_VER="${ORO_PG-9.6.20}"
MYSQL_VER="${ORO_MYSQL-5.7.32}"
ES_VER="${ORO_ES-7.9.3}"
REDIS_VER="${ORO_REDIS-5.0.10}"
RMQ_VER="${ORO_RMQ-3.8.9}"
MONGO_VER="${ORO_MONGO-4.4.2}"
NODEJS_VER="${ORO_NODEJS-14}"

# shellcheck disable=SC2034
DB="${ORO_DB-PG}"
# shellcheck disable=SC2034
SE="${ORO_SE-ES}"
# shellcheck disable=SC2034
CE="${ORO_CE-DBAL}"
# shellcheck disable=SC2034
CACHE="${ORO_CACHE-}"
HTTP_HOST="${HTTP_HOST-http://localhost/}"

# shellcheck disable=SC1091
# shellcheck source=.jenkins/common_functions.sh
. "$DIRNAME/common_functions.sh"

run() {
  local RETVAL
  get_env_spec
  echo "Run $ORO_TEST_SUITE"
  # ulimit -n 20480
  prepare_instance "$(realpath "$DIRNAME/..")" "${EXECUTOR_NUMBER}"
  APP_ROOT="/var/www/ovfs-mnt_${EXECUTOR_NUMBER}"
  echo "APP_ROOT=$APP_ROOT"
  trap 'collect_logs "$APP_ROOT/var/logs"' EXIT INT TERM

  init_composer "$APP_ROOT"
  cp -f "$APP_ROOT/config/parameters_test.yml.dist" "$APP_ROOT/config/parameters.yml"
  init_php || return 1

  cp "$APP_ROOT/phpunit.xml.dist" "$APP_ROOT/phpunit.xml"
  
  set_permission "$APP_ROOT"
  echo "sudo_scl time php \"$APP_ROOT/bin/phpunit\" -c \"$APP_ROOT\" --testsuite=dt-unit --colors=always"
  sudo_scl "time php \"$APP_ROOT/bin/phpunit\" -c \"$APP_ROOT\" --testsuite=dt-unit --colors=always --log-junit=\"$APP_ROOT/var/logs/junit/unit.xml\""
  RETVAL=$?
  add_root_node "$APP_ROOT/var/logs/junit/" "unit.xml"
  [ $RETVAL -eq 0 ] || fatal "ERROR to run phpunit"
  unset_permission "$APP_ROOT"
  # cleanup_system "$EXECUTOR_NUMBER"
}

install_system() {
  :
  # install_packages || return 1
  # init_nginx || return 1
  # install_composer || return 1
}

help() {
  OPTIONS_SPEC="\
$TITLE

$PROGNAME [options]

options:

-h            | --help              this help

Example: $PROGNAME --list
"
  echo "$OPTIONS_SPEC"

}

OPTIONS=$(getopt -q -n "$PROGNAME" -o h -l help -- "$@")

eval set -- "$OPTIONS"

while :; do
  case "$1" in
  -h | --help)
    help
    exit 0
    ;;
  --)
    shift
    break
    ;;
  *)
    fatal "ERROR: unrecognized option: $1"
    ;;
  esac
  shift
done

cleanup_system "$EXECUTOR_NUMBER" "ALL"
setup_system
counter=0
while [ -e /tmp/installing ]; do #waiting until other process finish installation but no more then 120 sec
  sleep 5
  echo "waiting installation $counter"
  counter=$((counter + 5))
  [ $counter -gt 120 ] && {
    rm -f /tmp/installing
    fatal "Exit because timer was expired for wait installation"
  }
done
if [ ! -e /tmp/installed ]; then #new installation. Run installation
  touch /tmp/installing
  echo "Run installation"
  install_system || {
    rm -f /tmp/installing
    fatal "Installation was finished with error!"
  }
  touch /tmp/installed
  rm -f /tmp/installing
fi

run
