#!/bin/bash

PROGNAME="${0##*/}"
DIRNAME=$(realpath "$(dirname "$0")")
DEBUG="${DEBUG-}"

TITLE='Copyright 2017 by ORO, Inc.'
USER=$(whoami)

EXECUTOR_NUMBER=${EXECUTOR_NUMBER-0}
[[ $EXECUTOR_NUMBER =~ ^[0-9]{1}$ ]] || fatal 'Not correct EXECUTOR_NUMBER'
PARALLEL_PROCESSES=${PARALLEL_PROCESSES-4}

PHP_VER="${ORO_PHP-74}"
PG_VER="${ORO_PG-9.6.20}"
MYSQL_VER="${ORO_MYSQL-5.7.32}"
ES_VER="${ORO_ES-7.9.3}"
REDIS_VER="${ORO_REDIS-5.0.10}"
RMQ_VER="${ORO_RMQ-3.8.9}"
MONGO_VER="${ORO_MONGO-4.4.2}"
NODEJS_VER="${ORO_NODEJS-14}"

# shellcheck disable=SC2034
DB="${ORO_DB-PG}"
# shellcheck disable=SC2034
SE="${ORO_SE-ES}"
# shellcheck disable=SC2034
CE="${ORO_CE-DBAL}"
# shellcheck disable=SC2034
CACHE="${ORO_CACHE-}"

# shellcheck disable=SC1091
# shellcheck source=.jenkins/common_functions.sh
. "$DIRNAME/common_functions.sh"

dbname=${DB_NAME:-oro_crm_$EXECUTOR_NUMBER}

init_composer_no-dev() {
  install_composer
  [[ $TOKEN ]] && COMPOSER_HOME=$SET_COMPOSER_HOME composer config -g github-oauth.github.com "$TOKEN"
  [[ $TOKEN_GITLAB ]] && COMPOSER_HOME=$SET_COMPOSER_HOME composer config -g gitlab-oauth.git.oroinc.com "$TOKEN_GITLAB"
  local COMPOSER=${2-composer.json}
  [[ $3 ]] && export COMPOSER_ROOT_VERSION="${3}"
  #install parallel plugin
  echo "time COMPOSER_HOME=$SET_COMPOSER_HOME composer global require hirak/prestissimo symfony/flex"
  time COMPOSER_HOME=$SET_COMPOSER_HOME composer global require hirak/prestissimo symfony/flex || fatal "Can't install hirak/prestissimo symfony/flex"

  echo "time COMPOSER_HOME=$SET_COMPOSER_HOME COMPOSER=$COMPOSER COMPOSER_MIRROR_PATH_REPOS=1 composer install --no-dev --prefer-dist --no-suggest --optimize-autoloader --no-interaction --working-dir=\"$1\""
  time COMPOSER_HOME=$SET_COMPOSER_HOME COMPOSER=$COMPOSER COMPOSER_MIRROR_PATH_REPOS=1 composer install --no-dev --prefer-dist --no-suggest --optimize-autoloader --no-interaction --working-dir="$1" || fatal "Can't install $1/$COMPOSER"
}

run() {
  local RETVAL
  local PORT=$((8000 + EXECUTOR_NUMBER))
  get_env_spec
  echo "Run $ORO_TEST_SUITE"
  # ulimit -n 20480
  prepare_instance "$(realpath "$DIRNAME/..")" "${EXECUTOR_NUMBER}"
  APP_ROOT="/var/www/ovfs-mnt_${EXECUTOR_NUMBER}"
  echo "APP_ROOT=$APP_ROOT"
  trap 'collect_logs "$APP_ROOT/var/logs"' EXIT INT TERM

  init_composer_no-dev "$APP_ROOT"

  PHP_VER="$PHP_VER" PG_VER="$PG_VER" MYSQL_VER="$MYSQL_VER" MYSQL_DOCKER_VER="$MYSQL_DOCKER_VER" ES_VER="$ES_VER" REDIS_VER="$REDIS_VER" RMQ_VER="$RMQ_VER" \
    DB="$DB" SE="$SE" CE="$CE" CACHE="$CACHE" \
    APP_DIR="$APP_ROOT" dbname=$dbname \
    time parallel --tagstring {} --no-notice --gnu -k --lb -j 4 --env _ "$DIRNAME/run_services.sh -t" ::: DB SE CE CACHE
  RETVAL=$?
  [ $RETVAL -eq 0 ] || fatal "ERROR to run services"

  set_permission "$APP_ROOT"
  enable_permission_installer "$APP_ROOT"

  echo "time sudo_scl php \"$APP_ROOT/bin/console\" oro:install --env=prod --user-name=admin --user-email=admin@example.com --user-firstname=John --user-lastname=Doe --user-password=admin --sample-data=n --organization-name=ORO --no-interaction --application-url=\"https://localhost.dev.oroinc.com:${PORT}\" --timeout=600"
  time sudo_scl "php \"$APP_ROOT/bin/console\" oro:install --env=prod --user-name=admin --user-email=admin@example.com --user-firstname=John --user-lastname=Doe --user-password=admin --sample-data=n --organization-name=ORO --no-interaction --application-url=\"https://localhost.dev.oroinc.com:${PORT}\" --timeout=600" || fatal "ERROR to run console installation"

  disable_permission_installer "$APP_ROOT"
  unset_permission "$APP_ROOT"

}

install_system() {
  :
  # install_packages || return 1
  # init_nginx || return 1
  # install_composer || return 1
}

help() {
  OPTIONS_SPEC="\
$TITLE

$PROGNAME [options]

options:

-h            | --help              this help

Example: $PROGNAME --list
"
  echo "$OPTIONS_SPEC"

}

OPTIONS=$(getopt -q -n "$PROGNAME" -o h -l help -- "$@")

eval set -- "$OPTIONS"

while :; do
  case "$1" in
  -h | --help)
    help
    exit 0
    ;;
  --)
    shift
    break
    ;;
  *)
    fatal "ERROR: unrecognized option: $1"
    ;;
  esac
  shift
done

cleanup_system "$EXECUTOR_NUMBER" "ALL"
setup_system
counter=0
while [ -e /tmp/installing ]; do #waiting until other process finish installation but no more then 120 sec
  sleep 5
  echo "waiting installation $counter"
  counter=$((counter + 5))
  [ $counter -gt 120 ] && {
    rm -f /tmp/installing
    fatal "Exit because timer was expired for wait installation"
  }
done
if [ ! -e /tmp/installed ]; then #new installation. Run installation
  touch /tmp/installing
  echo "Run installation"
  install_system || {
    rm -f /tmp/installing
    fatal "Installation was finished with error!"
  }
  touch /tmp/installed
  rm -f /tmp/installing
fi

run
