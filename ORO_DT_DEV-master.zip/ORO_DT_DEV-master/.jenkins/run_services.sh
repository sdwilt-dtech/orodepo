#!/bin/bash

# set -o xtrace

PROGNAME="${0##*/}"
DIRNAME=$(dirname "$(realpath "$(dirname "$0")")")
DEBUG="${DEBUG-}"

TITLE='Copyright 2017 by ORO, Inc.'

# shellcheck disable=SC1091
# shellcheck source=.jenkins/common_functions.sh
. "$DIRNAME/.jenkins/common_functions.sh"

init_db() {
  echo "Init DB $DB"
  [ "$#" -eq 1 ] || fatal "No path to application in function init_db"
  if [[ "X$DB" == 'XPG' ]]; then
    init_db_pgsql "$1"
  elif [[ "X$DB" == 'XMYSQL' ]]; then
    init_db_mysql "$1"
  else
    fatal "Can't recognize enviroment DB=$DB"
  fi
}

init_se() {
  echo "Init search engine $SE"
  [ "$#" -eq 1 ] || fatal "No path to application in function init_se"
  if [[ "X$SE" == 'XORM' ]]; then
    init_se_orm "$1"
  elif [[ "X$SE" == 'XES' ]]; then
    init_se_elastic "$1"
  else
    fatal "Can't recognize enviroment SE=$SE"
  fi
}

init_ce() {
  echo "Init consumer engine $CE"
  [ "$#" -eq 1 ] || fatal "No path to application in function init_ce"
  if [[ "X$CE" == 'XDBAL' ]]; then
    init_ce_dbal "$1"
  elif [[ "X$CE" == 'XRMQ' ]]; then
    init_ce_rmq "$1" "$dbname"
  else
    fatal "Can't recognize enviroment CE=$CE"
  fi

}

init_cache() {
  echo "Init cache $CACHE"
  [ "$#" -eq 1 ] || fatal "No path to application in function init_cache"
  if [[ "X$CACHE" == 'XREDIS' ]]; then
    init_cache_redis "$1"
  elif [[ "X$CACHE" == 'XREDIS_CLUSTER' ]]; then
    init_cache_redis_cluster "$1"
  fi
}

init_storage() {
  echo "Init storage $STORAGE"
  [ "$#" -eq 1 ] || fatal "No path to application in function init_storage"
  if [[ "X$STORAGE" == 'XMONGO_CLUSTER' ]]; then
    init_db_mongo_cluster "$1"
  fi
}

init_composer_parallel() {
  init_composer "$1" "$COMPOSER"
  if [[ "X$XSS_TEST" == "Xyes" ]]; then
    [[ $TOKEN ]] && composer config -g github-oauth.github.com "$TOKEN"
    echo "Setup requirements for XSS test"
    echo "time COMPOSER=\"$COMPOSER\" composer -v require \"oro/test-security\" --no-interaction --working-dir=\"$1\""
    time COMPOSER="$COMPOSER" composer -v require "oro/test-security" --no-interaction --working-dir="$1" || fatal "Cant install oro/test-security package"
  fi
}

help() {
  OPTIONS_SPEC="\
$TITLE

$PROGNAME [options]

options:

-t[type]  | --type[=type]           Prepare specific service type
-h            | --help              this help

Example: $PROGNAME --type DB
"
  echo "$OPTIONS_SPEC"

}

[[ $APP_DIR ]] || fatal "Not set APP_DIR variable"

OPTIONS=$(getopt -q -n "$PROGNAME" -o t:h -l type:,help -- "$@")

eval set -- "$OPTIONS"

while :; do
  case "$1" in
  -t | --type)
    shift
    case "$1" in
    DB)
      init_db "$APP_DIR" || return 1
      ;;
    SE)
      init_se "$APP_DIR" || return 1
      ;;
    CE)
      init_ce "$APP_DIR" || return 1
      ;;
    CACHE)
      init_cache "$APP_DIR" || return 1
      ;;
    STORAGE)
      init_storage "$APP_DIR" || return 1
      ;;
    COMPOSER)
      init_composer_parallel "$APP_DIR" || return 1
      ;;
    esac
    ;;
  -h | --help)
    help
    exit 0
    ;;
  --)
    shift
    break
    ;;
  *)
    fatal "ERROR: unrecognized option: $1"
    ;;
  esac
  shift
done
