Diversitech Dev Patches
=======================

Managed by https://github.com/cweagans/composer-patches#using-an-external-patch-file

Naming Requirements
-------------------

The patch file must be stored in a folder by package name. Name of the patch should contain a reference to JIRA issue
and follow the next format:

    %DIV_ISSUE%[_%ORO_ISSUE%].patch

where:
* %DIV_ISSUE% - a reference to issue in the DIV project, for example, DIV-476.
* %ORO_ISSUE% - a reference to issue in some Oro project, for example, BB-1899.

In case if the patch is added for dock-blocks to support fields of extended entities, the patch name could contain just
the name of the original file.


Examples of patches in file system:

    oro/
        commerce/
            DIV-476_BB-18994.patch   # contains "oro/commerce" package changes only
            ExtendCheckout.patch       # contains additional dock-blocks in
        platform-enterprise/
            DIV-1141_BAP-19294.patch # contains "oro/platform-enterprise" package changes only

Update patches.json

```
{
  "patches": {
    "oro/commerce": {
      "DIV-476_BB-18994.patch": "patches/oro/commerce/DIV-476_BB-18994.patch"
      "ExtendCheckout.patch": "patches/oro/commerce/ExtendCheckout.patch"
    },
    "oro/platform-enterprise": {
      "DIV-1141_BAP-19294.patch": "patches/oro/platform-enterprise/DIV-1141_BAP-19294.patch"
    }
  }
}
```
